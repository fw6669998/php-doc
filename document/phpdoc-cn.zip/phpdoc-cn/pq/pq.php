<?php
/**
 * This is a modern binding to the mature [libpq](http://www.postgresql.org/docs/current/static/libpq.html), the official PostgreSQL C-client library.
 *
 * ### Highlights:
 *
 * * Nearly 100% support for [asynchronous usage](pq/Connection/: Asynchronous Usage).
 * * Extended [type support by pg_type](pq/Types/: Overview).
 * * Fetching simple [multi-dimensional array maps](pq/Result/map).
 * * Working [Gateway implementation](https://bitbucket.org/m6w6/pq-gateway).
 */
namespace pq;
use pq;
/**
 * Fast import/export using COPY.
 */
class COPY  {
	/**
	 * Start a COPY operation from STDIN to the PostgreSQL server.
	 */
	const FROM_STDIN = 0;
	/**
	 * Start a COPY operation from the server to STDOUT.
	 */
	const TO_STDOUT = 1;
	/**
	 * The connection to the PostgreSQL server.
	 *
	 * @public
	 * @readonly
	 * @var \pq\Connection
	 */
	public $connection;
	/**
	 * The expression of the COPY statement used to start the operation.
	 *
	 * @public
	 * @readonly
	 * @var string
	 */
	public $expression;
	/**
	 * The drection of the COPY operation (pq\COPY::FROM_STDIN or pq\COPY::TO_STDOUT).
	 *
	 * @public
	 * @readonly
	 * @var int
	 */
	public $direction;
	/**
	 * Any additional options used to start the COPY operation.
	 *
	 * @public
	 * @readonly
	 * @var string
	 */
	public $options;
	/**
	 * Start a COPY operation.
	 *
	 * @param \pq\Connection $conn The connection to use for the COPY operation.
	 * @param string $expression The expression generating the data to copy.
	 * @param int $direction Data direction (pq\COPY::FROM_STDIN or pq\COPY::TO_STDOUT).
	 * @param string $options Any COPY options (see the [official PostgreSQL documentation](http://www.postgresql.org/docs/current/static/sql-copy.html) for details.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 */
	function __construct(\pq\Connection $conn, string $expression, int $direction, string $options = NULL) {}
	/**
	 * End the COPY operation to the server during pq\Result::COPY_IN state.
	 *
	 * @param string $error If set, the COPY operation will abort with provided message.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 */
	function end(string $error = NULL) {}
	/**
	 * Receive data from the server during pq\Result::COPY_OUT state.
	 *
	 * @param string $data Data read from the server.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 * @return bool success.
	 */
	function get(string &$data) {}
	/**
	 * Send data to the server during pq\Result::COPY_IN state.
	 *
	 * @param string $data Data to send to the server.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 */
	function put(string $data) {}
}
/**
 * Request cancellation of an asynchronous query.
 */
class Cancel  {
	/**
	 * The connection to cancel the query on.
	 *
	 * @public
	 * @readonly
	 * @var \pq\Connection
	 */
	public $connection;
	/**
	 * Create a new cancellation request for an [asynchronous](pq/Connection/: Asynchronous Usage) query.
	 *
	 * @param \pq\Connection $conn The connection to request cancellation on.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 */
	function __construct(\pq\Connection $conn) {}
	/**
	 * Perform the cancellation request.
	 *
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 */
	function cancel() {}
}
/**
 * The connection to the PostgreSQL server.
 *
 * See the [General Usage](pq/Connection/: General Usage) page for an introduction on how to use this class.
 */
class Connection  {
	/**
	 * (Re-)open a persistent connection.
	 */
	const PERSISTENT = 2;
	/**
	 * If the connection is not already open, perform the connection attempt [asynchronously](pq/Connection/: Asynchronous Usage).
	 */
	const ASYNC = 1;
	/**
	 * Everything well; if a connection has been newly and synchronously created, the connection will always have this status right after creation.
	 */
	const OK = 0;
	/**
	 * Broken connection; consider pq\Connection::reset() or recreation.
	 */
	const BAD = 1;
	/**
	 * Waiting for connection to be made.
	 */
	const STARTED = 2;
	/**
	 * Connection okay; waiting to send.
	 */
	const MADE = 3;
	/**
	 * Waiting for a response from the server.
	 */
	const AWAITING_RESPONSE = 4;
	/**
	 * Received authentication; waiting for backend start-up to finish.
	 */
	const AUTH_OK = 5;
	/**
	 * Negotiating SSL encryption.
	 */
	const SSL_STARTUP = 7;
	/**
	 * Negotiating environment-driven parameter settings.
	 */
	const SETENV = 6;
	/**
	 * No active transaction.
	 */
	const TRANS_IDLE = 0;
	/**
	 * A transaction command is in progress.
	 */
	const TRANS_ACTIVE = 1;
	/**
	 * Idling in a valid transaction block.
	 */
	const TRANS_INTRANS = 2;
	/**
	 * Idling in a failed transaction block.
	 */
	const TRANS_INERROR = 3;
	/**
	 * Bad connection.
	 */
	const TRANS_UNKNOWN = 4;
	/**
	 * The connection procedure has failed.
	 */
	const POLLING_FAILED = 0;
	/**
	 * Select for read-readiness.
	 */
	const POLLING_READING = 1;
	/**
	 * Select for write-readiness.
	 */
	const POLLING_WRITING = 2;
	/**
	 * The connection has been successfully made.
	 */
	const POLLING_OK = 3;
	/**
	 * Register the event handler for notices.
	 */
	const EVENT_NOTICE = 'notice';
	/**
	 * Register the event handler for any created results.
	 */
	const EVENT_RESULT = 'result';
	/**
	 * Register the event handler for connection resets.
	 */
	const EVENT_RESET = 'reset';
	/**
	 * A [connection status constant](pq/Connection#Connection.Status:) value.
	 *
	 * @public
	 * @readonly
	 * @var int
	 */
	public $status;
	/**
	 * A [transaction status constant](pq/Connection#Transaction.Status:) value.
	 *
	 * @public
	 * @readonly
	 * @var int
	 */
	public $transactionStatus;
	/**
	 * The server socket resource.
	 *
	 * @public
	 * @readonly
	 * @var
	 */
	public $socket;
	/**
	 * Whether the connection is busy with [asynchronous operations](pq/Connection/: Asynchronous Usage).
	 *
	 * @public
	 * @readonly
	 * @var bool
	 */
	public $busy;
	/**
	 * Any error message on failure.
	 *
	 * @public
	 * @readonly
	 * @var string
	 */
	public $errorMessage;
	/**
	 * List of registered event handlers.
	 *
	 * @public
	 * @readonly
	 * @var array
	 */
	public $eventHandlers;
	/**
	 * Connection character set.
	 *
	 * @public
	 * @var string
	 */
	public $encoding = NULL;
	/**
	 * Whether to fetch [asynchronous](pq/Connection/: Asynchronous Usage) results in unbuffered mode, i.e. each row generates a distinct pq\Result.
	 *
	 * @public
	 * @var bool
	 */
	public $unbuffered = FALSE;
	/**
	 * Whether to set the underlying socket nonblocking, useful for asynchronous handling of writes. See also pq\Connection::flush().
	 *
	 * ### Connection Information:
	 *
	 * @public
	 * @var bool
	 */
	public $nonblocking = FALSE;
	/**
	 * The database name of the connection.
	 *
	 * @public
	 * @readonly
	 * @var string
	 */
	public $db;
	/**
	 * The user name of the connection.
	 *
	 * @public
	 * @readonly
	 * @var string
	 */
	public $user;
	/**
	 * The password of the connection.
	 *
	 * @public
	 * @readonly
	 * @var string
	 */
	public $pass;
	/**
	 * The server host name of the connection.
	 *
	 * @public
	 * @readonly
	 * @var string
	 */
	public $host;
	/**
	 * The port of the connection.
	 *
	 * @public
	 * @readonly
	 * @var string
	 */
	public $port;
	/**
	 * The command-line options passed in the connection request.
	 *
	 * ### Inheritable Defaults:
	 *
	 * @public
	 * @readonly
	 * @var string
	 */
	public $options;
	/**
	 * Default fetch type for future pq\Result instances.
	 *
	 * @public
	 * @var int
	 */
	public $defaultFetchType = \pq\Result::FETCH_ARRAY;
	/**
	 * Default conversion bitmask for future pq\Result instances.
	 *
	 * @public
	 * @var int
	 */
	public $defaultAutoConvert = \pq\Result::CONV_ALL;
	/**
	 * Default transaction isolation level for future pq\Transaction instances.
	 *
	 * @public
	 * @var int
	 */
	public $defaultTransactionIsolation = \pq\Transaction::READ_COMMITTED;
	/**
	 * Default transaction readonlyness for future pq\Transaction instances.
	 *
	 * @public
	 * @var bool
	 */
	public $defaultTransactionReadonly = FALSE;
	/**
	 * Default transaction deferrability for future pq\Transaction instances.
	 *
	 * @public
	 * @var bool
	 */
	public $defaultTransactionDeferrable = FALSE;
	/**
	 * Create a new PostgreSQL connection.
	 * See also [General Usage](pq/Connection/: General Usage).
	 *
	 * @param string $dsn A ***connection string*** as described [in the PostgreSQL documentation](http://www.postgresql.org/docs/current/static/libpq-connect.html#LIBPQ-CONNSTRING).
	 * @param int $flags See [connection flag constants](pq/Connection#Connection.Flags:).
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 */
	function __construct(string $dsn = "", int $flags = 0) {}
	/**
	 * Declare a cursor for a query.
	 *
	 * @param string $name The identifying name of the cursor.
	 * @param int $flags Any combination of pq\Cursor constants.
	 * @param string $query The query for which to open a cursor.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\RuntimeException
	 * @throws \pq\Exception\BadMethodCallException
	 * @return \pq\Cursor an open cursor instance.
	 */
	function declare(string $name, int $flags, string $query) {}
	/**
	 * [Asynchronously](pq/Connection/: Asynchronous Usage) declare a cursor for a query.
	 *
	 * > ***NOTE***:
	 *   If pq\Connection::$unbuffered is TRUE, each call to pq\Connection::getResult() will generate a distinct pq\Result containing exactly one row.
	 *
	 * @param string $name The identifying name of the cursor.
	 * @param int $flags Any combination of pq\Cursor constants.
	 * @param string $query The query for which to open a cursor.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\RuntimeException
	 * @throws \pq\Exception\BadMethodCallException
	 * @return \pq\Cursor an open cursor instance.
	 */
	function declareAsync(string $name, int $flags, string $query) {}
	/**
	 * Escape binary data for use within a query with the type bytea.
	 *
	 * > ***NOTE:***
	 *   The result is not wrapped in single quotes.
	 *
	 * @param string $binary The binary data to escape.
	 * @throws \pq\Exception\BadMethodCallException
	 * @return string|FALSE string the escaped binary data.
	 * 		 or FALSE if escaping fails.
	 */
	function escapeBytea(string $binary) {}
	/**
	 * [Execute one or multiple SQL queries](pq/Connection/: Executing Queries) on the connection.
	 *
	 * > ***NOTE:***
	 * > Only the last result will be returned, if the query string contains more than one SQL query.
	 *
	 * @param string $query The queries to send to the server, separated by semi-colon.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 * @throws \pq\Exception\DomainException
	 * @return \pq\Result
	 */
	function exec(string $query) {}
	/**
	 * [Asynchronously](pq/Connection/: Asynchronous Usage) [execute an SQL query](pq/Connection: Executing Queries) on the connection.
	 *
	 * > ***NOTE***:
	 *   If pq\Connection::$unbuffered is TRUE, each call to pq\Connection::getResult() will generate a distinct pq\Result containing exactly one row.
	 *
	 * @param string $query The query to send to the server.
	 * @param callable $callback as function(pq\Result $res)
	 *   The callback to execute when the query finishes.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 */
	function execAsync(string $query, callable $callback = NULL) {}
	/**
	 * [Execute an SQL query](pq/Connection: Executing Queries) with properly escaped parameters substituted.
	 *
	 * @param string $query The query to execute.
	 * @param array $params The parameter list to substitute.
	 * @param array $types Corresponding list of type OIDs for the parameters.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\RuntimeException
	 * @throws \pq\Exception\DomainException
	 * @return \pq\Result
	 */
	function execParams(string $query, array $params, array $types = NULL) {}
	/**
	 * [Asynchronously](pq/Connection/: Asynchronous Usage) [execute an SQL query](pq/Connection: Executing Queries) with properly escaped parameters substituted.
	 *
	 * > ***NOTE***:
	 *   If pq\Connection::$unbuffered is TRUE, each call to pq\Connection::getResult() will generate a distinct pq\Result containing exactly one row.
	 *
	 * @param string $query The query to execute.
	 * @param array $params The parameter list to substitute.
	 * @param array $types Corresponding list of type OIDs for the parameters.
	 * @param callable $cb as function(\pq\Result $res) : void
	 *   Result handler callback.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\RuntimeException
	 * @throws \pq\Exception\BadMethodCallException
	 */
	function execParamsAsync(string $query, array $params, array $types = NULL, callable $cb = NULL) {}
	/**
	 * Flush pending writes on the connection.
	 * Call after sending any command or data on a nonblocking connection.
	 *
	 * If it returns FALSE, wait for the socket to become read or write-ready.
	 * If it becomes write-ready, call pq\Connection::flush() again.
	 * If it becomes read-ready, call pq\Connection::poll(), then call pq\Connection::flush() again.
	 * Repeat until pq\Connection::flush() returns TRUE.
	 *
	 * > ***NOTE:***
	 * > This method was added in v1.1.0, resp. v2.1.0.
	 *
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\RuntimeException
	 * @return bool whether everything has been flushed.
	 */
	function flush() {}
	/**
	 * Fetch the result of an [asynchronous](pq/Connection/: Asynchronous Usage) query.
	 *
	 * If the query hasn't finished yet, the call will block until the result is available.
	 *
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @return NULL|\pq\Result NULL if there has not been a query
	 * 		 or \pq\Result when the query has finished
	 */
	function getResult() {}
	/**
	 * Listen on $channel for notifications.
	 * See pq\Connection::unlisten().
	 *
	 * @param string $channel The channel to listen on.
	 * @param callable $listener as function(string $channel, string $message, int $pid)
	 *   A callback automatically called whenever a notification on $channel arrives.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 */
	function listen(string $channel, callable $listener) {}
	/**
	 * [Asynchronously](pq/Connection/: Asynchronous Usage) start listening on $channel for notifications.
	 * See pq\Connection::listen().
	 *
	 * @param string $channel The channel to listen on.
	 * @param callable $listener as function(string $channel, string $message, int $pid)
	 *   A callback automatically called whenever a notification on $channel arrives.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 */
	function listenAsync(string $channel, callable $listener) {}
	/**
	 * Notify all listeners on $channel with $message.
	 *
	 * @param string $channel The channel to notify.
	 * @param string $message The message to send.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 */
	function notify(string $channel, string $message) {}
	/**
	 * [Asynchronously](pq/Connection/: Asynchronous Usage) start notifying all listeners on $channel with $message.
	 *
	 * @param string $channel The channel to notify.
	 * @param string $message The message to send.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 */
	function notifyAsync(string $channel, string $message) {}
	/**
	 * Stops listening for an event type.
	 *
	 * @param string $event Any pq\Connection::EVENT_*.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @return bool success.
	 */
	function off(string $event) {}
	/**
	 * Listen for an event.
	 *
	 * @param string $event Any pq\Connection::EVENT_*.
	 * @param callable $callback as function(pq\Connection $c[, pq\Result $r)
	 *   The callback to invoke on event.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @return int number of previously attached event listeners.
	 */
	function on(string $event, callable $callback) {}
	/**
	 * Poll an [asynchronously](pq/Connection/: Asynchronous Usage) operating connection.
	 * See pq\Connection::resetAsync() for an usage example.
	 *
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\RuntimeException
	 * @throws \pq\Exception\BadMethodCallException
	 * @return int pq\Connection::POLLING_* constant
	 */
	function poll() {}
	/**
	 * Prepare a named statement for later execution with pq\Statement::execute().
	 *
	 * @param string $name The identifying name of the prepared statement.
	 * @param string $query The query to prepare.
	 * @param array $types An array of type OIDs for the substitution parameters.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 * @return \pq\Statement a prepared statement instance.
	 */
	function prepare(string $name, string $query, array $types = NULL) {}
	/**
	 * [Asynchronously](pq/Connection/: Asynchronous Usage) prepare a named statement for later execution with pq\Statement::exec().
	 *
	 * > ***NOTE***:
	 *   If pq\Connection::$unbuffered is TRUE, each call to pq\Connection::getResult() will generate a distinct pq\Result containing exactly one row.
	 *
	 * @param string $name The identifying name of the prepared statement.
	 * @param string $query The query to prepare.
	 * @param array $types An array of type OIDs for the substitution parameters.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 * @return \pq\Statement a prepared statement instance.
	 */
	function prepareAsync(string $name, string $query, array $types = NULL) {}
	/**
	 * Quote a string for safe use in a query.
	 * The result is truncated at any zero byte and wrapped in single quotes.
	 *
	 * > ***NOTE:***
	 *   Beware of matching character encodings.
	 *
	 * @param string $payload The payload to quote for use in a query.
	 * @throws \pq\Exception\BadMethodCallException
	 * @return string|FALSE string a single-quote wrapped string safe for literal use in a query.
	 * 		 or FALSE if quoting fails.
	 */
	function quote(string $payload) {}
	/**
	 * Quote an identifier for safe usage as name.
	 *
	 * > ***NOTE:***
	 *   Beware of case-sensitivity.
	 *
	 * @param string $name The name to quote.
	 * @throws \pq\Exception\BadMethodCallException
	 * @return string|FALSE string the quoted identifier.
	 * 		 or FALSE if quoting fails.
	 */
	function quoteName(string $name) {}
	/**
	 * Attempt to reset a possibly broken connection to a working state.
	 *
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 */
	function reset() {}
	/**
	 * [Asynchronously](pq/Connection/: Asynchronous Usage) reset a possibly broken connection to a working state.
	 *
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 */
	function resetAsync() {}
	/**
	 * Set a data type converter.
	 *
	 * @param \pq\Converter $converter An instance implementing pq\Converter.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 */
	function setConverter(\pq\Converter $converter) {}
	/**
	 * Begin a transaction.
	 *
	 * @param int $isolation Any pq\Transaction isolation level constant
	 *   (defaults to pq\Connection::$defaultTransactionIsolation).
	 * @param bool $readonly Whether the transaction executes only reads
	 *   (defaults to pq\Connection::$defaultTransactionReadonly).
	 * @param bool $deferrable Whether the transaction is deferrable
	 *   (defaults to pq\Connection::$defaultTransactionDeferrable).
	 *
	 * > ***NOTE:***
	 *   A transaction can only be deferrable if it also is readonly and serializable.
	 *   See the official [PostgreSQL documentation](http://www.postgresql.org/docs/current/static/sql-set-transaction.html) for further information.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 * @return \pq\Transaction a begun transaction instance.
	 */
	function startTransaction(int $isolation = \pq\Transaction::READ_COMMITTED, bool $readonly = FALSE, bool $deferrable = FALSE) {}
	/**
	 * [Asynchronously](pq/Connection/: Asynchronous Usage) begin a transaction.
	 *
	 * @param int $isolation Any pq\Transaction isolation level constant
	 *   (defaults to pq\Connection::$defaultTransactionIsolation).
	 * @param bool $readonly Whether the transaction executes only reads
	 *   (defaults to pq\Connection::$defaultTransactionReadonly).
	 * @param bool $deferrable Whether the transaction is deferrable
	 *   (defaults to pq\Connection::$defaultTransactionDeferrable).
	 *
	 * > ***NOTE:***
	 *   A transaction can only be deferrable if it also is readonly and serializable.
	 *   See the official [PostgreSQL documentation](http://www.postgresql.org/docs/current/static/sql-set-transaction.html) for further information.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 * @return \pq\Transaction an asynchronously begun transaction instance.
	 */
	function startTransactionAsync(int $isolation = \pq\Transaction::READ_COMMITTED, bool $readonly = FALSE, bool $deferrable = FALSE) {}
	/**
	 * Trace protocol communication with the server.
	 *
	 * > ***NOTE:***
	 *   Calling pq\Connection::trace() without argument or NULL stops tracing.
	 *
	 * @param resource $stream The resource to which the protocol trace will be output.
	 *   (The stream must be castable to STDIO).
	 * @throws \pq\Exception\BadMethodCallException
	 * @return bool success.
	 */
	function trace($stream = NULL) {}
	/**
	 * Unescape bytea data retrieved from the server.
	 *
	 * @param string $bytea Bytea data retrieved from the server.
	 * @throws \pq\Exception\BadMethodCallException
	 * @return string|FALSE string unescaped binary data.
	 * 		 or FALSE if unescaping fails.
	 */
	function unescapeBytea(string $bytea) {}
	/**
	 * Stop listening for notifications on channel $channel.
	 * See pq\Connection::listen().
	 *
	 * @param string $channel The name of a channel which is currently listened on.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 */
	function unlisten(string $channel) {}
	/**
	 * [Asynchronously](pq/Connection/: Asynchronous Usage) stop listening for notifications on channel $channel.
	 * See pq\Connection::unlisten() and pq\Connection::listenAsync().
	 *
	 * @param string $channel The name of a channel which is currently listened on.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 */
	function unlistenAsync(string $channel) {}
	/**
	 * Stop applying a data type converter.
	 *
	 * @param \pq\Converter $converter A converter previously set with pq\Connection::setConverter().
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 */
	function unsetConverter(\pq\Converter $converter) {}
}
/**
 * Interface for type conversions.
 */
interface Converter  {
	/**
	 * Convert a string received from the PostgreSQL server back to a PHP type.
	 *
	 * @param string $data String data received from the server.
	 * @param int $type The type OID of the data. Irrelevant for single-type converters.
	 * @return mixed the value converted to a PHP type.
	 */
	function convertFromString(string $data, int $type);
	/**
	 * Convert a value to a string for use in a query.
	 *
	 * @param mixed $value The PHP value which should be converted to a string.
	 * @param int $type The type OID the converter should handle. Irrelevant for singly-type converters.
	 * @return string a textual representation of the value accepted by the PostgreSQL server.
	 */
	function convertToString($value, int $type);
	/**
	 * Announce which types the implementing converter can handle.
	 *
	 * @return array OIDs of handled types.
	 */
	function convertTypes();
}
/**
 * Declare a cursor.
 */
class Cursor  {
	/**
	 * Causes the cursor to return data in binary rather than in text format. You probably do not want to use that.
	 */
	const BINARY = 1;
	/**
	 * The data returned by the cursor should be unaffected by updates to the tables underlying the cursor that take place after the cursor was opened.
	 */
	const INSENSITIVE = 2;
	/**
	 * The cursor should stay usable after the transaction that created it was successfully committed.
	 */
	const WITH_HOLD = 4;
	/**
	 * Force that rows can be retrieved in any order from the cursor.
	 */
	const SCROLL = 16;
	/**
	 * Force that rows are only retrievable in sequiential order.
	 *
	 * > ***NOTE:***
	 *   See the [notes in the official PostgreSQL documentation](http://www.postgresql.org/docs/current/static/sql-declare.html#SQL-DECLARE-NOTES) for more information.
	 */
	const NO_SCROLL = 32;
	/**
	 * The connection the cursor was declared on.
	 *
	 * @public
	 * @readonly
	 * @var \pq\Connection
	 */
	public $connection;
	/**
	 * The identifying name of the cursor.
	 *
	 * @public
	 * @readonly
	 * @var string
	 */
	public $name;
	/**
	 * Declare a cursor.
	 * See pq\Connection::declare().
	 *
	 * @param \pq\Connection $connection The connection on which the cursor should be declared.
	 * @param string $name The name of the cursor.
	 * @param int $flags See pq\Cursor constants.
	 * @param string $query The query for which the cursor should be opened.
	 * @param bool $async Whether to declare the cursor [asynchronously](pq/Connection/: Asynchronous Usage).
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 */
	function __construct(\pq\Connection $connection, string $name, int $flags, string $query, bool $async) {}
	/**
	 * Close an open cursor.
	 * This is a no-op on already closed cursors.
	 *
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 */
	function close() {}
	/**
	 * [Asynchronously](pq/Connection/: Asynchronous Usage) close an open cursor.
	 * See pq\Cursor::close().
	 *
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 */
	function closeAsync() {}
	/**
	 * Fetch rows from the cursor.
	 * See pq\Cursor::move().
	 *
	 * @param string $spec What to fetch.
	 *
	 * ### Fetch argument:
	 *
	 * FETCH and MOVE usually accepts arguments like the following, where `count` is the number of rows:
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 * @return \pq\Result the fetched row(s).
	 */
	function fetch(string $spec = "1") {}
	/**
	 * [Asynchronously](pq/Connection/: Asynchronous Usage) fetch rows from the cursor.
	 * See pq\Cursor::fetch().
	 *
	 * @param string $spec What to fetch.
	 * @param callable $callback as function(pq\Result $res)
	 *   A callback to execute when the result is ready.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 */
	function fetchAsync(string $spec = "1", callable $callback = NULL) {}
	/**
	 * Move the cursor.
	 * See pq\Cursor::fetch().
	 *
	 * @param string $spec What to fetch.
	 *
	 * ### Fetch argument:
	 *
	 * FETCH and MOVE usually accepts arguments like the following, where `count` is the number of rows:
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 * @return \pq\Result command status.
	 */
	function move(string $spec = "1") {}
	/**
	 * [Asynchronously](pq/Connection/: Asynchronous Usage) move the cursor.
	 * See pq\Cursor::move().
	 *
	 * @param string $spec What to fetch.
	 * @param callable $callback as function(pq\Result $res)
	 *   A callback to execute when the command completed.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 */
	function moveAsync(string $spec = "1", callable $callback = NULL) {}
	/**
	 * Reopen a cursor.
	 * This is a no-op on already open cursors.
	 *
	 * > ***NOTE:***
	 *   Only cursors closed by pq\Cursor::close() will be reopened.
	 *
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 */
	function open() {}
	/**
	 * [Asynchronously](pq/Connection/: Asynchronous Usage) reopen a cursor.
	 * See pq\Cursor::open().
	 *
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 */
	function openAsync() {}
}
/**
*<div id="class.datetime" class="reference"> <h1 class="title">DateTime 类</h1>  <div class="partintro"><p class="verinfo">(PHP 5 &gt;= 5.2.0, PHP 7)</p>   <div class="section" id="datetime.intro">   <h2 class="title">简介</h2>   <p class="para">    日期和时间。   </p>  </div>  <div class="section" id="datetime.synopsis">   <h2 class="title">类摘要</h2>   <div class="classsynopsis">    <div class="ooclass"></div>    <div class="classsynopsisinfo">     <span class="ooclass">      <strong class="classname">DateTime</strong>     </span>     <span class="oointerface">implements       <span class="interfacename"><a href="http://php.net/manual/zh/class.datetimeinterface.php" class="interfacename">DateTimeInterface</a></span>     </span>     {</div>    <div class="classsynopsisinfo classsynopsisinfo_comment">// 继承的常量 </div>    <div class="fieldsynopsis">     <span class="modifier">const</span>     <span class="type" style="color:#EAB766">string</span>      <var class="fieldsynopsis_varname">{@link <var class="varname">DateTimeInterface::ATOM</var>}</var>     <span class="initializer"> = &quot;Y-m-d\TH:i:sP&quot;</span>    ;</div><div class="fieldsynopsis">     <span class="modifier">const</span>     <span class="type" style="color:#EAB766">string</span>      <var class="fieldsynopsis_varname">{@link <var class="varname">DateTimeInterface::COOKIE</var>}</var>     <span class="initializer"> = &quot;l, d-M-Y H:i:s T&quot;</span>    ;</div><div class="fieldsynopsis">     <span class="modifier">const</span>     <span class="type" style="color:#EAB766">string</span>      <var class="fieldsynopsis_varname">{@link <var class="varname">DateTimeInterface::ISO8601</var>}</var>     <span class="initializer"> = &quot;Y-m-d\TH:i:sO&quot;</span>    ;</div><div class="fieldsynopsis">     <span class="modifier">const</span>     <span class="type" style="color:#EAB766">string</span>      <var class="fieldsynopsis_varname">{@link <var class="varname">DateTimeInterface::RFC822</var>}</var>     <span class="initializer"> = &quot;D, d M y H:i:s O&quot;</span>    ;</div><div class="fieldsynopsis">     <span class="modifier">const</span>     <span class="type" style="color:#EAB766">string</span>      <var class="fieldsynopsis_varname">{@link <var class="varname">DateTimeInterface::RFC850</var>}</var>     <span class="initializer"> = &quot;l, d-M-y H:i:s T&quot;</span>    ;</div><div class="fieldsynopsis">     <span class="modifier">const</span>     <span class="type" style="color:#EAB766">string</span>      <var class="fieldsynopsis_varname">{@link <var class="varname">DateTimeInterface::RFC1036</var>}</var>     <span class="initializer"> = &quot;D, d M y H:i:s O&quot;</span>    ;</div><div class="fieldsynopsis">     <span class="modifier">const</span>     <span class="type" style="color:#EAB766">string</span>      <var class="fieldsynopsis_varname">{@link <var class="varname">DateTimeInterface::RFC1123</var>}</var>     <span class="initializer"> = &quot;D, d M Y H:i:s O&quot;</span>    ;</div><div class="fieldsynopsis">      <span class="modifier">const</span>      <span class="type" style="color:#EAB766">string</span>       <var class="fieldsynopsis_varname">{@link <var class="varname">DateTimeInterface::RFC7231</var>}</var>      <span class="initializer"> = &quot;D, d M Y H:i:s \G\M\T&quot;</span>    ;</div><div class="fieldsynopsis">     <span class="modifier">const</span>     <span class="type" style="color:#EAB766">string</span>      <var class="fieldsynopsis_varname">{@link <var class="varname">DateTimeInterface::RFC2822</var>}</var>     <span class="initializer"> = &quot;D, d M Y H:i:s O&quot;</span>    ;</div><div class="fieldsynopsis">     <span class="modifier">const</span>     <span class="type" style="color:#EAB766">string</span>      <var class="fieldsynopsis_varname">{@link <var class="varname">DateTimeInterface::RFC3339</var>}</var>     <span class="initializer"> = &quot;Y-m-d\TH:i:sP&quot;</span>    ;</div><div class="fieldsynopsis">     <span class="modifier">const</span>     <span class="type" style="color:#EAB766">string</span>      <var class="fieldsynopsis_varname">{@link <var class="varname">DateTimeInterface::RFC3339_EXTENDED</var>}</var>     <span class="initializer"> = &quot;Y-m-d\TH:i:s.vP&quot;</span>    ;</div><div class="fieldsynopsis">     <span class="modifier">const</span>     <span class="type" style="color:#EAB766">string</span>      <var class="fieldsynopsis_varname">{@link <var class="varname">DateTimeInterface::RSS</var>}</var>     <span class="initializer"> = &quot;D, d M Y H:i:s O&quot;</span>    ;</div><div class="fieldsynopsis">     <span class="modifier">const</span>     <span class="type" style="color:#EAB766">string</span>      <var class="fieldsynopsis_varname">{@link <var class="varname">DateTimeInterface::W3C</var>}</var>     <span class="initializer"> = &quot;Y-m-d\TH:i:sP&quot;</span>    ;</div>        <div class="classsynopsisinfo classsynopsisinfo_comment">// 方法 </div>    <div class="constructorsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/datetime.construct.php" class="methodname" style="color:#CC7832">__construct</a></span>    ([ <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$time</span><span class="initializer"> = &quot;now&quot;</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766"><a href="http://php.net/manual/zh/class.datetimezone.php" class="type DateTimeZone" style="color:#EAB766">DateTimeZone</a></span> <span class="parameter" style="color:#3A95FF">$timezone</span><span class="initializer"> = <strong><span>NULL</span></strong></span></span>  ]] )</div>        <div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/datetime.add.php" class="methodname" style="color:#CC7832">add</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766"><a href="http://php.net/manual/zh/class.dateinterval.php" class="type DateInterval" style="color:#EAB766">DateInterval</a></span> <span class="parameter" style="color:#3A95FF">$interval</span></span>   ) : <span class="type" style="color:#EAB766"><a href="http://php.net/manual/zh/class.datetime.php" class="type DateTime" style="color:#EAB766">DateTime</a></span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="modifier">static</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/datetime.createfromformat.php" class="methodname" style="color:#CC7832">createFromFormat</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$format</span></span>   , <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$time</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766"><a href="http://php.net/manual/zh/class.datetimezone.php" class="type DateTimeZone" style="color:#EAB766">DateTimeZone</a></span> <span class="parameter" style="color:#3A95FF">$timezone</span></span>  ] ) : <span class="type" style="color:#EAB766"><a href="http://php.net/manual/zh/class.datetime.php" class="type DateTime" style="color:#EAB766">DateTime</a></span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="modifier">static</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/datetime.createfromimmutable.php" class="methodname" style="color:#CC7832">createFromImmutable</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766"><a href="http://php.net/manual/zh/class.datetimeimmutable.php" class="type DateTimeImmutable" style="color:#EAB766">DateTimeImmutable</a></span> <span class="parameter" style="color:#3A95FF">$object</span></span>   ) : <span class="type" style="color:#EAB766"><a href="http://php.net/manual/zh/class.datetime.php" class="type DateTime" style="color:#EAB766">DateTime</a></span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="modifier">static</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/datetime.getlasterrors.php" class="methodname" style="color:#CC7832">getLastErrors</a></span>    (   ) : <span class="type" style="color:#EAB766">array</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/datetime.modify.php" class="methodname" style="color:#CC7832">modify</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$modify</span></span>   ) : <span class="type" style="color:#EAB766"><a href="http://php.net/manual/zh/class.datetime.php" class="type DateTime" style="color:#EAB766">DateTime</a></span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="modifier">static</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/datetime.set-state.php" class="methodname" style="color:#CC7832">__set_state</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">array</span> <span class="parameter" style="color:#3A95FF">$array</span></span>   ) : <span class="type" style="color:#EAB766"><a href="http://php.net/manual/zh/class.datetime.php" class="type DateTime" style="color:#EAB766">DateTime</a></span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/datetime.setdate.php" class="methodname" style="color:#CC7832">setDate</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$year</span></span>   , <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$month</span></span>   , <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$day</span></span>   ) : <span class="type" style="color:#EAB766"><a href="http://php.net/manual/zh/class.datetime.php" class="type DateTime" style="color:#EAB766">DateTime</a></span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/datetime.setisodate.php" class="methodname" style="color:#CC7832">setISODate</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$year</span></span>   , <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$week</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$day</span><span class="initializer"> = 1</span></span>  ] ) : <span class="type" style="color:#EAB766"><a href="http://php.net/manual/zh/class.datetime.php" class="type DateTime" style="color:#EAB766">DateTime</a></span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/datetime.settime.php" class="methodname" style="color:#CC7832">setTime</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$hour</span></span>   , <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$minute</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$second</span><span class="initializer"> = 0</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$microseconds</span><span class="initializer"> = 0</span></span>  ]] ) : <span class="type" style="color:#EAB766"><a href="http://php.net/manual/zh/class.datetime.php" class="type DateTime" style="color:#EAB766">DateTime</a></span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/datetime.settimestamp.php" class="methodname" style="color:#CC7832">setTimestamp</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$unixtimestamp</span></span>   ) : <span class="type" style="color:#EAB766"><a href="http://php.net/manual/zh/class.datetime.php" class="type DateTime" style="color:#EAB766">DateTime</a></span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/datetime.settimezone.php" class="methodname" style="color:#CC7832">setTimezone</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766"><a href="http://php.net/manual/zh/class.datetimezone.php" class="type DateTimeZone" style="color:#EAB766">DateTimeZone</a></span> <span class="parameter" style="color:#3A95FF">$timezone</span></span>   ) : <span class="type" style="color:#EAB766"><a href="http://php.net/manual/zh/class.datetime.php" class="type DateTime" style="color:#EAB766">DateTime</a></span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/datetime.sub.php" class="methodname" style="color:#CC7832">sub</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766"><a href="http://php.net/manual/zh/class.dateinterval.php" class="type DateInterval" style="color:#EAB766">DateInterval</a></span> <span class="parameter" style="color:#3A95FF">$interval</span></span>   ) : <span class="type" style="color:#EAB766"><a href="http://php.net/manual/zh/class.datetime.php" class="type DateTime" style="color:#EAB766">DateTime</a></span></div>        <div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/datetime.diff.php" class="methodname" style="color:#CC7832">diff</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766"><a href="http://php.net/manual/zh/class.datetimeinterface.php" class="type DateTimeInterface" style="color:#EAB766">DateTimeInterface</a></span> <span class="parameter" style="color:#3A95FF">$targetObject</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">bool</span> <span class="parameter" style="color:#3A95FF">$absolute</span><span class="initializer"> = <strong><span>FALSE</span></strong></span></span>  ] ) : <span class="type" style="color:#EAB766"><span class="type" style="color:#EAB766"><a href="http://php.net/manual/zh/class.dateinterval.php" class="type DateInterval" style="color:#EAB766">DateInterval</a></span>|<span class="type" style="color:#EAB766"><span class="type false" style="color:#EAB766">false</span></span></span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/datetime.format.php" class="methodname" style="color:#CC7832">format</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$format</span></span>   ) : <span class="type" style="color:#EAB766"><span class="type" style="color:#EAB766">string</span>|<span class="type" style="color:#EAB766"><span class="type false" style="color:#EAB766">false</span></span></span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/datetime.getoffset.php" class="methodname" style="color:#CC7832">getOffset</a></span>    (   ) : <span class="type" style="color:#EAB766"><span class="type" style="color:#EAB766">int</span>|<span class="type" style="color:#EAB766"><span class="type false" style="color:#EAB766">false</span></span></span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/datetime.gettimestamp.php" class="methodname" style="color:#CC7832">getTimestamp</a></span>    (   ) : <span class="type" style="color:#EAB766">int</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/datetime.gettimezone.php" class="methodname" style="color:#CC7832">getTimezone</a></span>    (   ) : <span class="type" style="color:#EAB766"><span class="type" style="color:#EAB766"><a href="http://php.net/manual/zh/class.datetimezone.php" class="type DateTimeZone" style="color:#EAB766">DateTimeZone</a></span>|<span class="type" style="color:#EAB766"><span class="type false" style="color:#EAB766">false</span></span></span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/datetime.wakeup.php" class="methodname" style="color:#CC7832">__wakeup</a></span>    (   )</div>   }</div>  </div> <div class="section" id="datetime.changelog">  <h2 class="title">更新日志</h2>  <p class="para">   <table class="doctable informaltable">         <thead>      <tr>       <th>版本</th>       <th>说明</th>      </tr>     </thead>     <tbody class="tbody">      <tr>       <td>7.2.0</td>       <td>        <strong class="classname">DateTime</strong> 的类常量现在定义在 <a href="http://php.net/manual/zh/class.datetimeinterface.php" class="classname">DateTimeInterface</a> 上。       </td>      </tr>      <tr>       <td>7.0.0</td>       <td>        新增常量：<a href="http://php.net/manual/zh/class.datetimeinterface.php#datetime.constants.rfc3339_extended" class="link">DATE_RFC3339_EXTENDED</a> 和        {@link DateTime::RFC3339_EXTENDED}。       </td>      </tr>      <tr>       <td>5.5.0</td>       <td>        实现 <a href="http://php.net/manual/zh/class.datetimeinterface.php" class="classname">DateTimeInterface</a> 接口。       </td>      </tr>      <tr>       <td>5.4.24</td>       <td>        COOKIE 格式从 2 位数字表示年份（RFC 850）        修改为 4 位数字表示年份（RFC 1036）。       </td>      </tr>      <tr>       <td>5.2.2</td>       <td>        DateTime 对象进行比较操作（<a href="http://php.net/manual/zh/language.operators.comparison.php" class="link">comparison operators</a>）的时候        可以正常工作了。        在之前的版本中，当使用 <span>==</span> 进行相等比较的时候，        所有的 DateTime 对象都会被视为是相等的。       </td>      </tr>     </tbody>       </table>  </p> </div> </div> <h2>Table of Contents</h2><ul class="chunklist chunklist_reference"><li>{@link DateTime::add} — 给一个 DateTime 对象增加一定量的天，月，年，小时，分钟   以及秒。</li><li>{@link DateTime::__construct} — 返回一个新的 DateTime 对象</li><li>{@link DateTime::createFromFormat} — 根据给定的格式解析日期时间字符串</li><li>{@link DateTime::createFromImmutable} — Returns new DateTime object encapsulating the given DateTimeImmutable object</li><li>{@link DateTime::getLastErrors} — 获取警告和错误信息</li><li>{@link DateTime::modify} — 修改日期时间对象的值</li><li>{@link DateTime::__set_state} — __set_state 魔术方法处理函数</li><li>{@link DateTime::setDate} — 设置 DateTime 对象的日期</li><li>{@link DateTime::setISODate} — 设置 ISO 日期</li><li>{@link DateTime::setTime} — 设置 DateTime 对象的时间</li><li>{@link DateTime::setTimestamp} — 以 Unix 时间戳的方式设置 DateTime 对象</li><li>{@link DateTime::setTimezone} — 设置 DateTime 对象的时区</li><li>{@link DateTime::sub} — 对一个 DateTime 对象减去一定量的   日、月、年、小时、分钟和秒。</li></ul></div>
*/
class DateTime extends \DateTime implements \JsonSerializable {
	/**
	 * The default format of any date/time type automatically converted by pq\Result (depends on the actual type of the column).
	 *
	 * @public
	 * @var string
	 */
	public $format = "Y-m-d H:i:s.uO";
	/**
	 * Stringify the DateTime instance according to pq\DateTime::$format.
	 *
	 * @return string the DateTime as string.
	 */
	function __toString() {}
	/**
	 * Serialize to JSON.
	 * Alias of pq\DateTime::__toString().
	 *
	 * @return string the DateTime stringified according to pq\DateTime::$format.
	 */
	function jsonSerialize() {}
}
/**
 * A base interface for all pq\Exception classes.
 */
interface Exception  {
	/**
	 * An invalid argument was passed to a method (pq\Exception\InvalidArgumentException).
	 */
	const INVALID_ARGUMENT = 0;
	/**
	 * A runtime exception occurred (pq\Exception\RuntimeException).
	 */
	const RUNTIME = 1;
	/**
	 * The connection failed (pq\Exception\RuntimeException).
	 */
	const CONNECTION_FAILED = 2;
	/**
	 * An input/output exception occurred (pq\Exception\RuntimeException).
	 */
	const IO = 3;
	/**
	 * Escaping an argument or identifier failed internally (pq\Exception\RuntimeException).
	 */
	const ESCAPE = 4;
	/**
	 * An object's constructor was not called (pq\Exception\BadMethodCallException).
	 */
	const UNINITIALIZED = 6;
	/**
	 * Calling this method was not expected (yet) (pq\Exception\BadMethodCallException).
	 */
	const BAD_METHODCALL = 5;
	/**
	 * SQL syntax error (pq\Exception\DomainException).
	 */
	const SQL = 8;
	/**
	 * Implementation domain error (pq\Exception\DomainException).
	 */
	const DOMAIN = 7;
}
/**
 * A *large object*.
 *
 * > ***NOTE:***
 *   Working with *large objects* requires an active transaction.
 */
class LOB  {
	/**
	 * 0, representing an invalid OID.
	 */
	const INVALID_OID = 0;
	/**
	 * Read/write mode.
	 */
	const RW = 393216;
	/**
	 * The transaction wrapping the operations on the *large object*.
	 *
	 * @public
	 * @readonly
	 * @var \pq\Transaction
	 */
	public $transaction;
	/**
	 * The OID of the *large object*.
	 *
	 * @public
	 * @readonly
	 * @var int
	 */
	public $oid;
	/**
	 * The stream connected to the *large object*.
	 *
	 * @public
	 * @readonly
	 * @var
	 */
	public $stream;
	/**
	 * Open or create a *large object*.
	 * See pq\Transaction::openLOB() and pq\Transaction::createLOB().
	 *
	 * @param \pq\Transaction $txn The transaction which wraps the *large object* operations.
	 * @param int $oid The OID of the existing *large object* to open.
	 * @param int $mode Access mode (read, write or read/write).
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 */
	function __construct(\pq\Transaction $txn, int $oid = \pq\LOB::INVALID_OID, int $mode = \pq\LOB::RW) {}
	/**
	 * Read a string of data from the current position of the *large object*.
	 *
	 * @param int $length The amount of bytes to read from the *large object*.
	 * @param int $read The amount of bytes actually read from the *large object*.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 * @return string the data read.
	 */
	function read(int $length = 0x1000, int &$read = NULL) {}
	/**
	 * Seek to a position within the *large object*.
	 *
	 * @param int $offset The position to seek to.
	 * @param int $whence From where to seek (SEEK_SET, SEEK_CUR or SEEK_END).
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 * @return int the new position.
	 */
	function seek(int $offset, int $whence = SEEK_SET) {}
	/**
	 * Retrieve the current position within the *large object*.
	 *
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 * @return int the current position.
	 */
	function tell() {}
	/**
	 * Truncate the *large object*.
	 *
	 * @param int $length The length to truncate to.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 */
	function truncate(int $length = 0) {}
	/**
	 * Write data to the *large object*.
	 *
	 * @param string $data The data that should be written to the current position.
	 * @return int the number of bytes written.
	 */
	function write(string $data) {}
}
/**
 * A query result.
 *
 * See [Fetching Results](pq/Result/: Fetching Results) for a general overview.
 */
class Result implements \Traversable, \Countable {
	/**
	 * The query sent to the server was empty.
	 */
	const EMPTY_QUERY = 0;
	/**
	 * The query did not generate a result set and completed successfully.
	 */
	const COMMAND_OK = 1;
	/**
	 * The query successfully generated a result set.
	 */
	const TUPLES_OK = 2;
	/**
	 * The result contains a single row of the result set when using pq\Connection::$unbuffered.
	 */
	const SINGLE_TUPLE = 9;
	/**
	 * COPY data can be received from the server.
	 */
	const COPY_OUT = 3;
	/**
	 * COPY data can be sent to the server.
	 */
	const COPY_IN = 4;
	/**
	 * COPY in/out data transfer in progress.
	 */
	const COPY_BOTH = 8;
	/**
	 * The server sent a bad response.
	 */
	const BAD_RESPONSE = 5;
	/**
	 * A nonfatal error (notice or warning) occurred.
	 */
	const NONFATAL_ERROR = 6;
	/**
	 * A fatal error occurred.
	 */
	const FATAL_ERROR = 7;
	/**
	 * Fetch rows numerically indexed, where the index start with 0.
	 */
	const FETCH_ARRAY = 0;
	/**
	 * Fetch rows associatively indexed by column name.
	 */
	const FETCH_ASSOC = 1;
	/**
	 * Fetch rows as stdClass instance, where the column names are the property names.
	 */
	const FETCH_OBJECT = 2;
	/**
	 * Automatically convert 'f' and 't' to FALSE and TRUE and vice versa.
	 */
	const CONV_BOOL = 1;
	/**
	 * Automatically convert integral strings to either int if it fits into maximum integer size or else to float and vice versa.
	 */
	const CONV_INT = 2;
	/**
	 * Automatically convert floating point numbers.
	 */
	const CONV_FLOAT = 4;
	/**
	 * Do all scalar conversions listed above.
	 */
	const CONV_SCALAR = 15;
	/**
	 * Automatically convert arrays.
	 */
	const CONV_ARRAY = 16;
	/**
	 * Automatically convert date strings to pq\DateTime and vice versa.
	 */
	const CONV_DATETIME = 32;
	/**
	 * Automatically convert JSON.
	 */
	const CONV_JSON = 256;
	/**
	 * Do all of the above.
	 */
	const CONV_ALL = 65535;
	/**
	 * A [status constant](pq/Result#Status.values:).
	 *
	 * @public
	 * @readonly
	 * @var int
	 */
	public $status;
	/**
	 * The accompanying status message.
	 *
	 * @public
	 * @readonly
	 * @var string
	 */
	public $statusMessage;
	/**
	 * Any error message if $status indicates an error.
	 *
	 * @public
	 * @readonly
	 * @var string
	 */
	public $errorMessage;
	/**
	 * The number of rows in the result set.
	 *
	 * @public
	 * @readonly
	 * @var int
	 */
	public $numRows;
	/**
	 * The number of fields in a single tuple of the result set.
	 *
	 * @public
	 * @readonly
	 * @var int
	 */
	public $numCols;
	/**
	 * The number of rows affected by a statement.
	 *
	 * @public
	 * @readonly
	 * @var int
	 */
	public $affectedRows;
	/**
	 * Error details. See [PQresultErrorField](https://www.postgresql.org/docs/current/static/libpq-exec.html#LIBPQ-PQRESULTERRORFIELD) docs.
	 *
	 * @public
	 * @readonly
	 * @var array
	 */
	public $diag;
	/**
	 * The [type of return value](pq/Result#Fetch.types:) the fetch methods should return when no fetch type argument was given. Defaults to pq\Connection::$defaultFetchType.
	 *
	 * @public
	 * @var int
	 */
	public $fetchType = \pq\Result::FETCH_ARRAY;
	/**
	 * What [type of conversions](pq/Result#Conversion.bits:) to perform automatically.
	 *
	 * @public
	 * @var int
	 */
	public $autoConvert = \pq\Result::CONV_ALL;
	/**
	 * Bind a variable to a result column.
	 * See pq\Result::fetchBound().
	 *
	 * @param mixed $col The column name or index to bind to.
	 * @param mixed $var The variable reference.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @return bool success.
	 */
	function bind($col, $var) {}
	/**
	 * Count number of rows in this result set.
	 *
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @return int the number of rows.
	 */
	function count() {}
	/**
	 * Describe a prepared statement.
	 *
	 * > ***NOTE:***
	 *   This will only return meaningful information for a result of pq\Statement::desc().
	 *
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @return array list of parameter type OIDs for the prepared statement.
	 */
	function desc() {}
	/**
	 * Fetch all rows at once.
	 *
	 * @param int $fetch_type The type the return value should have, see pq\Result::FETCH_* constants, defaults to pq\Result::$fetchType.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @return array all fetched rows.
	 */
	function fetchAll(int $fetch_type = NULL) {}
	/**
	 * Fetch all rows of a single column.
	 *
	 * @param int $col The column name or index to fetch.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 * @return array list of column values.
	 */
	function fetchAllCols(int $col = 0) {}
	/**
	 * Iteratively fetch a row into bound variables.
	 * See pq\Result::bind().
	 *
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 * @return array|NULL array the fetched row as numerically indexed array.
	 * 		 or NULL when iteration ends.
	 */
	function fetchBound() {}
	/**
	 * Iteratively fetch a single column.
	 *
	 * @param mixed $ref The variable where the column value will be stored in.
	 * @param mixed $col The column name or index.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 * @return bool|NULL bool success.
	 * 		 or NULL when iteration ends.
	 */
	function fetchCol($ref, $col = 0) {}
	/**
	 * Iteratively fetch a row.
	 *
	 * @param int $fetch_type The type the return value should have, see pq\Result::FETCH_* constants, defaults to pq\Result::$fetchType.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 * @return array|array|object|NULL array numerically indexed for pq\Result::FETCH_ARRAY
	 * 		 or array associatively indexed for pq\Result::FETCH_ASSOC
	 * 		 or object stdClass instance for pq\Result::FETCH_OBJECT
	 * 		 or NULL when iteration ends.
	 */
	function fetchRow(int $fetch_type = NULL) {}
	/**
	 * Fetch the complete result set as a simple map, a *multi dimensional array*, each dimension indexed by a column.
	 *
	 * @param mixed $keys The the column indices/names used to index the map.
	 * @param mixed $vals The column indices/names which should build up the leaf entry of the map.
	 * @param int $fetch_type The type the return value should have, see pq\Result::FETCH_* constants, defaults to pq\Result::$fetchType.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 * @return array |object, the mapped columns.
	 */
	function map($keys = 0, $vals = NULL, int $fetch_type = NULL) {}
}
/**
 * A named prepared statement.
 * See pq\Connection::prepare().
 */
class Statement  {
	/**
	 * The connection to the server.
	 *
	 * @public
	 * @readonly
	 * @var \pq\Connection
	 */
	public $connection;
	/**
	 * The identifiying name of the prepared statement.
	 *
	 * @public
	 * @readonly
	 * @var string
	 */
	public $name;
	/**
	 * The query string used to prepare the statement.
	 *
	 * @public
	 * @readonly
	 * @var string
	 */
	public $query;
	/**
	 * List of corresponding query parameter type OIDs for the prepared statement.
	 *
	 * @public
	 * @readonly
	 * @var array
	 */
	public $types;
	/**
	 * Prepare a new statement.
	 * See pq\Connection::prepare().
	 *
	 * @param \pq\Connection $conn The connection to prepare the statement on.
	 * @param string $name The name identifying this statement.
	 * @param string $query The actual query to prepare.
	 * @param array $types A list of corresponding query parameter type OIDs.
	 * @param bool $async Whether to prepare the statement [asynchronously](pq/Connection/: Asynchronous Usage).
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 * @throws \pq\Exception\DomainException
	 */
	function __construct(\pq\Connection $conn, string $name, string $query, array $types = NULL, bool $async = FALSE) {}
	/**
	 * Bind a variable to an input parameter.
	 *
	 * @param int $param_no The parameter index to bind to.
	 * @param mixed $param_ref The variable to bind.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 */
	function bind(int $param_no, &$param_ref) {}
	/**
	 * Free the server resources used by the prepared statement, so it can no longer be executed.
	 * This is done implicitly when the object is destroyed.
	 *
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 */
	function deallocate() {}
	/**
	 * [Asynchronously](pq/Connection/: Asynchronous Usage) free the server resources used by the
	 * prepared statement, so it can no longer be executed.
	 *
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 */
	function deallocateAsync() {}
	/**
	 * Describe the parameters of the prepared statement.
	 *
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 * @throws \pq\Exception\DomainException
	 * @return array list of type OIDs of the substitution parameters.
	 */
	function desc() {}
	/**
	 * [Asynchronously](pq/Connection/: Asynchronous Usage) describe the parameters of the prepared statement.
	 *
	 * @param callable $callback as function(array $oids)
	 *   A callback to receive list of type OIDs of the substitution parameters.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 */
	function descAsync(callable $callback) {}
	/**
	 * Execute the prepared statement.
	 *
	 * @param array $params Any parameters to substitute in the prepared statement (defaults to any bou
	 *   nd variables).
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 * @return \pq\Result the result of the execution of the prepared statement.
	 */
	function exec(array $params = NULL) {}
	/**
	 * [Asynchronously](pq/Connection/: Asynchronous Usage) execute the prepared statement.
	 *
	 * @param array $params Any parameters to substitute in the prepared statement (defaults to any bou
	 *   nd variables).
	 * @param callable $cb as function(\pq\Result $res) : void
	 *   Result handler callback.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 */
	function execAsync(array $params = NULL, callable $cb = NULL) {}
	/**
	 * Re-prepare a statement that has been deallocated. This is a no-op on already open statements.
	 *
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 */
	function prepare() {}
	/**
	 * [Asynchronously](pq/Connection/: Asynchronous Usage) re-prepare a statement that has been
	 * deallocated. This is a no-op on already open statements.
	 *
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 */
	function prepareAsync() {}
}
/**
 * A database transaction.
 *
 * > ***NOTE:***
 *   Transactional properties like pq\Transaction::$isolation, pq\Transaction::$readonly and pq\Transaction::$deferrable can be changed after the transaction begun and the first query has been executed. Doing this will lead to appropriate `SET TRANSACTION` queries.
 */
class Transaction  {
	/**
	 * Transaction isolation level where only rows committed before the transaction began can be seen.
	 */
	const READ_COMMITTED = 0;
	/**
	 * Transaction isolation level where only rows committed before the first query was executed in this transaction.
	 */
	const REPEATABLE_READ = 1;
	/**
	 * Transaction isolation level that guarantees serializable repeatability which might lead to serialization_failure on high concurrency.
	 */
	const SERIALIZABLE = 2;
	/**
	 * The connection the transaction was started on.
	 *
	 * @public
	 * @readonly
	 * @var \pq\Connection
	 */
	public $connection;
	/**
	 * The transaction isolation level.
	 *
	 * @public
	 * @var int
	 */
	public $isolation = \pq\Transaction::READ_COMMITTED;
	/**
	 * Whether this transaction performs read only queries.
	 *
	 * @public
	 * @var bool
	 */
	public $readonly = FALSE;
	/**
	 * Whether the transaction is deferrable. See pq\Connection::startTransaction().
	 *
	 * @public
	 * @var bool
	 */
	public $deferrable = FALSE;
	/**
	 * Start a transaction.
	 * See pq\Connection::startTransaction().
	 *
	 * @param \pq\Connection $conn The connection to start the transaction on.
	 * @param bool $async Whether to start the transaction [asynchronously](pq/Connection/: Asynchronous Usage).
	 * @param int $isolation The transaction isolation level (defaults to pq\Connection::$defaultTransactionIsolation).
	 * @param bool $readonly Whether the transaction is readonly (defaults to pq\Connection::$defaultTransactionReadonly).
	 * @param bool $deferrable Whether the transaction is deferrable (defaults to pq\Connection::$defaultTransactionDeferrable).
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 */
	function __construct(\pq\Connection $conn, bool $async = FALSE, int $isolation = \pq\Transaction::READ_COMMITTED, bool $readonly = FALSE, bool $deferrable = FALSE) {}
	/**
	 * Commit the transaction or release the previous savepoint.
	 * See pq\Transaction::savepoint().
	 *
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 * @throws \pq\Exception\DomainException
	 */
	function commit() {}
	/**
	 * [Asynchronously](pq/Connection/: Asynchronous Usage) commit the transaction or release the previous savepoint.
	 * See pq\Transaction::commit() and pq\Transaction::savepoint().
	 *
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 */
	function commitAsync() {}
	/**
	 * Create a new *large object* and open it.
	 * See pq\Transaction::openLOB().
	 *
	 * @param int $mode How to open the *large object* (read, write or both; see pq\LOB constants).
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 * @return \pq\LOB instance of the new *large object*.
	 */
	function createLOB(int $mode = \pq\LOB::RW) {}
	/**
	 * Export a *large object* to a local file.
	 * See pq\Transaction::importLOB().
	 *
	 * @param int $oid The OID of the *large object*.
	 * @param string $path The path of a local file to export to.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 */
	function exportLOB(int $oid, string $path) {}
	/**
	 * Export a snapshot for transaction synchronization.
	 * See pq\Transaction::importSnapshot().
	 *
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 * @throws \pq\Exception\DomainException
	 * @return string the snapshot identifier usable with pq\Transaction::importSnapshot().
	 */
	function exportSnapshot() {}
	/**
	 * [Asynchronously](pq/Connection/: Asynchronous Usage) export a snapshot for transaction synchronization.
	 * See pq\Transaction::exportSnapshot().
	 *
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 */
	function exportSnapshotAsync() {}
	/**
	 * Import a local file into a *large object*.
	 *
	 * @param string $local_path A path to a local file to import.
	 * @param int $oid The target OID. A new *large object* will be created if INVALID_OID.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 * @return int the (new) OID of the *large object*.
	 */
	function importLOB(string $local_path, int $oid = \pq\LOB::INVALID_OID) {}
	/**
	 * Import a snapshot from another transaction to synchronize with.
	 * See pq\Transaction::exportSnapshot().
	 *
	 * > ***NOTE:***
	 *   The transaction must have an isolation level of at least pq\Transaction::REPEATABLE_READ.
	 *
	 * @param string $snapshot_id The snapshot identifier obtained by exporting a snapshot from a transaction.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 * @throws \pq\Exception\DomainException
	 */
	function importSnapshot(string $snapshot_id) {}
	/**
	 * [Asynchronously](pq/Connection/: Asynchronous Usage) import a snapshot from another transaction to synchronize with.
	 * See pq\Transaction::importSnapshot().
	 *
	 * > ***NOTE:***
	 *   The transaction must have an isolation level of at least pq\Transaction::REPEATABLE_READ.
	 *
	 * @param string $snapshot_id The snapshot identifier obtained by exporting a snapshot from a transaction.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 */
	function importSnapshotAsync(string $snapshot_id) {}
	/**
	 * Open a *large object*.
	 * See pq\Transaction::createLOB().
	 *
	 * @param int $oid The OID of the *large object*.
	 * @param int $mode Operational mode; read, write or both.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 * @return \pq\LOB instance of the opened *large object*.
	 */
	function openLOB(int $oid, int $mode = \pq\LOB::RW) {}
	/**
	 * Rollback the transaction or to the previous savepoint within this transaction.
	 * See pq\Transaction::commit() and pq\Transaction::savepoint().
	 *
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 * @throws \pq\Exception\DomainException
	 */
	function rollback() {}
	/**
	 * [Asynchronously](pq/Connection/: Asynchronous Usage) rollback the transaction or to the previous savepoint within this transaction.
	 * See pq\Transaction::rollback() and pq\Transaction::savepoint().
	 *
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 */
	function rollbackAsync() {}
	/**
	 * Create a `SAVEPOINT` within this transaction.
	 *
	 * > ***NOTE:***
	 *   pq\Transaction tracks an internal counter as savepoint identifier.
	 *
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 */
	function savepoint() {}
	/**
	 * [Asynchronously](pq/Connection/: Asynchronous Usage) create a `SAVEPOINT` within this transaction.
	 * See pq\Transaction::savepoint().
	 *
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 */
	function savepointAsync() {}
	/**
	 * Unlink a *large object*.
	 * See pq\Transaction::createLOB().
	 *
	 * @param int $oid The OID of the *large object*.
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 * @return \pq\LOB instance of the opened *large object*.
	 */
	function unlinkLOB(int $oid) {}
}
/**
 * Accessor to the PostgreSQL `pg_type` relation.
 * See [here for an overview](pq/Types/: Overview).
 */
class Types implements \ArrayAccess {
	/**
	 * OID of the `bool` type.
	 */
	const BOOL = 16;
	/**
	 * OID of the `bytea` type.
	 */
	const BYTEA = 17;
	/**
	 * OID of the `char` type.
	 */
	const CHAR = 18;
	/**
	 * OID of the `name` type.
	 */
	const NAME = 19;
	/**
	 * OID of the `int8` type.
	 */
	const INT8 = 20;
	/**
	 * OID of the `int2` type.
	 */
	const INT2 = 21;
	/**
	 * OID of the `int2vector` type.
	 */
	const INT2VECTOR = 22;
	/**
	 * OID of the `int4` type.
	 */
	const INT4 = 23;
	/**
	 * OID of the `regproc` type.
	 */
	const REGPROC = 24;
	/**
	 * OID of the `text` type.
	 */
	const TEXT = 25;
	/**
	 * OID of the `oid` type.
	 */
	const OID = 26;
	/**
	 * OID of the `tid` type.
	 */
	const TID = 27;
	/**
	 * OID of the `xid` type.
	 */
	const XID = 28;
	/**
	 * OID of the `cid` type.
	 */
	const CID = 29;
	/**
	 * OID of the `oidvector` type.
	 */
	const OIDVECTOR = 30;
	/**
	 * OID of the `pg_type` type.
	 */
	const PG_TYPE = 71;
	/**
	 * OID of the `pg_attribute` type.
	 */
	const PG_ATTRIBUTE = 75;
	/**
	 * OID of the `pg_proc` type.
	 */
	const PG_PROC = 81;
	/**
	 * OID of the `pg_class` type.
	 */
	const PG_CLASS = 83;
	/**
	 * OID of the `json` type.
	 */
	const JSON = 114;
	/**
	 * OID of the `xml` type.
	 */
	const XML = 142;
	/**
	 * OID of the `xmlarray` type.
	 */
	const XMLARRAY = 143;
	/**
	 * OID of the `jsonarray` type.
	 */
	const JSONARRAY = 199;
	/**
	 * OID of the `pg_node_tree` type.
	 */
	const PG_NODE_TREE = 194;
	/**
	 * OID of the `smgr` type.
	 */
	const SMGR = 210;
	/**
	 * OID of the `point` type.
	 */
	const POINT = 600;
	/**
	 * OID of the `lseg` type.
	 */
	const LSEG = 601;
	/**
	 * OID of the `path` type.
	 */
	const PATH = 602;
	/**
	 * OID of the `box` type.
	 */
	const BOX = 603;
	/**
	 * OID of the `polygon` type.
	 */
	const POLYGON = 604;
	/**
	 * OID of the `line` type.
	 */
	const LINE = 628;
	/**
	 * OID of the `linearray` type.
	 */
	const LINEARRAY = 629;
	/**
	 * OID of the `float4` type.
	 */
	const FLOAT4 = 700;
	/**
	 * OID of the `float8` type.
	 */
	const FLOAT8 = 701;
	/**
	 * OID of the `abstime` type.
	 */
	const ABSTIME = 702;
	/**
	 * OID of the `reltime` type.
	 */
	const RELTIME = 703;
	/**
	 * OID of the `tinterval` type.
	 */
	const TINTERVAL = 704;
	/**
	 * OID of the `unknown` type.
	 */
	const UNKNOWN = 705;
	/**
	 * OID of the `circle` type.
	 */
	const CIRCLE = 718;
	/**
	 * OID of the `circlearray` type.
	 */
	const CIRCLEARRAY = 719;
	/**
	 * OID of the `money` type.
	 */
	const MONEY = 790;
	/**
	 * OID of the `moneyarray` type.
	 */
	const MONEYARRAY = 791;
	/**
	 * OID of the `macaddr` type.
	 */
	const MACADDR = 829;
	/**
	 * OID of the `inet` type.
	 */
	const INET = 869;
	/**
	 * OID of the `cidr` type.
	 */
	const CIDR = 650;
	/**
	 * OID of the `boolarray` type.
	 */
	const BOOLARRAY = 1000;
	/**
	 * OID of the `byteaarray` type.
	 */
	const BYTEAARRAY = 1001;
	/**
	 * OID of the `chararray` type.
	 */
	const CHARARRAY = 1002;
	/**
	 * OID of the `namearray` type.
	 */
	const NAMEARRAY = 1003;
	/**
	 * OID of the `int2array` type.
	 */
	const INT2ARRAY = 1005;
	/**
	 * OID of the `int2vectorarray` type.
	 */
	const INT2VECTORARRAY = 1006;
	/**
	 * OID of the `int4array` type.
	 */
	const INT4ARRAY = 1007;
	/**
	 * OID of the `regprocarray` type.
	 */
	const REGPROCARRAY = 1008;
	/**
	 * OID of the `textarray` type.
	 */
	const TEXTARRAY = 1009;
	/**
	 * OID of the `oidarray` type.
	 */
	const OIDARRAY = 1028;
	/**
	 * OID of the `tidarray` type.
	 */
	const TIDARRAY = 1010;
	/**
	 * OID of the `xidarray` type.
	 */
	const XIDARRAY = 1011;
	/**
	 * OID of the `cidarray` type.
	 */
	const CIDARRAY = 1012;
	/**
	 * OID of the `oidvectorarray` type.
	 */
	const OIDVECTORARRAY = 1013;
	/**
	 * OID of the `bpchararray` type.
	 */
	const BPCHARARRAY = 1014;
	/**
	 * OID of the `varchararray` type.
	 */
	const VARCHARARRAY = 1015;
	/**
	 * OID of the `int8array` type.
	 */
	const INT8ARRAY = 1016;
	/**
	 * OID of the `pointarray` type.
	 */
	const POINTARRAY = 1017;
	/**
	 * OID of the `lsegarray` type.
	 */
	const LSEGARRAY = 1018;
	/**
	 * OID of the `patharray` type.
	 */
	const PATHARRAY = 1019;
	/**
	 * OID of the `boxarray` type.
	 */
	const BOXARRAY = 1020;
	/**
	 * OID of the `float4array` type.
	 */
	const FLOAT4ARRAY = 1021;
	/**
	 * OID of the `float8array` type.
	 */
	const FLOAT8ARRAY = 1022;
	/**
	 * OID of the `abstimearray` type.
	 */
	const ABSTIMEARRAY = 1023;
	/**
	 * OID of the `reltimearray` type.
	 */
	const RELTIMEARRAY = 1024;
	/**
	 * OID of the `tintervalarray` type.
	 */
	const TINTERVALARRAY = 1025;
	/**
	 * OID of the `polygonarray` type.
	 */
	const POLYGONARRAY = 1027;
	/**
	 * OID of the `aclitem` type.
	 */
	const ACLITEM = 1033;
	/**
	 * OID of the `aclitemarray` type.
	 */
	const ACLITEMARRAY = 1034;
	/**
	 * OID of the `macaddrarray` type.
	 */
	const MACADDRARRAY = 1040;
	/**
	 * OID of the `inetarray` type.
	 */
	const INETARRAY = 1041;
	/**
	 * OID of the `cidrarray` type.
	 */
	const CIDRARRAY = 651;
	/**
	 * OID of the `cstringarray` type.
	 */
	const CSTRINGARRAY = 1263;
	/**
	 * OID of the `bpchar` type.
	 */
	const BPCHAR = 1042;
	/**
	 * OID of the `varchar` type.
	 */
	const VARCHAR = 1043;
	/**
	 * OID of the `date` type.
	 */
	const DATE = 1082;
	/**
	 * OID of the `time` type.
	 */
	const TIME = 1083;
	/**
	 * OID of the `timestamp` type.
	 */
	const TIMESTAMP = 1114;
	/**
	 * OID of the `timestamparray` type.
	 */
	const TIMESTAMPARRAY = 1115;
	/**
	 * OID of the `datearray` type.
	 */
	const DATEARRAY = 1182;
	/**
	 * OID of the `timearray` type.
	 */
	const TIMEARRAY = 1183;
	/**
	 * OID of the `timestamptz` type.
	 */
	const TIMESTAMPTZ = 1184;
	/**
	 * OID of the `timestamptzarray` type.
	 */
	const TIMESTAMPTZARRAY = 1185;
	/**
	 * OID of the `interval` type.
	 */
	const INTERVAL = 1186;
	/**
	 * OID of the `intervalarray` type.
	 */
	const INTERVALARRAY = 1187;
	/**
	 * OID of the `numericarray` type.
	 */
	const NUMERICARRAY = 1231;
	/**
	 * OID of the `timetz` type.
	 */
	const TIMETZ = 1266;
	/**
	 * OID of the `timetzarray` type.
	 */
	const TIMETZARRAY = 1270;
	/**
	 * OID of the `bit` type.
	 */
	const BIT = 1560;
	/**
	 * OID of the `bitarray` type.
	 */
	const BITARRAY = 1561;
	/**
	 * OID of the `varbit` type.
	 */
	const VARBIT = 1562;
	/**
	 * OID of the `varbitarray` type.
	 */
	const VARBITARRAY = 1563;
	/**
	 * OID of the `numeric` type.
	 */
	const NUMERIC = 1700;
	/**
	 * OID of the `refcursor` type.
	 */
	const REFCURSOR = 1790;
	/**
	 * OID of the `refcursorarray` type.
	 */
	const REFCURSORARRAY = 2201;
	/**
	 * OID of the `regprocedure` type.
	 */
	const REGPROCEDURE = 2202;
	/**
	 * OID of the `regoper` type.
	 */
	const REGOPER = 2203;
	/**
	 * OID of the `regoperator` type.
	 */
	const REGOPERATOR = 2204;
	/**
	 * OID of the `regclass` type.
	 */
	const REGCLASS = 2205;
	/**
	 * OID of the `regtype` type.
	 */
	const REGTYPE = 2206;
	/**
	 * OID of the `regprocedurearray` type.
	 */
	const REGPROCEDUREARRAY = 2207;
	/**
	 * OID of the `regoperarray` type.
	 */
	const REGOPERARRAY = 2208;
	/**
	 * OID of the `regoperatorarray` type.
	 */
	const REGOPERATORARRAY = 2209;
	/**
	 * OID of the `regclassarray` type.
	 */
	const REGCLASSARRAY = 2210;
	/**
	 * OID of the `regtypearray` type.
	 */
	const REGTYPEARRAY = 2211;
	/**
	 * OID of the `uuid` type.
	 */
	const UUID = 2950;
	/**
	 * OID of the `uuidarray` type.
	 */
	const UUIDARRAY = 2951;
	/**
	 * OID of the `tsvector` type.
	 */
	const TSVECTOR = 3614;
	/**
	 * OID of the `gtsvector` type.
	 */
	const GTSVECTOR = 3642;
	/**
	 * OID of the `tsquery` type.
	 */
	const TSQUERY = 3615;
	/**
	 * OID of the `regconfig` type.
	 */
	const REGCONFIG = 3734;
	/**
	 * OID of the `regdictionary` type.
	 */
	const REGDICTIONARY = 3769;
	/**
	 * OID of the `tsvectorarray` type.
	 */
	const TSVECTORARRAY = 3643;
	/**
	 * OID of the `gtsvectorarray` type.
	 */
	const GTSVECTORARRAY = 3644;
	/**
	 * OID of the `tsqueryarray` type.
	 */
	const TSQUERYARRAY = 3645;
	/**
	 * OID of the `regconfigarray` type.
	 */
	const REGCONFIGARRAY = 3735;
	/**
	 * OID of the `regdictionaryarray` type.
	 */
	const REGDICTIONARYARRAY = 3770;
	/**
	 * OID of the `txid_snapshot` type.
	 */
	const TXID_SNAPSHOT = 2970;
	/**
	 * OID of the `txid_snapshotarray` type.
	 */
	const TXID_SNAPSHOTARRAY = 2949;
	/**
	 * OID of the `int4range` type.
	 */
	const INT4RANGE = 3904;
	/**
	 * OID of the `int4rangearray` type.
	 */
	const INT4RANGEARRAY = 3905;
	/**
	 * OID of the `numrange` type.
	 */
	const NUMRANGE = 3906;
	/**
	 * OID of the `numrangearray` type.
	 */
	const NUMRANGEARRAY = 3907;
	/**
	 * OID of the `tsrange` type.
	 */
	const TSRANGE = 3908;
	/**
	 * OID of the `tsrangearray` type.
	 */
	const TSRANGEARRAY = 3909;
	/**
	 * OID of the `tstzrange` type.
	 */
	const TSTZRANGE = 3910;
	/**
	 * OID of the `tstzrangearray` type.
	 */
	const TSTZRANGEARRAY = 3911;
	/**
	 * OID of the `daterange` type.
	 */
	const DATERANGE = 3912;
	/**
	 * OID of the `daterangearray` type.
	 */
	const DATERANGEARRAY = 3913;
	/**
	 * OID of the `int8range` type.
	 */
	const INT8RANGE = 3926;
	/**
	 * OID of the `int8rangearray` type.
	 */
	const INT8RANGEARRAY = 3927;
	/**
	 * OID of the `record` type.
	 */
	const RECORD = 2249;
	/**
	 * OID of the `recordarray` type.
	 */
	const RECORDARRAY = 2287;
	/**
	 * OID of the `cstring` type.
	 */
	const CSTRING = 2275;
	/**
	 * OID of the `any` type.
	 */
	const ANY = 2276;
	/**
	 * OID of the `anyarray` type.
	 */
	const ANYARRAY = 2277;
	/**
	 * OID of the `void` type.
	 */
	const VOID = 2278;
	/**
	 * OID of the `trigger` type.
	 */
	const TRIGGER = 2279;
	/**
	 * OID of the `event_trigger` type.
	 */
	const EVENT_TRIGGER = 3838;
	/**
	 * OID of the `language_handler` type.
	 */
	const LANGUAGE_HANDLER = 2280;
	/**
	 * OID of the `internal` type.
	 */
	const INTERNAL = 2281;
	/**
	 * OID of the `opaque` type.
	 */
	const OPAQUE = 2282;
	/**
	 * OID of the `anyelement` type.
	 */
	const ANYELEMENT = 2283;
	/**
	 * OID of the `anynonarray` type.
	 */
	const ANYNONARRAY = 2776;
	/**
	 * OID of the `anyenum` type.
	 */
	const ANYENUM = 3500;
	/**
	 * OID of the `fdw_handler` type.
	 */
	const FDW_HANDLER = 3115;
	/**
	 * OID of the `anyrange` type.
	 */
	const ANYRANGE = 3831;
	/**
	 * The connection which was used to obtain type information.
	 *
	 * @public
	 * @readonly
	 * @var \pq\Connection
	 */
	public $connection;
	/**
	 * Create a new instance populated with information obtained from the `pg_type` relation.
	 *
	 * @param \pq\Connection $conn The connection to use.
	 * @param array $namespaces Which namespaces to query (defaults to `public` and `pg_catalog`).
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 */
	function __construct(\pq\Connection $conn, array $namespaces = NULL) {}
	/**
	 * Refresh type information from `pg_type`.
	 *
	 * @param array $namespaces Which namespaces to query (defaults to `public` and `pg_catalog`).
	 * @throws \pq\Exception\InvalidArgumentException
	 * @throws \pq\Exception\BadMethodCallException
	 * @throws \pq\Exception\RuntimeException
	 */
	function refresh(array $namespaces = NULL) {}
}
namespace pq\Exception;
/**
*<div id="class.badmethodcallexception" class="reference"> <h1 class="title">The BadMethodCallException class</h1>   <div class="partintro"><p class="verinfo">(PHP 5 &gt;= 5.1.0, PHP 7)</p>   <div class="section" id="badmethodcallexception.intro">   <h2 class="title">简介</h2>   <p class="para">    当一个回调方法是一个未定义的方法或缺失一些参数时会抛出该异常。   </p>  </div>   <div class="section" id="badmethodcallexception.synopsis">   <h2 class="title">类摘要</h2>    <div class="classsynopsis">    <div class="ooclass"></div>     <div class="classsynopsisinfo">     <span class="ooclass">      <strong class="classname">BadMethodCallException</strong>     </span>     <span class="ooclass">      <span class="modifier">extends</span>      <a href="http://php.net/manual/zh/class.badfunctioncallexception.php" class="classname">BadFunctionCallException</a>     </span>     {</div>     <div class="classsynopsisinfo classsynopsisinfo_comment">// 继承的属性 </div>    <div class="fieldsynopsis">     <span class="modifier">protected</span>     <span class="type" style="color:#EAB766">string</span>      <var class="varname"><a href="http://php.net/manual/zh/class.exception.php#exception.props.message">$<var class="varname">message</var></a></var>    ;</div><div class="fieldsynopsis">     <span class="modifier">protected</span>     <span class="type" style="color:#EAB766">int</span>      <var class="varname"><a href="http://php.net/manual/zh/class.exception.php#exception.props.code">$<var class="varname">code</var></a></var>    ;</div><div class="fieldsynopsis">     <span class="modifier">protected</span>     <span class="type" style="color:#EAB766">string</span>      <var class="varname"><a href="http://php.net/manual/zh/class.exception.php#exception.props.file">$<var class="varname">file</var></a></var>    ;</div><div class="fieldsynopsis">     <span class="modifier">protected</span>     <span class="type" style="color:#EAB766">int</span>      <var class="varname"><a href="http://php.net/manual/zh/class.exception.php#exception.props.line">$<var class="varname">line</var></a></var>    ;</div>   <div class="classsynopsisinfo classsynopsisinfo_comment">// 继承的方法 </div>    <div class="methodsynopsis dc-description">   <span class="modifier">final</span> <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link Exception::getMessage}</span>    (   ) : <span class="type" style="color:#EAB766">string</span></div><div class="methodsynopsis dc-description">   <span class="modifier">final</span> <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link Exception::getPrevious}</span>    (   ) : <span class="type" style="color:#EAB766"><span class="type Throwable" style="color:#EAB766">Throwable</span></span></div><div class="methodsynopsis dc-description">   <span class="modifier">final</span> <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link Exception::getCode}</span>    (   ) : <span class="type" style="color:#EAB766">int</span></div><div class="methodsynopsis dc-description">   <span class="modifier">final</span> <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link Exception::getFile}</span>    (   ) : <span class="type" style="color:#EAB766">string</span></div><div class="methodsynopsis dc-description">   <span class="modifier">final</span> <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link Exception::getLine}</span>    (   ) : <span class="type" style="color:#EAB766">int</span></div><div class="methodsynopsis dc-description">   <span class="modifier">final</span> <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link Exception::getTrace}</span>    (   ) : <span class="type" style="color:#EAB766">array</span></div><div class="methodsynopsis dc-description">   <span class="modifier">final</span> <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link Exception::getTraceAsString}</span>    (   ) : <span class="type" style="color:#EAB766">string</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span>  <span class="methodname" style="color:#CC7832">{@link Exception::__toString}</span>    (   ) : <span class="type" style="color:#EAB766">string</span></div><div class="methodsynopsis dc-description">   <span class="modifier">final</span> <span class="modifier">private</span> <span class="methodname" style="color:#CC7832">{@link Exception::__clone}</span>    (   ) : <span class="type" style="color:#EAB766"><span class="type void" style="color:#EAB766">void</span></span></div>   }</div>   </div>  </div>   </div>
*/
class BadMethodCallException extends \BadMethodCallException implements \pq\Exception {
}
/**
*<div id="class.domainexception" class="reference"> <h1 class="title">The DomainException class</h1>   <div class="partintro"><p class="verinfo">(PHP 5 &gt;= 5.1.0, PHP 7)</p>   <div class="section" id="domainexception.intro">   <h2 class="title">简介</h2>   <p class="para">    Exception thrown if a value does not adhere to a defined valid data domain.   </p>  </div>   <div class="section" id="domainexception.synopsis">   <h2 class="title">类摘要</h2>    <div class="classsynopsis">    <div class="ooclass"></div>     <div class="classsynopsisinfo">     <span class="ooclass">      <strong class="classname">DomainException</strong>     </span>     <span class="ooclass">      <span class="modifier">extends</span>      <a href="http://php.net/manual/zh/class.logicexception.php" class="classname">LogicException</a>     </span>     {</div>     <div class="classsynopsisinfo classsynopsisinfo_comment">// 继承的属性 </div>    <div class="fieldsynopsis">     <span class="modifier">protected</span>     <span class="type" style="color:#EAB766">string</span>      <var class="varname"><a href="http://php.net/manual/zh/class.exception.php#exception.props.message">$<var class="varname">message</var></a></var>    ;</div><div class="fieldsynopsis">     <span class="modifier">protected</span>     <span class="type" style="color:#EAB766">int</span>      <var class="varname"><a href="http://php.net/manual/zh/class.exception.php#exception.props.code">$<var class="varname">code</var></a></var>    ;</div><div class="fieldsynopsis">     <span class="modifier">protected</span>     <span class="type" style="color:#EAB766">string</span>      <var class="varname"><a href="http://php.net/manual/zh/class.exception.php#exception.props.file">$<var class="varname">file</var></a></var>    ;</div><div class="fieldsynopsis">     <span class="modifier">protected</span>     <span class="type" style="color:#EAB766">int</span>      <var class="varname"><a href="http://php.net/manual/zh/class.exception.php#exception.props.line">$<var class="varname">line</var></a></var>    ;</div>   <div class="classsynopsisinfo classsynopsisinfo_comment">// 继承的方法 </div>    <div class="constructorsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link Exception::__construct}</span>    ([ <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$message</span><span class="initializer"> = &quot;&quot;</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$code</span><span class="initializer"> = 0</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766"><span class="type Throwable" style="color:#EAB766">Throwable</span></span> <span class="parameter" style="color:#3A95FF">$previous</span><span class="initializer"> = <strong><span>NULL</span></strong></span></span>  ]]] )</div>    <div class="methodsynopsis dc-description">   <span class="modifier">final</span> <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link Exception::getMessage}</span>    (   ) : <span class="type" style="color:#EAB766">string</span></div><div class="methodsynopsis dc-description">   <span class="modifier">final</span> <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link Exception::getPrevious}</span>    (   ) : <span class="type" style="color:#EAB766"><span class="type Throwable" style="color:#EAB766">Throwable</span></span></div><div class="methodsynopsis dc-description">   <span class="modifier">final</span> <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link Exception::getCode}</span>    (   ) : <span class="type" style="color:#EAB766">int</span></div><div class="methodsynopsis dc-description">   <span class="modifier">final</span> <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link Exception::getFile}</span>    (   ) : <span class="type" style="color:#EAB766">string</span></div><div class="methodsynopsis dc-description">   <span class="modifier">final</span> <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link Exception::getLine}</span>    (   ) : <span class="type" style="color:#EAB766">int</span></div><div class="methodsynopsis dc-description">   <span class="modifier">final</span> <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link Exception::getTrace}</span>    (   ) : <span class="type" style="color:#EAB766">array</span></div><div class="methodsynopsis dc-description">   <span class="modifier">final</span> <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link Exception::getTraceAsString}</span>    (   ) : <span class="type" style="color:#EAB766">string</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span>  <span class="methodname" style="color:#CC7832">{@link Exception::__toString}</span>    (   ) : <span class="type" style="color:#EAB766">string</span></div><div class="methodsynopsis dc-description">   <span class="modifier">final</span> <span class="modifier">private</span> <span class="methodname" style="color:#CC7832">{@link Exception::__clone}</span>    (   ) : <span class="type" style="color:#EAB766"><span class="type void" style="color:#EAB766">void</span></span></div>   }</div>   </div>  </div>   </div>
*/
class DomainException extends \DomainException implements \pq\Exception {
	/**
	 * The SQLSTATE code, see the [official documentation](http://www.postgresql.org/docs/current/static/errcodes-appendix.html) for further information.
	 *
	 * @public
	 * @readonly
	 * @var string
	 */
	public $sqlstate;
}
/**
*<div id="class.invalidargumentexception" class="reference"> <h1 class="title">The InvalidArgumentException class</h1>   <div class="partintro"><p class="verinfo">(PHP 5 &gt;= 5.1.0, PHP 7)</p>   <div class="section" id="invalidargumentexception.intro">   <h2 class="title">简介</h2>   <p class="para">    Exception thrown if an argument is not of the expected type.   </p>  </div>   <div class="section" id="invalidargumentexception.synopsis">   <h2 class="title">类摘要</h2>    <div class="classsynopsis">    <div class="ooclass"></div>     <div class="classsynopsisinfo">     <span class="ooclass">      <strong class="classname">InvalidArgumentException</strong>     </span>     <span class="ooclass">      <span class="modifier">extends</span>      <a href="http://php.net/manual/zh/class.logicexception.php" class="classname">LogicException</a>     </span>     {</div>     <div class="classsynopsisinfo classsynopsisinfo_comment">// 继承的属性 </div>    <div class="fieldsynopsis">     <span class="modifier">protected</span>     <span class="type" style="color:#EAB766">string</span>      <var class="varname"><a href="http://php.net/manual/zh/class.exception.php#exception.props.message">$<var class="varname">message</var></a></var>    ;</div><div class="fieldsynopsis">     <span class="modifier">protected</span>     <span class="type" style="color:#EAB766">int</span>      <var class="varname"><a href="http://php.net/manual/zh/class.exception.php#exception.props.code">$<var class="varname">code</var></a></var>    ;</div><div class="fieldsynopsis">     <span class="modifier">protected</span>     <span class="type" style="color:#EAB766">string</span>      <var class="varname"><a href="http://php.net/manual/zh/class.exception.php#exception.props.file">$<var class="varname">file</var></a></var>    ;</div><div class="fieldsynopsis">     <span class="modifier">protected</span>     <span class="type" style="color:#EAB766">int</span>      <var class="varname"><a href="http://php.net/manual/zh/class.exception.php#exception.props.line">$<var class="varname">line</var></a></var>    ;</div>   <div class="classsynopsisinfo classsynopsisinfo_comment">// 继承的方法 </div>    <div class="constructorsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link Exception::__construct}</span>    ([ <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$message</span><span class="initializer"> = &quot;&quot;</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$code</span><span class="initializer"> = 0</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766"><span class="type Throwable" style="color:#EAB766">Throwable</span></span> <span class="parameter" style="color:#3A95FF">$previous</span><span class="initializer"> = <strong><span>NULL</span></strong></span></span>  ]]] )</div>    <div class="methodsynopsis dc-description">   <span class="modifier">final</span> <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link Exception::getMessage}</span>    (   ) : <span class="type" style="color:#EAB766">string</span></div><div class="methodsynopsis dc-description">   <span class="modifier">final</span> <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link Exception::getPrevious}</span>    (   ) : <span class="type" style="color:#EAB766"><span class="type Throwable" style="color:#EAB766">Throwable</span></span></div><div class="methodsynopsis dc-description">   <span class="modifier">final</span> <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link Exception::getCode}</span>    (   ) : <span class="type" style="color:#EAB766">int</span></div><div class="methodsynopsis dc-description">   <span class="modifier">final</span> <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link Exception::getFile}</span>    (   ) : <span class="type" style="color:#EAB766">string</span></div><div class="methodsynopsis dc-description">   <span class="modifier">final</span> <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link Exception::getLine}</span>    (   ) : <span class="type" style="color:#EAB766">int</span></div><div class="methodsynopsis dc-description">   <span class="modifier">final</span> <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link Exception::getTrace}</span>    (   ) : <span class="type" style="color:#EAB766">array</span></div><div class="methodsynopsis dc-description">   <span class="modifier">final</span> <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link Exception::getTraceAsString}</span>    (   ) : <span class="type" style="color:#EAB766">string</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span>  <span class="methodname" style="color:#CC7832">{@link Exception::__toString}</span>    (   ) : <span class="type" style="color:#EAB766">string</span></div><div class="methodsynopsis dc-description">   <span class="modifier">final</span> <span class="modifier">private</span> <span class="methodname" style="color:#CC7832">{@link Exception::__clone}</span>    (   ) : <span class="type" style="color:#EAB766"><span class="type void" style="color:#EAB766">void</span></span></div>   }</div>   </div> </div>   </div>
*/
class InvalidArgumentException extends \InvalidArgumentException implements \pq\Exception {
}
/**
*<div id="class.runtimeexception" class="reference"> <h1 class="title">The RuntimeException class</h1>   <div class="partintro"><p class="verinfo">(PHP 5 &gt;= 5.1.0, PHP 7)</p>   <div class="section" id="runtimeexception.intro">   <h2 class="title">简介</h2>   <p class="para">    Exception thrown if an error which can only be found on runtime occurs.   </p>  </div>   <div class="section" id="runtimeexception.synopsis">   <h2 class="title">类摘要</h2>    <div class="classsynopsis">    <div class="ooclass"></div>     <div class="classsynopsisinfo">     <span class="ooclass">      <strong class="classname">RuntimeException</strong>     </span>     <span class="ooclass">      <span class="modifier">extends</span>      <a href="http://php.net/manual/zh/class.exception.php" class="classname">Exception</a>     </span>     {</div>     <div class="classsynopsisinfo classsynopsisinfo_comment">// 继承的属性 </div>    <div class="fieldsynopsis">     <span class="modifier">protected</span>     <span class="type" style="color:#EAB766">string</span>      <var class="varname"><a href="http://php.net/manual/zh/class.exception.php#exception.props.message">$<var class="varname">message</var></a></var>    ;</div><div class="fieldsynopsis">     <span class="modifier">protected</span>     <span class="type" style="color:#EAB766">int</span>      <var class="varname"><a href="http://php.net/manual/zh/class.exception.php#exception.props.code">$<var class="varname">code</var></a></var>    ;</div><div class="fieldsynopsis">     <span class="modifier">protected</span>     <span class="type" style="color:#EAB766">string</span>      <var class="varname"><a href="http://php.net/manual/zh/class.exception.php#exception.props.file">$<var class="varname">file</var></a></var>    ;</div><div class="fieldsynopsis">     <span class="modifier">protected</span>     <span class="type" style="color:#EAB766">int</span>      <var class="varname"><a href="http://php.net/manual/zh/class.exception.php#exception.props.line">$<var class="varname">line</var></a></var>    ;</div>   <div class="classsynopsisinfo classsynopsisinfo_comment">// 继承的方法 </div>    <div class="constructorsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link Exception::__construct}</span>    ([ <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$message</span><span class="initializer"> = &quot;&quot;</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$code</span><span class="initializer"> = 0</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766"><span class="type Throwable" style="color:#EAB766">Throwable</span></span> <span class="parameter" style="color:#3A95FF">$previous</span><span class="initializer"> = <strong><span>NULL</span></strong></span></span>  ]]] )</div>    <div class="methodsynopsis dc-description">   <span class="modifier">final</span> <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link Exception::getMessage}</span>    (   ) : <span class="type" style="color:#EAB766">string</span></div><div class="methodsynopsis dc-description">   <span class="modifier">final</span> <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link Exception::getPrevious}</span>    (   ) : <span class="type" style="color:#EAB766"><span class="type Throwable" style="color:#EAB766">Throwable</span></span></div><div class="methodsynopsis dc-description">   <span class="modifier">final</span> <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link Exception::getCode}</span>    (   ) : <span class="type" style="color:#EAB766">int</span></div><div class="methodsynopsis dc-description">   <span class="modifier">final</span> <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link Exception::getFile}</span>    (   ) : <span class="type" style="color:#EAB766">string</span></div><div class="methodsynopsis dc-description">   <span class="modifier">final</span> <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link Exception::getLine}</span>    (   ) : <span class="type" style="color:#EAB766">int</span></div><div class="methodsynopsis dc-description">   <span class="modifier">final</span> <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link Exception::getTrace}</span>    (   ) : <span class="type" style="color:#EAB766">array</span></div><div class="methodsynopsis dc-description">   <span class="modifier">final</span> <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link Exception::getTraceAsString}</span>    (   ) : <span class="type" style="color:#EAB766">string</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span>  <span class="methodname" style="color:#CC7832">{@link Exception::__toString}</span>    (   ) : <span class="type" style="color:#EAB766">string</span></div><div class="methodsynopsis dc-description">   <span class="modifier">final</span> <span class="modifier">private</span> <span class="methodname" style="color:#CC7832">{@link Exception::__clone}</span>    (   ) : <span class="type" style="color:#EAB766"><span class="type void" style="color:#EAB766">void</span></span></div>   }</div>   </div>  </div>   </div>
*/
class RuntimeException extends \RuntimeException implements \pq\Exception {
}
