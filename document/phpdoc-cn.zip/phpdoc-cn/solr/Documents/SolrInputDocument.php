<?php
/**
 * Helper autocomplete for php solr extension.
 *
 * @author Pierre-Julien Mazenot <pj.mazenot@gmail.com>
 * @link   https://github.com/pjmazenot/phpsolr-phpdoc
 */

/**
*<div id="class.solrinputdocument" class="reference"> <h1 class="title">The SolrInputDocument class</h1>  <div class="partintro"><p class="verinfo">(PECL solr &gt;= 0.9.2)</p>  <div class="section" id="solrinputdocument.intro">   <h2 class="title">简介</h2>   <p class="para">    This class represents a Solr document that is about to be submitted to the Solr index.   </p>  </div>  <div class="section" id="solrinputdocument.synopsis">   <h2 class="title">类摘要</h2>   <div class="classsynopsis">    <div class="ooclass"></div>    <div class="classsynopsisinfo">     <span class="ooclass">      <span class="modifier">final</span>      <strong class="classname">SolrInputDocument</strong>     </span>     {</div>    <div class="classsynopsisinfo classsynopsisinfo_comment">// 常量 </div>    <div class="fieldsynopsis">     <span class="modifier">const</span>     <span class="type" style="color:#EAB766">int</span>      <var class="fieldsynopsis_varname"><a href="http://php.net/manual/zh/class.solrinputdocument.php#solrinputdocument.constants.sort-default"><var class="varname">SORT_DEFAULT</var></a></var>     <span class="initializer"> = 1</span>    ;</div>    <div class="fieldsynopsis">     <span class="modifier">const</span>     <span class="type" style="color:#EAB766">int</span>      <var class="fieldsynopsis_varname"><a href="http://php.net/manual/zh/class.solrinputdocument.php#solrinputdocument.constants.sort-asc"><var class="varname">SORT_ASC</var></a></var>     <span class="initializer"> = 1</span>    ;</div>    <div class="fieldsynopsis">     <span class="modifier">const</span>     <span class="type" style="color:#EAB766">int</span>      <var class="fieldsynopsis_varname"><a href="http://php.net/manual/zh/class.solrinputdocument.php#solrinputdocument.constants.sort-desc"><var class="varname">SORT_DESC</var></a></var>     <span class="initializer"> = 2</span>    ;</div>    <div class="fieldsynopsis">     <span class="modifier">const</span>     <span class="type" style="color:#EAB766">int</span>      <var class="fieldsynopsis_varname"><a href="http://php.net/manual/zh/class.solrinputdocument.php#solrinputdocument.constants.sort-field-name"><var class="varname">SORT_FIELD_NAME</var></a></var>     <span class="initializer"> = 1</span>    ;</div>    <div class="fieldsynopsis">     <span class="modifier">const</span>     <span class="type" style="color:#EAB766">int</span>      <var class="fieldsynopsis_varname"><a href="http://php.net/manual/zh/class.solrinputdocument.php#solrinputdocument.constants.sort-field-value-count"><var class="varname">SORT_FIELD_VALUE_COUNT</var></a></var>     <span class="initializer"> = 2</span>    ;</div>    <div class="fieldsynopsis">     <span class="modifier">const</span>     <span class="type" style="color:#EAB766">int</span>      <var class="fieldsynopsis_varname"><a href="http://php.net/manual/zh/class.solrinputdocument.php#solrinputdocument.constants.sort-field-boost-value"><var class="varname">SORT_FIELD_BOOST_VALUE</var></a></var>     <span class="initializer"> = 4</span>    ;</div>        <div class="classsynopsisinfo classsynopsisinfo_comment">// 方法 </div>    <div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/solrinputdocument.addchilddocument.php" class="methodname" style="color:#CC7832">addChildDocument</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766"><a href="http://php.net/manual/zh/class.solrinputdocument.php" class="type SolrInputDocument" style="color:#EAB766">SolrInputDocument</a></span> <span class="parameter" style="color:#3A95FF">$child</span></span>   ) : <span class="type" style="color:#EAB766"><span class="type void" style="color:#EAB766">void</span></span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/solrinputdocument.addchilddocuments.php" class="methodname" style="color:#CC7832">addChildDocuments</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">array</span> <span class="parameter" style="color:#3A95FF">&$docs</span></span>   ) : <span class="type" style="color:#EAB766"><span class="type void" style="color:#EAB766">void</span></span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/solrinputdocument.addfield.php" class="methodname" style="color:#CC7832">addField</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$fieldName</span></span>   , <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$fieldValue</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">float</span> <span class="parameter" style="color:#3A95FF">$fieldBoostValue</span><span class="initializer"> = 0.0</span></span>  ] ) : <span class="type" style="color:#EAB766">bool</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/solrinputdocument.clear.php" class="methodname" style="color:#CC7832">clear</a></span>    (   ) : <span class="type" style="color:#EAB766">bool</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/solrinputdocument.clone.php" class="methodname" style="color:#CC7832">__clone</a></span>    (   ) : <span class="type" style="color:#EAB766"><span class="type void" style="color:#EAB766">void</span></span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/solrinputdocument.construct.php" class="methodname" style="color:#CC7832">__construct</a></span>    (   )</div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/solrinputdocument.deletefield.php" class="methodname" style="color:#CC7832">deleteField</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$fieldName</span></span>   ) : <span class="type" style="color:#EAB766">bool</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/solrinputdocument.destruct.php" class="methodname" style="color:#CC7832">__destruct</a></span>    (   ) : <span class="type" style="color:#EAB766"><span class="type void" style="color:#EAB766">void</span></span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/solrinputdocument.fieldexists.php" class="methodname" style="color:#CC7832">fieldExists</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$fieldName</span></span>   ) : <span class="type" style="color:#EAB766">bool</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/solrinputdocument.getboost.php" class="methodname" style="color:#CC7832">getBoost</a></span>    (   ) : <span class="type" style="color:#EAB766">float</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/solrinputdocument.getchilddocuments.php" class="methodname" style="color:#CC7832">getChildDocuments</a></span>    (   ) : <span class="type" style="color:#EAB766">array</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/solrinputdocument.getchilddocumentscount.php" class="methodname" style="color:#CC7832">getChildDocumentsCount</a></span>    (   ) : <span class="type" style="color:#EAB766">int</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/solrinputdocument.getfield.php" class="methodname" style="color:#CC7832">getField</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$fieldName</span></span>   ) : <span class="type" style="color:#EAB766"><a href="http://php.net/manual/zh/class.solrdocumentfield.php" class="type SolrDocumentField" style="color:#EAB766">SolrDocumentField</a></span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/solrinputdocument.getfieldboost.php" class="methodname" style="color:#CC7832">getFieldBoost</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$fieldName</span></span>   ) : <span class="type" style="color:#EAB766">float</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/solrinputdocument.getfieldcount.php" class="methodname" style="color:#CC7832">getFieldCount</a></span>    (   ) : <span class="type" style="color:#EAB766"><span class="type" style="color:#EAB766">int</span>|<span class="type" style="color:#EAB766"><span class="type false" style="color:#EAB766">false</span></span></span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/solrinputdocument.getfieldnames.php" class="methodname" style="color:#CC7832">getFieldNames</a></span>    (   ) : <span class="type" style="color:#EAB766">array</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/solrinputdocument.haschilddocuments.php" class="methodname" style="color:#CC7832">hasChildDocuments</a></span>    (   ) : <span class="type" style="color:#EAB766">bool</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/solrinputdocument.merge.php" class="methodname" style="color:#CC7832">merge</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766"><a href="http://php.net/manual/zh/class.solrinputdocument.php" class="type SolrInputDocument" style="color:#EAB766">SolrInputDocument</a></span> <span class="parameter" style="color:#3A95FF">$sourceDoc</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">bool</span> <span class="parameter" style="color:#3A95FF">$overwrite</span><span class="initializer"> = <strong><span>TRUE</span></strong></span></span>  ] ) : <span class="type" style="color:#EAB766">bool</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/solrinputdocument.reset.php" class="methodname" style="color:#CC7832">reset</a></span>    (   ) : <span class="type" style="color:#EAB766">bool</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/solrinputdocument.setboost.php" class="methodname" style="color:#CC7832">setBoost</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">float</span> <span class="parameter" style="color:#3A95FF">$documentBoostValue</span></span>   ) : <span class="type" style="color:#EAB766">bool</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/solrinputdocument.setfieldboost.php" class="methodname" style="color:#CC7832">setFieldBoost</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$fieldName</span></span>   , <span class="methodparam"><span class="type" style="color:#EAB766">float</span> <span class="parameter" style="color:#3A95FF">$fieldBoostValue</span></span>   ) : <span class="type" style="color:#EAB766">bool</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/solrinputdocument.sort.php" class="methodname" style="color:#CC7832">sort</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$sortOrderBy</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$sortDirection</span><span class="initializer"> = SolrInputDocument::SORT_ASC</span></span>  ] ) : <span class="type" style="color:#EAB766">bool</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/solrinputdocument.toarray.php" class="methodname" style="color:#CC7832">toArray</a></span>    (   ) : <span class="type" style="color:#EAB766">array</span></div>   }</div>  </div>    <div class="section" id="solrinputdocument.constants">   <h2 class="title">预定义常量</h2>   <div class="section" id="solrinputdocument.constants.types">    <h2 class="title">SolrInputDocument Class Constants</h2>    <dl>           <dt id="solrinputdocument.constants.sort-default"><strong><span>SolrInputDocument::SORT_DEFAULT</span></strong></dt>      <dd>       <p class="para">Sorts the fields in ascending order.</p>      </dd>                <dt id="solrinputdocument.constants.sort-asc"><strong><span>SolrInputDocument::SORT_ASC</span></strong></dt>      <dd>       <p class="para">Sorts the fields in ascending order.</p>      </dd>                <dt id="solrinputdocument.constants.sort-desc"><strong><span>SolrInputDocument::SORT_DESC</span></strong></dt>      <dd>       <p class="para">Sorts the fields in descending order.</p>      </dd>                <dt id="solrinputdocument.constants.sort-field-name"><strong><span>SolrInputDocument::SORT_FIELD_NAME</span></strong></dt>      <dd>       <p class="para">Sorts the fields by name</p>      </dd>                <dt id="solrinputdocument.constants.sort-field-value-count"><strong><span>SolrInputDocument::SORT_FIELD_VALUE_COUNT</span></strong></dt>      <dd>       <p class="para">Sorts the fields by number of values.</p>      </dd>                <dt id="solrinputdocument.constants.sort-field-boost-value"><strong><span>SolrInputDocument::SORT_FIELD_BOOST_VALUE</span></strong></dt>      <dd>       <p class="para">Sorts the fields by boost value.</p>      </dd>         </dl>   </div>  </div> </div> <h2>Table of Contents</h2><ul class="chunklist chunklist_reference"><li>{@link SolrInputDocument::addChildDocument} — Adds a child document for block indexing</li><li>{@link SolrInputDocument::addChildDocuments} — Adds an array of child documents</li><li>{@link SolrInputDocument::addField} — Adds a field to the document</li><li>{@link SolrInputDocument::clear} — Resets the input document</li><li>{@link SolrInputDocument::__clone} — Creates a copy of a SolrDocument</li><li>{@link SolrInputDocument::__construct} — Constructor</li><li>{@link SolrInputDocument::deleteField} — Removes a field from the document</li><li>{@link SolrInputDocument::__destruct} — Destructor</li><li>{@link SolrInputDocument::fieldExists} — Checks if a field exists</li><li>{@link SolrInputDocument::getBoost} — Retrieves the current boost value for the document</li><li>{@link SolrInputDocument::getChildDocuments} — Returns an array of child documents (SolrInputDocument)</li><li>{@link SolrInputDocument::getChildDocumentsCount} — Returns the number of child documents</li><li>{@link SolrInputDocument::getField} — Retrieves a field by name</li><li>{@link SolrInputDocument::getFieldBoost} — Retrieves the boost value for a particular field</li><li>{@link SolrInputDocument::getFieldCount} — Returns the number of fields in the document</li><li>{@link SolrInputDocument::getFieldNames} — Returns an array containing all the fields in the document</li><li>{@link SolrInputDocument::hasChildDocuments} — Returns true if the document has any child documents</li><li>{@link SolrInputDocument::merge} — Merges one input document into another</li><li>{@link SolrInputDocument::reset} — This is an alias of SolrInputDocument::clear</li><li>{@link SolrInputDocument::setBoost} — Sets the boost value for this document</li><li>{@link SolrInputDocument::setFieldBoost} — Sets the index-time boost value for a field</li><li>{@link SolrInputDocument::sort} — Sorts the fields within the document</li><li>{@link SolrInputDocument::toArray} — Returns an array representation of the input document</li></ul></div>
*/
final class SolrInputDocument {

	/** @var int Sorts the fields in ascending order. */
	const SORT_DEFAULT = 1 ;

	/** @var int Sorts the fields in ascending order. */
	const SORT_ASC = 1 ;

	/** @var int Sorts the fields in descending order. */
	const SORT_DESC = 2 ;

	/** @var int Sorts the fields by name */
	const SORT_FIELD_NAME = 1 ;

	/** @var int Sorts the fields by number of values. */
	const SORT_FIELD_VALUE_COUNT = 2 ;

	/** @var int Sorts the fields by boost value. */
	const SORT_FIELD_BOOST_VALUE = 4 ;

	/**
	 * (PECL solr &gt;= 2.3.0)<br/>
	 * Adds a child document for block indexing
	 * @link https://php.net/manual/en/solrinputdocument.addchilddocument.php
	 * @param SolrInputDocument $child <p>
	 * A SolrInputDocument object.
	 * </p>
	 * @throws SolrIllegalArgumentException
	 * @throws SolrException
	 */
	public function addChildDocument(SolrInputDocument $child) {}

	/**
	 * (PECL solr &gt;= 2.3.0)<br/>
	 * Adds an array of child documents
	 * @link https://php.net/manual/en/solrinputdocument.addchilddocuments.php
	 * @param array $docs <p>
	 * An array of SolrInputDocument objects.
	 * </p>
	 * @throws SolrIllegalArgumentException
	 * @throws SolrException
	 */
	public function addChildDocuments(array &$docs) {}

	/**
	 * (PECL solr &gt;= 0.9.2)<br/>
	 * Adds a field to the document
	 * @link https://php.net/manual/en/solrinputdocument.addfield.php
	 * @param string $fieldName <p>
	 * The name of the field
	 * </p>
	 * @param string $fieldValue <p>
	 * The value for the field.
	 * </p>
	 * @param float $fieldBoostValue [optional] <p>
	 * The index time boost for the field. Though this cannot be negative, you can still pass values less than 1.0 but
	 * they must be greater than zero.
	 * </p>
	 * @return bool <p>
	 * Returns <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 * </p>
	 */
	public function addField($fieldName, $fieldValue, $fieldBoostValue = 0.0) {}

	/**
	 * (PECL solr &gt;= 0.9.2)<br/>
	 * Resets the input document
	 * @link https://php.net/manual/en/solrinputdocument.clear.php
	 * @return bool <p>
	 * Returns <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 * </p>
	 */
	public function clear() {}

	/**
	 * (PECL solr &gt;= 0.9.2)<br/>
	 * Creates a copy of a SolrDocument
	 * @link https://php.net/manual/en/solrinputdocument.clone.php
	 */
	public function __clone() {}

	/**
	 * (PECL solr &gt;= 0.9.2)<br/>
	 * SolrInputDocument constructor.
	 * @link https://php.net/manual/en/solrinputdocument.construct.php
	 */
	public function __construct () {}

	/**
	 * (PECL solr &gt;= 0.9.2)<br/>
	 * Removes a field from the document
	 * @link https://php.net/manual/en/solrinputdocument.construct.php
	 * @param string $fieldName <p>
	 * The name of the field.
	 * </p>
	 * @return bool <p>
	 * Returns <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 * </p>
	 */
	public function deleteField($fieldName) {}

	/**
	 * (PECL solr &gt;= 0.9.2)<br/>
	 * Destructor
	 * @link https://php.net/manual/en/solrinputdocument.destruct.php
	 */
	public function __destruct() {}

	/**
	 * (PECL solr &gt;= 0.9.2)<br/>
	 * Checks if a field exists
	 * @link https://php.net/manual/en/solrinputdocument.fieldexists.php
	 * @param string $fieldName <p>
	 * Name of the field.
	 * </p>
	 * @return bool <p>
	 * Returns <b>TRUE</b> if the field was found and <b>FALSE</b> if it was not found.
	 * </p>
	 */
	public function fieldExists($fieldName) {}

	/**
	 * (PECL solr &gt;= 0.9.2)<br/>
	 * Retrieves the current boost value for the document
	 * @link https://php.net/manual/en/solrinputdocument.getboost.php
	 * @return float|false <p>
	 * Returns the boost value on success and <b>FALSE</b> on failure.
	 * </p>
	 */
	public function getBoost() {}

	/**
	 * (PECL solr &gt;= 2.3.0)<br/>
	 * Returns an array of child documents (SolrInputDocument)
	 * @link https://php.net/manual/en/solrinputdocument.getchilddocuments.php
	 * @return SolrInputDocument[]
	 */
	public function getChildDocuments() {}

	/**
	 * (PECL solr &gt;= 2.3.0)<br/>
	 * Returns the number of child documents
	 * @link https://php.net/manual/en/solrinputdocument.getchilddocumentscount.php
	 * @return int
	 */
	public function getChildDocumentsCount() {}

	/**
	 * (PECL solr &gt;= 0.9.2)<br/>
	 * Retrieves a field by name
	 * @link https://php.net/manual/en/solrinputdocument.getfield.php
	 * @param string $fieldName <p>
	 * The name of the field.
	 * </p>
	 * @return SolrDocumentField|false Returns a SolrDocumentField object on success and <b>FALSE</b> on failure.
	 */
	public function getField($fieldName) {}

	/**
	 * (PECL solr &gt;= 0.9.2)<br/>
	 * Retrieves the boost value for a particular field
	 * @link https://php.net/manual/en/solrinputdocument.getfieldboost.php
	 * @param string $fieldName <p>
	 * The name of the field.
	 * </p>
	 * @return float|false <p>
	 * Returns the boost value for the field or <b>FALSE</b> if there was an error.
	 * </p>
	 */
	public function getFieldBoost($fieldName) {}

	/**
	 * (PECL solr &gt;= 0.9.2)<br/>
	 * Returns the number of fields in the document
	 * @link https://php.net/manual/en/solrinputdocument.getfieldcount.php
	 * @return int|false <p>
	 * Returns an integer on success or <b>FALSE</b> on failure.
	 * </p>
	 */
	public function getFieldCount() {}

	/**
	 * (PECL solr &gt;= 0.9.2)<br/>
	 * Returns an array containing all the fields in the document
	 * @link https://php.net/manual/en/solrinputdocument.getfieldnames.php
	 * @return array|false <p>
	 * Returns an array on success and <b>FALSE</b> on failure.
	 * </p>
	 */
	public function getFieldNames() {}

	/**
	 * (PECL solr &gt;= 2.3.0)<br/>
	 * Checks whether the document has any child documents
	 * @link https://php.net/manual/en/solrinputdocument.haschilddocuments.php
	 * @return bool <p>
	 * Returns <b>TRUE</b> if the document has any child documents
	 * </p>
	 */
	public function hasChildDocuments() {}

	/**
	 * (PECL solr &gt;= 0.9.2)<br/>
	 * Merges one input document into another
	 * @link https://php.net/manual/en/solrinputdocument.merge.php
	 * @param SolrInputDocument $sourceDoc <p>
	 * The source document.
	 * </p>
	 * @param bool $overwrite [optional] <p>
	 * If this is <b>TRUE</b> it will replace matching fields in the destination document.
	 * </p>
	 * @return bool <p>
	 * Returns <b>TRUE</b> on success or <b>FALSE</b> on failure. In the future, this will be modified to return the
	 * number of fields in the new document.
	 * </p>
	 */
	public function merge(SolrInputDocument $sourceDoc, $overwrite = true) {}

	/**
	 * (PECL solr &gt;= 0.9.2)<br/>
	 * This is an alias of SolrInputDocument::clear
	 * @link https://php.net/manual/en/solrinputdocument.reset.php
	 * @return bool <p>
	 * Returns <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 * </p>
	 */
/**
*<div id="function.reset" class="refentry"> <div class="refnamediv">  <h1 class="refname">reset</h1>  <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">reset</span> &mdash; <span class="dc-title">将数组的内部指针指向第一个单元</span></p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.reset-description">  <h3 class="title">说明</h3>  <div class="methodsynopsis dc-description">   <span class="methodname" style="color:#CC7832"><strong>reset</strong></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">array</span> <span class="parameter" style="color:#3A95FF">&$array</span></span>   ) : <span class="type" style="color:#EAB766"><a href="http://php.net/manual/zh/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span></div>  <p class="para rdfs-comment">   <span class="function"><strong style="color:#CC7832">reset()</strong></span> 将 <span class="parameter" style="color:#3A95FF">array</span>   的内部指针倒回到第一个单元并返回第一个数组单元的值。  </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.reset-parameters">  <h3 class="title">参数</h3>  <span>   <dl>         <dt><span class="parameter" style="color:#3A95FF">array</span></dt>     <dd>      <p class="para">       输入的数组。      </p>     </dd>       </dl>  </span> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.reset-returnvalues">  <h3 class="title">返回值</h3>  <p class="para">   返回数组第一个单元的值，如果数组为空则返回 <strong><span>FALSE</span></strong>。  </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.reset-examples">  <h3 class="title">范例</h3>  <span>   <div class="example" id="example-5313">    <p><strong>Example #1 <span class="function"><strong style="color:#CC7832">reset()</strong></span> 例子</strong></p>    <div class="example-contents"><div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"><span style="color: #9876AA">&lt;?php<br /><br />$array&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #DD0000">'step&nbsp;one'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'step&nbsp;two'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'step&nbsp;three'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'step&nbsp;four'</span><span style="color: #007700">);<br /><br /></span><span style="color: #FF8000">//&nbsp;by&nbsp;default,&nbsp;the&nbsp;pointer&nbsp;is&nbsp;on&nbsp;the&nbsp;first&nbsp;element<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">)&nbsp;.&nbsp;</span><span style="color: #DD0000">"&lt;br&nbsp;/&gt;\n"</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;"step&nbsp;one"<br /><br />//&nbsp;skip&nbsp;two&nbsp;steps<br /></span><span style="color: #9876AA">next</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">);<br /></span><span style="color: #9876AA">next</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">);<br />echo&nbsp;</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">)&nbsp;.&nbsp;</span><span style="color: #DD0000">"&lt;br&nbsp;/&gt;\n"</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;"step&nbsp;three"<br /><br />//&nbsp;reset&nbsp;pointer,&nbsp;start&nbsp;again&nbsp;on&nbsp;step&nbsp;one<br /></span><span style="color: #9876AA">reset</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">);<br />echo&nbsp;</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">)&nbsp;.&nbsp;</span><span style="color: #DD0000">"&lt;br&nbsp;/&gt;\n"</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;"step&nbsp;one"<br /><br /></span><span style="color: #9876AA">?&gt;</span></span></span></div>    </div>   </div>  </span> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.reset-seealso">  <h3 class="title">参见</h3>  <span>   <ul class="simplelist">    <li class="member"><span class="function">{@link current()} - 返回数组中的当前单元</span></li>    <li class="member"><span class="function">{@link each()} - 返回数组中当前的键／值对并将数组指针向前移动一步</span></li>    <li class="member"><span class="function">{@link end()} - 将数组的内部指针指向最后一个单元</span></li>    <li class="member"><span class="function">{@link next()} - 将数组中的内部指针向前移动一位</span></li>    <li class="member"><span class="function">{@link prev()} - 将数组的内部指针倒回一位</span></li>   </ul>  </span> </div></div>
*/
	public function reset() {}

	/**
	 * (PECL solr &gt;= 0.9.2)<br/>
	 * Sets the boost value for this document
	 * @link https://php.net/manual/en/solrinputdocument.setboost.php
	 * @param float $documentBoostValue <p>
	 * The index-time boost value for this document.
	 * </p>
	 * @return bool <p>
	 * Returns <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 * </p>
	 */
	public function setBoost($documentBoostValue) {}

	/**
	 * (PECL solr &gt;= 0.9.2)<br/>
	 * Sets the index-time boost value for a field
	 * https://php.net/manual/en/solrinputdocument.setfieldboost.php
	 * @param string $fieldName <p>
	 * The name of the field.
	 * </p>
	 * @param float $fieldBoostValue <p>
	 * The index time boost value.
	 * </p>
	 */
	public function setFieldBoost($fieldName, $fieldBoostValue) {}

	/**
	 * (PECL solr &gt;= 0.9.2)<br/>
	 * Sorts the fields within the document
	 * @link https://php.net/manual/en/solrinputdocument.sort.php
	 * @param int $sortOrderBy <p>
	 * The sort criteria, must be one of :
	 * <ul>
	 * <li>SolrInputDocument::SORT_FIELD_NAME</li>
	 * <li>SolrInputDocument::SORT_FIELD_BOOST_VALUE</li>
	 * <li>SolrInputDocument::SORT_FIELD_VALUE_COUNT</li>
	 * </ul>
	 * </p>
	 * @param int $sortDirection [optional] <p>
	 * The sort direction, can be one of :
	 * <ul>
	 * <li>SolrInputDocument::SORT_DEFAULT</li>
	 * <li>SolrInputDocument::SORT_ASC</li>
	 * <li>SolrInputDocument::SORT_DESC</li>
	 * </ul>
	 * </p>
	 * @return bool <p>
	 * Returns <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 * </p>
	 */
/**
*<div id="function.sort" class="refentry"> <div class="refnamediv">  <h1 class="refname">sort</h1>  <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">sort</span> &mdash; <span class="dc-title">对数组排序</span></p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.sort-description">  <h3 class="title">说明</h3>  <div class="methodsynopsis dc-description">   <span class="methodname" style="color:#CC7832"><strong>sort</strong></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">array</span> <span class="parameter" style="color:#3A95FF">&$array</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$sort_flags</span><span class="initializer"> = SORT_REGULAR</span></span>  ] ) : <span class="type" style="color:#EAB766">bool</span></div>  <p class="para rdfs-comment">   本函数对数组进行排序。   当本函数结束时数组单元将被从最低到最高重新安排。  </p>  <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>:  <p class="para">  如果两个成员完全相同，那么它们在排序数组中的相对顺序是未定义的。 </p></p></blockquote> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.sort-parameters">  <h3 class="title">参数</h3>  <span>   <dl>         <dt><span class="parameter" style="color:#3A95FF">array</span></dt>     <dd>      <p class="para">       要排序的数组。      </p>     </dd>             <dt><span class="parameter" style="color:#3A95FF">sort_flags</span></dt>     <dd>      <p class="para">       可选的第二个参数 <span class="parameter" style="color:#3A95FF">sort_flags</span>   可以用以下值改变排序的行为：      </p>      <p class="para">       排序类型标记：       <ul class="itemizedlist">        <li class="listitem">         <span class="simpara"><strong><span>SORT_REGULAR</span></strong>  - 正常比较单元          详细描述参见 <a href="http://php.net/manual/zh/language.operators.comparison.php" class="link">比较运算符</a> 章节         </span>        </li>        <li class="listitem">         <span class="simpara"><strong><span>SORT_NUMERIC</span></strong> - 单元被作为数字来比较</span>        </li>        <li class="listitem">         <span class="simpara"><strong><span>SORT_STRING</span></strong> - 单元被作为字符串来比较</span>        </li>        <li class="listitem">         <span class="simpara"> <strong><span>SORT_LOCALE_STRING</span></strong> -      根据当前的区域（locale）设置来把单元当作字符串比较，可以用      <span class="function">{@link setlocale()}</span> 来改变。         </span>        </li>        <li class="listitem">         <span class="simpara"><strong><span>SORT_NATURAL</span></strong> - 和 <span class="function">{@link natsort()}</span> 类似对每个单元以“自然的顺序”对字符串进行排序。</span>        </li>        <li class="listitem">         <span class="simpara"><strong><span>SORT_FLAG_CASE</span></strong> - 能够与 <strong><span>SORT_STRING</span></strong> 或          <strong><span>SORT_NATURAL</span></strong>           合并（OR 位运算），不区分大小写排序字符串。</span>        </li>       </ul>      </p>     </dd>       </dl>  </span> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.sort-returnvalues">  <h3 class="title">返回值</h3>  <p class="para">   成功时返回 <strong><span>TRUE</span></strong>， 或者在失败时返回 <strong><span>FALSE</span></strong>。  </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.sort-examples">  <h3 class="title">范例</h3>  <span>   <div class="example" id="example-5316">    <p><strong>Example #1 <span class="function"><strong style="color:#CC7832">sort()</strong></span> 例子</strong></p>    <div class="example-contents"><div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"><span style="color: #9876AA">&lt;?php<br /><br />$fruits&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #DD0000">"lemon"</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">"orange"</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">"banana"</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">"apple"</span><span style="color: #007700">);<br /></span><span style="color: #9876AA">sort</span><span style="color: #007700">(</span><span style="color: #9876AA">$fruits</span><span style="color: #007700">);<br />foreach&nbsp;(</span><span style="color: #9876AA">$fruits&nbsp;</span><span style="color: #007700">as&nbsp;</span><span style="color: #9876AA">$key&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #9876AA">$val</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"fruits["&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #9876AA">$key&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #DD0000">"]&nbsp;=&nbsp;"&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #9876AA">$val&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br />}<br /><br /></span><span style="color: #9876AA">?&gt;</span></span></span></div>    </div>    <div class="example-contents"><p>以上例程会输出：</p></div>    <div class="example-contents screen" style="color:AFB1B3;background:black;padding-left:5px;"><div class="cdata"><span>fruits[0] = apple<br>fruits[1] = banana<br>fruits[2] = lemon<br>fruits[3] = orange<br></span></div>    </div>   </div>  </span>  <p class="para">   fruits 被按照字母顺序排序。  </p>  <p class="para">   <div class="example" id="example-5317">    <p><strong>Example #2 使用 <span class="function"><strong style="color:#CC7832">sort()</strong></span> 不区分大小写自然排序的例子</strong></p>    <div class="example-contents"><div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"><span style="color: #9876AA">&lt;?php<br /><br />$fruits&nbsp;</span><span style="color: #007700">=&nbsp;array(<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">"Orange1"</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">"orange2"</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">"Orange3"</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">"orange20"<br /></span><span style="color: #007700">);<br /></span><span style="color: #9876AA">sort</span><span style="color: #007700">(</span><span style="color: #9876AA">$fruits</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">SORT_NATURAL&nbsp;</span><span style="color: #007700">|&nbsp;</span><span style="color: #9876AA">SORT_FLAG_CASE</span><span style="color: #007700">);<br />foreach&nbsp;(</span><span style="color: #9876AA">$fruits&nbsp;</span><span style="color: #007700">as&nbsp;</span><span style="color: #9876AA">$key&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #9876AA">$val</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"fruits["&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #9876AA">$key&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #DD0000">"]&nbsp;=&nbsp;"&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #9876AA">$val&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br />}<br /><br /></span><span style="color: #9876AA">?&gt;</span></span></span></div>    </div>    <div class="example-contents"><p>以上例程会输出：</p></div>    <div class="example-contents screen" style="color:AFB1B3;background:black;padding-left:5px;"><div class="cdata"><span>fruits[0] = Orange1<br>fruits[1] = orange2<br>fruits[2] = Orange3<br>fruits[3] = orange20<br></span></div>    </div>   </div>  </p>  <p class="para">   fruits 排序得像 <span class="function">{@link natcasesort()}</span> 的结果。  </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 notes" id="refsect1-function.sort-notes">  <h3 class="title">注释</h3>  <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>: <span class="simpara">此函数为 <span class="parameter" style="color:#3A95FF">array</span>中的元素赋与新的键名。这将删除原有的键名，而不是仅仅将键名重新排序。</span></p></blockquote>  <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>:    <span class="simpara">    和大多数 PHP 排序函数一样，<span class="function"><strong style="color:#CC7832">sort()</strong></span>     使用了 <a href="http://en.wikipedia.org/wiki/Quicksort" class="link external">&raquo;&nbsp;Quicksort</a> 实现的。    The pivot is chosen in the middle of the partition resulting in an optimal    time for already sorted arrays. This is however an implementation detail you    shouldn&#039;t rely on.   </span>  </p></blockquote>  <div class="warning"><strong class="warning">Warning</strong>   <p class="simpara">    在对含有混合类型值的数组    以 <span class="parameter" style="color:#3A95FF">sort_flags</span> 为 <strong><span>SORT_REGULAR</span></strong> 排序时要小心，因为    <span class="function"><strong style="color:#CC7832">sort()</strong></span> 可能会产生不可预知的结果。   </p>  </div> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.sort-seealso">  <h3 class="title">参见</h3>  <span>   <ul class="simplelist">    <li class="member"><span class="function">{@link asort()} - 对数组进行排序并保持索引关系</span></li>    <li class="member"><span class="function">{@link rsort()} - 对数组逆向排序</span></li>    <li class="member"><a href="http://php.net/manual/zh/array.sorting.php" class="link">数组排序函数对比</a></li>   </ul>  </span> </div></div>
*/
	public function sort($sortOrderBy, $sortDirection = SolrInputDocument::SORT_ASC) {}

	/**
	 * (PECL solr &gt;= 0.9.2)<br/>
	 * Returns an array representation of the input document
	 * @link https://php.net/manual/en/solrinputdocument.toarray.php
	 * @return array|false <p>
	 * Returns an array containing the fields. It returns FALSE on failure.
	 * </p>
	 */
	public function toArray() {}

}
