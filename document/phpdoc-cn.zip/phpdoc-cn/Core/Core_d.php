<?php

// Start of Core v.5.3.6-13ubuntu3.2


/**
*        <a href="http://php.net/manual/zh/errorfunc.constants.php" class="link">Error reporting constant</a>     
*/
define ('E_ERROR', 1);

/**
*        <a href="http://php.net/manual/zh/errorfunc.constants.php" class="link">Error reporting constant</a>.        Available since PHP 5.2.0       
*/
define ('E_RECOVERABLE_ERROR', 4096);

/**
*        <a href="http://php.net/manual/zh/errorfunc.constants.php" class="link">Error reporting constant</a>     
*/
define ('E_WARNING', 2);

/**
*        <a href="http://php.net/manual/zh/errorfunc.constants.php" class="link">Error reporting constant</a>     
*/
define ('E_PARSE', 4);

/**
*        <a href="http://php.net/manual/zh/errorfunc.constants.php" class="link">Error reporting constant</a>     
*/
define ('E_NOTICE', 8);

/**
*        <a href="http://php.net/manual/zh/errorfunc.constants.php" class="link">Error reporting constant</a>     
*/
define ('E_STRICT', 2048);

/**
*        <a href="http://php.net/manual/zh/errorfunc.constants.php" class="link">Error reporting constant</a>.        Available since PHP 5.3.0       
*/
define ('E_DEPRECATED', 8192);

/**
*        <a href="http://php.net/manual/zh/errorfunc.constants.php" class="link">Error reporting constant</a>     
*/
define ('E_CORE_ERROR', 16);

/**
*        <a href="http://php.net/manual/zh/errorfunc.constants.php" class="link">Error reporting constant</a>     
*/
define ('E_CORE_WARNING', 32);

/**
*        <a href="http://php.net/manual/zh/errorfunc.constants.php" class="link">Error reporting constant</a>      
*/
define ('E_COMPILE_ERROR', 64);

/**
*        <a href="http://php.net/manual/zh/errorfunc.constants.php" class="link">Error reporting constant</a>     
*/
define ('E_COMPILE_WARNING', 128);

/**
*        <a href="http://php.net/manual/zh/errorfunc.constants.php" class="link">Error reporting constant</a>     
*/
define ('E_USER_ERROR', 256);

/**
*        <a href="http://php.net/manual/zh/errorfunc.constants.php" class="link">Error reporting constant</a>     
*/
define ('E_USER_WARNING', 512);

/**
*        <a href="http://php.net/manual/zh/errorfunc.constants.php" class="link">Error reporting constant</a>     
*/
define ('E_USER_NOTICE', 1024);

/**
*        <a href="http://php.net/manual/zh/errorfunc.constants.php" class="link">Error reporting constant</a>.        Available since PHP 5.3.0       
*/
define ('E_USER_DEPRECATED', 16384);

/**
*        <a href="http://php.net/manual/zh/errorfunc.constants.php" class="link">Error reporting constant</a>     
*/
define ('E_ALL', 32767);
define ('DEBUG_BACKTRACE_PROVIDE_OBJECT', 1);
define ('DEBUG_BACKTRACE_IGNORE_ARGS', 2);
define ('S_MEMORY', 1);
define ('S_VARS', 4);
define ('S_FILES', 8);
define ('S_INCLUDE', 16);
define ('S_SQL', 32);
define ('S_EXECUTOR', 64);
define ('S_MAIL', 128);
define ('S_SESSION', 256);
define ('S_MISC', 2);
define ('S_INTERNAL', 536870912);
define ('S_ALL', 511);

/**
*        See <a href="http://php.net/manual/zh/language.types.boolean.php" class="link">Booleans</a>.       
*/
define ('true', (bool)1, true);
/**
*        See <a href="http://php.net/manual/zh/language.types.boolean.php" class="link">Booleans</a>.       
*/
define ('false', (bool)0, true);
/**
*        See <a href="http://php.net/manual/zh/language.types.null.php" class="link">Null</a>.     
*/
define ('null', null, true);
define ('ZEND_THREAD_SAFE', false);
define ('ZEND_DEBUG_BUILD', false);
define ('PHP_WINDOWS_VERSION_BUILD', 0);
/**
*4
*/
define ('PHP_WINDOWS_VERSION_MAJOR', 0);
define ('PHP_WINDOWS_VERSION_MINOR', 0);
/**
*2
*/
define ('PHP_WINDOWS_VERSION_PLATFORM', 0);
/**
*PHP_WINDOWS_NT_*
*/
define ('PHP_WINDOWS_VERSION_PRODUCTTYPE', 0);
define ('PHP_WINDOWS_VERSION_SP_MAJOR', 0);
define ('PHP_WINDOWS_VERSION_SP_MINOR', 0);
/**
*<strong>Windows suitemask 位字段</strong>
*/
define ('PHP_WINDOWS_VERSION_SUITEMASK', 0);
define ('PHP_WINDOWS_NT_DOMAIN_CONTROLLER', 2);
/**
*<code>PHP_WINDOWS_NT_DOMAIN_CONTROLLER</code>
*/
define ('PHP_WINDOWS_NT_SERVER', 3);
define ('PHP_WINDOWS_NT_WORKSTATION', 1);
/**
*        A Windows <code class="literal">CTRL+C</code> event.        Available as of PHP 7.4.0 (Windows only).       
*/
define ('PHP_WINDOWS_EVENT_CTRL_C', 0);
/**
*        A Windows <code class="literal">CTRL+BREAK</code> event.        Available as of PHP 7.4.0 (Windows only).       
*/
define ('PHP_WINDOWS_EVENT_CTRL_BREAK', 1);
/**
*      The current PHP version as a string in         &quot;major.minor.release[extra]&quot; notation.     
*/
define ('PHP_VERSION', "5.3.6-13ubuntu3.2");
/**
*        The current PHP &quot;major&quot; version as an integer (e.g., int(5)         from version &quot;5.2.7-extra&quot;). Available since PHP 5.2.7.       
*/
define ('PHP_MAJOR_VERSION', 5);
/**
*        The current PHP &quot;minor&quot; version as an integer (e.g., int(2)         from version &quot;5.2.7-extra&quot;). Available since PHP 5.2.7.       
*/
define ('PHP_MINOR_VERSION', 3);
/**
*        The current PHP &quot;release&quot; version as an integer (e.g., int(7)         from version &quot;5.2.7-extra&quot;). Available since PHP 5.2.7.       
*/
define ('PHP_RELEASE_VERSION', 6);
/**
*        The current PHP &quot;extra&quot; version as a string (e.g., &#039;-extra&#039;        from version &quot;5.2.7-extra&quot;). Often used by distribution        vendors to indicate a package version. Available since        PHP 5.2.7.       
*/
define ('PHP_EXTRA_VERSION', "-13ubuntu3.2");
/**
*        The current PHP version as an integer, useful for         version comparisons (e.g., int(50207) from version &quot;5.2.7-extra&quot;).        Available since PHP 5.2.7.       
*/
define ('PHP_VERSION_ID', 50306);
/**
*        Available since PHP 5.2.7.       
*/
define ('PHP_ZTS', 0);
/**
*        Available since PHP 5.2.7.       
*/
define ('PHP_DEBUG', 0);
/**
*        The operating system PHP was built for.     
*/
define ('PHP_OS', "Linux");
/**
*        The operating system family PHP was built for. Either of        <code class="literal">&#039;Windows&#039;</code>, <code class="literal">&#039;BSD&#039;</code>,        <code class="literal">&#039;Darwin&#039;</code>, <code class="literal">&#039;Solaris&#039;</code>,        <code class="literal">&#039;Linux&#039;</code> or <code class="literal">&#039;Unknown&#039;</code>.        Available as of PHP 7.2.0.       
*/
define ('PHP_OS_FAMILY', "Linux");
/**
*      The Server API for this build of PHP.参见 <span class="function">{@link php_sapi_name()}</span>。     
*/
define ('PHP_SAPI', "cli");
/**
 * @since 7.4
 */
define ('PHP_CLI_PROCESS_TITLE', 1);
define ('DEFAULT_INCLUDE_PATH', ".:/usr/share/php:/usr/share/pear");
define ('PEAR_INSTALL_DIR', "/usr/share/php");
define ('PEAR_EXTENSION_DIR', "/usr/lib/php5/20090626");
define ('PHP_EXTENSION_DIR', "/usr/lib/php5/20090626");
/**
*        Specifies the PHP binary path during script execution.        Available since PHP 5.4.       
*/
define ('PHP_BINARY', '/usr/local/php/bin/php');
/**
*      The value &quot;--prefix&quot; was set to at configure.     
*/
define ('PHP_PREFIX', "/usr");
/**
*        Specifies where the binaries were installed into.     
*/
define ('PHP_BINDIR', "/usr/bin");
define ('PHP_LIBDIR', "/usr/lib/php5");
define ('PHP_DATADIR', "/usr/share");
define ('PHP_SYSCONFDIR', "/etc");
define ('PHP_LOCALSTATEDIR', "/var");
define ('PHP_CONFIG_FILE_PATH', "/etc/php5/cli");
define ('PHP_CONFIG_FILE_SCAN_DIR', "/etc/php5/cli/conf.d");
/**
*      The build-platform&#039;s shared library suffix, such as &quot;so&quot; (most Unixes)        or &quot;dll&quot; (Windows).     
*/
define ('PHP_SHLIB_SUFFIX', "so");
/**
*      当前平台中对于换行符的定义。自 PHP 5.0.2 起可用     
*/
define ('PHP_EOL', "\n");
define ('SUHOSIN_PATCH', 1);
define ('SUHOSIN_PATCH_VERSION', "0.9.10");
/**
*        The maximum length of filenames (including path) supported        by this build of PHP. Available since PHP 5.3.0.       
*/
define ('PHP_MAXPATHLEN', 4096);
/**
*      当前 PHP 版本支持的最大整型数字。在 32 位系统中通常为 int(2147483647)，64 位系统中为 int(9223372036854775807)。自 PHP 5.0.5 起可用。     
*/
define ('PHP_INT_MAX', 9223372036854775807);
/**
*        当前 PHP 版本支持的最大整型数字。在 32 位系统中通常为 int(-2147483648)，64 系统中为 int(-9223372036854775808)。自 PHP 7.0.0 起可用。通常情况下 PHP_INT_MIN === ~PHP_INT_MAX。       
*/
define ('PHP_INT_MIN', -9223372036854775808);
/**
*      The size of an integer in bytes in this build of PHP. 自 PHP 5.0.5 起可用     
*/
define ('PHP_INT_SIZE', 8);
/**
*        Number of decimal digits that can be rounded into a float and back        without precision loss.        Available as of PHP 7.2.0.       
*/
define('PHP_FLOAT_DIG', 15);
/**
*        Smallest representable positive number x, so that <code class="literal">x + 1.0 !=        1.0</code>.        Available as of PHP 7.2.0.       
*/
define('PHP_FLOAT_EPSILON', 2.2204460492503e-16);

/**
*        Largest representable floating point number.        Available as of PHP 7.2.0.       
*/
define('PHP_FLOAT_MAX', 1.7976931348623e+308);
/**
*        Smallest representable <em class="emphasis">positive</em> floating point number.        If you need the smallest representable <em class="emphasis">negative</em> floating point number, use <code class="literal">- PHP_FLOAT_MAX</code>.        Available as of PHP 7.2.0.       
*/
define('PHP_FLOAT_MIN', 2.2250738585072e-308);
define ('ZEND_MULTIBYTE', 0);
/**
*      Indicates that output buffering has begun.     
*/
define ('PHP_OUTPUT_HANDLER_START', 1);
/**
*      Indicates that the buffer has been flushed, but output buffering will      continue.     
*/
define ('PHP_OUTPUT_HANDLER_CONT', 2);
/**
*      Indicates that output buffering has ended.     
*/
define ('PHP_OUTPUT_HANDLER_END', 4);
define ('UPLOAD_ERR_OK', 0);
define ('UPLOAD_ERR_INI_SIZE', 1);
define ('UPLOAD_ERR_FORM_SIZE', 2);
define ('UPLOAD_ERR_PARTIAL', 3);
define ('UPLOAD_ERR_NO_FILE', 4);
define ('UPLOAD_ERR_NO_TMP_DIR', 6);
define ('UPLOAD_ERR_CANT_WRITE', 7);
define ('UPLOAD_ERR_EXTENSION', 8);
define('STDIN', fopen('php://stdin', 'r'));
define('STDOUT', fopen('php://stdout', 'w'));
define('STDERR', fopen('php://stderr', 'w'));

/**
*        The maximum number of file descriptors for select system calls. Available        as of PHP 7.1.0.     
*/
define('PHP_FD_SETSIZE', 1024);

/**
*      Indicates that the output buffer is being flushed, and had data to output.     
*/
define('PHP_OUTPUT_HANDLER_WRITE', 0);
/**
*      Indicates that the buffer has been flushed.     
*/
define('PHP_OUTPUT_HANDLER_FLUSH', 4);
/**
*      Indicates that the output buffer has been cleaned.     
*/
define('PHP_OUTPUT_HANDLER_CLEAN', 2);
/**
*      Indicates that this is the final output buffering operation.     
*/
define('PHP_OUTPUT_HANDLER_FINAL', 8);
/**
*      Controls whether an output buffer created by      <span class="function">{@link ob_start()}</span> can be cleaned.     
*/
define('PHP_OUTPUT_HANDLER_CLEANABLE', 16);
/**
*      Controls whether an output buffer created by      <span class="function">{@link ob_start()}</span> can be flushed.     
*/
define('PHP_OUTPUT_HANDLER_FLUSHABLE', 32);
/**
*      Controls whether an output buffer created by      <span class="function">{@link ob_start()}</span> can be removed before the end of the script.     
*/
define('PHP_OUTPUT_HANDLER_REMOVABLE', 64);
/**
*      The default set of output buffer flags; currently equivalent to      <strong><code>PHP_OUTPUT_HANDLER_CLEANABLE</code></strong> |      <strong><code>PHP_OUTPUT_HANDLER_FLUSHABLE</code></strong> |      <strong><code>PHP_OUTPUT_HANDLER_REMOVABLE</code></strong>.     
*/
define('PHP_OUTPUT_HANDLER_STDFLAGS', 112);
/** @link https://php.net/manual/en/outcontrol.constants.php */
define('PHP_OUTPUT_HANDLER_STARTED', 4096);
/** @link https://php.net/manual/en/outcontrol.constants.php */
define('PHP_OUTPUT_HANDLER_DISABLED', 8192);
