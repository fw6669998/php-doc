<?php

// Start of zip v.1.14.0

/**
*<div id="class.ziparchive" class="reference"> <h1 class="title"> <a href="http://php.net/manual/zh/class.ziparchive.php" class="classname">ZipArchive</a> 类</h1>   <div class="partintro"><p class="verinfo">(PHP 5 &gt;= 5.2.0, PHP 7, PECL zip &gt;= 1.1.0)</p>      <div class="section" id="ziparchive.intro">   <h2 class="title">简介</h2>   <p class="para">    一个用 Zip 压缩的文件存档。   </p>  </div>      <div class="section" id="ziparchive.synopsis">   <h2 class="title">类摘要</h2>         <div class="classsynopsis">    <div class="ooclass"></div>            <div class="classsynopsisinfo">     <span class="ooclass">      <strong class="classname">ZipArchive</strong>     </span>     {</div>        <div class="classsynopsisinfo classsynopsisinfo_comment">// 属性 </div>            <div class="classsynopsisinfo classsynopsisinfo_comment">// 方法 </div>    <div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.addemptydir.php" class="methodname" style="color:#CC7832">addEmptyDir</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$dirname</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$flags</span><span class="initializer"> = 0</span></span>  ] ) : <span class="type" style="color:#EAB766">bool</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.addfile.php" class="methodname" style="color:#CC7832">addFile</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$filename</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$entryname</span><span class="initializer"> = <strong><span>NULL</span></strong></span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$start</span><span class="initializer"> = 0</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$length</span><span class="initializer"> = 0</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$flags</span><span class="initializer"> = ZipArchive::FL_OVERWRITE</span></span>  ]]]] ) : <span class="type" style="color:#EAB766">bool</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.addfromstring.php" class="methodname" style="color:#CC7832">addFromString</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$name</span></span>   , <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$contents</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$flags</span><span class="initializer"> = ZipArchive::FL_OVERWRITE</span></span>  ] ) : <span class="type" style="color:#EAB766">bool</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.addglob.php" class="methodname" style="color:#CC7832">addGlob</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$pattern</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$flags</span><span class="initializer"> = 0</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">array</span> <span class="parameter" style="color:#3A95FF">$options</span><span class="initializer"> = array()</span></span>  ]] ) : <span class="type" style="color:#EAB766"><span class="type" style="color:#EAB766">array</span>|<span class="type" style="color:#EAB766"><span class="type false" style="color:#EAB766">false</span></span></span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.addpattern.php" class="methodname" style="color:#CC7832">addPattern</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$pattern</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$path</span><span class="initializer"> = &quot;.&quot;</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">array</span> <span class="parameter" style="color:#3A95FF">$options</span><span class="initializer"> = array()</span></span>  ]] ) : <span class="type" style="color:#EAB766"><span class="type" style="color:#EAB766">array</span>|<span class="type" style="color:#EAB766"><span class="type false" style="color:#EAB766">false</span></span></span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.close.php" class="methodname" style="color:#CC7832">close</a></span>    (   ) : <span class="type" style="color:#EAB766">bool</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.count.php" class="methodname" style="color:#CC7832">count</a></span>    (   ) : <span class="type" style="color:#EAB766">int</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.deleteindex.php" class="methodname" style="color:#CC7832">deleteIndex</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$index</span></span>   ) : <span class="type" style="color:#EAB766">bool</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.deletename.php" class="methodname" style="color:#CC7832">deleteName</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$name</span></span>   ) : <span class="type" style="color:#EAB766">bool</span></div><div class="methodsynopsis dc-description">   <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.extractto.php" class="methodname" style="color:#CC7832">extractTo</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$destination</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766"><a href="http://php.net/manual/zh/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span> <span class="parameter" style="color:#3A95FF">$entries</span></span>  ] ) : <span class="type" style="color:#EAB766">bool</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.getarchivecomment.php" class="methodname" style="color:#CC7832">getArchiveComment</a></span>    ([ <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$flags</span></span>  ] ) : <span class="type" style="color:#EAB766"><span class="type" style="color:#EAB766">string</span>|<span class="type" style="color:#EAB766"><span class="type false" style="color:#EAB766">false</span></span></span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.getcommentindex.php" class="methodname" style="color:#CC7832">getCommentIndex</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$index</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$flags</span></span>  ] ) : <span class="type" style="color:#EAB766"><span class="type" style="color:#EAB766">string</span>|<span class="type" style="color:#EAB766"><span class="type false" style="color:#EAB766">false</span></span></span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.getcommentname.php" class="methodname" style="color:#CC7832">getCommentName</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$name</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$flags</span></span>  ] ) : <span class="type" style="color:#EAB766"><span class="type" style="color:#EAB766">string</span>|<span class="type" style="color:#EAB766"><span class="type false" style="color:#EAB766">false</span></span></span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span>    <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.getexternalattributesindex.php" class="methodname" style="color:#CC7832">GetExternalAttributesIndex</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$index</span></span>   , <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">&$opsys</span></span>   , <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">&$attr</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$flags</span></span>  ] ) : <span class="type" style="color:#EAB766">bool</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span>    <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.getexternalattributesname.php" class="methodname" style="color:#CC7832">getExternalAttributesName</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$name</span></span>   , <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">&$opsys</span></span>   , <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">&$attr</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$flags</span></span>  ] ) : <span class="type" style="color:#EAB766">bool</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.getfromindex.php" class="methodname" style="color:#CC7832">getFromIndex</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$index</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$length</span><span class="initializer"> = 0</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$flags</span></span>  ]] ) : <span class="type" style="color:#EAB766"><span class="type" style="color:#EAB766">string</span>|<span class="type" style="color:#EAB766"><span class="type false" style="color:#EAB766">false</span></span></span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.getfromname.php" class="methodname" style="color:#CC7832">getFromName</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$name</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$length</span><span class="initializer"> = 0</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$flags</span></span>  ]] ) : <span class="type" style="color:#EAB766"><span class="type" style="color:#EAB766">string</span>|<span class="type" style="color:#EAB766"><span class="type false" style="color:#EAB766">false</span></span></span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.getnameindex.php" class="methodname" style="color:#CC7832">getNameIndex</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$index</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$flags</span></span>  ] ) : <span class="type" style="color:#EAB766"><span class="type" style="color:#EAB766">string</span>|<span class="type" style="color:#EAB766"><span class="type false" style="color:#EAB766">false</span></span></span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.getstatusstring.php" class="methodname" style="color:#CC7832">getStatusString</a></span>    (   ) : <span class="type" style="color:#EAB766"><span class="type" style="color:#EAB766">string</span>|<span class="type" style="color:#EAB766"><span class="type false" style="color:#EAB766">false</span></span></span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.getstream.php" class="methodname" style="color:#CC7832">getStream</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$name</span></span>   ) : <span class="type" style="color:#EAB766"><span class="type" style="color:#EAB766">resource</span>|<span class="type" style="color:#EAB766"><span class="type false" style="color:#EAB766">false</span></span></span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.iscompressionmethoddupported.php" class="methodname" style="color:#CC7832">isCompressionMethodSupported</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$method</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">bool</span> <span class="parameter" style="color:#3A95FF">$encode</span><span class="initializer"> = true</span></span>  ] ) : <span class="type" style="color:#EAB766">bool</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.isencryptionmethoddupported.php" class="methodname" style="color:#CC7832">isEncryptionMethodSupported</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$method</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">bool</span> <span class="parameter" style="color:#3A95FF">$encode</span><span class="initializer"> = true</span></span>  ] ) : <span class="type" style="color:#EAB766">bool</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.locatename.php" class="methodname" style="color:#CC7832">locateName</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$name</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$flags</span></span>  ] ) : <span class="type" style="color:#EAB766"><span class="type" style="color:#EAB766">int</span>|<span class="type" style="color:#EAB766"><span class="type false" style="color:#EAB766">false</span></span></span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.open.php" class="methodname" style="color:#CC7832">open</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$filename</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$flags</span></span>  ] ) : <span class="type" style="color:#EAB766"><a href="http://php.net/manual/zh/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span>    <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.registercancelcallback.php" class="methodname" style="color:#CC7832">registerCancelCallback</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766"><a href="http://php.net/manual/zh/language.types.callable.php" class="type callable" style="color:#EAB766">callable</a></span> <span class="parameter" style="color:#3A95FF">$callback</span></span>   ) : <span class="type" style="color:#EAB766">bool</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span>    <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.registerprogresscallback.php" class="methodname" style="color:#CC7832">registerProgressCallback</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">float</span> <span class="parameter" style="color:#3A95FF">$rate</span></span>   , <span class="methodparam"><span class="type" style="color:#EAB766"><a href="http://php.net/manual/zh/language.types.callable.php" class="type callable" style="color:#EAB766">callable</a></span> <span class="parameter" style="color:#3A95FF">$callback</span></span>   ) : <span class="type" style="color:#EAB766">bool</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.renameindex.php" class="methodname" style="color:#CC7832">renameIndex</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$index</span></span>   , <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$newname</span></span>   ) : <span class="type" style="color:#EAB766">bool</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.renamename.php" class="methodname" style="color:#CC7832">renameName</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$name</span></span>   , <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$newname</span></span>   ) : <span class="type" style="color:#EAB766">bool</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.replacefile.php" class="methodname" style="color:#CC7832">replaceFile</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$filename</span></span>   , <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$index</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$start</span><span class="initializer"> = 0</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$length</span><span class="initializer"> = 0</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$flags</span><span class="initializer"> = 0</span></span>  ]]] ) : <span class="type" style="color:#EAB766">bool</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.setarchivecomment.php" class="methodname" style="color:#CC7832">setArchiveComment</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$comment</span></span>   ) : <span class="type" style="color:#EAB766">bool</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.setcommentindex.php" class="methodname" style="color:#CC7832">setCommentIndex</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$index</span></span>   , <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$comment</span></span>   ) : <span class="type" style="color:#EAB766">bool</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.setcommentname.php" class="methodname" style="color:#CC7832">setCommentName</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$name</span></span>   , <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$comment</span></span>   ) : <span class="type" style="color:#EAB766">bool</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.setcompressionindex.php" class="methodname" style="color:#CC7832">setCompressionIndex</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$index</span></span>   , <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$comp_method</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$comp_flags</span><span class="initializer"> = 0</span></span>  ] ) : <span class="type" style="color:#EAB766">bool</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.setcompressionname.php" class="methodname" style="color:#CC7832">setCompressionName</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$name</span></span>   , <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$comp_method</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$comp_flags</span><span class="initializer"> = 0</span></span>  ] ) : <span class="type" style="color:#EAB766">bool</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span>    <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.setencryptionindex.php" class="methodname" style="color:#CC7832">setEncryptionIndex</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$index</span></span>   , <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$method</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$password</span></span>  ] ) : <span class="type" style="color:#EAB766">bool</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span>    <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.setencryptionname.php" class="methodname" style="color:#CC7832">setEncryptionName</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$name</span></span>   , <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$method</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$password</span></span>  ] ) : <span class="type" style="color:#EAB766">bool</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span>    <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.setexternalattributesindex.php" class="methodname" style="color:#CC7832">setExternalAttributesIndex</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$index</span></span>   , <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$opsys</span></span>   , <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$attr</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$flags</span></span>  ] ) : <span class="type" style="color:#EAB766">bool</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span>    <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.setexternalattributesname.php" class="methodname" style="color:#CC7832">setExternalAttributesName</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$name</span></span>   , <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$opsys</span></span>   , <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$attr</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$flags</span></span>  ] ) : <span class="type" style="color:#EAB766">bool</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span>    <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.setmtimeindex.php" class="methodname" style="color:#CC7832">setMtimeIndex</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$index</span></span>   , <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$timestamp</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$flags</span></span>  ] ) : <span class="type" style="color:#EAB766">bool</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span>    <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.setmtimename.php" class="methodname" style="color:#CC7832">setMtimeName</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$name</span></span>   , <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$timestamp</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$flags</span></span>  ] ) : <span class="type" style="color:#EAB766">bool</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.setpassword.php" class="methodname" style="color:#CC7832">setPassword</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$password</span></span>   ) : <span class="type" style="color:#EAB766">bool</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.statindex.php" class="methodname" style="color:#CC7832">statIndex</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$index</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$flags</span></span>  ] ) : <span class="type" style="color:#EAB766"><span class="type" style="color:#EAB766">array</span>|<span class="type" style="color:#EAB766"><span class="type false" style="color:#EAB766">false</span></span></span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.statname.php" class="methodname" style="color:#CC7832">statName</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$name</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$flags</span></span>  ] ) : <span class="type" style="color:#EAB766"><span class="type" style="color:#EAB766">array</span>|<span class="type" style="color:#EAB766"><span class="type false" style="color:#EAB766">false</span></span></span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.unchangeall.php" class="methodname" style="color:#CC7832">unchangeAll</a></span>    (   ) : <span class="type" style="color:#EAB766">bool</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.unchangearchive.php" class="methodname" style="color:#CC7832">unchangeArchive</a></span>    (   ) : <span class="type" style="color:#EAB766">bool</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.unchangeindex.php" class="methodname" style="color:#CC7832">unchangeIndex</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$index</span></span>   ) : <span class="type" style="color:#EAB766">bool</span></div><div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="http://php.net/manual/zh/ziparchive.unchangename.php" class="methodname" style="color:#CC7832">unchangeName</a></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$name</span></span>   ) : <span class="type" style="color:#EAB766">bool</span></div>       }</div>        </div>      <div class="section" id="ziparchive.props">   <h2 class="title">属性</h2>   <dl>         <dt id="ziparchive.props.status"><var class="varname">status</var></dt>     <dd>      <p class="para"> Zip Archive 的状态</p>     </dd>             <dt id="ziparchive.props.statussys"><var class="varname">statusSys</var></dt>     <dd>      <p class="para">Zip Archive 的系统状态</p>     </dd>             <dt id="ziparchive.props.numfiles"><var class="varname">numFiles</var></dt>     <dd>      <p class="para">压缩包里的文件数</p>     </dd>             <dt id="ziparchive.props.filename"><var class="varname">filename</var></dt>     <dd>      <p class="para">在文件系统里的文件名</p>     </dd>             <dt id="ziparchive.props.comment"><var class="varname">comment</var></dt>     <dd>      <p class="para">压缩包的注释</p>     </dd>       </dl>  </div>   </div>    <h2>Table of Contents</h2><ul class="chunklist chunklist_reference"><li>{@link ZipArchive::addEmptyDir} — Add a new directory</li><li>{@link ZipArchive::addFile} — Adds a file to a ZIP archive from the given path</li><li>{@link ZipArchive::addFromString} — Add a file to a ZIP archive using its contents</li><li>{@link ZipArchive::addGlob} — Add files from a directory by glob pattern</li><li>{@link ZipArchive::addPattern} — Add files from a directory by PCRE pattern</li><li>{@link ZipArchive::close} — Close the active archive (opened or newly created)</li><li>{@link ZipArchive::count} — Counts the number of files in the archive</li><li>{@link ZipArchive::deleteIndex} — Delete an entry in the archive using its index</li><li>{@link ZipArchive::deleteName} — Delete an entry in the archive using its name</li><li>{@link ZipArchive::extractTo} — 解压缩文件</li><li>{@link ZipArchive::getArchiveComment} — Returns the Zip archive comment</li><li>{@link ZipArchive::getCommentIndex} — Returns the comment of an entry using the entry index</li><li>{@link ZipArchive::getCommentName} — Returns the comment of an entry using the entry name</li><li>{@link ZipArchive::getExternalAttributesIndex} — Retrieve the external attributes of an entry defined by its index</li><li>{@link ZipArchive::getExternalAttributesName} — Retrieve the external attributes of an entry defined by its name</li><li>{@link ZipArchive::getFromIndex} — Returns the entry contents using its index</li><li>{@link ZipArchive::getFromName} — Returns the entry contents using its name</li><li>{@link ZipArchive::getNameIndex} — Returns the name of an entry using its index</li><li>{@link ZipArchive::getStatusString} — Returns the status error message, system and/or zip messages</li><li>{@link ZipArchive::getStream} — Get a file handler to the entry defined by its name (read only)</li><li>{@link ZipArchive::isCompressionMethodSupported} — Check if a compression method is supported by libzip</li><li>{@link ZipArchive::isEncryptionMethodSupported} — Check if a encryption method is supported by libzip</li><li>{@link ZipArchive::locateName} — Returns the index of the entry in the archive</li><li>{@link ZipArchive::open} — Open a ZIP file archive</li><li>{@link ZipArchive::registerCancelCallback} — Register a callback to allow cancellation during archive close.</li><li>{@link ZipArchive::registerProgressCallback} — Register a callback to provide updates during archive close.</li><li>{@link ZipArchive::renameIndex} — Renames an entry defined by its index</li><li>{@link ZipArchive::renameName} — Renames an entry defined by its name</li><li>{@link ZipArchive::replaceFile} — Replace file in ZIP archive with a given path</li><li>{@link ZipArchive::setArchiveComment} — Set the comment of a ZIP archive</li><li>{@link ZipArchive::setCommentIndex} — Set the comment of an entry defined by its index</li><li>{@link ZipArchive::setCommentName} — Set the comment of an entry defined by its name</li><li>{@link ZipArchive::setCompressionIndex} — Set the compression method of an entry defined by its index</li><li>{@link ZipArchive::setCompressionName} — Set the compression method of an entry defined by its name</li><li>{@link ZipArchive::setEncryptionIndex} — Set the encryption method of an entry defined by its index</li><li>{@link ZipArchive::setEncryptionName} — Set the encryption method of an entry defined by its name</li><li>{@link ZipArchive::setExternalAttributesIndex} — Set the external attributes of an entry defined by its index</li><li>{@link ZipArchive::setExternalAttributesName} — Set the external attributes of an entry defined by its name</li><li>{@link ZipArchive::setMtimeIndex} — Set the modification time of an entry defined by its index</li><li>{@link ZipArchive::setMtimeName} — Set the modification time of an entry defined by its name</li><li>{@link ZipArchive::setPassword} — Set the password for the active archive</li><li>{@link ZipArchive::statIndex} — Get the details of an entry defined by its index</li><li>{@link ZipArchive::statName} — Get the details of an entry defined by its name</li><li>{@link ZipArchive::unchangeAll} — Undo all changes done in the archive</li><li>{@link ZipArchive::unchangeArchive} — Revert all global changes done in the archive</li><li>{@link ZipArchive::unchangeIndex} — Revert all changes done to an entry at the given index</li><li>{@link ZipArchive::unchangeName} — Revert all changes done to an entry with the given name</li></ul></div>
*/
class ZipArchive implements Countable {

	/**
	 * Create the archive if it does not exist.
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const CREATE = 1;

	/**
	 * Error if archive already exists.
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const EXCL = 2;

	/**
	 * Perform additional consistency checks on the archive, and error if they fail.
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const CHECKCONS = 4;

	/**
	 * Always start a new archive, this mode will overwrite the file if
	 * it already exists.
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const OVERWRITE = 8;

	/**
	 * Ignore case on name lookup
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const FL_NOCASE = 1;

	/**
	 * Ignore directory component
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const FL_NODIR = 2;

	/**
	 * Read compressed data
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const FL_COMPRESSED = 4;

	/**
	 * Use original data, ignoring changes.
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const FL_UNCHANGED = 8;

	/**
	 * better of deflate or store.
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const CM_DEFAULT = -1;

	/**
	 * stored (uncompressed).
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const CM_STORE = 0;

	/**
	 * shrunk
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const CM_SHRINK = 1;

	/**
	 * reduced with factor 1
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const CM_REDUCE_1 = 2;

	/**
	 * reduced with factor 2
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const CM_REDUCE_2 = 3;

	/**
	 * reduced with factor 3
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const CM_REDUCE_3 = 4;

	/**
	 * reduced with factor 4
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const CM_REDUCE_4 = 5;

	/**
	 * imploded
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const CM_IMPLODE = 6;

	/**
	 * deflated
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const CM_DEFLATE = 8;

	/**
	 * deflate64
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const CM_DEFLATE64 = 9;

	/**
	 * PKWARE imploding
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const CM_PKWARE_IMPLODE = 10;

	/**
	 * BZIP2 algorithm
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const CM_BZIP2 = 12;
	const CM_LZMA = 14;
	const CM_TERSE = 18;
	const CM_LZ77 = 19;
	const CM_WAVPACK = 97;
	const CM_PPMD = 98;

	/**
	 * No error.
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const ER_OK = 0;

	/**
	 * Multi-disk zip archives not supported.
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const ER_MULTIDISK = 1;

	/**
	 * Renaming temporary file failed.
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const ER_RENAME = 2;

	/**
	 * Closing zip archive failed
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const ER_CLOSE = 3;

	/**
	 * Seek error
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const ER_SEEK = 4;

	/**
	 * Read error
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const ER_READ = 5;

	/**
	 * Write error
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const ER_WRITE = 6;

	/**
	 * CRC error
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const ER_CRC = 7;

	/**
	 * Containing zip archive was closed
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const ER_ZIPCLOSED = 8;

	/**
	 * No such file.
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const ER_NOENT = 9;

	/**
	 * File already exists
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const ER_EXISTS = 10;

	/**
	 * Can't open file
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const ER_OPEN = 11;

	/**
	 * Failure to create temporary file.
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const ER_TMPOPEN = 12;

	/**
	 * Zlib error
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const ER_ZLIB = 13;

	/**
	 * Memory allocation failure
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const ER_MEMORY = 14;

	/**
	 * Entry has been changed
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const ER_CHANGED = 15;

	/**
	 * Compression method not supported.
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const ER_COMPNOTSUPP = 16;

	/**
	 * Premature EOF
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const ER_EOF = 17;

	/**
	 * Invalid argument
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const ER_INVAL = 18;

	/**
	 * Not a zip archive
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const ER_NOZIP = 19;

	/**
	 * Internal error
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const ER_INTERNAL = 20;

	/**
	 * Zip archive inconsistent
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const ER_INCONS = 21;

	/**
	 * Can't remove file
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const ER_REMOVE = 22;

	/**
	 * Entry has been deleted
	 * @link https://php.net/manual/en/zip.constants.php
	 */
	const ER_DELETED = 23;

	/**
	 * No encryption
	 * @link https://secure.php.net/manual/en/zip.constants.php
	 * @since 7.2
	 */
	const EM_NONE = 0;

	/**
	 * AES 128 encryption
	 * @link https://secure.php.net/manual/en/zip.constants.php
	 * @since 7.2
	 */
	const EM_AES_128 = 257;

	/**
	 * AES 192 encryption
	 * @link https://secure.php.net/manual/en/zip.constants.php
	 * @since 7.2
	 */
	const EM_AES_192 = 258;

	/**
	 * AES 256 encryption
	 * @link https://secure.php.net/manual/en/zip.constants.php
	 * @since 7.2
	 */
	const EM_AES_256 = 259;

    /**
     * Status of the Zip Archive
     */
    public $status;
    /**
     * System status of the Zip Archive
     */
    public $statusSys;
    /**
     * Number of files in archive
     */
    public $numFiles;
    /**
     * File name in the file system
     */
    public $filename;
    /**
     * Comment for the archive
     */
    public $comment;

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.1.0)<br/>
	 * Open a ZIP file archive
	 * @link https://php.net/manual/en/ziparchive.open.php
	 * @param string $filename <p>
	 * The file name of the ZIP archive to open.
	 * </p>
	 * @param int $flags [optional] <p>
	 * The mode to use to open the archive.
	 * <p>
	 * <b>ZipArchive::OVERWRITE</b>
	 * </p>
	 * @return mixed <i>Error codes</i>
	 * <p>
	 * Returns <b>TRUE</b> on success or the error code.
	 * <p>
	 * <b>ZipArchive::ER_EXISTS</b>
	 * </p>
	 * <p>
	 * File already exists.
	 * </p>
	 * <p>
	 * <b>ZipArchive::ER_INCONS</b>
	 * </p>
	 * <p>
	 * Zip archive inconsistent.
	 * </p>
	 * <p>
	 * <b>ZipArchive::ER_INVAL</b>
	 * </p>
	 * <p>
	 * Invalid argument.
	 * </p>
	 * <p>
	 * <b>ZipArchive::ER_MEMORY</b>
	 * </p>
	 * <p>
	 * Malloc failure.
	 * </p>
	 * <p>
	 * <b>ZipArchive::ER_NOENT</b>
	 * </p>
	 * <p>
	 * No such file.
	 * </p>
	 * <p>
	 * <b>ZipArchive::ER_NOZIP</b>
	 * </p>
	 * <p>
	 * Not a zip archive.
	 * </p>
	 * <p>
	 * <b>ZipArchive::ER_OPEN</b>
	 * </p>
	 * <p>
	 * Can't open file.
	 * </p>
	 * <p>
	 * <b>ZipArchive::ER_READ</b>
	 * </p>
	 * <p>
	 * Read error.
	 * </p>
	 * <p>
	 * <b>ZipArchive::ER_SEEK</b>
	 * </p>
	 * <p>
	 * Seek error.
	 * </p>
	 * </p>
	 */
	public function open ($filename, $flags = null) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.1.0)<br/>
	 * Close the active archive (opened or newly created)
	 * @link https://php.net/manual/en/ziparchive.close.php
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 */
	public function close () {}

	/**
	 * (PHP 7 &gt;= 7.2.0, PECL zip &gt;= 1.15.0)<br/>
	 * Counts the number of files in the archive.
	 * @link https://www.php.net/manual/en/ziparchive.count.php
	 * @return int
	 * @since 7.2
	 */
/**
*<div id="function.count" class="refentry">   <div class="refnamediv">    <h1 class="refname">count</h1>    <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">count</span> &mdash; <span class="dc-title">计算数组中的单元数目，或对象中的属性个数</span></p>   </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.count-description">  <h3 class="title">说明</h3>  <div class="methodsynopsis dc-description">   <span class="methodname" style="color:#CC7832"><strong>count</strong></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766"><a href="http://php.net/manual/zh/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span> <span class="parameter" style="color:#3A95FF">$array_or_countable</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$mode</span><span class="initializer"> = COUNT_NORMAL</span></span>  ] ) : <span class="type" style="color:#EAB766">int</span></div>  <p class="para rdfs-comment">   统计出数组里的所有元素的数量，或者对象里的东西。  </p>    <p class="para">     对于对象，如果安装了 <a href="http://php.net/manual/zh/ref.spl.php" class="link">SPL</a>，可以通过实现     <span>Countable</span> 接口对 <span class="function"><strong style="color:#CC7832">count()</strong></span>挂钩（hook）     。该接口只有一个方法     <span class="methodname" style="color:#CC7832">{@link Countable::count()}</span>，此方法为 <span class="function"><strong style="color:#CC7832">count()</strong></span>     函数返回值。    </p>    <p class="para">     关于 PHP 中如何实现和使用数组可以参考手册中<a href="http://php.net/manual/zh/language.types.array.php" class="link">数组</a>章节中的详细描述。  </p> </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.count-parameters">  <h3 class="title">参数</h3>  <span>   <dl>         <dt><span class="parameter" style="color:#3A95FF">array_or_countable</span></dt>     <dd>      <p class="para">       数组或者 <a href="http://php.net/manual/zh/class.countable.php" class="classname">Countable</a>  对象。      </p>     </dd>             <dt><span class="parameter" style="color:#3A95FF">mode</span></dt>     <dd>      <p class="para">       如果可选的 <span class="parameter" style="color:#3A95FF">mode</span> 参数设为     <strong><span>COUNT_RECURSIVE</span></strong>（或 1），<span class="function"><strong style="color:#CC7832">count()</strong></span>     将递归地对数组计数。对计算多维数组的所有单元尤其有用。      </p>      <div class="caution"><strong class="caution">Caution</strong>       <p class="para">        <span class="function"><strong style="color:#CC7832">count()</strong></span> 能检测递归来避免无限循环，但每次出现时会产生 <strong><span>E_WARNING</span></strong> 错误        （如果 array 不止一次包含了自身）并返回大于预期的统计数字。       </p>      </div>     </dd>       </dl>  </span> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.count-returnvalues">  <h3 class="title">返回值</h3>  <p class="para">   返回 <span class="parameter" style="color:#3A95FF">array_or_countable</span> 中的单元数目。      如果参数既不是数组，也不是实现     <span>Countable</span> 接口的对象，将返回     <span>1</span>。   有个例外：如果     <span class="parameter" style="color:#3A95FF">array_or_countable</span> 是 <strong><span>NULL</span></strong> 则结果是 <span>0</span>。  </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.count-examples">  <h3 class="title">范例</h3>  <span>   <div class="example" id="example-5288">    <p><strong>Example #1 <span class="function"><strong style="color:#CC7832">count()</strong></span> 例子</strong></p>    <div class="example-contents"><div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"><span style="color: #9876AA">&lt;?php<br />$a</span><span style="color: #007700">[</span><span style="color: #9876AA">0</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #9876AA">1</span><span style="color: #007700">;<br /></span><span style="color: #9876AA">$a</span><span style="color: #007700">[</span><span style="color: #9876AA">1</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #9876AA">3</span><span style="color: #007700">;<br /></span><span style="color: #9876AA">$a</span><span style="color: #007700">[</span><span style="color: #9876AA">2</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #9876AA">5</span><span style="color: #007700">;<br /></span><span style="color: #9876AA">var_dump</span><span style="color: #007700">(</span><span style="color: #9876AA">count</span><span style="color: #007700">(</span><span style="color: #9876AA">$a</span><span style="color: #007700">));<br /><br /></span><span style="color: #9876AA">$b</span><span style="color: #007700">[</span><span style="color: #9876AA">0</span><span style="color: #007700">]&nbsp;&nbsp;=&nbsp;</span><span style="color: #9876AA">7</span><span style="color: #007700">;<br /></span><span style="color: #9876AA">$b</span><span style="color: #007700">[</span><span style="color: #9876AA">5</span><span style="color: #007700">]&nbsp;&nbsp;=&nbsp;</span><span style="color: #9876AA">9</span><span style="color: #007700">;<br /></span><span style="color: #9876AA">$b</span><span style="color: #007700">[</span><span style="color: #9876AA">10</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #9876AA">11</span><span style="color: #007700">;<br /></span><span style="color: #9876AA">var_dump</span><span style="color: #007700">(</span><span style="color: #9876AA">count</span><span style="color: #007700">(</span><span style="color: #9876AA">$b</span><span style="color: #007700">));<br /><br /></span><span style="color: #9876AA">var_dump</span><span style="color: #007700">(</span><span style="color: #9876AA">count</span><span style="color: #007700">(</span><span style="color: #9876AA">null</span><span style="color: #007700">));<br /><br /></span><span style="color: #9876AA">var_dump</span><span style="color: #007700">(</span><span style="color: #9876AA">count</span><span style="color: #007700">(</span><span style="color: #9876AA">false</span><span style="color: #007700">));<br /></span><span style="color: #9876AA">?&gt;</span></span></span></div>    </div>    <div class="example-contents"><p>以上例程会输出：</p></div>    <div class="example-contents screen" style="color:AFB1B3;background:black;padding-left:5px;"><div class="cdata"><span>int(3)<br>int(3)<br><br>Warning: count(): Parameter must be an array or an object that implements Countable in … on line 12 // PHP 7.2 起<br>int(0)<br><br>Warning: count(): Parameter must be an array or an object that implements Countable in … on line 14 // PHP 7.2 起<br>int(1)<br></span></div>    </div>   </div>  </span>  <p class="para">   <div class="example" id="example-5289">    <p><strong>Example #2 递归 <span class="function"><strong style="color:#CC7832">count()</strong></span> 例子</strong></p>    <div class="example-contents"><div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"><span style="color: #9876AA">&lt;?php<br />$food&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #DD0000">'fruits'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;array(</span><span style="color: #DD0000">'orange'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'banana'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'apple'</span><span style="color: #007700">),<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'veggie'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;array(</span><span style="color: #DD0000">'carrot'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'collard'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'pea'</span><span style="color: #007700">));<br /><br /></span><span style="color: #FF8000">//&nbsp;recursive&nbsp;count<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #9876AA">count</span><span style="color: #007700">(</span><span style="color: #9876AA">$food</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">COUNT_RECURSIVE</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;output&nbsp;8<br /><br />//&nbsp;normal&nbsp;count<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #9876AA">count</span><span style="color: #007700">(</span><span style="color: #9876AA">$food</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;output&nbsp;2<br /><br /></span><span style="color: #9876AA">?&gt;</span></span></span></div>    </div>   </div>  </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 changelog" id="refsect1-function.count-changelog">  <h3 class="title">更新日志</h3>  <table class="doctable informaltable">       <thead>     <tr>      <th>版本</th>      <th>说明</th>     </tr>    </thead>    <tbody class="tbody">     <tr>      <td>7.2.0</td>      <td>       当无效的 countable 类型传递给 <span class="parameter" style="color:#3A95FF">array_or_countable</span> 参数时，<span class="function"><strong style="color:#CC7832">count()</strong></span> 会产生警告。      </td>     </tr>    </tbody>     </table> </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.count-seealso">  <h3 class="title">参见</h3>  <span>   <ul class="simplelist">    <li class="member"><span class="function">{@link is_array()} - 检测变量是否是数组</span></li>    <li class="member"><span class="function">{@link isset()} - 检测变量是否已设置并且非 NULL</span></li>    <li class="member"><span class="function">{@link empty()} - 检查一个变量是否为空</span></li>    <li class="member"><span class="function">{@link strlen()} - 获取字符串长度</span></li>    <li class="member"><span class="function">{@link is_countable()} - Verify that the contents of a variable is a countable value</span></li>   </ul>  </span> </div></div>
*/
	public function count() {}

	/**
	 * Returns the status error message, system and/or zip messages
	 * @link https://php.net/manual/en/ziparchive.getstatusstring.php
	 * @return string|false a string with the status message on success or <b>FALSE</b> on failure.
	 * @since 5.2.7
	 */
	public function getStatusString () {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.8.0)<br/>
	 * Add a new directory
	 * @link https://php.net/manual/en/ziparchive.addemptydir.php
	 * @param string $dirname <p>
	 * The directory to add.
	 * </p>
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 */
	public function addEmptyDir ($dirname) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.1.0)<br/>
	 * Add a file to a ZIP archive using its contents
	 * @link https://php.net/manual/en/ziparchive.addfromstring.php
	 * @param string $localname <p>
	 * The name of the entry to create.
	 * </p>
	 * @param string $contents <p>
	 * The contents to use to create the entry. It is used in a binary
	 * safe mode.
	 * </p>
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 */
	public function addFromString ($localname, $contents) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.1.0)<br/>
	 * Adds a file to a ZIP archive from the given path
	 * @link https://php.net/manual/en/ziparchive.addfile.php
	 * @param string $filename <p>
	 * The path to the file to add.
	 * </p>
	 * @param string $localname [optional] <p>
	 * If supplied, this is the local name inside the ZIP archive that will override the <i>filename</i>.
	 * </p>
	 * @param int $start [optional] <p>
	 * This parameter is not used but is required to extend <b>ZipArchive</b>.
	 * </p>
	 * @param int $length [optional] <p>
	 * This parameter is not used but is required to extend <b>ZipArchive</b>.
	 * </p>
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 */
	public function addFile ($filename, $localname = null, $start = 0, $length = 0) {}

	/**
	 * (PHP 5 &gt;= 5.3.0, PECL zip &gt;= 1.9.0)<br/>
	 * Add files from a directory by glob pattern
	 * @link https://php.net/manual/en/ziparchive.addglob.php
	 * @param string $pattern <p>
	 * A <b>glob</b> pattern against which files will be matched.
	 * </p>
	 * @param int $flags [optional] <p>
	 * A bit mask of glob() flags.
	 * </p>
	 * @param array $options [optional] <p>
	 * An associative array of options. Available options are:
	 * <p>
	 * "add_path"
	 * </p>
	 * <p>
	 * Prefix to prepend when translating to the local path of the file within
	 * the archive. This is applied after any remove operations defined by the
	 * "remove_path" or "remove_all_path"
	 * options.
	 * </p>
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 */
	public function addGlob ($pattern, $flags = 0, array $options = array()) {}

	/**
	 * (PHP 5 &gt;= 5.3.0, PECL zip &gt;= 1.9.0)<br/>
	 * Add files from a directory by PCRE pattern
	 * @link https://php.net/manual/en/ziparchive.addpattern.php
	 * @param string $pattern <p>
	 * A PCRE pattern against which files will be matched.
	 * </p>
	 * @param string $path [optional] <p>
	 * The directory that will be scanned. Defaults to the current working directory.
	 * </p>
	 * @param array $options [optional] <p>
	 * An associative array of options accepted by <b>ZipArchive::addGlob</b>.
	 * </p>
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 */
	public function addPattern ($pattern, $path = '.', array $options = array()) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.5.0)<br/>
	 * Renames an entry defined by its index
	 * @link https://php.net/manual/en/ziparchive.renameindex.php
	 * @param int $index <p>
	 * Index of the entry to rename.
	 * </p>
	 * @param string $newname <p>
	 * New name.
	 * </p>
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 */
	public function renameIndex ($index, $newname) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.5.0)<br/>
	 * Renames an entry defined by its name
	 * @link https://php.net/manual/en/ziparchive.renamename.php
	 * @param string $name <p>
	 * Name of the entry to rename.
	 * </p>
	 * @param string $newname <p>
	 * New name.
	 * </p>
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 */
	public function renameName ($name, $newname) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.4.0)<br/>
	 * Set the comment of a ZIP archive
	 * @link https://php.net/manual/en/ziparchive.setarchivecomment.php
	 * @param string $comment <p>
	 * The contents of the comment.
	 * </p>
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 */
	public function setArchiveComment ($comment) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.1.0)<br/>
	 * Returns the Zip archive comment
	 * @link https://php.net/manual/en/ziparchive.getarchivecomment.php
	 * @param int $flags [optional] <p>
	 * If flags is set to <b>ZipArchive::FL_UNCHANGED</b>, the original unchanged
	 * comment is returned.
	 * </p>
	 * @return string|false the Zip archive comment or <b>FALSE</b> on failure.
	 */
	public function getArchiveComment ($flags = null) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.4.0)<br/>
	 * Set the comment of an entry defined by its index
	 * @link https://php.net/manual/en/ziparchive.setcommentindex.php
	 * @param int $index <p>
	 * Index of the entry.
	 * </p>
	 * @param string $comment <p>
	 * The contents of the comment.
	 * </p>
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 */
	public function setCommentIndex ($index, $comment) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.4.0)<br/>
	 * Set the comment of an entry defined by its name
	 * @link https://php.net/manual/en/ziparchive.setcommentname.php
	 * @param string $name <p>
	 * Name of the entry.
	 * </p>
	 * @param string $comment <p>
	 * The contents of the comment.
	 * </p>
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 */
	public function setCommentName ($name, $comment) {}

	/**
	 * Set the compression method of an entry defined by its index
	 * @link https://php.net/manual/en/ziparchive.setcompressionindex.php
	 * @param int $index Index of the entry.
	 * @param int $comp_method The compression method. Either ZipArchive::CM_DEFAULT, ZipArchive::CM_STORE or ZipArchive::CM_DEFLATE.
	 * @param int $comp_flags [optional] Compression flags. Currently unused.
	 * @return bool Returns TRUE on success or FALSE on failure.
	 * @since 7.0
	 */
	public function setCompressionIndex ($index, $comp_method, $comp_flags = 0) {}

	/**
	 * Set the compression method of an entry defined by its name
	 * https://secure.php.net/manual/en/ziparchive.setcompressionname.php
	 * @param string $name Name of the entry.
	 * @param int $comp_method The compression method. Either ZipArchive::CM_DEFAULT, ZipArchive::CM_STORE or ZipArchive::CM_DEFLATE.
	 * @param int $comp_flags [optional] Compression flags. Currently unused.
	 * @return bool Returns TRUE on success or FALSE on failure.
	 * @since 7.0
	 */
	public function setCompressionName ($name, $comp_method, $comp_flags = 0){}

/**
*<div id="ziparchive.setencryptionindex" class="refentry"> <div class="refnamediv">  <h1 class="refname">ZipArchive::setEncryptionIndex</h1>  <p class="verinfo">(PHP &gt;= 7.2.0, PECL zip &gt;= 1.14.0)</p><p class="refpurpose"><span class="refname">ZipArchive::setEncryptionIndex</span> &mdash; <span class="dc-title">Set the encryption method of an entry defined by its index</span></p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-ziparchive.setencryptionindex-description">  <h3 class="title">说明</h3>  <div class="methodsynopsis dc-description">   <span class="modifier">public</span>    <span class="methodname" style="color:#CC7832"><strong>ZipArchive::setEncryptionIndex</strong></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$index</span></span>   , <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$method</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$password</span></span>  ] ) : <span class="type" style="color:#EAB766">bool</span></div>  <p class="para rdfs-comment">   Set the encryption method of an entry defined by its index.  </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-ziparchive.setencryptionindex-parameters">  <h3 class="title">参数</h3>  <span>   <dl>         <dt><span class="parameter" style="color:#3A95FF">index</span></dt>     <dd>      <p class="para">       Index of the entry.      </p>     </dd>             <dt><span class="parameter" style="color:#3A95FF">method</span></dt>     <dd>      <p class="para">       The encryption method defined by one of the ZipArchive::EM_ constants.      </p>     </dd>             <dt><span class="parameter" style="color:#3A95FF">password</span></dt>     <dd>      <p class="para">       Optional password, default used when missing.      </p>     </dd>       </dl>  </span> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-ziparchive.setencryptionindex-returnvalues">  <h3 class="title">返回值</h3>  <p class="para">   成功时返回 <strong><span>TRUE</span></strong>， 或者在失败时返回 <strong><span>FALSE</span></strong>。  </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 notes" id="refsect1-ziparchive.setencryptionindex-notes">  <h3 class="title">注释</h3>  <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>:    <p class="para">    This function is only available if built against libzip ≥ 1.2.0.   </p>  </p></blockquote> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-ziparchive.setencryptionindex-seealso">  <h3 class="title">参见</h3>  <span>   <ul class="simplelist">    <li class="member"><span class="methodname" style="color:#CC7832">{@link ZipArchive::setPassword()} - Set the password for the active archive</span></li>    <li class="member"><span class="methodname" style="color:#CC7832">{@link ZipArchive::setEncryptionName()} - Set the encryption method of an entry defined by its name</span></li>   </ul>  </span> </div></div>
     * @return bool Returns TRUE on success or FALSE on failure.*/
    public function setEncryptionIndex ($index, $method, $password = null) {}

/**
*<div id="ziparchive.setencryptionname" class="refentry"> <div class="refnamediv">  <h1 class="refname">ZipArchive::setEncryptionName</h1>  <p class="verinfo">(PHP &gt;= 7.2.0, PECL zip &gt;= 1.14.0)</p><p class="refpurpose"><span class="refname">ZipArchive::setEncryptionName</span> &mdash; <span class="dc-title">Set the encryption method of an entry defined by its name</span></p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-ziparchive.setencryptionname-description">  <h3 class="title">说明</h3>  <div class="methodsynopsis dc-description">   <span class="modifier">public</span>    <span class="methodname" style="color:#CC7832"><strong>ZipArchive::setEncryptionName</strong></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$name</span></span>   , <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$method</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$password</span></span>  ] ) : <span class="type" style="color:#EAB766">bool</span></div>  <p class="para rdfs-comment">   Set the encryption method of an entry defined by its name.  </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-ziparchive.setencryptionname-parameters">  <h3 class="title">参数</h3>  <span>   <dl>         <dt><span class="parameter" style="color:#3A95FF">name</span></dt>     <dd>      <p class="para">       Name of the entry.      </p>     </dd>             <dt><span class="parameter" style="color:#3A95FF">method</span></dt>     <dd>      <p class="para">       The encryption method defined by one of the ZipArchive::EM_ constants.      </p>     </dd>             <dt><span class="parameter" style="color:#3A95FF">password</span></dt>     <dd>      <p class="para">       Optional password, default used when missing.      </p>     </dd>       </dl>  </span> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-ziparchive.setencryptionname-returnvalues">  <h3 class="title">返回值</h3>  <p class="para">   成功时返回 <strong><span>TRUE</span></strong>， 或者在失败时返回 <strong><span>FALSE</span></strong>。  </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-ziparchive.setencryptionname-examples">  <h3 class="title">范例</h3>    <span>     This example creates a ZIP file archive     <var class="filename">test.zip</var> and add     the file <var class="filename">test.txt</var>     encrypted using the AES 256 method.    </span>    <div class="example" id="example-793">     <p><strong>Example #1 Archive and encrypt a file</strong></p>     <div class="example-contents"><div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"><span style="color: #9876AA">&lt;?php<br />$zip&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #9876AA">ZipArchive</span><span style="color: #007700">();<br />if&nbsp;(</span><span style="color: #9876AA">$zip</span><span style="color: #007700">-&gt;</span><span style="color: #9876AA">open</span><span style="color: #007700">(</span><span style="color: #DD0000">'test.zip'</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">ZipArchive</span><span style="color: #007700">::</span><span style="color: #9876AA">CREATE</span><span style="color: #007700">)&nbsp;===&nbsp;</span><span style="color: #9876AA">TRUE</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #9876AA">$zip</span><span style="color: #007700">-&gt;</span><span style="color: #9876AA">setPassword</span><span style="color: #007700">(</span><span style="color: #DD0000">'secret'</span><span style="color: #007700">);<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #9876AA">$zip</span><span style="color: #007700">-&gt;</span><span style="color: #9876AA">addFile</span><span style="color: #007700">(</span><span style="color: #DD0000">'text.txt'</span><span style="color: #007700">);<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #9876AA">$zip</span><span style="color: #007700">-&gt;</span><span style="color: #9876AA">setEncryptionName</span><span style="color: #007700">(</span><span style="color: #DD0000">'text.txt'</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">ZipArchive</span><span style="color: #007700">::</span><span style="color: #9876AA">EM_AES_256</span><span style="color: #007700">);<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #9876AA">$zip</span><span style="color: #007700">-&gt;</span><span style="color: #9876AA">close</span><span style="color: #007700">();<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"Ok\n"</span><span style="color: #007700">;<br />}&nbsp;else&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"KO\n"</span><span style="color: #007700">;<br />}<br /></span><span style="color: #9876AA">?&gt;</span></span></span></div>     </div>    </div> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 notes" id="refsect1-ziparchive.setencryptionname-notes">  <h3 class="title">注释</h3>  <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>:    <p class="para">    This function is only available if built against libzip ≥ 1.2.0.   </p>  </p></blockquote> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-ziparchive.setencryptionname-seealso">  <h3 class="title">参见</h3>  <span>   <ul class="simplelist">    <li class="member"><span class="methodname" style="color:#CC7832">{@link ZipArchive::setPassword()} - Set the password for the active archive</span></li>    <li class="member"><span class="methodname" style="color:#CC7832">{@link ZipArchive::setEncryptionIndex()} - Set the encryption method of an entry defined by its index</span></li>   </ul>  </span> </div></div>
     * @return bool Returns TRUE on success or FALSE on failure.*/
    public function setEncryptionName ($name, $method, $password = null) {}

/**
*<div id="ziparchive.setpassword" class="refentry"> <div class="refnamediv">  <h1 class="refname">ZipArchive::setPassword</h1>  <p class="verinfo">(PHP 5 &gt;= 5.6.0, PHP 7, PECL zip &gt;= 1.12.4)</p><p class="refpurpose"><span class="refname">ZipArchive::setPassword</span> &mdash; <span class="dc-title">Set the password for the active archive</span></p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-ziparchive.setpassword-description">  <h3 class="title">说明</h3>  <div class="methodsynopsis dc-description">   <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><strong>ZipArchive::setPassword</strong></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$password</span></span>   ) : <span class="type" style="color:#EAB766">bool</span></div>  <p class="para rdfs-comment">   Sets the password for the active archive.  </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-ziparchive.setpassword-parameters">  <h3 class="title">参数</h3>  <dl>       <dt><span class="parameter" style="color:#3A95FF">password</span></dt>    <dd>     <span>      The password to be used for the archive.     </span>    </dd>     </dl> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-ziparchive.setpassword-returnvalues">  <h3 class="title">返回值</h3>  <p class="para">   成功时返回 <strong><span>TRUE</span></strong>， 或者在失败时返回 <strong><span>FALSE</span></strong>。  </p> </div>  <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 notes" id="refsect1-ziparchive.setpassword-notes">  <h3 class="title">注释</h3>  <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>:    <p class="para">    As of PHP 7.2.0 and libzip 1.2.0 the password is used to decompress the archive,    and is also the default password for <span class="methodname" style="color:#CC7832">{@link ZipArchive::setEncryptionName()}</span>    and <span class="methodname" style="color:#CC7832">{@link ZipArchive::setEncryptionIndex()}</span>.    Formerly, this function only set the password to be used to decompress the archive;    it did not turn a non-password-protected <a href="http://php.net/manual/zh/class.ziparchive.php" class="classname">ZipArchive</a>    into a password-protected <a href="http://php.net/manual/zh/class.ziparchive.php" class="classname">ZipArchive</a>.   </p>  </p></blockquote> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-ziparchive.setpassword-seealso">  <h3 class="title">参见</h3>  <span>   <ul class="simplelist">    <li class="member"><span class="methodname" style="color:#CC7832">{@link ZipArchive::setEncryptionIndex()} - Set the encryption method of an entry defined by its index</span></li>    <li class="member"><span class="methodname" style="color:#CC7832">{@link ZipArchive::setEncryptionName()} - Set the encryption method of an entry defined by its name</span></li>   </ul>  </span> </div></div>
     * @return bool*/
    public function setPassword($password) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.4.0)<br/>
	 * Returns the comment of an entry using the entry index
	 * @link https://php.net/manual/en/ziparchive.getcommentindex.php
	 * @param int $index <p>
	 * Index of the entry
	 * </p>
	 * @param int $flags [optional] <p>
	 * If flags is set to <b>ZipArchive::FL_UNCHANGED</b>, the original unchanged
	 * comment is returned.
	 * </p>
	 * @return string|false the comment on success or <b>FALSE</b> on failure.
	 */
	public function getCommentIndex ($index, $flags = null) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.4.0)<br/>
	 * Returns the comment of an entry using the entry name
	 * @link https://php.net/manual/en/ziparchive.getcommentname.php
	 * @param string $name <p>
	 * Name of the entry
	 * </p>
	 * @param int $flags [optional] <p>
	 * If flags is set to <b>ZipArchive::FL_UNCHANGED</b>, the original unchanged
	 * comment is returned.
	 * </p>
	 * @return string|false the comment on success or <b>FALSE</b> on failure.
	 */
	public function getCommentName ($name, $flags = null) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.5.0)<br/>
	 * delete an entry in the archive using its index
	 * @link https://php.net/manual/en/ziparchive.deleteindex.php
	 * @param int $index <p>
	 * Index of the entry to delete.
	 * </p>
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 */
	public function deleteIndex ($index) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.5.0)<br/>
	 * delete an entry in the archive using its name
	 * @link https://php.net/manual/en/ziparchive.deletename.php
	 * @param string $name <p>
	 * Name of the entry to delete.
	 * </p>
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 */
	public function deleteName ($name) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.5.0)<br/>
	 * Get the details of an entry defined by its name.
	 * @link https://php.net/manual/en/ziparchive.statname.php
	 * @param string $name <p>
	 * Name of the entry
	 * </p>
	 * @param int $flags [optional] <p>
	 * The flags argument specifies how the name lookup should be done.
	 * Also, <b>ZipArchive::FL_UNCHANGED</b> may be ORed to it to request
	 * information about the original file in the archive,
	 * ignoring any changes made.
	 * <p>
	 * <b>ZipArchive::FL_NOCASE</b>
	 * </p>
	 * @return array|false an array containing the entry details or <b>FALSE</b> on failure.
	 */
	public function statName ($name, $flags = null) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.1.0)<br/>
	 * Get the details of an entry defined by its index.
	 * @link https://php.net/manual/en/ziparchive.statindex.php
	 * @param int $index <p>
	 * Index of the entry
	 * </p>
	 * @param int $flags [optional] <p>
	 * <b>ZipArchive::FL_UNCHANGED</b> may be ORed to it to request
	 * information about the original file in the archive,
	 * ignoring any changes made.
	 * </p>
	 * @return array|false an array containing the entry details or <b>FALSE</b> on failure.
	 */
	public function statIndex ($index, $flags = null) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.5.0)<br/>
	 * Returns the index of the entry in the archive
	 * @link https://php.net/manual/en/ziparchive.locatename.php
	 * @param string $name <p>
	 * The name of the entry to look up
	 * </p>
	 * @param int $flags [optional] <p>
	 * The flags are specified by ORing the following values,
	 * or 0 for none of them.
	 * <p>
	 * <b>ZipArchive::FL_NOCASE</b>
	 * </p>
	 * @return int|false the index of the entry on success or <b>FALSE</b> on failure.
	 */
	public function locateName ($name, $flags = null) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.5.0)<br/>
	 * Returns the name of an entry using its index
	 * @link https://php.net/manual/en/ziparchive.getnameindex.php
	 * @param int $index <p>
	 * Index of the entry.
	 * </p>
	 * @param int $flags [optional] <p>
	 * If flags is set to <b>ZipArchive::FL_UNCHANGED</b>, the original unchanged
	 * name is returned.
	 * </p>
	 * @return string|false the name on success or <b>FALSE</b> on failure.
	 */
	public function getNameIndex ($index, $flags = null) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.1.0)<br/>
	 * Revert all global changes done in the archive.
	 * @link https://php.net/manual/en/ziparchive.unchangearchive.php
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 */
	public function unchangeArchive () {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.1.0)<br/>
	 * Undo all changes done in the archive
	 * @link https://php.net/manual/en/ziparchive.unchangeall.php
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 */
	public function unchangeAll () {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.1.0)<br/>
	 * Revert all changes done to an entry at the given index
	 * @link https://php.net/manual/en/ziparchive.unchangeindex.php
	 * @param int $index <p>
	 * Index of the entry.
	 * </p>
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 */
	public function unchangeIndex ($index) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.5.0)<br/>
	 * Revert all changes done to an entry with the given name.
	 * @link https://php.net/manual/en/ziparchive.unchangename.php
	 * @param string $name <p>
	 * Name of the entry.
	 * </p>
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 */
	public function unchangeName ($name) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.1.0)<br/>
	 * Extract the archive contents
	 * @link https://php.net/manual/en/ziparchive.extractto.php
	 * @param string $destination <p>
	 * Location where to extract the files.
	 * </p>
	 * @param mixed $entries [optional] <p>
	 * The entries to extract. It accepts either a single entry name or
	 * an array of names.
	 * </p>
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 */
	public function extractTo ($destination, $entries = null) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.1.0)<br/>
	 * Returns the entry contents using its name
	 * @link https://php.net/manual/en/ziparchive.getfromname.php
	 * @param string $name <p>
	 * Name of the entry
	 * </p>
	 * @param int $length [optional] <p>
	 * The length to be read from the entry. If 0, then the
	 * entire entry is read.
	 * </p>
	 * @param int $flags [optional] <p>
	 * The flags to use to open the archive. the following values may
	 * be ORed to it.
	 * <p>
	 * <b>ZipArchive::FL_UNCHANGED</b>
	 * </p>
	 * @return string|false the contents of the entry on success or <b>FALSE</b> on failure.
	 */
	public function getFromName ($name, $length = 0, $flags = null) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.3.0)<br/>
	 * Returns the entry contents using its index
	 * @link https://php.net/manual/en/ziparchive.getfromindex.php
	 * @param int $index <p>
	 * Index of the entry
	 * </p>
	 * @param int $length [optional] <p>
	 * The length to be read from the entry. If 0, then the
	 * entire entry is read.
	 * </p>
	 * @param int $flags [optional] <p>
	 * The flags to use to open the archive. the following values may
	 * be ORed to it.
	 * <p>
	 * <b>ZipArchive::FL_UNCHANGED</b>
	 * </p>
	 * @return string|false the contents of the entry on success or <b>FALSE</b> on failure.
	 */
	public function getFromIndex ($index, $length = 0, $flags = null) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.1.0)<br/>
	 * Get a file handler to the entry defined by its name (read only).
	 * @link https://php.net/manual/en/ziparchive.getstream.php
	 * @param string $name <p>
	 * The name of the entry to use.
	 * </p>
	 * @return resource|false a file pointer (resource) on success or <b>FALSE</b> on failure.
	 */
	public function getStream ($name) {}

}

/**
*<div id="function.zip-open" class="refentry"> <div class="refnamediv">  <h1 class="refname">zip_open</h1>  <p class="verinfo">(PHP 4 &gt;= 4.1.0, PHP 5 &gt;= 5.2.0, PHP 7, PECL zip &gt;= 1.0.0)</p><p class="refpurpose"><span class="refname">zip_open</span> &mdash; <span class="dc-title">打开ZIP存档文件</span></p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.zip-open-description">  <h3 class="title">说明</h3>  <div class="methodsynopsis dc-description">   <span class="methodname" style="color:#CC7832"><strong>zip_open</strong></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$filename</span></span>   ) : <span class="type" style="color:#EAB766">resource</span></div>  <p class="para rdfs-comment">   打开一个新的ZIP归档文件进行读取。   </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.zip-open-parameters">  <h3 class="title">参数</h3>  <span>   <dl>         <dt><span class="parameter" style="color:#3A95FF">filename</span></dt>     <dd>      <p class="para">       待打开ZIP归档的文件名。      </p>     </dd>       </dl>  </span> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.zip-open-returnvalues">  <h3 class="title">返回值</h3>  <p class="para">   成功的时候返回一个资源句柄供函数<span class="function">{@link zip_read()}</span> 和 <span class="function">{@link zip_close()}</span>后续使用;   如果<span class="parameter" style="color:#3A95FF">filename</span> 文件不存在或者出现其他错误，则会返回相应的错误码。  </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.zip-open-seealso">  <h3 class="title">参见</h3>  <span>   <ul class="simplelist">    <li class="member"><span class="function">{@link zip_read()} - 读取ZIP存档文件中下一项</span></li>    <li class="member"><span class="function">{@link zip_close()} - 关闭一个ZIP档案文件</span></li>   </ul>  </span> </div></div>
 * @return resource a resource handle for later use with*/
function zip_open ($filename) {}

/**
*<div id="function.zip-close" class="refentry"> <div class="refnamediv">  <h1 class="refname">zip_close</h1>  <p class="verinfo">(PHP 4 &gt;= 4.1.0, PHP 5 &gt;= 5.2.0, PHP 7, PECL zip &gt;= 1.0.0)</p><p class="refpurpose"><span class="refname">zip_close</span> &mdash; <span class="dc-title">关闭一个ZIP档案文件</span></p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.zip-close-description">  <h3 class="title">说明</h3>  <div class="methodsynopsis dc-description">   <span class="methodname" style="color:#CC7832"><strong>zip_close</strong></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">resource</span> <span class="parameter" style="color:#3A95FF">$zip</span></span>   ) : <span class="type" style="color:#EAB766"><span class="type void" style="color:#EAB766">void</span></span></div>  <p class="para rdfs-comment">   关闭一个指定的ZIP档案文件。  </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.zip-close-parameters">  <h3 class="title">参数</h3>  <span>   <dl>         <dt><span class="parameter" style="color:#3A95FF">zip</span></dt>     <dd>      <p class="para">       一个由<span class="function">{@link zip_open()}</span>打开的ZIP文件资源。      </p>     </dd>       </dl>  </span> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.zip-close-returnvalues">  <h3 class="title">返回值</h3>  <p class="para">   没有返回值。  </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.zip-close-seealso">  <h3 class="title">参见</h3>  <span>   <ul class="simplelist">    <li class="member"><span class="function">{@link zip_open()} - 打开ZIP存档文件</span></li>    <li class="member"><span class="function">{@link zip_read()} - 读取ZIP存档文件中下一项</span></li>   </ul>  </span> </div></div>
 * @return void No value is returned.*/
function zip_close ($zip) {}

/**
*<div id="function.zip-read" class="refentry"> <div class="refnamediv">  <h1 class="refname">zip_read</h1>  <p class="verinfo">(PHP 4 &gt;= 4.1.0, PHP 5 &gt;= 5.2.0, PHP 7, PECL zip &gt;= 1.0.0)</p><p class="refpurpose"><span class="refname">zip_read</span> &mdash; <span class="dc-title">读取ZIP存档文件中下一项</span></p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.zip-read-description">  <h3 class="title">说明</h3>  <div class="methodsynopsis dc-description">   <span class="methodname" style="color:#CC7832"><strong>zip_read</strong></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">resource</span> <span class="parameter" style="color:#3A95FF">$zip</span></span>   ) : <span class="type" style="color:#EAB766">resource</span></div>  <p class="para rdfs-comment">   读取ZIP存档文件中下一项。  </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.zip-read-parameters">  <h3 class="title">参数</h3>  <span>   <dl>         <dt><span class="parameter" style="color:#3A95FF">zip</span></dt>     <dd>      <p class="para">        一个ZIP压缩文件,该ZIP归档文件之前应由函数 <span class="function">{@link zip_open()}</span> 打开。      </p>     </dd>       </dl>  </span> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.zip-read-returnvalues">  <h3 class="title">返回值</h3>  <p class="para">   成功的时候返回该当前实体资源供<span>zip_entry_...</span> 系列函数后续使用;    如果没有更多的读取项，则会返回 <strong><span>FALSE</span></strong>   如果遇到错误则会返回相应的错误码。  </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.zip-read-seealso">  <h3 class="title">参见</h3>  <span>   <ul class="simplelist">    <li class="member"><span class="function">{@link zip_open()} - 打开ZIP存档文件</span></li>    <li class="member"><span class="function">{@link zip_close()} - 关闭一个ZIP档案文件</span></li>    <li class="member"><span class="function">{@link zip_entry_open()} - 打开用于读取的目录实体</span></li>    <li class="member"><span class="function">{@link zip_entry_read()} - 读取一个打开了的压缩目录实体</span></li>   </ul>  </span> </div></div>
 * @return resource a directory entry resource for later use with the*/
function zip_read ($zip) {}

/**
*<div id="function.zip-entry-open" class="refentry"> <div class="refnamediv">  <h1 class="refname">zip_entry_open</h1>  <p class="verinfo">(PHP 4 &gt;= 4.1.0, PHP 5 &gt;= 5.2.0, PHP 7, PECL zip &gt;= 1.0.0)</p><p class="refpurpose"><span class="refname">zip_entry_open</span> &mdash; <span class="dc-title">打开用于读取的目录实体</span></p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.zip-entry-open-description">  <h3 class="title">说明</h3>  <div class="methodsynopsis dc-description">   <span class="methodname" style="color:#CC7832"><strong>zip_entry_open</strong></span>          ( <span class="methodparam"><span class="type" style="color:#EAB766">resource</span> <span class="parameter" style="color:#3A95FF">$zip</span></span>   , <span class="methodparam"><span class="type" style="color:#EAB766">resource</span> <span class="parameter" style="color:#3A95FF">$zip_entry</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$mode</span></span>  ] ) : <span class="type" style="color:#EAB766">bool</span></div>  <p class="para rdfs-comment">   打开ZIP文件中的目录实体以便后续读取。   </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.zip-entry-open-parameters">  <h3 class="title">参数</h3>  <span>   <dl>         <dt><span class="parameter" style="color:#3A95FF">zip</span></dt>     <dd>      <p class="para">       由函数<span class="function">{@link zip_open()}</span>返回的有效的资源句柄。      </p>     </dd>             <dt><span class="parameter" style="color:#3A95FF">zip_entry</span></dt>     <dd>      <p class="para">       由函数<span class="function">{@link zip_read()}</span>返回的目录实体。      </p>     </dd>             <dt><span class="parameter" style="color:#3A95FF">mode</span></dt>     <dd>      <p class="para">       任何在<span class="function">{@link fopen()}</span>处理文档中指定的模式。      </p>      <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>:        <p class="para">        由于ZIP在PHP中只支持读取模式，所以<span class="parameter" style="color:#3A95FF">mode</span>         实际上总是被设置为<span>&quot;rb&quot;</span>(其他模式会被忽略)。       </p>      </p></blockquote>     </dd>       </dl>  </span> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.zip-entry-open-returnvalues">  <h3 class="title">返回值</h3>  <p class="para">   成功时返回 <strong><span>TRUE</span></strong>， 或者在失败时返回 <strong><span>FALSE</span></strong>。  </p>  <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>:    <p class="para">    与<span class="function">{@link fopen()}</span>和其他类似的方法不同，<span class="function"><strong style="color:#CC7832">zip_entry_open()</strong></span>    的返回值只用于标示该操作结果，不需要读取或关闭该目录实体。   </p>  </p></blockquote> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.zip-entry-open-seealso">  <h3 class="title">参见</h3>  <span>   <ul class="simplelist">    <li class="member"><span class="function">{@link zip_entry_close()} - 关闭目录项</span></li>    <li class="member"><span class="function">{@link zip_entry_read()} - 读取一个打开了的压缩目录实体</span></li>   </ul>  </span> </div></div>
 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.*/
function zip_entry_open ($zip, $zip_entry, $mode = null) {}

/**
*<div id="function.zip-entry-close" class="refentry"> <div class="refnamediv">  <h1 class="refname">zip_entry_close</h1>  <p class="verinfo">(PHP 4 &gt;= 4.1.0, PHP 5 &gt;= 5.2.0, PHP 7, PECL zip &gt;= 1.0.0)</p><p class="refpurpose"><span class="refname">zip_entry_close</span> &mdash; <span class="dc-title">关闭目录项</span></p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.zip-entry-close-description">  <h3 class="title">说明</h3>  <div class="methodsynopsis dc-description">   <span class="methodname" style="color:#CC7832"><strong>zip_entry_close</strong></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">resource</span> <span class="parameter" style="color:#3A95FF">$zip_entry</span></span>   ) : <span class="type" style="color:#EAB766">bool</span></div>  <p class="para rdfs-comment">   关闭指定的目录项。   </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.zip-entry-close-parameters">  <h3 class="title">参数</h3>  <span>   <dl>         <dt><span class="parameter" style="color:#3A95FF">zip_entry</span></dt>     <dd>      <p class="para">       一个由<span class="function">{@link zip_entry_open()}</span>打开的项目。      </p>     </dd>       </dl>  </span> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.zip-entry-close-returnvalues">  <h3 class="title">返回值</h3>  <p class="para">   成功时返回 <strong><span>TRUE</span></strong>， 或者在失败时返回 <strong><span>FALSE</span></strong>。  </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.zip-entry-close-seealso">  <h3 class="title">参见</h3>  <span>   <ul class="simplelist">    <li class="member"><span class="function">{@link zip_entry_open()} - 打开用于读取的目录实体</span></li>    <li class="member"><span class="function">{@link zip_entry_read()} - 读取一个打开了的压缩目录实体</span></li>   </ul>  </span> </div></div>
 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.*/
function zip_entry_close ($zip_entry) {}

/**
*<div id="function.zip-entry-read" class="refentry"> <div class="refnamediv">  <h1 class="refname">zip_entry_read</h1>  <p class="verinfo">(PHP 4 &gt;= 4.1.0, PHP 5 &gt;= 5.2.0, PHP 7, PECL zip &gt;= 1.0.0)</p><p class="refpurpose"><span class="refname">zip_entry_read</span> &mdash; <span class="dc-title">读取一个打开了的压缩目录实体</span></p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.zip-entry-read-description">  <h3 class="title">说明</h3>  <div class="methodsynopsis dc-description">   <span class="methodname" style="color:#CC7832"><strong>zip_entry_read</strong></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">resource</span> <span class="parameter" style="color:#3A95FF">$zip_entry</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$length</span><span class="initializer"> = 1024</span></span>  ] ) : <span class="type" style="color:#EAB766">string</span></div>  <p class="para rdfs-comment">      读取一个打开了的压缩目录实体。  </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.zip-entry-read-parameters">  <h3 class="title">参数</h3>  <span>   <dl>         <dt><span class="parameter" style="color:#3A95FF">zip_entry</span></dt>     <dd>      <p class="para">       由函数<span class="function">{@link zip_read()}</span> 返回的目录实体。      </p>     </dd>             <dt><span class="parameter" style="color:#3A95FF">length</span></dt>     <dd>      <p class="para">       需要返回的字节数。      </p>      <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>:        <p class="para">        这字节数应该是你所要读取的未压缩的字节数。       </p>      </p></blockquote>     </dd>       </dl>  </span> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.zip-entry-read-returnvalues">  <h3 class="title">返回值</h3>  <p class="para">   成功的时候返回读取到的数据；到达文件末尾的时候返回一个空的字符串；   读取出错的时候则会返回<strong><span>FALSE</span></strong>   </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.zip-entry-read-seealso">  <h3 class="title">参见</h3>  <span>   <ul class="simplelist">    <li class="member"><span class="function">{@link zip_entry_open()} - 打开用于读取的目录实体</span></li>    <li class="member"><span class="function">{@link zip_entry_close()} - 关闭目录项</span></li>    <li class="member"><span class="function">{@link zip_entry_filesize()} - 检索目录实体的实际大小</span></li>   </ul>  </span> </div></div>
 * @return string|false the data read, empty string on end of a file, or <b>FALSE</b> on error.*/
function zip_entry_read ($zip_entry, $length = 1024) {}

/**
*<div id="function.zip-entry-filesize" class="refentry"> <div class="refnamediv">  <h1 class="refname">zip_entry_filesize</h1>  <p class="verinfo">(PHP 4 &gt;= 4.1.0, PHP 5 &gt;= 5.2.0, PHP 7, PECL zip &gt;= 1.0.0)</p><p class="refpurpose"><span class="refname">zip_entry_filesize</span> &mdash; <span class="dc-title">检索目录实体的实际大小</span></p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.zip-entry-filesize-description">  <h3 class="title">说明</h3>  <div class="methodsynopsis dc-description">   <span class="methodname" style="color:#CC7832"><strong>zip_entry_filesize</strong></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">resource</span> <span class="parameter" style="color:#3A95FF">$zip_entry</span></span>   ) : <span class="type" style="color:#EAB766">int</span></div>  <p class="para rdfs-comment">   返回指定目录实体的实际大小。   </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.zip-entry-filesize-parameters">  <h3 class="title">参数</h3>  <span>   <dl>         <dt><span class="parameter" style="color:#3A95FF">zip_entry</span></dt>     <dd>      <p class="para">       由函数<span class="function">{@link zip_read()}</span> 返回的目录实体。      </p>     </dd>       </dl>  </span> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.zip-entry-filesize-returnvalues">  <h3 class="title">返回值</h3>  <p class="para">   返回该目录实体的大小。  </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.zip-entry-filesize-seealso">  <h3 class="title">参见</h3>  <span>   <ul class="simplelist">    <li class="member"><span class="function">{@link zip_open()} - 打开ZIP存档文件</span></li>    <li class="member"><span class="function">{@link zip_read()} - 读取ZIP存档文件中下一项</span></li>   </ul>  </span> </div></div>
 * @return int The size of the directory entry.*/
function zip_entry_filesize ($zip_entry) {}

/**
*<div id="function.zip-entry-name" class="refentry"> <div class="refnamediv">  <h1 class="refname">zip_entry_name</h1>                   <p class="verinfo">(PHP 4 &gt;= 4.1.0, PHP 5 &gt;= 5.2.0, PHP 7, PECL zip &gt;= 1.0.0)</p><p class="refpurpose"><span class="refname">zip_entry_name</span> &mdash; <span class="dc-title">检索目录项的名称</span></p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.zip-entry-name-description">  <h3 class="title">说明</h3>  <div class="methodsynopsis dc-description">   <span class="methodname" style="color:#CC7832"><strong>zip_entry_name</strong></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">resource</span> <span class="parameter" style="color:#3A95FF">$zip_entry</span></span>   ) : <span class="type" style="color:#EAB766">string</span></div>  <p class="para rdfs-comment">   返回指定目录项的名称。   </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.zip-entry-name-parameters">  <h3 class="title">参数</h3>  <span>   <dl>         <dt><span class="parameter" style="color:#3A95FF">zip_entry</span></dt>     <dd>      <p class="para">       由函数<span class="function">{@link zip_read()}</span> 返回的目录项。      </p>     </dd>       </dl>  </span> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.zip-entry-name-returnvalues">  <h3 class="title">返回值</h3>  <p class="para">   目录项的名称。  </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.zip-entry-name-seealso">  <h3 class="title">参见</h3>  <span>   <ul class="simplelist">    <li class="member"><span class="function">{@link zip_open()} - 打开ZIP存档文件</span></li>    <li class="member"><span class="function">{@link zip_read()} - 读取ZIP存档文件中下一项</span></li>   </ul>  </span> </div></div>
 * @return string The name of the directory entry.*/
function zip_entry_name ($zip_entry) {}

/**
*<div id="function.zip-entry-compressedsize" class="refentry"> <div class="refnamediv">  <h1 class="refname">zip_entry_compressedsize</h1>  <p class="verinfo">(PHP 4 &gt;= 4.1.0, PHP 5 &gt;= 5.2.0, PHP 7, PECL zip &gt;= 1.0.0)</p><p class="refpurpose"><span class="refname">zip_entry_compressedsize</span> &mdash; <span class="dc-title">检索目录项压缩过后的大小</span></p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.zip-entry-compressedsize-description">  <h3 class="title">说明</h3>  <div class="methodsynopsis dc-description">   <span class="methodname" style="color:#CC7832"><strong>zip_entry_compressedsize</strong></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">resource</span> <span class="parameter" style="color:#3A95FF">$zip_entry</span></span>   ) : <span class="type" style="color:#EAB766">int</span></div>  <p class="para rdfs-comment">   返回指定目录项压缩过后的大小。   </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.zip-entry-compressedsize-parameters">  <h3 class="title">参数</h3>  <span>   <dl>         <dt><span class="parameter" style="color:#3A95FF">zip_entry</span></dt>     <dd>      <p class="para">       由函数<span class="function">{@link zip_read()}</span> 返回的目录项。      </p>     </dd>       </dl>  </span> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.zip-entry-compressedsize-returnvalues">  <h3 class="title">返回值</h3>  <p class="para">   压缩后的大小。  </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.zip-entry-compressedsize-seealso">  <h3 class="title">参见</h3>  <span>   <ul class="simplelist">    <li class="member"><span class="function">{@link zip_open()} - 打开ZIP存档文件</span></li>    <li class="member"><span class="function">{@link zip_read()} - 读取ZIP存档文件中下一项</span></li>   </ul>  </span> </div></div>
 * @return int The compressed size.*/
function zip_entry_compressedsize ($zip_entry) {}

/**
*<div id="function.zip-entry-compressionmethod" class="refentry"> <div class="refnamediv">  <h1 class="refname">zip_entry_compressionmethod</h1>  <p class="verinfo">(PHP 4 &gt;= 4.1.0, PHP 5 &gt;= 5.2.0, PHP 7, PECL zip &gt;= 1.0.0)</p><p class="refpurpose"><span class="refname">zip_entry_compressionmethod</span> &mdash; <span class="dc-title">检索目录实体的压缩方法</span></p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.zip-entry-compressionmethod-description">  <h3 class="title">说明</h3>  <div class="methodsynopsis dc-description">   <span class="methodname" style="color:#CC7832"><strong>zip_entry_compressionmethod</strong></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">resource</span> <span class="parameter" style="color:#3A95FF">$zip_entry</span></span>   ) : <span class="type" style="color:#EAB766">string</span></div>  <p class="para rdfs-comment">   返回由函数<span class="parameter" style="color:#3A95FF">zip_entry</span>确定的目录实体的压缩方法。   </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.zip-entry-compressionmethod-parameters">  <h3 class="title">参数</h3>  <span>   <dl>         <dt><span class="parameter" style="color:#3A95FF">zip_entry</span></dt>     <dd>      <p class="para">       由函数<span class="function">{@link zip_read()}</span> 返回的目录实体。      </p>     </dd>       </dl>  </span> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.zip-entry-compressionmethod-returnvalues">  <h3 class="title">返回值</h3>  <p class="para">   压缩方法。  </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.zip-entry-compressionmethod-seealso">  <h3 class="title">参见</h3>  <span>   <ul class="simplelist">    <li class="member"><span class="function">{@link zip_open()} - 打开ZIP存档文件</span></li>    <li class="member"><span class="function">{@link zip_read()} - 读取ZIP存档文件中下一项</span></li>   </ul>  </span> </div></div>
 * @return string The compression method.*/
function zip_entry_compressionmethod ($zip_entry) {}

// End of zip v.1.11.0
?>
