<?php

namespace parallel;

use Countable;
use parallel\Events\{Event, Input};
use Traversable;

/**
 * ### The Event Loop
 * ---------------------------------------------------------------------------------------------------------------------
 * The Event loop monitors the state of sets of futures and or channels (targets) in order to perform read
 * (Future::value(), Channel::recv()) and write (Channel::send()) operations as the targets become available and the
 * operations may be performed without blocking the event loop.
 */
final class Events implements Countable, Traversable{

	/* Input */

	/**
	 * Shall set input for this event loop
	 * @param Events\Input $input
	 */
	public function setInput(Input $input) : void{}

	/* Targets */

	/**
	 * Shall watch for events on the given channel
	 * @param Channel $channel
	 *
	 * @throws Events\Error\Existence if channel was already added.
	 */
	public function addChannel(Channel $channel) : void{}

	/**
	 * Shall watch for events on the given future
	 *
	 * @param string $name
	 * @param Future $future
	 *
	 * @throws Events\Error\Existence if target with the given name was already added.
	 */
	public function addFuture(string $name, Future $future) : void{}

	/**
	 * Shall remove the given target
	 * @param string $target
	 *
	 * @throws Events\Error\Existence if target with the given name was not found.
	 */
	public function remove(string $target) : void{}

	/* Behaviour */

	/**
	 * Shall set blocking mode
	 *
	 * By default when events are polled for, blocking will occur (at the PHP level) until the first event can be
	 * returned: Setting blocking mode to false will cause poll to return control if the first target polled is not
	 * ready.
	 *
	 * This differs from setting a timeout of 0 with @see Events::setTimeout(), since a timeout of 0, while
	 * allowed, will cause an exception to be raised, which may be extremely slow or wasteful if what is really desired
	 * is non-blocking behaviour.
	 *
	 * A non-blocking loop effects the return value of @see Events::poll(), such that it may be null before all events
	 * have been processed.
	 *
	 * @param bool $blocking
	 *
	 * @throws Events\Error if loop has timeout set.
	 */
	public function setBlocking(bool $blocking) : void{}

	/* Behaviour */

	/**
	 * Shall set the timeout in microseconds
	 *
	 * By default when events are polled for, blocking will occur (at the PHP level) until the first event can be
	 * returned: Setting the timeout causes an exception to be thrown when the timeout is reached.
	 *
	 * This differs from setting blocking mode to false with @see Events::setBlocking(), which will not cause an
	 * exception to be thrown.
	 *
	 * @throws Events\Error if loop is non-blocking.
	 *
	 * @param int $timeout
	 */
	public function setTimeout(int $timeout) : void{}

	/* Polling */

	/**
	 * Shall poll for the next event
	 *
	 * Should there be no targets remaining, null shall be returned
	 * Should this be a non-blocking loop, and blocking would occur, null shall be returned
	 * Otherwise, the Event returned describes the event.
	 *
	 * @return Event|null
	 *
	 * @throws Events\Error\Timeout if timeout is used and reached.
	 */
	public function poll() : ?Event{}

	/**
	 * @return int
	 */
/**
*<div id="function.count" class="refentry">   <div class="refnamediv">    <h1 class="refname">count</h1>    <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">count</span> &mdash; <span class="dc-title">计算数组中的单元数目，或对象中的属性个数</span></p>   </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.count-description">  <h3 class="title">说明</h3>  <div class="methodsynopsis dc-description">   <span class="methodname" style="color:#CC7832"><strong>count</strong></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766"><a href="http://php.net/manual/zh/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span> <span class="parameter" style="color:#3A95FF">$array_or_countable</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$mode</span><span class="initializer"> = COUNT_NORMAL</span></span>  ] ) : <span class="type" style="color:#EAB766">int</span></div>  <p class="para rdfs-comment">   统计出数组里的所有元素的数量，或者对象里的东西。  </p>    <p class="para">     对于对象，如果安装了 <a href="http://php.net/manual/zh/ref.spl.php" class="link">SPL</a>，可以通过实现     <span>Countable</span> 接口对 <span class="function"><strong style="color:#CC7832">count()</strong></span>挂钩（hook）     。该接口只有一个方法     <span class="methodname" style="color:#CC7832">{@link Countable::count()}</span>，此方法为 <span class="function"><strong style="color:#CC7832">count()</strong></span>     函数返回值。    </p>    <p class="para">     关于 PHP 中如何实现和使用数组可以参考手册中<a href="http://php.net/manual/zh/language.types.array.php" class="link">数组</a>章节中的详细描述。  </p> </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.count-parameters">  <h3 class="title">参数</h3>  <span>   <dl>         <dt><span class="parameter" style="color:#3A95FF">array_or_countable</span></dt>     <dd>      <p class="para">       数组或者 <a href="http://php.net/manual/zh/class.countable.php" class="classname">Countable</a>  对象。      </p>     </dd>             <dt><span class="parameter" style="color:#3A95FF">mode</span></dt>     <dd>      <p class="para">       如果可选的 <span class="parameter" style="color:#3A95FF">mode</span> 参数设为     <strong><span>COUNT_RECURSIVE</span></strong>（或 1），<span class="function"><strong style="color:#CC7832">count()</strong></span>     将递归地对数组计数。对计算多维数组的所有单元尤其有用。      </p>      <div class="caution"><strong class="caution">Caution</strong>       <p class="para">        <span class="function"><strong style="color:#CC7832">count()</strong></span> 能检测递归来避免无限循环，但每次出现时会产生 <strong><span>E_WARNING</span></strong> 错误        （如果 array 不止一次包含了自身）并返回大于预期的统计数字。       </p>      </div>     </dd>       </dl>  </span> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.count-returnvalues">  <h3 class="title">返回值</h3>  <p class="para">   返回 <span class="parameter" style="color:#3A95FF">array_or_countable</span> 中的单元数目。      如果参数既不是数组，也不是实现     <span>Countable</span> 接口的对象，将返回     <span>1</span>。   有个例外：如果     <span class="parameter" style="color:#3A95FF">array_or_countable</span> 是 <strong><span>NULL</span></strong> 则结果是 <span>0</span>。  </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.count-examples">  <h3 class="title">范例</h3>  <span>   <div class="example" id="example-5288">    <p><strong>Example #1 <span class="function"><strong style="color:#CC7832">count()</strong></span> 例子</strong></p>    <div class="example-contents"><div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"><span style="color: #9876AA">&lt;?php<br />$a</span><span style="color: #007700">[</span><span style="color: #9876AA">0</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #9876AA">1</span><span style="color: #007700">;<br /></span><span style="color: #9876AA">$a</span><span style="color: #007700">[</span><span style="color: #9876AA">1</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #9876AA">3</span><span style="color: #007700">;<br /></span><span style="color: #9876AA">$a</span><span style="color: #007700">[</span><span style="color: #9876AA">2</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #9876AA">5</span><span style="color: #007700">;<br /></span><span style="color: #9876AA">var_dump</span><span style="color: #007700">(</span><span style="color: #9876AA">count</span><span style="color: #007700">(</span><span style="color: #9876AA">$a</span><span style="color: #007700">));<br /><br /></span><span style="color: #9876AA">$b</span><span style="color: #007700">[</span><span style="color: #9876AA">0</span><span style="color: #007700">]&nbsp;&nbsp;=&nbsp;</span><span style="color: #9876AA">7</span><span style="color: #007700">;<br /></span><span style="color: #9876AA">$b</span><span style="color: #007700">[</span><span style="color: #9876AA">5</span><span style="color: #007700">]&nbsp;&nbsp;=&nbsp;</span><span style="color: #9876AA">9</span><span style="color: #007700">;<br /></span><span style="color: #9876AA">$b</span><span style="color: #007700">[</span><span style="color: #9876AA">10</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #9876AA">11</span><span style="color: #007700">;<br /></span><span style="color: #9876AA">var_dump</span><span style="color: #007700">(</span><span style="color: #9876AA">count</span><span style="color: #007700">(</span><span style="color: #9876AA">$b</span><span style="color: #007700">));<br /><br /></span><span style="color: #9876AA">var_dump</span><span style="color: #007700">(</span><span style="color: #9876AA">count</span><span style="color: #007700">(</span><span style="color: #9876AA">null</span><span style="color: #007700">));<br /><br /></span><span style="color: #9876AA">var_dump</span><span style="color: #007700">(</span><span style="color: #9876AA">count</span><span style="color: #007700">(</span><span style="color: #9876AA">false</span><span style="color: #007700">));<br /></span><span style="color: #9876AA">?&gt;</span></span></span></div>    </div>    <div class="example-contents"><p>以上例程会输出：</p></div>    <div class="example-contents screen" style="color:AFB1B3;background:black;padding-left:5px;"><div class="cdata"><span>int(3)<br>int(3)<br><br>Warning: count(): Parameter must be an array or an object that implements Countable in … on line 12 // PHP 7.2 起<br>int(0)<br><br>Warning: count(): Parameter must be an array or an object that implements Countable in … on line 14 // PHP 7.2 起<br>int(1)<br></span></div>    </div>   </div>  </span>  <p class="para">   <div class="example" id="example-5289">    <p><strong>Example #2 递归 <span class="function"><strong style="color:#CC7832">count()</strong></span> 例子</strong></p>    <div class="example-contents"><div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"><span style="color: #9876AA">&lt;?php<br />$food&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #DD0000">'fruits'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;array(</span><span style="color: #DD0000">'orange'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'banana'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'apple'</span><span style="color: #007700">),<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'veggie'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;array(</span><span style="color: #DD0000">'carrot'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'collard'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'pea'</span><span style="color: #007700">));<br /><br /></span><span style="color: #FF8000">//&nbsp;recursive&nbsp;count<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #9876AA">count</span><span style="color: #007700">(</span><span style="color: #9876AA">$food</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">COUNT_RECURSIVE</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;output&nbsp;8<br /><br />//&nbsp;normal&nbsp;count<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #9876AA">count</span><span style="color: #007700">(</span><span style="color: #9876AA">$food</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;output&nbsp;2<br /><br /></span><span style="color: #9876AA">?&gt;</span></span></span></div>    </div>   </div>  </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 changelog" id="refsect1-function.count-changelog">  <h3 class="title">更新日志</h3>  <table class="doctable informaltable">       <thead>     <tr>      <th>版本</th>      <th>说明</th>     </tr>    </thead>    <tbody class="tbody">     <tr>      <td>7.2.0</td>      <td>       当无效的 countable 类型传递给 <span class="parameter" style="color:#3A95FF">array_or_countable</span> 参数时，<span class="function"><strong style="color:#CC7832">count()</strong></span> 会产生警告。      </td>     </tr>    </tbody>     </table> </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.count-seealso">  <h3 class="title">参见</h3>  <span>   <ul class="simplelist">    <li class="member"><span class="function">{@link is_array()} - 检测变量是否是数组</span></li>    <li class="member"><span class="function">{@link isset()} - 检测变量是否已设置并且非 NULL</span></li>    <li class="member"><span class="function">{@link empty()} - 检查一个变量是否为空</span></li>    <li class="member"><span class="function">{@link strlen()} - 获取字符串长度</span></li>    <li class="member"><span class="function">{@link is_countable()} - Verify that the contents of a variable is a countable value</span></li>   </ul>  </span> </div></div>
*/
	public function count() : int{}
}
