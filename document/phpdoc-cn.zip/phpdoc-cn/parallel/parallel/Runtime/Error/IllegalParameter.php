<?php

namespace parallel\Runtime\Error;

use parallel\Runtime\Error;

class IllegalParameter extends Error{
}
