<?php

namespace parallel\Runtime\Object;

class Unavailable{
}
