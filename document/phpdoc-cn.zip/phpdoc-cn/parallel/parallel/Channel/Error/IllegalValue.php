<?php

namespace parallel\Channel\Error;

use parallel\Channel\Error;

class IllegalValue extends Error{
}
