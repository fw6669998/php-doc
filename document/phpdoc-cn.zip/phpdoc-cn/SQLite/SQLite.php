<?php

// Start of SQLite v.2.0-dev

/**
 * @link https://php.net/manual/en/ref.sqlite.php
 */
class SQLiteDatabase  {

	/**
	 * (PHP 5 &lt; 5.4.0, PECL sqlite &gt;= 1.0.0)
	 * @link https://php.net/manual/en/function.sqlite-open.php
	 * @param $filename <p>The filename of the SQLite database. If the file does not exist, SQLite will attempt to create it. PHP must have write permissions to the file if data is inserted, the database schema is modified or to create the database if it does not exist.</p>
	 * @param $mode [optional] <p>The mode of the file. Intended to be used to open the database in read-only mode. Presently, this parameter is ignored by the sqlite library. The default value for mode is the octal value 0666 and this is the recommended value.</p>
	 * @param $error_message [optional] <p>Passed by reference and is set to hold a descriptive error message explaining why the database could not be opened if there was an error.</p>
	 */
	final public function __construct ($filename, $mode = 0666, &$error_message) {}

	/**
	 * (PHP 5 &lt; 5.4.0, PECL sqlite &gt;= 1.0.0)
	 * @link https://php.net/manual/en/function.sqlite-query.php
	 * @param $query <p>
	 * The query to be executed.
	 * </p>
	 * <p>
	 * Data inside the query should be {@link https://php.net/manual/en/function.sqlite-escape-string.php properly escaped}.
	 * </p>
	 * @param $result_type [optional]
	 * <p>The optional <i>result_type</i> parameter accepts a constant and determines how the returned array will be indexed. Using <b>SQLITE_ASSOC</b> will return only associative indices (named fields) while <b>SQLITE_NUM</b> will return only numerical indices (ordinal field numbers). <b>SQLITE_BOTH</b> will return both associative and numerical indices. <b>SQLITE_BOTH</b> is the default for this function.</p>
	 * @param $error_message [optional] <p>The specified variable will be filled if an error occurs. This is specially important because SQL syntax errors can't be fetched using the {@see sqlite_last_error()} function.</p>
	 * @return resource|false <p>
	 * This function will return a result handle or <b>FALSE</b> on failure.
	 * For queries that return rows, the result handle can then be used with
	 * functions such as {@see sqlite_fetch_array()} and
	 * {@see sqlite_seek()}.
	 * </p>
	 * <p>
	 * Regardless of the query type, this function will return <b>FALSE</b> if the
	 * query failed.
	 * </p>
	 * <p>
	 * {@see sqlite_query()} returns a buffered, seekable result
	 * handle.  This is useful for reasonably small queries where you need to
	 * be able to randomly access the rows.  Buffered result handles will
	 * allocate memory to hold the entire result and will not return until it
	 * has been fetched.  If you only need sequential access to the data, it is
	 * recommended that you use the much higher performance
	 * {@see sqlite_unbuffered_query()} instead.
	 * </p>
	 */
	public function query ($query, $result_type, &$error_message) {}

	/**
	 * (PHP 5 &lt; 5.4.0, PECL sqlite &gt;= 1.0.0)
	 * @link https://php.net/manual/en/function.sqlite-exec.php
	 * @param string $query <p>
	 * The query to be executed.
	 * </p>
	 * <p>
	 * Data inside the query should be {@link https://php.net/manual/en/function.sqlite-escape-string.php properly escaped}.
	 * </p>
	 * @param string $error_message [optional] <p>The specified variable will be filled if an error occurs. This is specially important because SQL syntax errors can't be fetched using the
	 * {@see sqlite_last_error()} function.</p>
	 * @return bool <p>
	 * This function will return a boolean result; <b>TRUE</b> for success or <b>FALSE</b> for failure.
	 * If you need to run a query that returns rows, see {@see sqlite_query()}.
	 * </p>
	 * <p>The column names returned by
	 * <b>SQLITE_ASSOC</b> and <b>SQLITE_BOTH</b> will be
	 * case-folded according to the value of the
	 * {@link https://php.net/manual/en/sqlite.configuration.php#ini.sqlite.assoc-case sqlite.assoc_case} configuration
	 * option.</p>
	 */
	public function queryExec ($query, &$error_message) {}

	/**
	 * (PHP 5 &lt; 5.4.0, PECL sqlite &gt;= 1.0.0)
	 * Execute a query against a given database and returns an array
	 * @link https://php.net/manual/en/function.sqlite-array-query.php
	 * @param $query <p>
	 * The query to be executed.
	 * </p>
	 * <p>
	 * Data inside the query should be {@link https://php.net/manual/en/function.sqlite-escape-string.php properly escaped}.
	 * </p>
	 * @param $result_type [optional] <p>The optional <i>result_type</i>
	 * parameter accepts a constant and determines how the returned array will be
	 * indexed. Using <b>SQLITE_ASSOC</b> will return only associative
	 * indices (named fields) while <b>SQLITE_NUM</b> will return
	 * only numerical indices (ordinal field numbers). <b>SQLITE_BOTH</b>
	 * will return both associative and numerical indices.
	 * <b>SQLITE_BOTH</b> is the default for this function.</p>
	 * @param $decode_binary [optional] <p>When the <i>decode_binary</i>
	 * parameter is set to <b>TRUE</b> (the default), PHP will decode the binary encoding
	 * it applied to the data if it was encoded using the
	 * {@see sqlite_escape_string()}.  You should normally leave this
	 * value at its default, unless you are interoperating with databases created by
	 * other sqlite capable applications.</p>
	 * <p>
	 * Returns an array of the entire result set; <b>FALSE</b> otherwise.
	 * </p>
	 * <p>The column names returned by
	 * <b>SQLITE_ASSOC</b> and <b>SQLITE_BOTH</b> will be
	 * case-folded according to the value of the
	 * {@link https://php.net/manual/en/sqlite.configuration.php#ini.sqlite.assoc-case sqlite.assoc_case} configuration
	 * option.</p>
	 */
	public function arrayQuery ($query, $result_type, $decode_binary) {}

	/**
	 * (PHP 5 &lt; 5.4.0, PECL sqlite &gt;= 1.0.1)
	 * Executes a query and returns either an array for one single column or the value of the first row
	 * @link https://php.net/manual/en/function.sqlite-single-query.php
	 * @param string $query
	 * @param bool $first_row_only [optional]
	 * @param bool $decode_binary [optional]
	 * @return array
	 */
	public function singleQuery ($query, $first_row_only, $decode_binary) {}

	/**
	 * (PHP 5 &lt; 5.4.0, PECL sqlite &gt;= 1.0.0)
	 * Execute a query that does not prefetch and buffer all data
	 * @link https://php.net/manual/en/function.sqlite-unbuffered-query.php
	 * @param $query  <p>
	 * The query to be executed.
	 * </p>
	 * <p>
	 * Data inside the query should be {@link https://php.net/manual/en/function.sqlite-escape-string.php properly escaped}.
	 * </p>
	 * @param $result_type [optional] <p>The optional <i>result_type</i> parameter accepts a constant and determines how the returned array will be indexed.
	 * Using <b>SQLITE_ASSOC</b> will return only associative indices (named fields) while <b>SQLITE_NUM</b> will return only numerical indices (ordinal field numbers).
	 * <b>SQLITE_BOTH</b> will return both associative and numerical indices. <b>SQLITE_BOTH</b> is the default for this function.
	 * @param $error_message [optional]
	 * @return resource Returns a result handle or <b>FALSE</b> on failure.
	 * {@see sqlite_unbuffered_query()} returns a sequential forward-only result set that can only be used to read each row, one after the other.
	 */
	public function unbufferedQuery ($query, $result_type = SQLITE_BOTH, &$error_message) {}

	/**
	 * (PHP 5 &lt; 5.4.0, PECL sqlite &gt;= 1.0.0)
	 * Returns the rowid of the most recently inserted row
	 * @link https://php.net/manual/en/function.sqlite-last-insert-rowid.php
	 * @return int Returns the row id, as an integer.
	 */
	public function lastInsertRowid () {}

	/**
	 * (PHP 5 &lt; 5.4.0, PECL sqlite &gt;= 1.0.0)
	 * Returns the number of rows that were changed by the most recent SQL statement
	 * @link https://php.net/manual/en/function.sqlite-changes.php
	 * @return int Returns the number of changed rows.
	 */
	public function changes () {}

	/**
	 * (PHP 5 &lt; 5.4.0, PECL sqlite &gt;= 1.0.0)
	 * Register an aggregating UDF for use in SQL statements
	 * @link https://php.net/manual/en/function.sqlite-create-aggregate.php
	 * @param $function_name <p>The name of the function used in SQL statements.</p>
	 * @param $step_func <p>Callback function called for each row of the result set. Function parameters are &$context, $value, ....</p>
	 * @param $finalize_func <p>Callback function to aggregate the "stepped" data from each row. Function parameter is &$context and the function should return the final result of aggregation.</p>
	 * @param $num_args [optional] <p>Hint to the SQLite parser if the callback function accepts a predetermined number of arguments.</p>
	 */
	public function createAggregate ($function_name, $step_func, $finalize_func, $num_args = -1) {}

	/**
	 * (PHP 5 &lt; 5.4.0, PECL sqlite &gt;= 1.0.0)
	 * Registers a "regular" User Defined Function for use in SQL statements
	 * @link https://php.net/manual/en/function.sqlite-create-function.php
	 * @param $function_name <p>The name of the function used in SQL statements.</p>
	 * @param $callback <p>
	 * Callback function to handle the defined SQL function.
	 * </p>
	 * <blockquote><p><b>Note</b>:
	 * Callback functions should return a type understood by SQLite (i.e.
	 * {@link https://php.net/manual/en/language.types.intro.php scalar type}).
	 * </p></blockquote>
	 * @param $num_args [optional]   <blockquote><p><b>Note</b>: Two alternative syntaxes are
	 * supported for compatibility with other database extensions (such as MySQL).
	 * The preferred form is the first, where the <i>dbhandle</i>
	 * parameter is the first parameter to the function.</p></blockquote>
	 */
	public function createFunction ($function_name, $callback, $num_args = -1) {}

	/**
	 * (PHP 5 &lt; 5.4.0, PECL sqlite &gt;= 1.0.0)
	 * Set busy timeout duration, or disable busy handlers
	 * @link https://php.net/manual/en/function.sqlite-busy-timeout.php
	 * @param $milliseconds <p> The number of milliseconds. When set to 0, busy handlers will be disabled and SQLite will return immediately with a <b>SQLITE_BUSY</b> status code if another process/thread has the database locked for an update.
	 * PHP sets the default busy timeout to be 60 seconds when the database is opened.</p>
	 * @return int <p>Returns an error code, or 0 if no error occurred.</p>
	 */
	public function busyTimeout ($milliseconds) {}

	/**
	 * (PHP 5 &lt; 5.4.0, PECL sqlite &gt;= 1.0.0)
	 * Returns the error code of the last error for a database
	 * @link https://php.net/manual/en/function.sqlite-last-error.php
	 * @return int Returns an error code, or 0 if no error occurred.
	 */
	public function lastError () {}

	/**
	 * (PHP 5 &lt; 5.4.0)
	 * Return an array of column types from a particular table
	 * @link https://php.net/manual/en/function.sqlite-fetch-column-types.php
	 * @param $table_name <p>The table name to query.</p>
	 * @param $result_type [optional] <p>
	 * The optional <i>result_type</i> parameter accepts a
	 * constant and determines how the returned array will be indexed. Using
	 * <b>SQLITE_ASSOC</b> will return only associative indices
	 * (named fields) while <b>SQLITE_NUM</b> will return only
	 * numerical indices (ordinal field numbers).
	 * <b>SQLITE_ASSOC</b> is the default for
	 * this function.
	 * </p>
	 * @return array <p>
	 * Returns an array of column data types; <b>FALSE</b> on error.
	 * </p>
	 * <p>The column names returned by
	 * <b>SQLITE_ASSOC</b> and <b>SQLITE_BOTH</b> will be
	 * case-folded according to the value of the
	 * {@link https://php.net/manual/en/sqlite.configuration.php#ini.sqlite.assoc-case sqlite.assoc_case} configuration
	 * option.</p>
	 */
	public function fetchColumnTypes ($table_name, $result_type = SQLITE_ASSOC) {}

}

/**
 * @link https://php.net/manual/en/ref.sqlite.php
 */
final class SQLiteResult implements Iterator, Countable {

	/**
	 * (PHP 5 &lt; 5.4.0, PECL sqlite &gt;= 1.0.0)
	 * Fetches the next row from a result set as an array
	 * @link https://php.net/manual/en/function.sqlite-fetch-array.php
	 * @param $result_type [optional]
	 * <p>
	 * The optional <i>result_type</i>
	 * parameter accepts a constant and determines how the returned array will be
	 * indexed. Using <b>SQLITE_ASSOC</b> will return only associative
	 * indices (named fields) while <b>SQLITE_NUM</b> will return
	 * only numerical indices (ordinal field numbers). <b>SQLITE_BOTH</b>
	 * will return both associative and numerical indices.
	 * <b>SQLITE_BOTH</b> is the default for this function.
	 * @param $decode_binary [optional] <p>When the <i>decode_binary</i>
	 * parameter is set to <b>TRUE</b> (the default), PHP will decode the binary encoding
	 * it applied to the data if it was encoded using the
	 *{@link https://php.net/manual/en/sqlite.configuration.php#ini.sqlite.assoc-case sqlite.assoc_case}. You should normally leave this
	 * value at its default, unless you are interoperating with databases created by
	 * other sqlite capable applications.</p>
	 * @return array <p>
	 * Returns an array of the next row from a result set; <b>FALSE</b> if the
	 * next position is beyond the final row.
	 * </p>
	 * <p>The column names returned by
	 * <b>SQLITE_ASSOC</b> and <b>SQLITE_BOTH</b> will be
	 * case-folded according to the value of the
	 * {@link https://php.net/manual/en/sqlite.configuration.php#ini.sqlite.assoc-case sqlite.assoc_case}  configuration
	 * option.</p>
	 */
	public function fetch ($result_type = SQLITE_BOTH, $decode_binary =  true) {}

	/**
	 * (PHP 5 &lt; 5.4.0)
	 * Fetches the next row from a result set as an object
	 * @link https://php.net/manual/en/function.sqlite-fetch-object.php
	 * @param string $class_name [optional]
	 * @param array $ctor_params [optional]
	 * @param bool $decode_binary [optional]
	 * @return object
	 */
	public function fetchObject ($class_name, $ctor_params, $decode_binary = true) {}

	/**
	 * (PHP 5 &lt; 5.4.0, PECL sqlite &gt;= 1.0.1)
	 * Fetches the first column of a result set as a string
	 * @link https://php.net/manual/en/function.sqlite-fetch-single.php
	 * @param bool $decode_binary [optional]
	 * @return string <p>Returns the first column value, as a string.</p>
	 */
	public function fetchSingle ($decode_binary = true) {}

	/**
	 * (PHP 5 &lt; 5.4.0)
	 * Fetches the next row from a result set as an object
	 * @link https://php.net/manual/en/function.sqlite-fetch-object.php
	 * @param resource $result_type [optional]
	 * @param array $ctor_params [optional]
	 * @param bool $decode_binary [optional]
	 * @return object
	 */
	public function fetchAll ($result_type, array $ctor_params,  $decode_binary = true) {}

	/**
	 * (PHP 5 &lt; 5.4.0, PECL sqlite &gt;= 1.0.0)
	 * Fetches a column from the current row of a result set
	 * @link https://php.net/manual/en/function.sqlite-column.php
	 * @param $index_or_name
	 * @param $decode_binary [optional] <p>When the <i>decode_binary</i>
	 * parameter is set to <b>TRUE</b> (the default), PHP will decode the binary encoding
	 * it applied to the data if it was encoded using the
	 * {@see sqlite_escape_string()}.  You should normally leave this
	 * value at its default, unless you are interoperating with databases created by
	 * other sqlite capable applications.</p>
	 * @return mixed <p>Returns the column value</p>
	 */
	public function column ($index_or_name, $decode_binary = true) {}

	/**
	 * (PHP 5 &lt; 5.4.0, PECL sqlite &gt;= 1.0.0)
	 * Returns the number of fields in a result set
	 * @link https://php.net/manual/en/function.sqlite-num-fields.php
	 * @return int <p>Returns the number of fields, as an integer.</p>
	 */
	public function numFields () {}

	/**
	 * (PHP 5 &lt; 5.4.0, PECL sqlite &gt;= 1.0.0)
	 * Returns the name of a particular field
	 * @link https://php.net/manual/en/function.sqlite-field-name.php
	 * @param $field_index <p>The ordinal column number in the result set.</p>
	 * @return string <p>
	 * Returns the name of a field in an SQLite result set, given the ordinal
	 * column number; <b>FALSE</b> on error.
	 * </p>
	 * <p>The column names returned by
	 * <b>SQLITE_ASSOC</b> and <b>SQLITE_BOTH</b> will be
	 * case-folded according to the value of the
	 * {@link https://php.net/manual/en/sqlite.configuration.php#ini.sqlite.assoc-case sqlite.assoc_case}configuration
	 * option.</p>
	 *
	 */
	public function fieldName ($field_index) {}

	/**
	 * (PHP 5 &lt; 5.4.0, PECL sqlite &gt;= 1.0.0)
	 * Fetches the current row from a result set as an array
	 * @link https://php.net/manual/en/function.sqlite-current.php
	 * @param $result_type [optional] <p>The optional <i>result_type</i>
	 * parameter accepts a constant and determines how the returned array will be
	 * indexed. Using <b>SQLITE_ASSOC</b> will return only associative
	 * indices (named fields) while <b>SQLITE_NUM</b> will return
	 * only numerical indices (ordinal field numbers). <b>SQLITE_BOTH</b>
	 * will return both associative and numerical indices.
	 * <b>SQLITE_BOTH</b> is the default for this function.</p>
	 * @param $decode_binary [optional] <p>When the <i>decode_binary</i>
	 * parameter is set to <b>TRUE</b> (the default), PHP will decode the binary encoding
	 * it applied to the data if it was encoded using the
	 * {@see sqlite_escape_string()}.  You should normally leave this
	 * value at its default, unless you are interoperating with databases created by
	 * other sqlite capable applications.</p>
	 * @return array <p>
	 * Returns an array of the current row from a result set; <b>FALSE</b> if the
	 * current position is beyond the final row.
	 * </p>
	 * <p>The column names returned by
	 * <b>SQLITE_ASSOC</b> and <b>SQLITE_BOTH</b> will be
	 * case-folded according to the value of the
	 * {@link https://php.net/manual/en/sqlite.configuration.php#ini.sqlite.assoc-case sqlite.assoc_case} configuration
	 * option.</p>
	 */
/**
*<div id="function.current" class="refentry">   <div class="refnamediv">    <h1 class="refname">current</h1>    <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">current</span> &mdash; <span class="dc-title">返回数组中的当前单元</span></p>   </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.current-description">  <h3 class="title">说明</h3>  <div class="methodsynopsis dc-description">   <span class="methodname" style="color:#CC7832"><strong>current</strong></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">array</span> <span class="parameter" style="color:#3A95FF">&$array</span></span>   ) : <span class="type" style="color:#EAB766"><a href="http://php.net/manual/zh/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span></div>    <p class="para rdfs-comment">     每个数组中都有一个内部的指针指向它“当前的”单元，初始指向插入到数组中的第一个单元。    </p>   </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.current-parameters">  <h3 class="title">参数</h3>  <span>   <dl>         <dt><span class="parameter" style="color:#3A95FF">array</span></dt>     <dd>      <p class="para">       这个数组。      </p>     </dd>       </dl>  </span> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.current-returnvalues">  <h3 class="title">返回值</h3>  <p class="para">   <span class="function"><strong style="color:#CC7832">current()</strong></span> 函数返回当前被内部指针指向的数组单元的值，并不移动指针。如果内部指针指向超出了单元列表的末端，<span class="function"><strong style="color:#CC7832">current()</strong></span>     返回 <strong><span>FALSE</span></strong>。  </p>  <div class="warning"><strong class="warning">Warning</strong><p class="simpara">此函数可能返回布尔值<strong><span>FALSE</span></strong>，但也可能返回等同于 <strong><span>FALSE</span></strong> 的非布尔值。请阅读 <a href="http://php.net/manual/zh/language.types.boolean.php" class="link">布尔类型</a>章节以获取更多信息。应使用<a href="http://php.net/manual/zh/language.operators.comparison.php" class="link">===运算符</a>来测试此函数的返回值。</p></div> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.current-examples">  <h3 class="title">范例</h3>  <span>   <div class="example" id="example-5290">    <p><strong>Example #1 使用  <span class="function"><strong style="color:#CC7832">current()</strong></span> 系列函数的例子</strong></p>    <div class="example-contents"><div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"><span style="color: #9876AA">&lt;?php<br />$transport&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #DD0000">'foot'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'bike'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'car'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'plane'</span><span style="color: #007700">);<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'foot';<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">next</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'bike';<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'bike';<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">prev</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'foot';<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">end</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'plane';<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'plane';<br /><br /></span><span style="color: #9876AA">$arr&nbsp;</span><span style="color: #007700">=&nbsp;array();<br /></span><span style="color: #9876AA">var_dump</span><span style="color: #007700">(</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$arr</span><span style="color: #007700">));&nbsp;</span><span style="color: #FF8000">//&nbsp;bool(false)<br /><br /></span><span style="color: #9876AA">$arr&nbsp;</span><span style="color: #007700">=&nbsp;array(array());<br /></span><span style="color: #9876AA">var_dump</span><span style="color: #007700">(</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$arr</span><span style="color: #007700">));&nbsp;</span><span style="color: #FF8000">//&nbsp;array(0)&nbsp;{&nbsp;}<br /></span><span style="color: #9876AA">?&gt;</span></span></span></div>    </div>   </div>  </span> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 notes" id="refsect1-function.current-notes">  <h3 class="title">注释</h3>  <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>:    <span class="simpara">    如果数组包含 <span class="type" style="color:#EAB766">boolean</span> <strong><span>FALSE</span></strong> 的单元则本函数在碰到这个单元时也返回       <strong><span>FALSE</span></strong>，使得不可能判断是否到了此数组列表的末端。    要正确遍历可能含有空单元的数组，用 <span class="function">{@link each()}</span> 函数。   </span>  </p></blockquote> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.current-seealso">  <h3 class="title">参见</h3>  <span>   <ul class="simplelist">    <li class="member"><span class="function">{@link end()} - 将数组的内部指针指向最后一个单元</span></li>    <li class="member"><span class="function">{@link key()} - 从关联数组中取得键名</span></li>    <li class="member"><span class="function">{@link each()} - 返回数组中当前的键／值对并将数组指针向前移动一步</span></li>    <li class="member"><span class="function">{@link prev()} - 将数组的内部指针倒回一位</span></li>    <li class="member"><span class="function">{@link reset()} - 将数组的内部指针指向第一个单元</span></li>    <li class="member"><span class="function">{@link next()} - 将数组中的内部指针向前移动一位</span></li>   </ul>  </span> </div>      </div>
*/
	public function current ($result_type = SQLITE_BOTH , $decode_binary = true) {}
	/**
	 * Return the key of the current element
	 * @link https://php.net/manual/en/iterator.key.php
	 * @return mixed scalar on success, or null on failure.
	 * @since 5.0.0
	 */
/**
*<div id="function.key" class="refentry">   <div class="refnamediv">    <h1 class="refname">key</h1>    <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">key</span> &mdash; <span class="dc-title">从关联数组中取得键名</span></p>   </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.key-description">  <h3 class="title">说明</h3>  <div class="methodsynopsis dc-description">   <span class="methodname" style="color:#CC7832"><strong>key</strong></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">array</span> <span class="parameter" style="color:#3A95FF">$array</span></span>   ) : <span class="type" style="color:#EAB766"><a href="http://php.net/manual/zh/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span></div>    <p class="para rdfs-comment">     <span class="function"><strong style="color:#CC7832">key()</strong></span> 返回数组中当前单元的键名。    </p>   </div>  <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.key-parameters">  <h3 class="title">参数</h3>  <span>   <dl>         <dt><span class="parameter" style="color:#3A95FF">array</span></dt>     <dd>      <p class="para">       该数组。      </p>     </dd>       </dl>  </span> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.key-returnvalues">  <h3 class="title">返回值</h3>  <p class="para">   <span class="function"><strong style="color:#CC7832">key()</strong></span> 函数返回数组中内部指针指向的当前单元的键名。   但它不会移动指针。如果内部指针超过了元素列表尾部，或者数组是空的，<span class="function"><strong style="color:#CC7832">key()</strong></span> 会返回 <strong><span>NULL</span></strong>。  </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 changelog" id="refsect1-function.key-changelog">  <h3 class="title">更新日志</h3>  <span>   <table class="doctable informaltable">         <thead>      <tr>       <th>版本</th>       <th>说明</th>      </tr>     </thead>     <tbody class="tbody">      <tr>       <td>7.0.0</td>       <td>        <span class="parameter" style="color:#3A95FF">array</span> 现在总是会传值。         在此之前，它会尽可能传引用，否则就传值。       </td>      </tr>     </tbody>       </table>  </span> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.key-examples">  <h3 class="title">范例</h3>  <span>   <div class="example" id="example-5298">    <p><strong>Example #1 <span class="function"><strong style="color:#CC7832">key()</strong></span> 例子</strong></p>    <div class="example-contents"><div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"><span style="color: #9876AA">&lt;?php<br />$array&nbsp;</span><span style="color: #007700">=&nbsp;array(<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'fruit1'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">'apple'</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'fruit2'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">'orange'</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'fruit3'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">'grape'</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'fruit4'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">'apple'</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'fruit5'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">'apple'</span><span style="color: #007700">);<br /><br /></span><span style="color: #FF8000">//&nbsp;this&nbsp;cycle&nbsp;echoes&nbsp;all&nbsp;associative&nbsp;array<br />//&nbsp;key&nbsp;where&nbsp;value&nbsp;equals&nbsp;"apple"<br /></span><span style="color: #007700">while&nbsp;(</span><span style="color: #9876AA">$fruit_name&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">))&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(</span><span style="color: #9876AA">$fruit_name&nbsp;</span><span style="color: #007700">==&nbsp;</span><span style="color: #DD0000">'apple'</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #9876AA">key</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">).</span><span style="color: #DD0000">'&lt;br&nbsp;/&gt;'</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #9876AA">next</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">);<br />}<br /></span><span style="color: #9876AA">?&gt;</span></span></span></div>    </div>    <div class="example-contents"><p>以上例程会输出：</p></div>    <div class="example-contents screen" style="color:AFB1B3;background:black;padding-left:5px;"><div class="cdata"><span>fruit1&lt;br /&gt;<br>fruit4&lt;br /&gt;<br>fruit5&lt;br /&gt;<br></span></div>    </div>   </div>  </span> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.key-seealso">  <h3 class="title">参见</h3>  <span>   <ul class="simplelist">    <li class="member"><span class="function">{@link current()} - 返回数组中的当前单元</span></li>    <li class="member"><span class="function">{@link next()} - 将数组中的内部指针向前移动一位</span></li>    <li class="member"><a href="http://php.net/manual/zh/control-structures.foreach.php" class="link">foreach</a></li>   </ul>  </span> </div>  </div>
*/
	public function key () {}
	/**
	 * Seek to the next row number
	 * @link https://php.net/manual/en/function.sqlite-next.php
	 * @return bool Returns <b>TRUE</b> on success, or <b>FALSE</b> if there are no more rows.
	 * @since 5.0.0
	 */
/**
*<div id="function.next" class="refentry">   <div class="refnamediv">    <h1 class="refname">next</h1>    <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">next</span> &mdash; <span class="dc-title">     将数组中的内部指针向前移动一位    </span></p>   </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.next-description">  <h3 class="title">说明</h3>  <div class="methodsynopsis dc-description">   <span class="methodname" style="color:#CC7832"><strong>next</strong></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">array</span> <span class="parameter" style="color:#3A95FF">&$array</span></span>   ) : <span class="type" style="color:#EAB766"><a href="http://php.net/manual/zh/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span></div>   <p class="para rdfs-comment">     <span class="function"><strong style="color:#CC7832">next()</strong></span> 和 <span class="function">{@link current()}</span>     的行为类似，只有一点区别，在返回值之前将内部指针向前移动一位。这意味着它返回的是下一个数组单元的值并将数组指针向前移动了一位。    </p>   </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.next-parameters">  <h3 class="title">参数</h3>  <span>   <dl>         <dt><span class="parameter" style="color:#3A95FF">array</span></dt>     <dd>      <p class="para">       受影响的 <span class="type" style="color:#EAB766">array</span> 。      </p>     </dd>       </dl>  </span> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.next-returnvalues">  <h3 class="title">返回值</h3>  <p class="para">   返回数组内部指针指向的下一个单元的值，或当没有更多单元时返回 <strong><span>FALSE</span></strong>。  </p>  <div class="warning"><strong class="warning">Warning</strong><p class="simpara">此函数可能返回布尔值<strong><span>FALSE</span></strong>，但也可能返回等同于 <strong><span>FALSE</span></strong> 的非布尔值。请阅读 <a href="http://php.net/manual/zh/language.types.boolean.php" class="link">布尔类型</a>章节以获取更多信息。应使用<a href="http://php.net/manual/zh/language.operators.comparison.php" class="link">===运算符</a>来测试此函数的返回值。</p></div> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.next-examples">  <h3 class="title">范例</h3>  <span>   <div class="example" id="example-5310">    <p><strong>Example #1  <span class="function"><strong style="color:#CC7832">next()</strong></span> 及相关函数的用法示例</strong></p>    <div class="example-contents"><div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"><span style="color: #9876AA">&lt;?php<br />$transport&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #DD0000">'foot'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'bike'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'car'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'plane'</span><span style="color: #007700">);<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'foot';<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">next</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'bike';<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">next</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'car';<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">prev</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'bike';<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">end</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'plane';<br /></span><span style="color: #9876AA">?&gt;</span></span></span></div>    </div>   </div>  </span> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 notes" id="refsect1-function.next-notes">  <h3 class="title">注释</h3>  <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>:    <span class="simpara">     你将无法区别包含数组尾以及 <span class="type" style="color:#EAB766">boolean</span> <strong><span>FALSE</span></strong> 单元的数组。要正确遍历可能含有空单元或者单元值为 0 的数组，参见   <span class="function">{@link each()}</span> 函数。   </span>  </p></blockquote> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.next-seealso">  <h3 class="title">参见</h3>  <span>   <ul class="simplelist">    <li class="member"><span class="function">{@link current()} - 返回数组中的当前单元</span></li>    <li class="member"><span class="function">{@link end()} - 将数组的内部指针指向最后一个单元</span></li>    <li class="member"><span class="function">{@link prev()} - 将数组的内部指针倒回一位</span></li>    <li class="member"><span class="function">{@link reset()} - 将数组的内部指针指向第一个单元</span></li>    <li class="member"><span class="function">{@link each()} - 返回数组中当前的键／值对并将数组指针向前移动一步</span></li>   </ul>  </span> </div>  </div>
*/
	public function next () {}
	/**
	 * Checks if current position is valid
	 * @link https://php.net/manual/en/iterator.valid.php
	 * @return bool <p>
	 * Returns <b>TRUE</b> if there are more rows available from the
	 * <i>result</i> handle, or <b>FALSE</b> otherwise.
	 * </p>
	 * @since 5.0.0
	 */
	public function valid () {}
	/**
	 * Rewind the Iterator to the first element
	 * @link https://php.net/manual/en/iterator.rewind.php
	 * @return void Any returned value is ignored.
	 * @since 5.0.0
	 */
/**
*<div id="function.rewind" class="refentry"> <div class="refnamediv">  <h1 class="refname">rewind</h1>  <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">rewind</span> &mdash; <span class="dc-title">倒回文件指针的位置</span></p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.rewind-description">  <h3 class="title">说明</h3>  <div class="methodsynopsis dc-description">   <span class="methodname" style="color:#CC7832"><strong>rewind</strong></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">resource</span> <span class="parameter" style="color:#3A95FF">$handle</span></span>   ) : <span class="type" style="color:#EAB766">bool</span></div>  <p class="para rdfs-comment">   将 <span class="parameter" style="color:#3A95FF">handle</span> 的文件位置指针设为文件流的开头。  </p>  <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>:    <p class="para">    如果将文件以附加（&quot;a&quot; 或者 &quot;a+&quot;）模式打开，写入文件的任何数据总是会被附加在后面，不管文件指针的位置。   </p>  </p></blockquote> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.rewind-parameters">  <h3 class="title">参数</h3>  <span>   <dl>         <dt><span class="parameter" style="color:#3A95FF">handle</span></dt>     <dd>      <p class="para">       文件指针必须合法，并且指向由 <span class="function">{@link fopen()}</span>   成功打开的文件。      </p>     </dd>       </dl>  </span> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.rewind-returnvalues">  <h3 class="title">返回值</h3>  <p class="para">   成功时返回 <strong><span>TRUE</span></strong>， 或者在失败时返回 <strong><span>FALSE</span></strong>。  </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.rewind-examples">  <h3 class="title">范例</h3>  <span>   <div class="example" id="example-2575">    <p><strong>Example #1 <span class="function"><strong style="color:#CC7832">rewind()</strong></span> overwriting example</strong></p>    <div class="example-contents"><div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"><span style="color: #9876AA">&lt;?php<br />$handle&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">fopen</span><span style="color: #007700">(</span><span style="color: #DD0000">'output.txt'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'r+'</span><span style="color: #007700">);<br /><br /></span><span style="color: #9876AA">fwrite</span><span style="color: #007700">(</span><span style="color: #9876AA">$handle</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'Really&nbsp;long&nbsp;sentence.'</span><span style="color: #007700">);<br /></span><span style="color: #9876AA">rewind</span><span style="color: #007700">(</span><span style="color: #9876AA">$handle</span><span style="color: #007700">);<br /></span><span style="color: #9876AA">fwrite</span><span style="color: #007700">(</span><span style="color: #9876AA">$handle</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'Foo'</span><span style="color: #007700">);<br /></span><span style="color: #9876AA">rewind</span><span style="color: #007700">(</span><span style="color: #9876AA">$handle</span><span style="color: #007700">);<br /><br />echo&nbsp;</span><span style="color: #9876AA">fread</span><span style="color: #007700">(</span><span style="color: #9876AA">$handle</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">filesize</span><span style="color: #007700">(</span><span style="color: #DD0000">'output.txt'</span><span style="color: #007700">));<br /><br /></span><span style="color: #9876AA">fclose</span><span style="color: #007700">(</span><span style="color: #9876AA">$handle</span><span style="color: #007700">);<br /></span><span style="color: #9876AA">?&gt;</span></span></span></div>    </div>    <div class="example-contents"><p>以上例程的输出类似于：</p></div>    <div class="example-contents screen" style="color:AFB1B3;background:black;padding-left:5px;"><div class="cdata"><span>Foolly long sentence.<br></span></div>    </div>   </div>  </span> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.rewind-seealso">  <h3 class="title">参见</h3>  <span>   <ul class="simplelist">    <li class="member"><span class="function">{@link fread()} - 读取文件（可安全用于二进制文件）</span></li>    <li class="member"><span class="function">{@link fseek()} - 在文件指针中定位</span></li>    <li class="member"><span class="function">{@link ftell()} - 返回文件指针读/写的位置</span></li>    <li class="member"><span class="function">{@link fwrite()} - 写入文件（可安全用于二进制文件）</span></li>   </ul>  </span> </div></div>
*/
	public function rewind () {}

	/**
	 * Count elements of an object
	 * @link https://php.net/manual/en/countable.count.php
	 * @return int <p>The custom count as an integer.
	 * </p>
	 * <p>
	 * The return value is cast to an integer.
	 * </p>
	 * @since 5.1.0
	 */
/**
*<div id="function.count" class="refentry">   <div class="refnamediv">    <h1 class="refname">count</h1>    <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">count</span> &mdash; <span class="dc-title">计算数组中的单元数目，或对象中的属性个数</span></p>   </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.count-description">  <h3 class="title">说明</h3>  <div class="methodsynopsis dc-description">   <span class="methodname" style="color:#CC7832"><strong>count</strong></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766"><a href="http://php.net/manual/zh/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span> <span class="parameter" style="color:#3A95FF">$array_or_countable</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$mode</span><span class="initializer"> = COUNT_NORMAL</span></span>  ] ) : <span class="type" style="color:#EAB766">int</span></div>  <p class="para rdfs-comment">   统计出数组里的所有元素的数量，或者对象里的东西。  </p>    <p class="para">     对于对象，如果安装了 <a href="http://php.net/manual/zh/ref.spl.php" class="link">SPL</a>，可以通过实现     <span>Countable</span> 接口对 <span class="function"><strong style="color:#CC7832">count()</strong></span>挂钩（hook）     。该接口只有一个方法     <span class="methodname" style="color:#CC7832">{@link Countable::count()}</span>，此方法为 <span class="function"><strong style="color:#CC7832">count()</strong></span>     函数返回值。    </p>    <p class="para">     关于 PHP 中如何实现和使用数组可以参考手册中<a href="http://php.net/manual/zh/language.types.array.php" class="link">数组</a>章节中的详细描述。  </p> </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.count-parameters">  <h3 class="title">参数</h3>  <span>   <dl>         <dt><span class="parameter" style="color:#3A95FF">array_or_countable</span></dt>     <dd>      <p class="para">       数组或者 <a href="http://php.net/manual/zh/class.countable.php" class="classname">Countable</a>  对象。      </p>     </dd>             <dt><span class="parameter" style="color:#3A95FF">mode</span></dt>     <dd>      <p class="para">       如果可选的 <span class="parameter" style="color:#3A95FF">mode</span> 参数设为     <strong><span>COUNT_RECURSIVE</span></strong>（或 1），<span class="function"><strong style="color:#CC7832">count()</strong></span>     将递归地对数组计数。对计算多维数组的所有单元尤其有用。      </p>      <div class="caution"><strong class="caution">Caution</strong>       <p class="para">        <span class="function"><strong style="color:#CC7832">count()</strong></span> 能检测递归来避免无限循环，但每次出现时会产生 <strong><span>E_WARNING</span></strong> 错误        （如果 array 不止一次包含了自身）并返回大于预期的统计数字。       </p>      </div>     </dd>       </dl>  </span> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.count-returnvalues">  <h3 class="title">返回值</h3>  <p class="para">   返回 <span class="parameter" style="color:#3A95FF">array_or_countable</span> 中的单元数目。      如果参数既不是数组，也不是实现     <span>Countable</span> 接口的对象，将返回     <span>1</span>。   有个例外：如果     <span class="parameter" style="color:#3A95FF">array_or_countable</span> 是 <strong><span>NULL</span></strong> 则结果是 <span>0</span>。  </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.count-examples">  <h3 class="title">范例</h3>  <span>   <div class="example" id="example-5288">    <p><strong>Example #1 <span class="function"><strong style="color:#CC7832">count()</strong></span> 例子</strong></p>    <div class="example-contents"><div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"><span style="color: #9876AA">&lt;?php<br />$a</span><span style="color: #007700">[</span><span style="color: #9876AA">0</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #9876AA">1</span><span style="color: #007700">;<br /></span><span style="color: #9876AA">$a</span><span style="color: #007700">[</span><span style="color: #9876AA">1</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #9876AA">3</span><span style="color: #007700">;<br /></span><span style="color: #9876AA">$a</span><span style="color: #007700">[</span><span style="color: #9876AA">2</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #9876AA">5</span><span style="color: #007700">;<br /></span><span style="color: #9876AA">var_dump</span><span style="color: #007700">(</span><span style="color: #9876AA">count</span><span style="color: #007700">(</span><span style="color: #9876AA">$a</span><span style="color: #007700">));<br /><br /></span><span style="color: #9876AA">$b</span><span style="color: #007700">[</span><span style="color: #9876AA">0</span><span style="color: #007700">]&nbsp;&nbsp;=&nbsp;</span><span style="color: #9876AA">7</span><span style="color: #007700">;<br /></span><span style="color: #9876AA">$b</span><span style="color: #007700">[</span><span style="color: #9876AA">5</span><span style="color: #007700">]&nbsp;&nbsp;=&nbsp;</span><span style="color: #9876AA">9</span><span style="color: #007700">;<br /></span><span style="color: #9876AA">$b</span><span style="color: #007700">[</span><span style="color: #9876AA">10</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #9876AA">11</span><span style="color: #007700">;<br /></span><span style="color: #9876AA">var_dump</span><span style="color: #007700">(</span><span style="color: #9876AA">count</span><span style="color: #007700">(</span><span style="color: #9876AA">$b</span><span style="color: #007700">));<br /><br /></span><span style="color: #9876AA">var_dump</span><span style="color: #007700">(</span><span style="color: #9876AA">count</span><span style="color: #007700">(</span><span style="color: #9876AA">null</span><span style="color: #007700">));<br /><br /></span><span style="color: #9876AA">var_dump</span><span style="color: #007700">(</span><span style="color: #9876AA">count</span><span style="color: #007700">(</span><span style="color: #9876AA">false</span><span style="color: #007700">));<br /></span><span style="color: #9876AA">?&gt;</span></span></span></div>    </div>    <div class="example-contents"><p>以上例程会输出：</p></div>    <div class="example-contents screen" style="color:AFB1B3;background:black;padding-left:5px;"><div class="cdata"><span>int(3)<br>int(3)<br><br>Warning: count(): Parameter must be an array or an object that implements Countable in … on line 12 // PHP 7.2 起<br>int(0)<br><br>Warning: count(): Parameter must be an array or an object that implements Countable in … on line 14 // PHP 7.2 起<br>int(1)<br></span></div>    </div>   </div>  </span>  <p class="para">   <div class="example" id="example-5289">    <p><strong>Example #2 递归 <span class="function"><strong style="color:#CC7832">count()</strong></span> 例子</strong></p>    <div class="example-contents"><div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"><span style="color: #9876AA">&lt;?php<br />$food&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #DD0000">'fruits'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;array(</span><span style="color: #DD0000">'orange'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'banana'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'apple'</span><span style="color: #007700">),<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'veggie'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;array(</span><span style="color: #DD0000">'carrot'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'collard'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'pea'</span><span style="color: #007700">));<br /><br /></span><span style="color: #FF8000">//&nbsp;recursive&nbsp;count<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #9876AA">count</span><span style="color: #007700">(</span><span style="color: #9876AA">$food</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">COUNT_RECURSIVE</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;output&nbsp;8<br /><br />//&nbsp;normal&nbsp;count<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #9876AA">count</span><span style="color: #007700">(</span><span style="color: #9876AA">$food</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;output&nbsp;2<br /><br /></span><span style="color: #9876AA">?&gt;</span></span></span></div>    </div>   </div>  </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 changelog" id="refsect1-function.count-changelog">  <h3 class="title">更新日志</h3>  <table class="doctable informaltable">       <thead>     <tr>      <th>版本</th>      <th>说明</th>     </tr>    </thead>    <tbody class="tbody">     <tr>      <td>7.2.0</td>      <td>       当无效的 countable 类型传递给 <span class="parameter" style="color:#3A95FF">array_or_countable</span> 参数时，<span class="function"><strong style="color:#CC7832">count()</strong></span> 会产生警告。      </td>     </tr>    </tbody>     </table> </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.count-seealso">  <h3 class="title">参见</h3>  <span>   <ul class="simplelist">    <li class="member"><span class="function">{@link is_array()} - 检测变量是否是数组</span></li>    <li class="member"><span class="function">{@link isset()} - 检测变量是否已设置并且非 NULL</span></li>    <li class="member"><span class="function">{@link empty()} - 检查一个变量是否为空</span></li>    <li class="member"><span class="function">{@link strlen()} - 获取字符串长度</span></li>    <li class="member"><span class="function">{@link is_countable()} - Verify that the contents of a variable is a countable value</span></li>   </ul>  </span> </div></div>
*/
	public function count () {}

	/**
	 * Seek to the previous row number of a result set
	 * @link https://php.net/manual/en/function.sqlite-prev.php
	 * @return bool <p> Returns <b>TRUE</b> on success, or <b>FALSE</b> if there are no more previous rows.
	 * </p>
	 * @since 5.4.0
	 */
/**
*<div id="function.prev" class="refentry">   <div class="refnamediv">    <h1 class="refname">prev</h1>    <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">prev</span> &mdash; <span class="dc-title">将数组的内部指针倒回一位</span></p>   </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.prev-description">  <h3 class="title">说明</h3>  <div class="methodsynopsis dc-description">   <span class="methodname" style="color:#CC7832"><strong>prev</strong></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">array</span> <span class="parameter" style="color:#3A95FF">&$array</span></span>   ) : <span class="type" style="color:#EAB766"><a href="http://php.net/manual/zh/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span></div>  <p class="para rdfs-comment">   将数组的内部指针倒回一位。  </p>  <p class="para">     <span class="function"><strong style="color:#CC7832">prev()</strong></span> 和     <span class="function">{@link next()}</span> 的行为类似，只除了它将内部指针倒回一位而不是前移一位。    </p>   </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.prev-parameters">  <h3 class="title">参数</h3>  <span>   <dl>         <dt><span class="parameter" style="color:#3A95FF">array</span></dt>     <dd>      <p class="para">       The input array.      </p>     </dd>       </dl>  </span> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.prev-returnvalues">  <h3 class="title">返回值</h3>  <p class="para">   返回数组内部指针指向的前一个单元的值，或当没有更多单元时返回 <strong><span>FALSE</span></strong>。  </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.prev-examples">  <h3 class="title">范例</h3>  <span>   <div class="example" id="example-5311">    <p><strong>Example #1 <span class="function"><strong style="color:#CC7832">prev()</strong></span> 及相关函数用法示例</strong></p>    <div class="example-contents"><div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"><span style="color: #9876AA">&lt;?php<br />$transport&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #DD0000">'foot'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'bike'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'car'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'plane'</span><span style="color: #007700">);<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'foot';<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">next</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'bike';<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">next</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'car';<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">prev</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'bike';<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">end</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'plane';<br /></span><span style="color: #9876AA">?&gt;</span></span></span></div>    </div>   </div>  </span> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 notes" id="refsect1-function.prev-notes">  <h3 class="title">注释</h3>  <div class="warning"><strong class="warning">Warning</strong><p class="simpara">此函数可能返回布尔值<strong><span>FALSE</span></strong>，但也可能返回等同于 <strong><span>FALSE</span></strong> 的非布尔值。请阅读 <a href="http://php.net/manual/zh/language.types.boolean.php" class="link">布尔类型</a>章节以获取更多信息。应使用<a href="http://php.net/manual/zh/language.operators.comparison.php" class="link">===运算符</a>来测试此函数的返回值。</p></div>  <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>:    <span class="simpara">    你会无法区分包含 <span class="type" style="color:#EAB766">boolean</span> <strong><span>FALSE</span></strong> 单元的数组开头。要正确遍历可能含有空单元或者单元值为 0 的数组，参见       <span class="function">{@link each()}</span> 函数。   </span>  </p></blockquote> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.prev-seealso">  <h3 class="title">参见</h3>  <span>   <ul class="simplelist">    <li class="member"><span class="function">{@link current()} - 返回数组中的当前单元</span></li>    <li class="member"><span class="function">{@link end()} - 将数组的内部指针指向最后一个单元</span></li>    <li class="member"><span class="function">{@link next()} - 将数组中的内部指针向前移动一位</span></li>    <li class="member"><span class="function">{@link reset()} - 将数组的内部指针指向第一个单元</span></li>    <li class="member"><span class="function">{@link each()} - 返回数组中当前的键／值对并将数组指针向前移动一步</span></li>   </ul>  </span> </div>  </div>
*/
	public function prev () {}

	/**
	 *@since 5.4.0
	 * Returns whether or not a previous row is available
	 * @link https://php.net/manual/en/function.sqlite-has-prev.php
	 * @return bool <p>
	 * Returns <b>TRUE</b> if there are more previous rows available from the
	 * <i>result</i> handle, or <b>FALSE</b> otherwise.
	 * </p>
	 */
	public function hasPrev () {}

	/**
	 * (PHP 5 &lt; 5.4.0, PECL sqlite &gt;= 1.0.0)
	 * Returns the number of rows in a buffered result set
	 * @link https://php.net/manual/en/function.sqlite-num-rows.php
	 * @return int Returns the number of rows, as an integer.
	 */
	public function numRows () {}

	/**
	 * (PHP 5 &lt; 5.4.0, PECL sqlite &gt;= 1.0.0)
	 * Seek to a particular row number of a buffered result set
	 * @link https://php.net/manual/en/function.sqlite-seek.php
	 * @param $row
	 * <p>
	 * The ordinal row number to seek to.  The row number is zero-based (0 is
	 * the first row).
	 * </p>
	 * <blockquote><p><b>Note</b>: </p><p>This function cannot be used with
	 * unbuffered result handles.</p></blockquote>
	 */
	public function seek ($row) {}

}

/**
 * Represents an unbuffered SQLite result set. Unbuffered results sets are sequential, forward-seeking only.
 * @link https://php.net/manual/en/ref.sqlite.php
 */
final class SQLiteUnbuffered  {

	/**
	 * @param $result_type [optional]
	 * @param $decode_binary [optional]
	 */
	public function fetch ($result_type, $decode_binary) {}

	/**
	 * @param $class_name [optional]
	 * @param $ctor_params [optional]
	 * @param $decode_binary [optional]
	 */
	public function fetchObject ($class_name, $ctor_params, $decode_binary) {}

	/**
	 * @param $decode_binary [optional]
	 */
	public function fetchSingle ($decode_binary) {}

	/**
	 * @param $result_type [optional]
	 * @param $decode_binary [optional]
	 */
	public function fetchAll ($result_type, $decode_binary) {}

	/**
	 * @param $index_or_name
	 * @param $decode_binary [optional]
	 */
	public function column ($index_or_name, $decode_binary) {}

	public function numFields () {}

	/**
	 * @param $field_index
	 */
	public function fieldName ($field_index) {}

	/**
	 * @param $result_type [optional]
	 * @param $decode_binary [optional]
	 */
/**
*<div id="function.current" class="refentry">   <div class="refnamediv">    <h1 class="refname">current</h1>    <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">current</span> &mdash; <span class="dc-title">返回数组中的当前单元</span></p>   </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.current-description">  <h3 class="title">说明</h3>  <div class="methodsynopsis dc-description">   <span class="methodname" style="color:#CC7832"><strong>current</strong></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">array</span> <span class="parameter" style="color:#3A95FF">&$array</span></span>   ) : <span class="type" style="color:#EAB766"><a href="http://php.net/manual/zh/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span></div>    <p class="para rdfs-comment">     每个数组中都有一个内部的指针指向它“当前的”单元，初始指向插入到数组中的第一个单元。    </p>   </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.current-parameters">  <h3 class="title">参数</h3>  <span>   <dl>         <dt><span class="parameter" style="color:#3A95FF">array</span></dt>     <dd>      <p class="para">       这个数组。      </p>     </dd>       </dl>  </span> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.current-returnvalues">  <h3 class="title">返回值</h3>  <p class="para">   <span class="function"><strong style="color:#CC7832">current()</strong></span> 函数返回当前被内部指针指向的数组单元的值，并不移动指针。如果内部指针指向超出了单元列表的末端，<span class="function"><strong style="color:#CC7832">current()</strong></span>     返回 <strong><span>FALSE</span></strong>。  </p>  <div class="warning"><strong class="warning">Warning</strong><p class="simpara">此函数可能返回布尔值<strong><span>FALSE</span></strong>，但也可能返回等同于 <strong><span>FALSE</span></strong> 的非布尔值。请阅读 <a href="http://php.net/manual/zh/language.types.boolean.php" class="link">布尔类型</a>章节以获取更多信息。应使用<a href="http://php.net/manual/zh/language.operators.comparison.php" class="link">===运算符</a>来测试此函数的返回值。</p></div> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.current-examples">  <h3 class="title">范例</h3>  <span>   <div class="example" id="example-5290">    <p><strong>Example #1 使用  <span class="function"><strong style="color:#CC7832">current()</strong></span> 系列函数的例子</strong></p>    <div class="example-contents"><div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"><span style="color: #9876AA">&lt;?php<br />$transport&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #DD0000">'foot'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'bike'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'car'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'plane'</span><span style="color: #007700">);<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'foot';<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">next</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'bike';<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'bike';<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">prev</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'foot';<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">end</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'plane';<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'plane';<br /><br /></span><span style="color: #9876AA">$arr&nbsp;</span><span style="color: #007700">=&nbsp;array();<br /></span><span style="color: #9876AA">var_dump</span><span style="color: #007700">(</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$arr</span><span style="color: #007700">));&nbsp;</span><span style="color: #FF8000">//&nbsp;bool(false)<br /><br /></span><span style="color: #9876AA">$arr&nbsp;</span><span style="color: #007700">=&nbsp;array(array());<br /></span><span style="color: #9876AA">var_dump</span><span style="color: #007700">(</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$arr</span><span style="color: #007700">));&nbsp;</span><span style="color: #FF8000">//&nbsp;array(0)&nbsp;{&nbsp;}<br /></span><span style="color: #9876AA">?&gt;</span></span></span></div>    </div>   </div>  </span> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 notes" id="refsect1-function.current-notes">  <h3 class="title">注释</h3>  <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>:    <span class="simpara">    如果数组包含 <span class="type" style="color:#EAB766">boolean</span> <strong><span>FALSE</span></strong> 的单元则本函数在碰到这个单元时也返回       <strong><span>FALSE</span></strong>，使得不可能判断是否到了此数组列表的末端。    要正确遍历可能含有空单元的数组，用 <span class="function">{@link each()}</span> 函数。   </span>  </p></blockquote> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.current-seealso">  <h3 class="title">参见</h3>  <span>   <ul class="simplelist">    <li class="member"><span class="function">{@link end()} - 将数组的内部指针指向最后一个单元</span></li>    <li class="member"><span class="function">{@link key()} - 从关联数组中取得键名</span></li>    <li class="member"><span class="function">{@link each()} - 返回数组中当前的键／值对并将数组指针向前移动一步</span></li>    <li class="member"><span class="function">{@link prev()} - 将数组的内部指针倒回一位</span></li>    <li class="member"><span class="function">{@link reset()} - 将数组的内部指针指向第一个单元</span></li>    <li class="member"><span class="function">{@link next()} - 将数组中的内部指针向前移动一位</span></li>   </ul>  </span> </div>      </div>
*/
	public function current ($result_type, $decode_binary) {}

/**
*<div id="function.next" class="refentry">   <div class="refnamediv">    <h1 class="refname">next</h1>    <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">next</span> &mdash; <span class="dc-title">     将数组中的内部指针向前移动一位    </span></p>   </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.next-description">  <h3 class="title">说明</h3>  <div class="methodsynopsis dc-description">   <span class="methodname" style="color:#CC7832"><strong>next</strong></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">array</span> <span class="parameter" style="color:#3A95FF">&$array</span></span>   ) : <span class="type" style="color:#EAB766"><a href="http://php.net/manual/zh/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span></div>   <p class="para rdfs-comment">     <span class="function"><strong style="color:#CC7832">next()</strong></span> 和 <span class="function">{@link current()}</span>     的行为类似，只有一点区别，在返回值之前将内部指针向前移动一位。这意味着它返回的是下一个数组单元的值并将数组指针向前移动了一位。    </p>   </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.next-parameters">  <h3 class="title">参数</h3>  <span>   <dl>         <dt><span class="parameter" style="color:#3A95FF">array</span></dt>     <dd>      <p class="para">       受影响的 <span class="type" style="color:#EAB766">array</span> 。      </p>     </dd>       </dl>  </span> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.next-returnvalues">  <h3 class="title">返回值</h3>  <p class="para">   返回数组内部指针指向的下一个单元的值，或当没有更多单元时返回 <strong><span>FALSE</span></strong>。  </p>  <div class="warning"><strong class="warning">Warning</strong><p class="simpara">此函数可能返回布尔值<strong><span>FALSE</span></strong>，但也可能返回等同于 <strong><span>FALSE</span></strong> 的非布尔值。请阅读 <a href="http://php.net/manual/zh/language.types.boolean.php" class="link">布尔类型</a>章节以获取更多信息。应使用<a href="http://php.net/manual/zh/language.operators.comparison.php" class="link">===运算符</a>来测试此函数的返回值。</p></div> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.next-examples">  <h3 class="title">范例</h3>  <span>   <div class="example" id="example-5310">    <p><strong>Example #1  <span class="function"><strong style="color:#CC7832">next()</strong></span> 及相关函数的用法示例</strong></p>    <div class="example-contents"><div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"><span style="color: #9876AA">&lt;?php<br />$transport&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #DD0000">'foot'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'bike'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'car'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'plane'</span><span style="color: #007700">);<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'foot';<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">next</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'bike';<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">next</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'car';<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">prev</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'bike';<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">end</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'plane';<br /></span><span style="color: #9876AA">?&gt;</span></span></span></div>    </div>   </div>  </span> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 notes" id="refsect1-function.next-notes">  <h3 class="title">注释</h3>  <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>:    <span class="simpara">     你将无法区别包含数组尾以及 <span class="type" style="color:#EAB766">boolean</span> <strong><span>FALSE</span></strong> 单元的数组。要正确遍历可能含有空单元或者单元值为 0 的数组，参见   <span class="function">{@link each()}</span> 函数。   </span>  </p></blockquote> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.next-seealso">  <h3 class="title">参见</h3>  <span>   <ul class="simplelist">    <li class="member"><span class="function">{@link current()} - 返回数组中的当前单元</span></li>    <li class="member"><span class="function">{@link end()} - 将数组的内部指针指向最后一个单元</span></li>    <li class="member"><span class="function">{@link prev()} - 将数组的内部指针倒回一位</span></li>    <li class="member"><span class="function">{@link reset()} - 将数组的内部指针指向第一个单元</span></li>    <li class="member"><span class="function">{@link each()} - 返回数组中当前的键／值对并将数组指针向前移动一步</span></li>   </ul>  </span> </div>  </div>
*/
	public function next () {}

	public function valid () {}

}

final class SQLiteException extends RuntimeException  {
	protected $message;
	protected $code;
	protected $file;
	protected $line;


	/**
	 * Clone the exception
	 * @link https://php.net/manual/en/exception.clone.php
	 * @return void
	 * @since 5.1.0
	 */
	final private function __clone () {}

	/**
	 * Construct the exception
	 * @link https://php.net/manual/en/exception.construct.php
	 * @param $message [optional]
	 * @param $code [optional]
	 * @param $previous [optional]
	 * @since 5.1.0
	 */
	public function __construct ($message, $code, $previous) {}

	/**
	 * String representation of the exception
	 * @link https://php.net/manual/en/exception.tostring.php
	 * @return string the string representation of the exception.
	 * @since 5.1.0
	 */
	public function __toString () {}

}

/**
 * (PHP 5, PECL sqlite &gt;= 1.0.0)<br/>
 * Opens a SQLite database and create the database if it does not exist
 * @link https://php.net/manual/en/function.sqlite-open.php
 * @param string $filename <p>
 * The filename of the SQLite database. If the file does not exist, SQLite
 * will attempt to create it. PHP must have write permissions to the file
 * if data is inserted, the database schema is modified or to create the
 * database if it does not exist.
 * </p>
 * @param int $mode [optional] <p>
 * The mode of the file. Intended to be used to open the database in
 * read-only mode. Presently, this parameter is ignored by the sqlite
 * library. The default value for mode is the octal value
 * 0666 and this is the recommended value.
 * </p>
 * @param string $error_message [optional] <p>
 * Passed by reference and is set to hold a descriptive error message
 * explaining why the database could not be opened if there was an error.
 * </p>
 * @return resource|false a resource (database handle) on success, false on error.
 */
function sqlite_open ($filename, $mode = null, &$error_message = null) {}

/**
 * (PHP 5, PECL sqlite &gt;= 1.0.0)<br/>
 * Opens a persistent handle to an SQLite database and create the database if it does not exist
 * @link https://php.net/manual/en/function.sqlite-popen.php
 * @param string $filename <p>
 * The filename of the SQLite database. If the file does not exist, SQLite
 * will attempt to create it. PHP must have write permissions to the file
 * if data is inserted, the database schema is modified or to create the
 * database if it does not exist.
 * </p>
 * @param int $mode [optional] <p>
 * The mode of the file. Intended to be used to open the database in
 * read-only mode. Presently, this parameter is ignored by the sqlite
 * library. The default value for mode is the octal value
 * 0666 and this is the recommended value.
 * </p>
 * @param string $error_message [optional] <p>
 * Passed by reference and is set to hold a descriptive error message
 * explaining why the database could not be opened if there was an error.
 * </p>
 * @return resource|false <p>a resource (database handle) on success, false on error.</p>
 */
function sqlite_popen ($filename, $mode = null, &$error_message = null) {}

/**
 * (PHP 5, PECL sqlite &gt;= 1.0.0)<br/>
 * Closes an open SQLite database
 * @link https://php.net/manual/en/function.sqlite-close.php
 * @param resource $dbhandle <p>
 * The SQLite Database resource; returned from sqlite_open
 * when used procedurally.
 * </p>
 * @return void
 */
function sqlite_close ($dbhandle) {}

/**
 * (PHP 5 &lt; 5.4.0, PECL sqlite &gt;= 1.0.0)<br/>
 * Executes a query against a given database and returns a result handle
 * there are two signatures with <i>$query</i> first and with <i>$dbhandle</i> first.
 * @link https://php.net/manual/en/function.sqlite-query.php
 * @param string|resource $query <p>
 * The query to be executed.
 * </p>
 * <p>
 * Data inside the query should be properly escaped.
 * </p>
 * @param resource|string $dbhandle The SQLite Database resource; returned from sqlite_open() when used procedurally. This parameter is not required when using the object-oriented method.
 * @param int $result_type [optional] &sqlite.result-type;<p>The optional <i>result_type</i>
 * parameter accepts a constant and determines how the returned array will be
 * indexed. Using <b>SQLITE_ASSOC</b> will return only associative
 * indices (named fields) while <b>SQLITE_NUM</b> will return
 * only numerical indices (ordinal field numbers). <b>SQLITE_BOTH</b>
 * will return both associative and numerical indices.
 * <b>SQLITE_BOTH</b> is the default for this function.</p>
 * @param mixed $error_msg [optional] <p>
 * The specified variable will be filled if an error occurs. This is
 * specially important because SQL syntax errors can't be fetched using
 * the
 * {@see sqlite_last_error} function.
 * </p>
 * @return resource|false  This function will return a result handle or <b>FALSE</b> on failure.
 * For queries that return rows, the result handle can then be used with
 * functions such as
 * {@see sqlite_fetch_array} and
 * {@see sqlite_seek}.
 * </p>
 * <p>
 * Regardless of the query type, this function will return false if the
 * query failed.
 * </p>
 * <p>
 * {@see sqlite_query} returns a buffered, seekable result
 * handle. This is useful for reasonably small queries where you need to
 * be able to randomly access the rows. Buffered result handles will
 * allocate memory to hold the entire result and will not return until it
 * has been fetched. If you only need sequential access to the data, it is
 * recommended that you use the much higher performance
 * {@see sqlite_unbuffered_query} instead.
 */
function sqlite_query ($query, $dbhandle, $result_type = null, &$error_msg = SQLITE_BOTH) {}

/**
 * (PHP 5, PECL sqlite &gt;= 1.0.3)<br/>
 * Executes a result-less query against a given database
 * @link https://php.net/manual/en/function.sqlite-exec.php
 * @param string $query <p>
 * The query to be executed.
 * </p>
 * <p>
 * Data inside the query should be properly escaped.
 * </p>
 * @param resource $dbhandle <p>
 * The SQLite Database resource; returned from
 * {@see sqlite_open()} when used procedurally. This parameter
 * is not required when using the object-oriented method.
 * </p>
 * @param string $error_msg [optional] <p>
 * The specified variable will be filled if an error occurs. This is
 * specially important because SQL syntax errors can't be fetched using
 * the
 * {@see sqlite_last_error} function.
 * </p>
 * @return bool <p>This function will return a boolean result; true for success or false for failure.
 * If you need to run a query that returns rows, see sqlite_query.</p>
 */
function sqlite_exec ($dbhandle, $query, &$error_msg = null) {}

/**
 * (PHP 5, PECL sqlite &gt;= 1.0.0)<br/>
 * Execute a query against a given database and returns an array
 * @link https://php.net/manual/en/function.sqlite-array-query.php
 * @param string $query <p>
 * The query to be executed.
 * </p>
 * <p>
 * Data inside the query should be properly escaped.
 * </p>
 * @param resource $dbhandle <p>
 * The SQLite Database resource; returned from
 * {@see sqlite_open()}
 * when used procedurally.  This parameter is not required
 * when using the object-oriented method.
 * </p>
 * @param int $result_type [optional] &sqlite.result-type; <p>The optional <i>result_type</i>
 * parameter accepts a constant and determines how the returned array will be
 * indexed. Using <b>SQLITE_ASSOC</b> will return only associative
 * indices (named fields) while <b>SQLITE_NUM</b> will return
 * only numerical indices (ordinal field numbers). <b>SQLITE_BOTH</b>
 * will return both associative and numerical indices.
 * <b>SQLITE_BOTH</b> is the default for this function.</p>
 * @param bool $decode_binary [optional] &sqlite.decode-bin; <p>When the <i>decode_binary</i>
 * parameter is set to <b>TRUE</b> (the default), PHP will decode the binary encoding
 * it applied to the data if it was encoded using the
 * {@link sqlite_escape_string()}.  You should normally leave this
 * value at its default, unless you are interoperating with databases created by
 * other sqlite capable applications.</p>
 * @return array|false an array of the entire result set; false otherwise.
 * <p>The column names returned by
 * <b>SQLITE_ASSOC</b> and <b>SQLITE_BOTH</b> will be
 * case-folded according to the value of the
 * {@link php.net/en/sqlite.configuration.php#ini.sqlite.assoc-case sqlite.assoc_case} configuration
 * option.</p>
 */
function sqlite_array_query ($dbhandle, $query, $result_type = null, $decode_binary = null) {}

/**
 * (PHP 5, PECL sqlite &gt;= 1.0.1)<br/>
 * Executes a query and returns either an array for one single column or the value of the first row
 * @link https://php.net/manual/en/function.sqlite-single-query.php
 * @param resource $db
 * @param string $query
 * @param bool $first_row_only [optional]
 * @param bool $decode_binary [optional]
 * @return array
 */
function sqlite_single_query ($db, $query, $first_row_only = null, $decode_binary = null) {}

/**
 * (PHP 5, PECL sqlite &gt;= 1.0.0)<br/>
 * Fetches the next row from a result set as an array
 * @link https://php.net/manual/en/function.sqlite-fetch-array.php
 * @param resource $result <p>The SQLite result resource. This parameter is not required when using the object-oriented method.</p>
 * @param int $result_type [optional] &sqlite.result-type;
 * @param bool $decode_binary [optional] &sqlite.decode-bin;
 * @return array|false <p>an array of the next row from a result set; false if the
 * next position is beyond the final row.</p>
 */
function sqlite_fetch_array ($result, $result_type = SQLITE_BOTH, $decode_binary = null) {}

/**
 * Fetches the next row from a result set as an object
 * @link https://php.net/manual/en/function.sqlite-fetch-object.php
 * @param resource $result
 * @param string $class_name [optional]
 * @param array $ctor_params [optional]
 * @param bool $decode_binary [optional]
 * @return object
 */
function sqlite_fetch_object ($result, $class_name = null, array $ctor_params = null, $decode_binary = null) {}

/**
 * (PHP 5, PECL sqlite &gt;= 1.0.1)<br/>
 * Fetches the first column of a result set as a string
 * @link https://php.net/manual/en/function.sqlite-fetch-single.php
 * @param resource $result <p>The SQLite result resource. This parameter is not required when using the object-oriented method.</p>
 * @param bool $decode_binary [optional] <p>When the <b>decode_binary</b>
 * parameter is set to <b>TRUE</b> (the default), PHP will decode the binary encoding
 * it applied to the data if it was encoded using the
 * {@see sqlite_escape_string()}.  You should normally leave this
 * value at its default, unless you are interoperating with databases created by
 * other sqlite capable applications.</p>
 * @return string <p>the first column value, as a string.</p>
 */
function sqlite_fetch_single ($result, $decode_binary = null) {}

/**
 * (PHP 5, PECL sqlite &gt;= 1.0.0)<br/>
 * &Alias; {@see sqlite_fetch_single}
 * @link https://php.net/manual/en/function.sqlite-fetch-string.php
 * @param resource $result <p>The SQLite result resource. This parameter is not required when using the object-oriented method.</p>
 * @param bool $decode_binary [optional] <p>When the <b>decode_binary</b>
 * parameter is set to <b>TRUE</b> (the default), PHP will decode the binary encoding
 * it applied to the data if it was encoded using the
 * {@see sqlite_escape_string()}.  You should normally leave this
 * value at its default, unless you are interoperating with databases created by
 * other sqlite capable applications.</p>
 * @return string <p>the first column value, as a string.</p>
 */
function sqlite_fetch_string ($result, $decode_binary) {}

/**
 * (PHP 5, PECL sqlite &gt;= 1.0.0)<br/>
 * Fetches all rows from a result set as an array of arrays
 * @link https://php.net/manual/en/function.sqlite-fetch-all.php
 * @param int $result_type [optional] &sqlite.result-type;
 * @param bool $decode_binary [optional] &sqlite.decode-bin;
 * @return array <p>an array of the remaining rows in a result set. If called right
 * after
 * {@see sqlite_query}, it returns all rows. If called
 * after
 * {@see sqlite_fetch_array}, it returns the rest. If
 * there are no rows in a result set, it returns an empty array.</p>
 * <p>The column names returned by <b>SQLITE_ASSOC</b> and <b>SQLITE_BOTH</b> will be case-folded according to the value of the
 * {@link https://php.net/manual/en/sqlite.configuration.php#ini.sqlite.assoc-case sqlite.assoc_case} configuration option.</p>
 */
function sqlite_fetch_all ($result_type = null, $decode_binary = null) {}

/**
 * (PHP 5, PECL sqlite &gt;= 1.0.0)<br/>
 * Fetches the current row from a result set as an array
 * @link https://php.net/manual/en/function.sqlite-current.php
 * @param resource $result <p>The SQLite result resource. This parameter is not required when using the object-oriented method.</p>
 * @param int $result_type [optional] <p>The optional result_type parameter accepts a constant and determines how the returned array will be indexed. Using <b>SQLITE_ASSOC</b> will return only associative indices (named fields) while <b>SQLITE_NUM</b> will return only numerical indices (ordinal field numbers). <b>SQLITE_BOTH</b> will return both associative and numerical indices. <b>SQLITE_BOTH</b> is the default for this function.</p>
 * @param bool $decode_binary [optional] <p>When the decode_binary parameter is set to <b>TRUE</b> (the default), PHP will decode the binary encoding it applied to the data if it was encoded using the sqlite_escape_string(). You should normally leave this value at its default, unless you are interoperating with databases created by other sqlite capable applications.</p>
 * @return array|false an array of the current row from a result set; false if the
 * current position is beyond the final row.
 */
function sqlite_current ($result, $result_type = null, $decode_binary = null) {}

/**
 * (PHP 5, PECL sqlite &gt;= 1.0.0)<br/>
 * Fetches a column from the current row of a result set
 * @link https://php.net/manual/en/function.sqlite-column.php
 * @param resource $result <p>The SQLite result resource. This parameter is not required when using the object-oriented method.</p>
 * @param mixed $index_or_name <p>
 * The column index or name to fetch.
 * </p>
 * @param bool $decode_binary [optional] <p>When the <b>decode_binary</b>
 * parameter is set to <b>TRUE</b> (the default), PHP will decode the binary encoding
 * it applied to the data if it was encoded using the
 * {@see sqlite_escape_string()}.  You should normally leave this
 * value at its default, unless you are interoperating with databases created by
 * other sqlite capable applications.</p>
 * @return mixed the column value.
 */
function sqlite_column ($result, $index_or_name, $decode_binary = null) {}

/**
 * (PHP 5, PECL sqlite &gt;= 1.0.0)<br/>
 * Returns the version of the linked SQLite library
 * @link https://php.net/manual/en/function.sqlite-libversion.php
 * @return string the library version, as a string.
 */
function sqlite_libversion () {}

/**
 * (PHP 5, PECL sqlite &gt;= 1.0.0)<br/>
 * Returns the encoding of the linked SQLite library
 * @link https://php.net/manual/en/function.sqlite-libencoding.php
 * @return string the library encoding.
 */
function sqlite_libencoding () {}

/**
 * (PHP 5, PECL sqlite &gt;= 1.0.0)<br/>
 * Returns the number of rows that were changed by the most
 * recent SQL statement
 * @link https://php.net/manual/en/function.sqlite-changes.php
 * @param $db
 * @return int the number of changed rows.
 */
function sqlite_changes ($db) {}

/**
 * (PHP 5, PECL sqlite &gt;= 1.0.0)<br/>
 * Returns the rowid of the most recently inserted row
 * @link https://php.net/manual/en/function.sqlite-last-insert-rowid.php
 * @param resource $dbhandle <p>The SQLite Database resource; returned from
 * {@see sqlite_open()} when used procedurally. This parameter is not required when using the object-oriented method.</p>
 * @return int the row id, as an integer.
 */
function sqlite_last_insert_rowid ($dbhandle) {}

/**
 * (PHP 5, PECL sqlite &gt;= 1.0.0)<br/>
 * Returns the number of rows in a buffered result set
 * @link https://php.net/manual/en/function.sqlite-num-rows.php
 * @param $result <p>
 * The SQLite result resource.  This parameter is not required when using
 * the object-oriented method.
 * </p>
 * <blockquote><p><b>Note</b>: </p><p>This function cannot be used with
 * unbuffered result handles.</p></blockquote>
 * @return int the number of rows, as an integer.
 */
function sqlite_num_rows ($result) {}

/**
 * (PHP 5, PECL sqlite &gt;= 1.0.0)<br/>
 * Returns the number of fields in a result set
 * @link https://php.net/manual/en/function.sqlite-num-fields.php
 * @param resource $result <p>The SQLite result resource. This parameter is not required when using the object-oriented method.</p>
 * @return int the number of fields, as an integer.
 */
function sqlite_num_fields ($result) {}

/**
 * (PHP 5, PECL sqlite &gt;= 1.0.0)<br/>
 * Returns the name of a particular field
 * @link https://php.net/manual/en/function.sqlite-field-name.php
 * @param resource $result <p>The SQLite result resource. This parameter is not required when using the object-oriented method.</p>
 * @param int $field_index <p>
 * The ordinal column number in the result set.
 * </p>
 * @return string the name of a field in an SQLite result set, given the ordinal
 * column number; false on error.
 */
function sqlite_field_name ($result, $field_index) {}

/**
 * (PHP 5, PECL sqlite &gt;= 1.0.0)<br/>
 * Seek to a particular row number of a buffered result set
 * @link https://php.net/manual/en/function.sqlite-seek.php
 * @param resource $result <p>
 * The SQLite result resource.  This parameter is not required when using
 * the object-oriented method.
 * </p>
 * <blockquote><p><b>Note</b>: </p><p>This function cannot be used with
 * unbuffered result handles.</p></blockquote>
 * @param int $rownum <p>
 * The ordinal row number to seek to. The row number is zero-based (0 is
 * the first row).
 * </p>
 * @return bool false if the row does not exist, true otherwise.
 */
function sqlite_seek ($result, $rownum) {}

/**
 * (PHP 5, PECL sqlite &gt;= 1.0.0)<br/>
 * Seek to the first row number
 * @link https://php.net/manual/en/function.sqlite-rewind.php
 * @param resource $result <p>
 * The SQLite result resource.  This parameter is not required when using
 * the object-oriented method.
 * </p>
 * <blockquote><p><b>Note</b>: </p><p>This function cannot be used with
 * unbuffered result handles.</p></blockquote>
 * @return bool false if there are no rows in the result set, true otherwise.
 */
function sqlite_rewind ($result) {}

/**
 * (PHP 5, PECL sqlite &gt;= 1.0.0)<br/>
 * Seek to the next row number
 * @link https://php.net/manual/en/function.sqlite-next.php
 * @param resource $result <p>
 * The SQLite result resource.  This parameter is not required when using
 * the object-oriented method.
 * </p>
 * <blockquote><p><b>Note</b>: </p><p>This function cannot be used with
 * unbuffered result handles.</p></blockquote>
 * @return bool <b>TRUE</b> on success, or <b>FALSE</b> if there are no more rows.
 */
function sqlite_next ($result) {}

/**
 * Seek to the previous row number of a result set
 * @link https://php.net/manual/en/function.sqlite-prev.php
 * @param resource $result <p>
 * The SQLite result resource.  This parameter is not required when using
 * the object-oriented method.
 * </p>
 * <blockquote><p><b>Note</b>: </p><p>This function cannot be used with
 * unbuffered result handles.</p></blockquote>
 * @return bool true on success, or false if there are no more previous rows.
 */
function sqlite_prev ($result) {}

/**
 * Returns whether more rows are available
 * @link https://php.net/manual/en/function.sqlite-valid.php
 * @param resource $result <p>
 * The SQLite result resource.  This parameter is not required when using
 * the object-oriented method.
 * </p>
 * <blockquote><p><b>Note</b>: </p><p>This function cannot be used with
 * unbuffered result handles.</p></blockquote>
 * @return bool <b>TRUE</b> if there are more rows available from the
 * result handle, or <b>FALSE</b> otherwise.
 */
function sqlite_valid ($result) {}

/**
 * (PHP 5, PECL sqlite &gt;= 1.0.0)<br/>
 * Finds whether or not more rows are available
 * @link https://php.net/manual/en/function.sqlite-has-more.php
 * @param resource $result <p>
 * The SQLite result resource.
 * </p>
 * @return bool <b>TRUE</b> if there are more rows available from the
 * result handle, or <b>FALSE</b> otherwise.
 */
function sqlite_has_more ($result) {}

/**
 * Returns whether or not a previous row is available
 * @link https://php.net/manual/en/function.sqlite-has-prev.php
 * @param resource $result <p>
 * The SQLite result resource.  This parameter is not required when using
 * the object-oriented method.
 * </p>
 * @return bool <b>TRUE</b> if there are more previous rows available from the
 * result handle, or <b>FALSE</b> otherwise.
 */
function sqlite_has_prev ($result) {}

/**
 * (PHP 5, PECL sqlite &gt;= 1.0.0)<br/>
 * Escapes a string for use as a query parameter
 * @link https://php.net/manual/en/function.sqlite-escape-string.php
 * @param string $item <p>
 * The string being quoted.
 * </p>
 * <p>
 * If the item contains a NUL
 * character, or if it begins with a character whose ordinal value is
 * 0x01, PHP will apply a binary encoding scheme so that
 * you can safely store and retrieve binary data.
 * </p>
 * @return string an escaped string for use in an SQLite SQL statement.
 */
function sqlite_escape_string ($item) {}

/**
 * (PHP 5, PECL sqlite &gt;= 1.0.0)<br/>
 * Set busy timeout duration, or disable busy handlers
 * @link https://php.net/manual/en/function.sqlite-busy-timeout.php
 * @param resource $dbhandle <p>The SQLite Database resource; returned from
 * {@see sqlite_open()} when used procedurally.
 * This parameter is not required when using the object-oriented method.</p>
 * @param int $milliseconds <p>
 * The number of milliseconds. When set to
 * 0, busy handlers will be disabled and SQLite will
 * return immediately with a <b>SQLITE_BUSY</b> status code
 * if another process/thread has the database locked for an update.
 * </p>
 * <p>
 * PHP sets the default busy timeout to be 60 seconds when the database is
 * opened.
 * </p>
 * <p>
 * There are one thousand (1000) milliseconds in one second.
 * </p>
 * @return void
 */
function sqlite_busy_timeout ($dbhandle, $milliseconds) {}

/**
 * (PHP 5, PECL sqlite &gt;= 1.0.0)<br/>
 * Returns the error code of the last error for a database
 * @link https://php.net/manual/en/function.sqlite-last-error.php
 * @param resource $dbhandle <p>The SQLite Database resource; returned from
 * {@see sqlite_open()} when used procedurally.
 * This parameter is not required when using the object-oriented method.</p>
 * @return int an error code, or 0 if no error occurred.
 */
function sqlite_last_error ($dbhandle) {}

/**
 * (PHP 5, PECL sqlite &gt;= 1.0.0)<br/>
 * Returns the textual description of an error code
 * @link https://php.net/manual/en/function.sqlite-error-string.php
 * @param int $error_code <p>
 * The error code being used, which might be passed in from
 * {@see sqlite_last_error}.
 * </p>
 * @return string a human readable description of the error_code,
 * as a string.
 */
function sqlite_error_string ($error_code) {}

/**
 * (PHP 5, PECL sqlite &gt;= 1.0.0)<br/>
 * Execute a query that does not prefetch and buffer all data
 * @link https://php.net/manual/en/function.sqlite-unbuffered-query.php
 * @param resource $dbhandle <p>The SQLite Database resource; returned from
 * {@see sqlite_open()} when used procedurally.
 * This parameter is not required when using the object-oriented method.</p>
 * @param string $query <p>
 * The query to be executed.
 * </p>
 * <p>
 * Data inside the query should be properly escaped.
 * </p>
 * @param int $result_type [optional] &sqlite.result-type;
 * @param string $error_msg [optional] <p>
 * The specified variable will be filled if an error occurs. This is
 * specially important because SQL syntax errors can't be fetched using
 * the sqlite_last_error function.
 * </p>
 * @return SQLiteUnbuffered|false a result handle or false on failure.
 * </p>
 * <p>
 * sqlite_unbuffered_query returns a sequential
 * forward-only result set that can only be used to read each row, one after
 * the other.
 */
function sqlite_unbuffered_query ($dbhandle, $query, $result_type = SQLITE_BOTH, &$error_msg = null) {}

/**
 * (PHP 5, PECL sqlite &gt;= 1.0.0)<br/>
 * Register an aggregating UDF for use in SQL statements
 * @link https://php.net/manual/en/function.sqlite-create-aggregate.php
 * @param resource $dbhandle <p>The SQLite Database resource; returned from
 * {@see sqlite_open()} when used procedurally.
 * This parameter is not required when using the object-oriented method.
 * @param string $function_name <p>
 * The name of the function used in SQL statements.
 * </p>
 * @param callback $step_func <p>
 * Callback function called for each row of the result set.
 * </p>
 * @param callback $finalize_func <p>
 * Callback function to aggregate the "stepped" data from each row.
 * </p>
 * @param int $num_args [optional] <p>
 * Hint to the SQLite parser if the callback function accepts a
 * predetermined number of arguments.
 * </p>
 * @return void
 */
function sqlite_create_aggregate ($dbhandle, $function_name, $step_func, $finalize_func, $num_args = null) {}

/**
 * (PHP 5, sqlite &gt;= 1.0.0)<br/>
 * Registers a "regular" User Defined Function for use in SQL statements
 * @link https://php.net/manual/en/function.sqlite-create-function.php
 * @param resource $dbhandle <p>The SQLite Database resource; returned from
 * {@see sqlite_open()} when used procedurally.
 * This parameter is not required when using the object-oriented method.
 * @param string $function_name <p>
 * The name of the function used in SQL statements.
 * </p>
 * @param callback $callback <p>
 * Callback function to handle the defined SQL function.
 * </p>
 * Callback functions should return a type understood by SQLite (i.e.
 * scalar type).
 * @param int $num_args [optional] <p>
 * Hint to the SQLite parser if the callback function accepts a
 * predetermined number of arguments.
 * </p>
 * @return void
 */
function sqlite_create_function ($dbhandle, $function_name, $callback, $num_args = null) {}

/**
 * Opens a SQLite database and returns a SQLiteDatabase object
 * @link https://php.net/manual/en/function.sqlite-factory.php
 * @param string $filename <p>
 * The filename of the SQLite database.
 * </p>
 * @param int $mode [optional] <p>
 * The mode of the file. Intended to be used to open the database in
 * read-only mode. Presently, this parameter is ignored by the sqlite
 * library. The default value for mode is the octal value
 * 0666 and this is the recommended value.
 * </p>
 * @param string $error_message [optional] <p>
 * Passed by reference and is set to hold a descriptive error message
 * explaining why the database could not be opened if there was an error.
 * </p>
 * @return SQLiteDatabase a SQLiteDatabase object on success, &null; on error.
 */
function sqlite_factory ($filename, $mode = null, &$error_message = null) {}

/**
 * (PHP 5, PECL sqlite &gt;= 1.0.0)<br/>
 * Encode binary data before returning it from an UDF
 * @link https://php.net/manual/en/function.sqlite-udf-encode-binary.php
 * @param string $data <p>
 * The string being encoded.
 * </p>
 * @return string The encoded string.
 */
function sqlite_udf_encode_binary ($data) {}

/**
 * (PHP 5, PECL sqlite &gt;= 1.0.0)<br/>
 * Decode binary data passed as parameters to an <acronym>UDF</acronym>
 * @link https://php.net/manual/en/function.sqlite-udf-decode-binary.php
 * @param string $data <p>
 * The encoded data that will be decoded, data that was applied by either
 * sqlite_udf_encode_binary or
 * sqlite_escape_string.
 * </p>
 * @return string The decoded string.
 */
function sqlite_udf_decode_binary ($data) {}

/**
 * Return an array of column types from a particular table
 * @link https://php.net/manual/en/function.sqlite-fetch-column-types.php
 * @param string $table_name <p>
 * The table name to query.
 * </p>
 * @param resource $dbhandle <p>The SQLite Database resource; returned from
 * {@see sqlite_open()} when used procedurally.
 * This parameter is not required when using the object-oriented method.</p>
 * @param int $result_type [optional] <p>
 * The optional result_type parameter accepts a
 * constant and determines how the returned array will be indexed. Using
 * <b>SQLITE_ASSOC</b> will return only associative indices
 * (named fields) while <b>SQLITE_NUM</b> will return only
 * numerical indices (ordinal field numbers).
 * SQLITE_BOTH will return both associative and
 * numerical indices. <b>SQLITE_ASSOC</b> is the default for
 * this function.
 * </p>
 * @return array|false an array of column data types; false on error.
 */
function sqlite_fetch_column_types ($dbhandle, $table_name, $result_type = null) {}


/**
 * Columns are returned into the array having both a numerical index
 * and the field name as the array index.
 * @link https://php.net/manual/en/sqlite.constants.php
 */
define ('SQLITE_BOTH', 3);

/**
 * Columns are returned into the array having a numerical index to the
 * fields. This index starts with 0, the first field in the result.
 * @link https://php.net/manual/en/sqlite.constants.php
 */
define ('SQLITE_NUM', 2);

/**
 * Columns are returned into the array having the field name as the array
 * index.
 * @link https://php.net/manual/en/sqlite.constants.php
 */
define ('SQLITE_ASSOC', 1);

/**
 * Successful result.
 * @link https://php.net/manual/en/sqlite.constants.php
 */
define ('SQLITE_OK', 0);

/**
 * SQL error or missing database.
 * @link https://php.net/manual/en/sqlite.constants.php
 */
define ('SQLITE_ERROR', 1);

/**
 * An internal logic error in SQLite.
 * @link https://php.net/manual/en/sqlite.constants.php
 */
define ('SQLITE_INTERNAL', 2);

/**
 * Access permission denied.
 * @link https://php.net/manual/en/sqlite.constants.php
 */
define ('SQLITE_PERM', 3);

/**
 * Callback routine requested an abort.
 * @link https://php.net/manual/en/sqlite.constants.php
 */
define ('SQLITE_ABORT', 4);

/**
 * The database file is locked.
 * @link https://php.net/manual/en/sqlite.constants.php
 */
define ('SQLITE_BUSY', 5);

/**
 * A table in the database is locked.
 * @link https://php.net/manual/en/sqlite.constants.php
 */
define ('SQLITE_LOCKED', 6);

/**
 * Memory allocation failed.
 * @link https://php.net/manual/en/sqlite.constants.php
 */
define ('SQLITE_NOMEM', 7);

/**
 * Attempt to write a readonly database.
 * @link https://php.net/manual/en/sqlite.constants.php
 */
define ('SQLITE_READONLY', 8);

/**
 * Operation terminated internally.
 * @link https://php.net/manual/en/sqlite.constants.php
 */
define ('SQLITE_INTERRUPT', 9);

/**
 * Disk I/O error occurred.
 * @link https://php.net/manual/en/sqlite.constants.php
 */
define ('SQLITE_IOERR', 10);

/**
 * The database disk image is malformed.
 * @link https://php.net/manual/en/sqlite.constants.php
 */
define ('SQLITE_CORRUPT', 11);

/**
 * (Internal) Table or record not found.
 * @link https://php.net/manual/en/sqlite.constants.php
 */
define ('SQLITE_NOTFOUND', 12);

/**
 * Insertion failed because database is full.
 * @link https://php.net/manual/en/sqlite.constants.php
 */
define ('SQLITE_FULL', 13);

/**
 * Unable to open the database file.
 * @link https://php.net/manual/en/sqlite.constants.php
 */
define ('SQLITE_CANTOPEN', 14);

/**
 * Database lock protocol error.
 * @link https://php.net/manual/en/sqlite.constants.php
 */
define ('SQLITE_PROTOCOL', 15);

/**
 * (Internal) Database table is empty.
 * @link https://php.net/manual/en/sqlite.constants.php
 */
define ('SQLITE_EMPTY', 16);

/**
 * The database schema changed.
 * @link https://php.net/manual/en/sqlite.constants.php
 */
define ('SQLITE_SCHEMA', 17);

/**
 * Too much data for one row of a table.
 * @link https://php.net/manual/en/sqlite.constants.php
 */
define ('SQLITE_TOOBIG', 18);

/**
 * Abort due to constraint violation.
 * @link https://php.net/manual/en/sqlite.constants.php
 */
define ('SQLITE_CONSTRAINT', 19);

/**
 * Data type mismatch.
 * @link https://php.net/manual/en/sqlite.constants.php
 */
define ('SQLITE_MISMATCH', 20);

/**
 * Library used incorrectly.
 * @link https://php.net/manual/en/sqlite.constants.php
 */
define ('SQLITE_MISUSE', 21);

/**
 * Uses of OS features not supported on host.
 * @link https://php.net/manual/en/sqlite.constants.php
 */
define ('SQLITE_NOLFS', 22);

/**
 * Authorized failed.
 * @link https://php.net/manual/en/sqlite.constants.php
 */
define ('SQLITE_AUTH', 23);

/**
 * File opened that is not a database file.
 * @link https://php.net/manual/en/sqlite.constants.php
 */
define ('SQLITE_NOTADB', 26);

/**
 * Auxiliary database format error.
 * @link https://php.net/manual/en/sqlite.constants.php
 */
define ('SQLITE_FORMAT', 24);

/**
 * Internal process has another row ready.
 * @link https://php.net/manual/en/sqlite.constants.php
 */
define ('SQLITE_ROW', 100);

/**
 * Internal process has finished executing.
 * @link https://php.net/manual/en/sqlite.constants.php
 */
define ('SQLITE_DONE', 101);

/**
 * Specifies that a function created with {@see SQLite3::createFunction()} is deterministic,
 * i.e. it always returns the same result given the same inputs within a single SQL statement.
 * @since 7.1.4
 * @link https://php.net/manual/en/sqlite.constants.php
 */
define('SQLITE3_DETERMINISTIC', 2048);
