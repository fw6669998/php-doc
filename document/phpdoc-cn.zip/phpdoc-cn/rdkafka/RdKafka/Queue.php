<?php

namespace RdKafka;

class Queue
{
    private function __construct()
    {
    }

    /**
     * @param string $timeout_ms
     *
     * @return Message|null
     */
    public function consume($timeout_ms)
    {
    }
}
