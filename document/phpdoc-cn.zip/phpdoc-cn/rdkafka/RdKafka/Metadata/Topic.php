<?php

namespace RdKafka\Metadata;

class Topic
{
    /**
     * @return string
     */
    public function getTopic()
    {
    }

    /**
     * @return Partition[]
     */
    public function getPartitions()
    {
    }

    /**
     * @return mixed
     */
    public function getErr()
    {
    }
}
