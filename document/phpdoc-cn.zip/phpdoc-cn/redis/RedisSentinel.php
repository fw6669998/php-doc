<?php

/**
 * The MIT License (MIT)
 *
 * Copyright (c) Tawana Musewe
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * <https://opensource.org/licenses/MIT>.
 */

/**
 * Helper autocomplete for phpredis extension
 *
 * @author  Tawana Musewe <tawana@aeonis.co.za>
 * @link    https://github.com/tbtmuse/phpredis-sentinel-phpdoc
 */
class RedisSentinel {

	/**
	 * Creates a Redis Sentinel
	 *
	 * @param string      $host          Sentinel IP address or hostname
	 * @param int         $port          Sentinel Port
	 * @param float       $timeout       Value in seconds (optional, default is 0 meaning unlimited)
	 * @param string|null $persistent    Persistent connection id (optional, default is null meaning not persistent)
	 * @param int         $retryInterval Value in milliseconds (optional, default is 0)
	 * @param float       $readTimeout   Value in seconds (optional, default is 0 meaning unlimited)
	 *
	 * @example
	 * // 1s timeout, 100ms delay between reconnection attempts.
	 * $sentinel = new RedisSentinel('127.0.0.1', 26379, 1, null, 100);
	 */
	public function __construct(
		string $host,
		int $port,
		float $timeout = 0,
		?string $persistent = null,
		int $retryInterval = 0,
		float $readTimeout = 0
	) {}

	/**
	 * Check if the current Sentinel configuration is able to reach the quorum needed to failover a master, and the
	 * majority needed to authorize the failover. This command should be used in monitoring systems to check if a
	 * Sentinel deployment is ok.
	 *
	 * @param string $master Name of master
	 *
	 * @return bool True in case of success, False in case of failure.
	 *
	 * @example $sentinel->ckquorum('mymaster');
	 *
	 * @since   >= 5.2.0
	 */
	public function ckquorum(string $master): bool {}

	/**
	 * Force a failover as if the master was not reachable, and without asking for agreement to other Sentinels
	 * (however a new version of the configuration will be published so that the other Sentinels will update
	 * their configurations).
	 *
	 * @param string $master Name of master
	 *
	 * @return bool True in case of success, False in case of failure.
	 *
	 * @example $sentinel->failover('mymaster');
	 *
	 * @since   >= 5.2.0
	 */
	public function failover(string $master): bool {}

	/**
	 * Force Sentinel to rewrite its configuration on disk, including the current Sentinel state.
	 *
	 * Normally Sentinel rewrites the configuration every time something changes in its state (in the context of the
	 * subset of the state which is persisted on disk across restart). However sometimes it is possible that the
	 * configuration file is lost because of operation errors, disk failures, package upgrade scripts or configuration
	 * managers. In those cases a way to to force Sentinel to rewrite the configuration file is handy.
	 *
	 * This command works even if the previous configuration file is completely missing.
	 *
	 * @return bool True in case of success, False in case of failure.
	 *
	 * @example $sentinel->flushconfig();
	 *
	 * @since   >= 5.2.0
	 */
	public function flushconfig(): bool {}

	/**
	 * Return the ip and port number of the master with that name. If a failover is in progress or terminated
	 * successfully for this master it returns the address and port of the promoted replica.
	 *
	 * @param string $master Name of master
	 *
	 * @return array|bool ['address', 'port'] in case of success, False in case of failure.
	 *
	 * @example $sentinel->getMasterAddrByName('mymaster');
	 *
	 * @since   >= 5.2.0
	 */
	public function getMasterAddrByName(string $master) {}

	/**
	 * Return the state and info of the specified master
	 *
	 * @param string $master Name of master
	 *
	 * @return array|bool Associative array with info in case of success, False in case of failure.
	 *
	 * @example $sentinel->master('mymaster');
	 *
	 * @since   >= 5.2.0
	 */
	public function master(string $master) {}

	/**
	 * Return a list of monitored masters and their state
	 *
	 * @return array|bool Array of arrays with info for each master in case of success, FALSE in case of failure.
	 *
	 * @example $sentinel->masters();
	 *
	 * @since   >= 5.2.0
	 */
	public function masters() {}

	/**
	 * Ping the sentinel
	 *
	 * @return bool True in case of success, False in case of failure
	 *
	 * @example $sentinel->ping();
	 *
	 * @since   >= 5.2.0
	 */
	public function ping(): bool {}

	/**
	 * Reset all the masters with matching name. The pattern argument is a glob-style pattern.
	 * The reset process clears any previous state in a master (including a failover in progress), and removes every
	 * replica and sentinel already discovered and associated with the master.
	 *
	 * @param string $pattern Glob-style pattern
	 *
	 * @return bool True in case of success, False in case of failure
	 *
	 * @example $sentinel->reset('*');
	 *
	 * @since   >= 5.2.0
	 */
/**
*<div id="function.reset" class="refentry"> <div class="refnamediv">  <h1 class="refname">reset</h1>  <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">reset</span> &mdash; <span class="dc-title">将数组的内部指针指向第一个单元</span></p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.reset-description">  <h3 class="title">说明</h3>  <div class="methodsynopsis dc-description">   <span class="methodname" style="color:#CC7832"><strong>reset</strong></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">array</span> <span class="parameter" style="color:#3A95FF">&$array</span></span>   ) : <span class="type" style="color:#EAB766"><a href="http://php.net/manual/zh/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span></div>  <p class="para rdfs-comment">   <span class="function"><strong style="color:#CC7832">reset()</strong></span> 将 <span class="parameter" style="color:#3A95FF">array</span>   的内部指针倒回到第一个单元并返回第一个数组单元的值。  </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.reset-parameters">  <h3 class="title">参数</h3>  <span>   <dl>         <dt><span class="parameter" style="color:#3A95FF">array</span></dt>     <dd>      <p class="para">       输入的数组。      </p>     </dd>       </dl>  </span> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.reset-returnvalues">  <h3 class="title">返回值</h3>  <p class="para">   返回数组第一个单元的值，如果数组为空则返回 <strong><span>FALSE</span></strong>。  </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.reset-examples">  <h3 class="title">范例</h3>  <span>   <div class="example" id="example-5313">    <p><strong>Example #1 <span class="function"><strong style="color:#CC7832">reset()</strong></span> 例子</strong></p>    <div class="example-contents"><div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"><span style="color: #9876AA">&lt;?php<br /><br />$array&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #DD0000">'step&nbsp;one'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'step&nbsp;two'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'step&nbsp;three'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'step&nbsp;four'</span><span style="color: #007700">);<br /><br /></span><span style="color: #FF8000">//&nbsp;by&nbsp;default,&nbsp;the&nbsp;pointer&nbsp;is&nbsp;on&nbsp;the&nbsp;first&nbsp;element<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">)&nbsp;.&nbsp;</span><span style="color: #DD0000">"&lt;br&nbsp;/&gt;\n"</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;"step&nbsp;one"<br /><br />//&nbsp;skip&nbsp;two&nbsp;steps<br /></span><span style="color: #9876AA">next</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">);<br /></span><span style="color: #9876AA">next</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">);<br />echo&nbsp;</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">)&nbsp;.&nbsp;</span><span style="color: #DD0000">"&lt;br&nbsp;/&gt;\n"</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;"step&nbsp;three"<br /><br />//&nbsp;reset&nbsp;pointer,&nbsp;start&nbsp;again&nbsp;on&nbsp;step&nbsp;one<br /></span><span style="color: #9876AA">reset</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">);<br />echo&nbsp;</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">)&nbsp;.&nbsp;</span><span style="color: #DD0000">"&lt;br&nbsp;/&gt;\n"</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;"step&nbsp;one"<br /><br /></span><span style="color: #9876AA">?&gt;</span></span></span></div>    </div>   </div>  </span> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.reset-seealso">  <h3 class="title">参见</h3>  <span>   <ul class="simplelist">    <li class="member"><span class="function">{@link current()} - 返回数组中的当前单元</span></li>    <li class="member"><span class="function">{@link each()} - 返回数组中当前的键／值对并将数组指针向前移动一步</span></li>    <li class="member"><span class="function">{@link end()} - 将数组的内部指针指向最后一个单元</span></li>    <li class="member"><span class="function">{@link next()} - 将数组中的内部指针向前移动一位</span></li>    <li class="member"><span class="function">{@link prev()} - 将数组的内部指针倒回一位</span></li>   </ul>  </span> </div></div>
*/
	public function reset(string $pattern): bool {}

	/**
	 * Return a list of sentinel instances for this master, and their state
	 *
	 * @param string $master Name of master
	 *
	 * @return array|bool Array of arrays with info for each sentinel in case of success, False in case of failure
	 *
	 * @example $sentinel->sentinels('mymaster');
	 *
	 * @since   >= 5.2.0
	 */
	public function sentinels(string $master) {}

	/**
	 * Return a list of sentinel instances for this master, and their state
	 *
	 * @param string $master Name of master
	 *
	 * @return array|bool Array of arrays with info for each replica in case of success, False in case of failure
	 *
	 * @example $sentinel->slaves('mymaster');
	 *
	 * @since   >= 5.2.0
	 */
	public function slaves(string $master) {}
}
