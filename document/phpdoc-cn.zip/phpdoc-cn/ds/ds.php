<?php

/**
 * PHP Data Structure stubs, a PECL extension
 * @version 1.0.0
 * @author Dominic Guhl <dominic.guhl@posteo.de>
 * @copyright © 2019 PHP Documentation Group
 * @license CC-BY 3.0, https://www.php.net/manual/en/cc.license.php
 */

namespace Ds {

    use Countable;
    use JsonSerializable;
    use OutOfBoundsException;
    use OutOfRangeException;
    use Traversable;
    use UnderflowException;

    /**
     * Collection is the base interface which covers functionality common to all
     * the data structures in this library. It guarantees that all structures
     * are traversable, countable, and can be converted to json using
     * json_encode().
     * @package Ds
     */
    interface Collection extends Traversable, Countable, JsonSerializable
    {
        /**
         * Removes all values from the collection.
         * @link https://www.php.net/manual/en/ds-collection.clear.php
         */
        public function clear(): void;

/**
*<div id="function.copy" class="refentry"> <div class="refnamediv">  <h1 class="refname">copy</h1>  <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">copy</span> &mdash; <span class="dc-title">拷贝文件</span></p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.copy-description">  <h3 class="title">说明</h3>  <div class="methodsynopsis dc-description">   <span class="methodname" style="color:#CC7832"><strong>copy</strong></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$source</span></span>   , <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$dest</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">resource</span> <span class="parameter" style="color:#3A95FF">$context</span></span>  ] ) : <span class="type" style="color:#EAB766">bool</span></div>  <p class="para rdfs-comment">   将文件从 <span class="parameter" style="color:#3A95FF">source</span> 拷贝到 <span class="parameter" style="color:#3A95FF">dest</span>。  </p>  <p class="para">   如果要移动文件的话，请使用 <span class="function">{@link rename()}</span> 函数。  </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.copy-parameters">  <h3 class="title">参数</h3>  <span>   <dl>         <dt><span class="parameter" style="color:#3A95FF">source</span></dt>     <dd>      <p class="para">       源文件路径。      </p>     </dd>             <dt><span class="parameter" style="color:#3A95FF">dest</span></dt>     <dd>      <p class="para">       目标路径。如果 <span class="parameter" style="color:#3A95FF">dest</span> 是一个 URL，则如果封装协议不支持覆盖已有的文件时拷贝操作会失败。      </p>      <div class="warning"><strong class="warning">Warning</strong>       <p class="para">       如果目标文件已存在，将会被覆盖。       </p>      </div>     </dd>             <dt><span class="parameter" style="color:#3A95FF">context</span></dt>     <dd>      <p class="para">       A valid context resource created with        <span class="function">{@link stream_context_create()}</span>.      </p>     </dd>       </dl>  </span> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.copy-returnvalues">  <h3 class="title">返回值</h3>  <p class="para">   成功时返回 <strong><span>TRUE</span></strong>， 或者在失败时返回 <strong><span>FALSE</span></strong>。  </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.copy-examples">  <h3 class="title">范例</h3>  <span>   <div class="example" id="example-2498">    <p><strong>Example #1 <span class="function"><strong style="color:#CC7832">copy()</strong></span> 例子</strong></p>    <div class="example-contents"><div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"><span style="color: #9876AA">&lt;?php<br />$file&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'example.txt'</span><span style="color: #007700">;<br /></span><span style="color: #9876AA">$newfile&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'example.txt.bak'</span><span style="color: #007700">;<br /><br />if&nbsp;(!</span><span style="color: #9876AA">copy</span><span style="color: #007700">(</span><span style="color: #9876AA">$file</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">$newfile</span><span style="color: #007700">))&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"failed&nbsp;to&nbsp;copy&nbsp;</span><span style="color: #9876AA">$file</span><span style="color: #DD0000">...\n"</span><span style="color: #007700">;<br />}<br /></span><span style="color: #9876AA">?&gt;</span></span></span></div>    </div>   </div>  </span> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.copy-seealso">  <h3 class="title">参见</h3>  <span>   <ul class="simplelist">    <li class="member"><span class="function">{@link move_uploaded_file()} - 将上传的文件移动到新位置</span></li>    <li class="member"><span class="function">{@link rename()} - 重命名一个文件或目录</span></li>    <li class="member">The section of the manual about <a href="http://php.net/manual/zh/features.file-upload.php" class="link">handling file uploads</a></li>   </ul>  </span> </div></div>
         * @return Collection*/
        public function copy();

        /**
         * Returns whether the collection is empty.
         * @link https://www.php.net/manual/en/ds-collection.isempty.php
         * @return bool
         */
        public function isEmpty(): bool;

        /**
         * Converts the collection to an array.
         * <p>Note: Casting to an array is not supported yet.
         * @link https://www.php.net/manual/en/ds-collection.toarray.php
         * @return array An array containing all the values in the same order as
         * the collection.
         */
        public function toArray(): array;
    }

    /**
     * Hashable is an interface which allows objects to be used as keys. It’s
     * an alternative to spl_object_hash(), which determines an object’s hash
     * based on its handle: this means that two objects that are considered
     * equal by an implicit definition would not treated as equal because they
     * are not the same instance.
     *
     * hash() is used to return a scalar value to be used as the object's hash
     * value, which determines where it goes in the hash table. While this value
     * does not have to be unique, objects which are equal must have the same
     * hash value.
     *
     * equals() is used to determine if two objects are equal. It's guaranteed
     * that the comparing object will be an instance of the same class as the
     * subject.
     * @package Ds
     */
    interface Hashable
    {
        /**
         * Determines whether another object is equal to the current instance.
         *
         * This method allows objects to be used as keys in structures such as
         * Ds\Map and Ds\Set, or any other lookup structure that honors this
         * interface.
         *
         * Note: It's guaranteed that $obj is an instance of the same class.
         *
         * Caution: It's important that objects which are equal also have the
         * same hash value.
         * @see https://www.php.net/manual/en/ds-hashable.hash.php
         * @link https://www.php.net/manual/en/ds-hashable.equals.php
         * @param object $obj The object to compare the current instance to,
         * which is always an instance of the same class.
         *
         * @return bool True if equal, false otherwise.
         */
        public function equals($obj): bool;

/**
*<div id="function.hash" class="refentry"> <div class="refnamediv">  <h1 class="refname">hash</h1>  <p class="verinfo">(PHP 5 &gt;= 5.1.2, PHP 7, PECL hash &gt;= 1.1)</p><p class="refpurpose"><span class="refname">hash</span> &mdash; <span class="dc-title">生成哈希值 （消息摘要）</span></p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.hash-description">  <h3 class="title">说明</h3>  <div class="methodsynopsis dc-description">   <span class="methodname" style="color:#CC7832"><strong>hash</strong></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$algo</span></span>   , <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#3A95FF">$data</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">bool</span> <span class="parameter" style="color:#3A95FF">$raw_output</span><span class="initializer"> = <strong><span>FALSE</span></strong></span></span>  ] ) : <span class="type" style="color:#EAB766">string</span></div> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.hash-parameters">  <h3 class="title">参数</h3>  <span>   <dl>         <dt><span class="parameter" style="color:#3A95FF">algo</span></dt>     <dd>      <p class="para">       要使用的哈希算法，例如：&quot;md5&quot;，&quot;sha256&quot;，&quot;haval160,4&quot; 等。       在 <span class="function">{@link hash_algos()}</span> 中查看支持的算法。      </p>     </dd>             <dt><span class="parameter" style="color:#3A95FF">data</span></dt>     <dd>      <p class="para">       要进行哈希运算的消息。      </p>     </dd>             <dt><span class="parameter" style="color:#3A95FF">raw_output</span></dt>     <dd>      <p class="para">       设置为 <strong><span>TRUE</span></strong> 输出原始二进制数据，       设置为 <strong><span>FALSE</span></strong> 输出小写 16 进制字符串。      </p>     </dd>       </dl>  </span> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.hash-returnvalues">  <h3 class="title">返回值</h3>  <p class="para">   如果 <span class="parameter" style="color:#3A95FF">raw_output</span> 设置为 <strong><span>TRUE</span></strong>， 则返回原始二进制数据表示的信息摘要，   否则返回 16 进制小写字符串格式表示的信息摘要。  </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.hash-examples">  <h3 class="title">范例</h3>  <span>   <div class="example" id="zlib-encode.example.basic">    <p><strong>Example #1 一个 <span class="function"><strong style="color:#CC7832">hash()</strong></span> 例程</strong></p>    <div class="example-contents"><div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"><span style="color: #9876AA">&lt;?php<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #9876AA">hash</span><span style="color: #007700">(</span><span style="color: #DD0000">'ripemd160'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'The&nbsp;quick&nbsp;brown&nbsp;fox&nbsp;jumped&nbsp;over&nbsp;the&nbsp;lazy&nbsp;dog.'</span><span style="color: #007700">);<br /></span><span style="color: #9876AA">?&gt;</span></span></span></div>    </div>    <div class="example-contents"><p>以上例程会输出：</p></div>    <div class="example-contents screen" style="color:AFB1B3;background:black;padding-left:5px;"><div class="cdata"><span>ec457d0a974c48d5685a7efa03d137dc8bbde7e3<br></span></div>    </div>   </div>  </span>  <p class="para">   <div class="example" id="random-bytes.example.basic">    <p><strong>Example #2 使用 PHP 5.4 或者更高版本计算 tiger 哈希值</strong></p>    <div class="example-contents"><div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"><span style="color: #9876AA">&lt;?php<br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #9876AA">old_tiger</span><span style="color: #007700">(</span><span style="color: #9876AA">$data&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">""</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">$width</span><span style="color: #007700">=</span><span style="color: #9876AA">192</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">$rounds&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">3</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #9876AA">substr</span><span style="color: #007700">(<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #9876AA">implode</span><span style="color: #007700">(<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #9876AA">array_map</span><span style="color: #007700">(<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;function&nbsp;(</span><span style="color: #9876AA">$h</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #9876AA">str_pad</span><span style="color: #007700">(</span><span style="color: #9876AA">bin2hex</span><span style="color: #007700">(</span><span style="color: #9876AA">strrev</span><span style="color: #007700">(</span><span style="color: #9876AA">$h</span><span style="color: #007700">)),&nbsp;</span><span style="color: #9876AA">16</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">"0"</span><span style="color: #007700">);<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;},<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #9876AA">str_split</span><span style="color: #007700">(</span><span style="color: #9876AA">hash</span><span style="color: #007700">(</span><span style="color: #DD0000">"tiger192,</span><span style="color: #9876AA">$rounds</span><span style="color: #DD0000">"</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">$data</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">true</span><span style="color: #007700">),&nbsp;</span><span style="color: #9876AA">8</span><span style="color: #007700">)<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;)<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;),<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #9876AA">0</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">48</span><span style="color: #007700">-(</span><span style="color: #9876AA">192</span><span style="color: #007700">-</span><span style="color: #9876AA">$width</span><span style="color: #007700">)/</span><span style="color: #9876AA">4<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">);<br />}<br />echo&nbsp;</span><span style="color: #9876AA">hash</span><span style="color: #007700">(</span><span style="color: #DD0000">'tiger192,3'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'a-string'</span><span style="color: #007700">),&nbsp;</span><span style="color: #9876AA">PHP_EOL</span><span style="color: #007700">;<br />echo&nbsp;</span><span style="color: #9876AA">old_tiger</span><span style="color: #007700">(</span><span style="color: #DD0000">'a-string'</span><span style="color: #007700">),&nbsp;</span><span style="color: #9876AA">PHP_EOL</span><span style="color: #007700">;<br /></span><span style="color: #9876AA">?&gt;</span></span></span></div>    </div>    <div class="example-contents"><p>以上例程在 PHP 5.3 中的输出：</p></div>    <div class="example-contents screen" style="color:AFB1B3;background:black;padding-left:5px;"><div class="cdata"><span>146a7492719b3564094efe7abbd40a7416fd900179d02773<br>64359b7192746a14740ad4bb7afe4e097327d0790190fd16<br></span></div>    </div>    <div class="example-contents"><p>以上例程在 PHP 5.4 中的输出：</p></div>    <div class="example-contents screen" style="color:AFB1B3;background:black;padding-left:5px;"><div class="cdata"><span>64359b7192746a14740ad4bb7afe4e097327d0790190fd16<br>146a7492719b3564094efe7abbd40a7416fd900179d02773<br></span></div>    </div>   </div>  </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.hash-seealso">  <h3 class="title">参见</h3>  <span>   <ul class="simplelist">    <li class="member"><span class="function">{@link hash_file()} - 使用给定文件的内容生成哈希值</span></li>    <li class="member"><span class="function">{@link hash_hmac()} - 使用 HMAC 方法生成带有密钥的哈希值</span></li>    <li class="member"><span class="function">{@link hash_init()} - 初始化增量哈希运算上下文</span></li>    <li class="member"><span class="function">{@link md5()} - 计算字符串的 MD5 散列值</span></li>    <li class="member"><span class="function">{@link sha1()} - 计算字符串的 sha1 散列值</span></li>   </ul>  </span> </div></div>
         * @return mixed A scalar value to be used as this object's hash value.*/
        public function hash();
    }

    /**
     * A Sequence describes the behaviour of values arranged in a single,
     * linear dimension. Some languages refer to this as a "List". It’s
     * similar to an array that uses incremental integer keys, with the
     * exception of a few characteristics:
     * <li>Values will always be indexed as [0, 1, 2, …, size - 1].
     * <li>Only allowed to access values by index in the range [0, size - 1].
     * <p><p>
     *  <p>Use cases:
     *
     * <li>Wherever you would use an array as a list (not concerned with keys).
     * <li>A more efficient alternative to SplDoublyLinkedList and SplFixedArray.
     * @package Ds
     */
    interface Sequence extends Collection
    {
        /**
         * Ensures that enough memory is allocated for a required capacity.
         * This removes the need to reallocate the internal as values are added.
         *
         * @param int $capacity The number of values for which capacity should
         * be allocated.<p>Note: Capacity will stay the same if this value is
         * less than or equal to the current capacity.
         * @link https://www.php.net/manual/en/ds-sequence.allocate.php
         */
        public function allocate(int $capacity): void;

        /**
         * Updates all values by applying a callback function to each value in
         * the sequence.
         * @param callable $callback A callable to apply to each value in the
         * sequence. The callback should return what the value should be
         * replaced by.<p>
         * <code>callback ( mixed $value ) : mixed</code>
         * @link https://www.php.net/manual/en/ds-sequence.apply.php
         */
        public function apply(callable $callback): void;

        /**
         * Returns the current capacity.
         * @return int The current capacity.
         * @link https://www.php.net/manual/en/ds-sequence.capacity.php
         */
        public function capacity(): int;

        /**
         * Determines if the sequence contains all values.
         * @param mixed $values Values to check.
         * @return bool FALSE if any of the provided values are not in the
         * sequence, TRUE otherwise.
         * @link https://www.php.net/manual/en/ds-sequence.contains.php
         */
        public function contains(...$values): bool;

        /**
         * Creates a new sequence using a callable to determine which values
         * to include.
         * @param callable $callback Optional callable which returns TRUE if the
         * value should be included, FALSE otherwise. If a callback is not
         * provided, only values which are TRUE (see converting to boolean) will
         * be included.<p>
         * <code>callback ( mixed $value ) : bool</code>
         * @return Sequence A new sequence containing all the values for which
         * either the callback returned TRUE, or all values that convert to
         * TRUE if a callback was not provided.
         * @link https://www.php.net/manual/en/ds-sequence.filter.php
         */
        public function filter(callable $callback = null);

        /**
         * Returns the index of the value, or FALSE if not found.
         * @param mixed $value The value to find.
         * @return int|bool The index of the value, or FALSE if not found.
         * @link https://www.php.net/manual/en/ds-sequence.find.php
         */
        public function find($value);

        /**
         * Returns the first value in the sequence.
         * @return mixed The first value in the sequence.
         * @throws UnderflowException if empty.
         * @link https://www.php.net/manual/en/ds-sequence.first.php
         */
        public function first();

        /**
         * Returns the value at a given index.
         * @param int $index The index to access, starting at 0.
         * @return mixed The value at the requested index.
         * @throws OutOfRangeException if the index is not valid.
         * @link https://www.php.net/manual/en/ds-sequence.get.php
         */
        public function get(int $index);

        /**
         * Inserts values into the sequence at a given index.
         *
         * @param int $index The index at which to insert. 0 <= index <= count
         * <p> Note: You can insert at the index equal to the number of values.
         * @param mixed ...$values The value or values to insert.
         * @throws OutOfRangeException if the index is not valid.
         * @link https://www.php.net/manual/en/ds-sequence.insert.php
         */
        public function insert(int $index, ...$values): void;

/**
*<div id="function.join" class="refentry"> <div class="refnamediv">  <h1 class="refname">join</h1>  <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">join</span> &mdash; <span class="dc-title">别名 <span class="function">{@link implode()}</span></span></p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.join-description">  <h3 class="title">说明</h3>  <p class="simpara">   此函数是该函数的别名：   <span class="function">{@link implode()}</span>.  </p> </div></div>
         * @return string All values of the sequence joined together as a*/
        public function join(string $glue = ''): string;

        /**
         * Returns the last value in the sequence.
         * @return mixed The last value in the sequence.
         * @throws UnderflowException if empty.
         * @link https://www.php.net/manual/en/ds-sequence.last.php
         */
        public function last();

        /**
         * Returns the result of applying a callback function to each value in
         * the sequence.
         * @param callable $callback A callable to apply to each value in the
         * sequence.
         * The callable should return what the new value will be in the new
         * sequence.
         * <code>callback ( mixed $value ) : mixed</code>
         * @return Sequence The result of applying a callback to each value in
         * the sequence.<p>Note: The values of the current instance won't be
         * affected.
         * @link https://www.php.net/manual/en/ds-sequence.map.php
         */
        public function map(callable $callback);

        /**
         * Returns the result of adding all given values to the sequence.
         * @param array|Traversable $values A traversable object or an array.
         * @return Sequence The result of adding all given values to the
         * sequence, effectively the same as adding the values to a copy,
         * then returning that copy.
         * @link https://www.php.net/manual/en/ds-sequence.merge.php
         */
        public function merge($values);

        /**
         * Removes and returns the last value.
         * @return mixed The removed last value.
         * @throws UnderflowException if empty.
         * @link https://www.php.net/manual/en/ds-sequence.pop.php
         */
        public function pop();

        /**
         * Adds values to the end of the sequence.
         * @param mixed ...$values The values to add.
         */
        public function push(...$values): void;

        /**
         * Reduces the sequence to a single value using a callback function.
         * @param callable $callback <p><p>
         * <code>
         * callback ( mixed $carry , mixed $value ) : mixed</code>
         * <b>$carry</b> The return value of the previous callback, or initial if it's
         * the first iteration.<p>
         * <b>$value</b> The value of the current iteration.
         * @param mixed $initial The initial value of the carry value. Can be NULL.
         * @return mixed The return value of the final callback.
         * @link https://www.php.net/manual/en/ds-sequence.reduce.php
         */
        public function reduce(callable $callback, $initial = null);

        /**
         * Removes and returns a value by index.
         * @param int $index The index of the value to remove.
         * @return mixed The value that was removed.
         * @link https://www.php.net/manual/en/ds-sequence.remove.php
         */
        public function remove(int $index);

        /**
         * Reverses the sequence in-place.
         * @link https://www.php.net/manual/en/ds-sequence.reverse.php
         */
        public function reverse(): void;

        /**
         * Returns a reversed copy of the sequence.
         * @return Sequence A reversed copy of the sequence.
         * <p>Note: The current instance is not affected.
         */
        public function reversed();

        /**
         * Rotates the sequence by a given number of rotations, which is
         * equivalent to successively calling
         * $sequence->push($sequence->shift()) if the number of rotations is
         * positive, or $sequence->unshift($sequence->pop()) if negative.
         * @param int $rotations The number of times the sequence should be
         * rotated.
         * @link https://www.php.net/manual/en/ds-sequence.rotate.php
         */
        public function rotate(int $rotations): void;

        /**
         * Updates a value at a given index.
         * @param int $index The index of the value to update.
         * @param mixed $value The new value.
         * @throws OutOfRangeException if the index is not valid.
         * @link https://www.php.net/manual/en/ds-sequence.set.php
         */
        public function set(int $index, $value): void;

        /**
         * Removes and returns the first value.
         * @return mixed
         * @throws UnderflowException if empty.
         * @link https://www.php.net/manual/en/ds-sequence.shift.php
         */
        public function shift();

        /**
         * Creates a sub-sequence of a given range.
         * @param int $index The index at which the sub-sequence starts.
         * If positive, the sequence will start at that index in the sequence.
         * If negative, the sequence will start that far from the end.
         * @param int|null $length If a length is given and is positive, the
         * resulting sequence will have up to that many values in it. If the
         * length results in an overflow, only values up to the end of the
         * sequence will be included. If a length is given and is negative,
         * the sequence will stop that many values from the end. If a length
         * is not provided, the resulting sequence will contain all values
         * between the index and the end of the sequence.
         * @return Sequence A sub-sequence of the given range.
         * @link https://www.php.net/manual/en/ds-sequence.slice.php
         */
        public function slice(int $index, int $length = null);

/**
*<div id="function.sort" class="refentry"> <div class="refnamediv">  <h1 class="refname">sort</h1>  <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">sort</span> &mdash; <span class="dc-title">对数组排序</span></p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.sort-description">  <h3 class="title">说明</h3>  <div class="methodsynopsis dc-description">   <span class="methodname" style="color:#CC7832"><strong>sort</strong></span>    ( <span class="methodparam"><span class="type" style="color:#EAB766">array</span> <span class="parameter" style="color:#3A95FF">&$array</span></span>   [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#3A95FF">$sort_flags</span><span class="initializer"> = SORT_REGULAR</span></span>  ] ) : <span class="type" style="color:#EAB766">bool</span></div>  <p class="para rdfs-comment">   本函数对数组进行排序。   当本函数结束时数组单元将被从最低到最高重新安排。  </p>  <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>:  <p class="para">  如果两个成员完全相同，那么它们在排序数组中的相对顺序是未定义的。 </p></p></blockquote> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.sort-parameters">  <h3 class="title">参数</h3>  <span>   <dl>         <dt><span class="parameter" style="color:#3A95FF">array</span></dt>     <dd>      <p class="para">       要排序的数组。      </p>     </dd>             <dt><span class="parameter" style="color:#3A95FF">sort_flags</span></dt>     <dd>      <p class="para">       可选的第二个参数 <span class="parameter" style="color:#3A95FF">sort_flags</span>   可以用以下值改变排序的行为：      </p>      <p class="para">       排序类型标记：       <ul class="itemizedlist">        <li class="listitem">         <span class="simpara"><strong><span>SORT_REGULAR</span></strong>  - 正常比较单元          详细描述参见 <a href="http://php.net/manual/zh/language.operators.comparison.php" class="link">比较运算符</a> 章节         </span>        </li>        <li class="listitem">         <span class="simpara"><strong><span>SORT_NUMERIC</span></strong> - 单元被作为数字来比较</span>        </li>        <li class="listitem">         <span class="simpara"><strong><span>SORT_STRING</span></strong> - 单元被作为字符串来比较</span>        </li>        <li class="listitem">         <span class="simpara"> <strong><span>SORT_LOCALE_STRING</span></strong> -      根据当前的区域（locale）设置来把单元当作字符串比较，可以用      <span class="function">{@link setlocale()}</span> 来改变。         </span>        </li>        <li class="listitem">         <span class="simpara"><strong><span>SORT_NATURAL</span></strong> - 和 <span class="function">{@link natsort()}</span> 类似对每个单元以“自然的顺序”对字符串进行排序。</span>        </li>        <li class="listitem">         <span class="simpara"><strong><span>SORT_FLAG_CASE</span></strong> - 能够与 <strong><span>SORT_STRING</span></strong> 或          <strong><span>SORT_NATURAL</span></strong>           合并（OR 位运算），不区分大小写排序字符串。</span>        </li>       </ul>      </p>     </dd>       </dl>  </span> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.sort-returnvalues">  <h3 class="title">返回值</h3>  <p class="para">   成功时返回 <strong><span>TRUE</span></strong>， 或者在失败时返回 <strong><span>FALSE</span></strong>。  </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.sort-examples">  <h3 class="title">范例</h3>  <span>   <div class="example" id="example-5316">    <p><strong>Example #1 <span class="function"><strong style="color:#CC7832">sort()</strong></span> 例子</strong></p>    <div class="example-contents"><div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"><span style="color: #9876AA">&lt;?php<br /><br />$fruits&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #DD0000">"lemon"</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">"orange"</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">"banana"</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">"apple"</span><span style="color: #007700">);<br /></span><span style="color: #9876AA">sort</span><span style="color: #007700">(</span><span style="color: #9876AA">$fruits</span><span style="color: #007700">);<br />foreach&nbsp;(</span><span style="color: #9876AA">$fruits&nbsp;</span><span style="color: #007700">as&nbsp;</span><span style="color: #9876AA">$key&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #9876AA">$val</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"fruits["&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #9876AA">$key&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #DD0000">"]&nbsp;=&nbsp;"&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #9876AA">$val&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br />}<br /><br /></span><span style="color: #9876AA">?&gt;</span></span></span></div>    </div>    <div class="example-contents"><p>以上例程会输出：</p></div>    <div class="example-contents screen" style="color:AFB1B3;background:black;padding-left:5px;"><div class="cdata"><span>fruits[0] = apple<br>fruits[1] = banana<br>fruits[2] = lemon<br>fruits[3] = orange<br></span></div>    </div>   </div>  </span>  <p class="para">   fruits 被按照字母顺序排序。  </p>  <p class="para">   <div class="example" id="example-5317">    <p><strong>Example #2 使用 <span class="function"><strong style="color:#CC7832">sort()</strong></span> 不区分大小写自然排序的例子</strong></p>    <div class="example-contents"><div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"><span style="color: #9876AA">&lt;?php<br /><br />$fruits&nbsp;</span><span style="color: #007700">=&nbsp;array(<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">"Orange1"</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">"orange2"</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">"Orange3"</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">"orange20"<br /></span><span style="color: #007700">);<br /></span><span style="color: #9876AA">sort</span><span style="color: #007700">(</span><span style="color: #9876AA">$fruits</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">SORT_NATURAL&nbsp;</span><span style="color: #007700">|&nbsp;</span><span style="color: #9876AA">SORT_FLAG_CASE</span><span style="color: #007700">);<br />foreach&nbsp;(</span><span style="color: #9876AA">$fruits&nbsp;</span><span style="color: #007700">as&nbsp;</span><span style="color: #9876AA">$key&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #9876AA">$val</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"fruits["&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #9876AA">$key&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #DD0000">"]&nbsp;=&nbsp;"&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #9876AA">$val&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br />}<br /><br /></span><span style="color: #9876AA">?&gt;</span></span></span></div>    </div>    <div class="example-contents"><p>以上例程会输出：</p></div>    <div class="example-contents screen" style="color:AFB1B3;background:black;padding-left:5px;"><div class="cdata"><span>fruits[0] = Orange1<br>fruits[1] = orange2<br>fruits[2] = Orange3<br>fruits[3] = orange20<br></span></div>    </div>   </div>  </p>  <p class="para">   fruits 排序得像 <span class="function">{@link natcasesort()}</span> 的结果。  </p> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 notes" id="refsect1-function.sort-notes">  <h3 class="title">注释</h3>  <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>: <span class="simpara">此函数为 <span class="parameter" style="color:#3A95FF">array</span>中的元素赋与新的键名。这将删除原有的键名，而不是仅仅将键名重新排序。</span></p></blockquote>  <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>:    <span class="simpara">    和大多数 PHP 排序函数一样，<span class="function"><strong style="color:#CC7832">sort()</strong></span>     使用了 <a href="http://en.wikipedia.org/wiki/Quicksort" class="link external">&raquo;&nbsp;Quicksort</a> 实现的。    The pivot is chosen in the middle of the partition resulting in an optimal    time for already sorted arrays. This is however an implementation detail you    shouldn&#039;t rely on.   </span>  </p></blockquote>  <div class="warning"><strong class="warning">Warning</strong>   <p class="simpara">    在对含有混合类型值的数组    以 <span class="parameter" style="color:#3A95FF">sort_flags</span> 为 <strong><span>SORT_REGULAR</span></strong> 排序时要小心，因为    <span class="function"><strong style="color:#CC7832">sort()</strong></span> 可能会产生不可预知的结果。   </p>  </div> </div> <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.sort-seealso">  <h3 class="title">参见</h3>  <span>   <ul class="simplelist">    <li class="member"><span class="function">{@link asort()} - 对数组进行排序并保持索引关系</span></li>    <li class="member"><span class="function">{@link rsort()} - 对数组逆向排序</span></li>    <li class="member"><a href="http://php.net/manual/zh/array.sorting.php" class="link">数组排序函数对比</a></li>   </ul>  </span> </div></div>
*/
        public function sort(callable $comparator = null): void;

        /**
         * Returns a sorted copy, using an optional comparator function.
         * @param callable|null $comparator The comparison function must return
         * an integer less than, equal to, or greater than zero if the first
         * argument is considered to be respectively less than, equal to, or
         * greater than the second. Note that before PHP 7.0.0 this integer had
         * to be in the range from -2147483648 to 2147483647.<p>
         * <code>callback ( mixed $a, mixed $b ) : int</code>
         * <p>Caution: Returning non-integer values from the comparison
         * function, such as float, will result in an internal cast to integer
         * of the callback's return value. So values such as 0.99 and 0.1 will
         * both be cast to an integer value of 0, which will compare such
         * values as equal.
         * @return Sequence Returns a sorted copy of the sequence.
         * @link https://www.php.net/manual/en/ds-sequence.sort.php
         */
        public function sorted(callable $comparator);

        /**
         * Returns the sum of all values in the sequence.
         * <p>Note: Arrays and objects are considered equal to zero when
         * calculating the sum.
         * @return float|int The sum of all the values in the sequence as
         * either a float or int depending on the values in the sequence.
         */
        public function sum(): float;

        /**
         * Adds values to the front of the sequence, moving all the current
         * values forward to make room for the new values.
         * @param mixed $values The values to add to the front of the sequence.
         * <p>Note: Multiple values will be added in the same order that they
         * are passed.
         */
        public function unshift($values): void;
    }


    /**
     * A Vector is a sequence of values in a contiguous buffer that grows and
     * shrinks automatically. It’s the most efficient sequential structure
     * because a value’s index is a direct mapping to its index in the buffer,
     * and the growth factor isn't bound to a specific multiple or exponent.
     * <p><p>
     * <h3>Strengths
     * <li>Supports array syntax (square brackets).
     * <li>Uses less overall memory than an array for the same number of values.
     * <li>Automatically frees allocated memory when its size drops low enough.
     * <li>Capacity does not have to be a power of 2.
     * <li>get(), set(), push(), pop() are all O(1).
     * <p>
     * <h3>Weaknesses
     * <li>shift(), unshift(), insert() and remove() are all O(n).
     *
     * @package Ds
     */
    class Vector implements Sequence
    {

        const MIN_CAPACITY = 10;

        /**
         * Ensures that enough memory is allocated for a required capacity.
         * This removes the need to reallocate the internal as values are added.
         * @param int $capacity The number of values for which capacity should
         * be allocated.
         * <p>Note: Capacity will stay the same if this value is less than or
         * equal to the current capacity.
         * @link https://www.php.net/manual/en/ds-vector.allocate.php
         */
        public function allocate(int $capacity): void
        {
        }

        /**
         * Updates all values by applying a callback function to each value in
         * the vector.
         * @param callable $callback
         * <code>callback ( mixed $value ) : mixed</code>
         * A callable to apply to each value in the vector. The callback should
         * return what the value should be replaced by.
         * @link https://www.php.net/manual/en/ds-vector.apply.php
         */
        public function apply(callable $callback): void
        {
        }

        /**
         * Returns the current capacity.
         * @return int The current capacity.
         * @link https://www.php.net/manual/en/ds-vector.capacity.php
         */
        public function capacity(): int
        {
        }

        /**
         * Removes all values from the vector.
         * @link https://www.php.net/manual/en/ds-vector.clear.php
         */
        public function clear(): void
        {
        }

        /**
         * Determines if the vector contains all values.
         * @param mixed ...$values Values to check.
         * @return bool FALSE if any of the provided values are not in the
         * vector, TRUE otherwise.
         * @link https://www.php.net/manual/en/ds-vector.contains.php
         */
        public function contains(...$values): bool
        {
        }

        /**
         *Returns a shallow copy of the vector.
         * @return Vector Returns a shallow copy of the vector.
         */
        public function copy(): Vector
        {
        }

        /**
         * Creates a new vector using a callable to determine which values to
         * include.
         *
         * @param callable $callback
         * Optional callable which returns TRUE if the value should be included,
         * FALSE otherwise. If a callback is not provided, only values which are
         * TRUE (see converting to boolean)  will be included.
         * <code>callback ( mixed $value ) : bool</code>
         * @return Vector A new vector containing all the values for which
         * either the callback returned TRUE, or all values that convert to
         * TRUE if a callback was not provided.
         * @link https://www.php.net/manual/en/ds-vector.filter.php
         */
        public function filter(callable $callback = null): Vector
        {
        }

        /**
         * Returns the index of the value, or FALSE if not found.
         * @param mixed $value The value to find.
         * @return mixed|bool The index of the value, or FALSE if not found.
         * <p>Note: Values will be compared by value and by type.
         * @link https://www.php.net/manual/en/ds-vector.find.php
         */
        public function find($value)
        {
        }

        /**
         * Returns the first value in the vector.
         * @return mixed
         * @throws UnderflowException if empty.
         * @link https://www.php.net/manual/en/ds-vector.first.php
         */
        public function first()
        {
        }

        /**
         * Returns the value at a given index.
         * @param int $index The index to access, starting at 0.
         * @return mixed
         * @link https://www.php.net/manual/en/ds-vector.get.php
         */
        public function get(int $index)
        {
        }

        /**
         * Inserts values into the sequence at a given index.
         *
         * @param int $index The index at which to insert. 0 <= index <= count
         * Note:<br>
         * You can insert at the index equal to the number of values.
         * @param array $values The value or values to insert.
         * @link https://www.php.net/manual/en/ds-vector.insert.php
         */
        public function insert(int $index, ...$values): void
        {
        }

        /**
         * Joins all values together as a string using an optional separator between each value.
         *
         * @param string|null $glue An optional string to separate each value.
         * @return string All values of the sequence joined together as a string.
         * @link https://www.php.net/manual/en/ds-vector.join.php
         */
        public function join(?string $glue = null): string
        {
        }

        /**
         * Returns the last value in the sequence.
         *
         * @return mixed The last value in the sequence.
         * @link https://www.php.net/manual/en/ds-vector.last.php
         */
        public function last()
        {
        }

        /**
         * Returns the result of applying a callback function to each value in the sequence.
         *
         * @param callable $callback A callable to apply to each value in the sequence.
         * <br>The callable should return what the new value will be in the new sequence.
         *
         * @return Vector
         * @link https://www.php.net/manual/en/ds-vector.map.php
         */
        public function map(callable $callback): Vector
        {
        }

        /**
         * Returns the result of adding all given values to the sequence.
         *
         * @param Traversable|array $values A traversable object or an array.
         * @return Vector The result of adding all given values to the sequence, effectively the same as adding the
         * values to a copy, then returning that copy.<br>
         * Note:<br>
         * The current instance won't be affected.
         * @link https://www.php.net/manual/en/ds-vector.merge.php
         */
        public function merge($values): Vector
        {
        }

        /**
         * Removes and returns the last value.
         *
         * @return mixed
         * @link https://www.php.net/manual/en/ds-vector.pop.php
         */
        public function pop()
        {
        }

        /**
         * Adds values to the end of the sequence.
         * @param array $values
         * @link https://www.php.net/manual/en/ds-vector.push.php
         */
        public function push(...$values): void
        {
        }

        /**
         * Reduces the sequence to a single value using a callback function.
         * @param callable $callback <br>
         * <code>callback ( mixed $carry , mixed $value ) : mixed</code><br>
         * <b>carry</b> The return value of the previous callback, or initial if it's the first iteration.<br>
         * <b>value</b> The value of the current iteration.
         * @param mixed $initial The initial value of the carry value. Can be NULL.
         *
         * @return mixed|void The return value of the final callback.
         *
         * @link https://www.php.net/manual/en/ds-vector.reduce.php
         */
        public function reduce(callable $callback, $initial = null)
        {
        }

        /**
         * Removes and returns a value by index.
         * @param int $index The index of the value to remove.
         * @return mixed The value that was removed.
         * @link https://www.php.net/manual/en/ds-vector.remove.php
         */
        public function remove(int $index)
        {
        }

        /**
         * Reverses the sequence in-place.
         * @link https://www.php.net/manual/en/ds-vector.reverse.php
         */
        public function reverse(): void
        {
        }

        /**
         * Returns a reversed copy of the sequence.
         * @return Vector A reversed copy of the sequence.<br>
         * Note: The current instance is not affected.
         * @link https://www.php.net/manual/en/ds-vector.reversed.php
         */
        public function reversed(): Vector
        {
        }

        /**
         * Rotates the sequence by a given number of rotations, which is
         * equivalent to successively calling $sequence->push($sequence->shift())
         * if the number of rotations is positive, or $sequence->unshift($sequence->pop())
         * if negative.
         *
         * @link https://www.php.net/manual/en/ds-vector.rotate.php
         *
         * @param int $rotations The number of times the sequence should be rotated.
         */
        public function rotate(int $rotations): void
        {
        }

        /**
         * Updates a value at a given index.
         *
         * @link https://www.php.net/manual/en/ds-vector.set.php
         *
         * @param int $index The index of the value to update.
         * @param mixed $value The new value.
         *
         * @throws OutOfRangeException if the index is not valid.
         */
        public function set(int $index, $value): void
        {
        }

        /**
         * Removes and returns the first value.
         *
         * @link https://www.php.net/manual/en/ds-vector.shift.php
         *
         * @return mixed The first value, which was removed.
         * @throws UnderflowException if empty.
         */
        public function shift()
        {
        }

        /**
         * Creates a sub-sequence of a given range.
         * @link https://www.php.net/manual/en/ds-vector.slice.php
         * @param int $index The index at which the sub-sequence starts. If
         * positive, the sequence will start at that
         * index in the sequence. If negative, the sequence will start that
         * far from the end.
         * @param int|null $length If a length is given and is positive, the
         * resulting sequence will have up to that many values in it. If the
         * length results in an overflow, only values up to the end of the
         * sequence will be included. If a length is given and is negative,
         * the sequence will stop that many values from the end. If a length
         * is not provided, the resulting sequence will contain all values
         * between the index and the end of the sequence.
         * @return Vector
         */
        public function slice(int $index, int $length = null): Vector
        {
        }

        /**
         * Sorts the sequence in-place, using an optional comparator function.
         * @link https://www.php.net/manual/en/ds-vector.sort.php
         * @param callable $comparator The comparison function must return an
         * integer less than, equal to, or greater
         * than zero if the first argument is considered to be respectively less than, equal to, or greater than the
         * second. Note that before PHP 7.0.0 this integer had to be in the
         * range from -2147483648 to 2147483647.<br>
         * <code>callback ( mixed $a, mixed $b ) : int</code>
         * Caution: Returning non-integer values from the comparison function,
         * such as float, will result in an
         * internal cast to integer of the callback's return value. So values
         * such as 0.99 and 0.1 will both be cast to an integer value of 0,
         * which will compare such values as equal.
         */
        public function sort(callable $comparator = null): void
        {
        }

        /**
         * Returns a sorted copy, using an optional comparator function.
         * @link https://www.php.net/manual/en/ds-vector.sorted.php
         * @param callable $comparator The comparison function must return an integer less than, equal to, or greater
         * than zero if the first argument is considered to be respectively less than, equal to, or greater than the
         * second. Note that before PHP 7.0.0 this integer had to be in the range from -2147483648 to 2147483647.<br>
         * <code>callback ( mixed $a, mixed $b ) : int</code>
         * Caution: Returning non-integer values from the comparison function, such as float, will result in an
         * internal cast to integer of the callback's return value. So values such as 0.99 and 0.1 will both be cast to an integer value of 0, which will compare such values as equal.
         * @return Vector Returns a sorted copy of the sequence.
         */
        public function sorted(callable $comparator): Vector
        {
        }

        /**
         * Returns the sum of all values in the sequence.<br>
         * Note: Arrays and objects are considered equal to zero when
         * calculating the sum.
         * @link https://www.php.net/manual/en/ds-vector.sum.php
         * @return float
         */
        public function sum(): float
        {
        }

        /**
         * Adds values to the front of the sequence, moving all the current
         * values forward to make room for the new values.
         * @param mixed $values The values to add to the front of the sequence.<br>
         * Note: Multiple values will be added in the same order that they are
         * passed
         * @link https://www.php.net/manual/en/ds-vector.unshift.php
         */
        public function unshift($values): void
        {
        }

        /**
         * Count elements of an object
         * @link https://php.net/manual/en/ds-vector.count.php
         * @return int The custom count as an integer.
         * </p>
         * <p>
         * The return value is cast to an integer.
         * @since 5.1
         */
        public function count(): int
        {
        }

        /**
         * Returns whether the collection is empty.
         * @link https://www.php.net/manual/en/ds-vector.isempty.php
         * @return bool
         */
        public function isEmpty(): bool
        {
        }

        /**
         * Converts the collection to an array.
         * <p>Note: Casting to an array is not supported yet.
         * @link https://www.php.net/manual/en/ds-vector.toarray.php
         * @return array An array containing all the values in the same order as
         * the collection.
         */
        public function toArray(): array
        {
        }

        /**
         * Specify data which should be serialized to JSON
         * @link https://php.net/manual/en/ds-vector.jsonserialize.php
         * @return mixed data which can be serialized by <b>json_encode</b>,
         * which is a value of any type other than a resource.
         * @since 5.4
         */
        public function jsonSerialize()
        {
        }
    }

    class Deque implements Sequence
    {
        /**
         * Count elements of an object
         * @link https://php.net/manual/en/countable.count.php
         * @return int The custom count as an integer.
         * </p>
         * <p>
         * The return value is cast to an integer.
         * @since 5.1
         */
        public function count(): int
        {
        }

        /**
         * Removes all values from the deque.
         * @link https://www.php.net/manual/en/ds-deque.clear.php
         */
        public function clear(): void
        {
        }

        /**
         * Returns a shallow copy of the deque.
         * @link https://www.php.net/manual/en/ds-deque.copy.php
         * @return Collection
         */
        public function copy(): Collection
        {
        }

        /**
         * Returns whether the deque is empty.
         * @link https://www.php.net/manual/en/ds-deque.isempty.php
         * @return bool
         */
        public function isEmpty(): bool
        {
        }

        /**
         * Converts the deque to an array.
         * <p>Note: Casting to an array is not supported yet.
         * @link https://www.php.net/manual/en/ds-deque.toarray.php
         * @return array An array containing all the values in the same order as
         * the deque.
         */
        public function toArray(): array
        {
        }

        /**
         * Ensures that enough memory is allocated for a required capacity.
         * This removes the need to reallocate the internal as values are added.
         *
         * @param int $capacity The number of values for which capacity should
         * be allocated.<p>Note: Capacity will stay the same if this value is
         * less than or equal to the current capacity.
         * <p>Note: Capacity will always be rounded up to the nearest power of 2.
         * @link https://www.php.net/manual/en/ds-deque.allocate.php
         */
        public function allocate(int $capacity): void
        {
        }

        /**
         * Updates all values by applying a callback function to each value in
         * the deque.
         * @param callable $callback A callable to apply to each value in the
         * deque. The callback should return what the value should be
         * replaced by.<p>
         * <code>callback ( mixed $value ) : mixed</code>
         * @link https://www.php.net/manual/en/ds-deque.apply.php
         */
        public function apply(callable $callback): void
        {
        }

        /**
         * Returns the current capacity.
         * @return int The current capacity.
         * @link https://www.php.net/manual/en/ds-deque.capacity.php
         */
        public function capacity(): int
        {
        }

        /**
         * Determines if the deque contains all values.
         * @param mixed $values Values to check.
         * @return bool FALSE if any of the provided values are not in the
         * deque, TRUE otherwise.
         * @link https://www.php.net/manual/en/ds-deque.contains.php
         */
        public function contains(...$values): bool
        {
        }

        /**
         * Creates a new deque using a callable to determine which values
         * to include.
         * @param callable $callback Optional callable which returns TRUE if the
         * value should be included, FALSE otherwise. If a callback is not
         * provided, only values which are TRUE (see converting to boolean) will
         * be included.<p>
         * <code>callback ( mixed $value ) : bool</code>
         * @return Deque A new deque containing all the values for which
         * either the callback returned TRUE, or all values that convert to
         * TRUE if a callback was not provided.
         * @link https://www.php.net/manual/en/ds-deque.filter.php
         */
        public function filter(callable $callback = null): Deque
        {
        }

        /**
         * Returns the index of the value, or FALSE if not found.
         * @param mixed $value The value to find.
         * @return int|bool The index of the value, or FALSE if not found.
         * @link https://www.php.net/manual/en/ds-deque.find.php
         */
        public function find($value)
        {
        }

        /**
         * Returns the first value in the deque.
         * @return mixed The first value in the deque.
         * @throws UnderflowException if empty.
         * @link https://www.php.net/manual/en/ds-deque.first.php
         */
        public function first()
        {
        }

        /**
         * Returns the value at a given index.
         * @param int $index The index to access, starting at 0.
         * @return mixed The value at the requested index.
         * @throws OutOfRangeException if the index is not valid.
         * @link https://www.php.net/manual/en/ds-deque.get.php
         */
        public function get(int $index)
        {
        }

        /**
         * Inserts values into the deque at a given index.
         *
         * @param int $index The index at which to insert. 0 <= index <= count
         * <p> Note: You can insert at the index equal to the number of values.
         * @param mixed ...$values The value or values to insert.
         * @throws OutOfRangeException if the index is not valid.
         * @link https://www.php.net/manual/en/ds-deque.insert.php
         */
        public function insert(int $index, ...$values): void
        {
        }

        /**
         * Joins all values together as a string using an optional separator
         * between each value.
         * @param string $glue An optional string to separate each value.
         * @return string All values of the deque joined together as a
         * string.
         * @link https://www.php.net/manual/en/ds-deque.join.php
         */
        public function join(string $glue = ''): string
        {
        }

        /**
         * Returns the last value in the deque.
         * @return mixed The last value in the deque.
         * @throws UnderflowException if empty.
         * @link https://www.php.net/manual/en/ds-deque.last.php
         */
        public function last()
        {
        }

        /**
         * Returns the result of applying a callback function to each value in
         * the deque.
         * @param callable $callback A callable to apply to each value in the
         * deque.
         * The callable should return what the new value will be in the new
         * deque.
         * <code>callback ( mixed $value ) : mixed</code>
         * @return Deque The result of applying a callback to each value in
         * the deque.<p>Note: The values of the current instance won't be
         * affected.
         * @link https://www.php.net/manual/en/ds-deque.map.php
         */
        public function map(callable $callback): Deque
        {
        }

        /**
         * Returns the result of adding all given values to the deque.
         * @param array|Traversable $values A traversable object or an array.
         * @return Deque The result of adding all given values to the
         * deque, effectively the same as adding the values to a copy,
         * then returning that copy.
         * @link https://www.php.net/manual/en/ds-deque.merge.php
         */
        public function merge($values): Deque
        {
        }

        /**
         * Removes and returns the last value.
         * @return mixed The removed last value.
         * @throws UnderflowException if empty.
         * @link https://www.php.net/manual/en/ds-deque.pop.php
         */
        public function pop()
        {
        }

        /**
         * Adds values to the end of the deque.
         * @param mixed ...$values The values to add.
         */
        public function push(...$values): void
        {
        }

        /**
         * Reduces the deque to a single value using a callback function.
         * @param callable $callback <p><p>
         * <code>
         * callback ( mixed $carry , mixed $value ) : mixed</code>
         * <b>$carry</b> The return value of the previous callback, or initial if it's
         * the first iteration.<p>
         * <b>$value</b> The value of the current iteration.
         * @param mixed $initial The initial value of the carry value. Can be NULL.
         * @return mixed The return value of the final callback.
         * @link https://www.php.net/manual/en/ds-deque.reduce.php
         */
        public function reduce(callable $callback, $initial = null)
        {
        }

        /**
         * Removes and returns a value by index.
         * @param int $index The index of the value to remove.
         * @return mixed The value that was removed.
         * @link https://www.php.net/manual/en/ds-deque.remove.php
         */
        public function remove(int $index)
        {
        }

        /**
         * Reverses the deque in-place.
         * @link https://www.php.net/manual/en/ds-deque.reverse.php
         */
        public function reverse(): void
        {
        }

        /**
         * Returns a reversed copy of the deque.
         * @return Deque A reversed copy of the deque.
         * <p>Note: The current instance is not affected.
         */
        public function reversed(): Deque
        {
        }

        /**
         * Rotates the deque by a given number of rotations, which is
         * equivalent to successively calling
         * $deque->push($deque->shift()) if the number of rotations is
         * positive, or $deque->unshift($deque->pop()) if negative.
         * @param int $rotations The number of times the deque should be
         * rotated.
         * @link https://www.php.net/manual/en/ds-deque.rotate.php
         */
        public function rotate(int $rotations): void
        {
        }

        /**
         * Updates a value at a given index.
         * @param int $index The index of the value to update.
         * @param mixed $value The new value.
         * @throws OutOfRangeException if the index is not valid.
         * @link https://www.php.net/manual/en/ds-deque.set.php
         */
        public function set(int $index, $value): void
        {
        }

        /**
         * Removes and returns the first value.
         * @return mixed
         * @throws UnderflowException if empty.
         * @link https://www.php.net/manual/en/ds-deque.shift.php
         */
        public function shift()
        {
        }

        /**
         * Creates a sub-deque of a given range.
         * @param int $index The index at which the sub-deque starts.
         * If positive, the deque will start at that index in the deque.
         * If negative, the deque will start that far from the end.
         * @param int|null $length If a length is given and is positive, the
         * resulting deque will have up to that many values in it. If the
         * length results in an overflow, only values up to the end of the
         * deque will be included. If a length is given and is negative,
         * the deque will stop that many values from the end. If a length
         * is not provided, the resulting deque will contain all values
         * between the index and the end of the deque.
         * @return Deque A sub-deque of the given range.
         * @link https://www.php.net/manual/en/ds-deque.slice.php
         */
        public function slice(int $index, int $length = null): Deque
        {
        }

        /**
         * Sorts the deque in-place, using an optional comparator function.
         * @param callable|null $comparator The comparison function must return
         * an integer less than, equal to, or greater than zero if the first
         * argument is considered to be respectively less than, equal to, or
         * greater than the second. Note that before PHP 7.0.0 this integer had
         * to be in the range from -2147483648 to 2147483647.<p>
         * <code>callback ( mixed $a, mixed $b ) : int</code>
         * <p>Caution: Returning non-integer values from the comparison
         * function, such as float, will result in an internal cast to integer
         * of the callback's return value. So values such as 0.99 and 0.1 will
         * both be cast to an integer value of 0, which will compare such
         * values as equal.
         * @link https://www.php.net/manual/en/ds-deque.sort.php
         */
        public function sort(callable $comparator = null): void
        {
        }

        /**
         * Returns a sorted copy, using an optional comparator function.
         * @param callable|null $comparator The comparison function must return
         * an integer less than, equal to, or greater than zero if the first
         * argument is considered to be respectively less than, equal to, or
         * greater than the second. Note that before PHP 7.0.0 this integer had
         * to be in the range from -2147483648 to 2147483647.<p>
         * <code>callback ( mixed $a, mixed $b ) : int</code>
         * <p>Caution: Returning non-integer values from the comparison
         * function, such as float, will result in an internal cast to integer
         * of the callback's return value. So values such as 0.99 and 0.1 will
         * both be cast to an integer value of 0, which will compare such
         * values as equal.
         * @return Deque Returns a sorted copy of the deque.
         * @link https://www.php.net/manual/en/ds-deque.sort.php
         */
        public function sorted(callable $comparator): Deque
        {
        }

        /**
         * Returns the sum of all values in the deque.
         * <p>Note: Arrays and objects are considered equal to zero when
         * calculating the sum.
         * @return float|int The sum of all the values in the deque as
         * either a float or int depending on the values in the deque.
         */
        public function sum(): float
        {
        }

        /**
         * Adds values to the front of the deque, moving all the current
         * values forward to make room for the new values.
         * @param mixed $values The values to add to the front of the deque.
         * <p>Note: Multiple values will be added in the same order that they
         * are passed.
         */
        public function unshift($values): void
        {
        }

        /**
         * Specify data which should be serialized to JSON
         * @link https://php.net/manual/en/ds-vector.jsonserialize.php
         * @return mixed data which can be serialized by <b>json_encode</b>,
         * which is a value of any type other than a resource.
         * @since 5.4
         */
        public function jsonSerialize()
        {
        }


    }

    class Map implements Collection
    {
        /**
         * Count elements of an object
         * @link https://php.net/manual/en/countable.count.php
         * @return int The custom count as an integer.
         * </p>
         * <p>
         * The return value is cast to an integer.
         * @since 5.1
         */
        public function count(): int
        {
        }

        /**
         * Removes all values from the collection.
         * @link https://www.php.net/manual/en/ds-collection.clear.php
         */
        public function clear(): void
        {
        }

        /**
         * Returns a shallow copy of the collection.
         * @link https://www.php.net/manual/en/ds-collection.copy.php
         * @return Collection
         */
        public function copy(): Collection
        {
        }

        /**
         * Returns whether the collection is empty.
         * @link https://www.php.net/manual/en/ds-collection.isempty.php
         * @return bool
         */
        public function isEmpty(): bool
        {
        }

        /**
         * Converts the map to an array.
         * <p>Note: Casting to an array is not supported yet.
         * <p>Caution: Maps where non-scalar keys are can't be converted to an
         * array.
         * <p>Caution: An array will treat all numeric keys as integers, eg.
         * "1" and 1 as keys in the map will only result in 1 being included in
         * the array.
         * @link https://www.php.net/manual/en/ds-map.toarray.php
         * @return array An array containing all the values in the same order as
         * the map.
         */
        public function toArray(): array
        {
        }

        /**
         * Specify data which should be serialized to JSON
         * @link https://php.net/manual/en/jsonserializable.jsonserialize.php
         * @return mixed data which can be serialized by <b>json_encode</b>,
         * which is a value of any type other than a resource.
         * @since 5.4
         */
        public function jsonSerialize()
        {
        }

        /**
         * Returns a set containing all the keys of the map, in the same order.
         * @link https://www.php.net/manual/en/ds-map.keys.php
         * @return Set A Ds\Set containing all the keys of the map.
         */
        public function keys(): Set
        {
        }

        /**
         * Sorts the map in-place by key, using an optional comparator function.
         * @param callable|null $comparator The comparison function must return
         * an integer less than, equal to, or greater than zero if the first
         * argument is considered to be respectively less than, equal to, or
         * greater than the second. Note that before PHP 7.0.0 this integer had
         * to be in the range from -2147483648 to  2147483647.
         * <code>callback ( mixed $a, mixed $b ) : int</code>
         * <p>Caution: Returning non-integer values from the comparison function, such
         * as float, will result in an internal cast to integer of the
         * callback's return value. So values such as 0.99 and 0.1 will both be
         * cast to an  integer value of 0, which will compare such values as
         * equal.</p>
         * @link https://www.php.net/manual/en/ds-map.ksort.php
         */
        public function ksort(?callable $comparator = null)
        {
        }

        /**
         * Returns a copy sorted by key, using an optional comparator function.
         * @param callable|null $comparator The comparison function must return
         * an integer less than, equal to, or greater than zero if the first
         * argument is considered to be respectively less than, equal to, or
         * greater than the second. Note that before PHP 7.0.0 this integer had
         * to be in the range from -2147483648 to 2147483647.
         * <code>callback ( mixed $a, mixed $b ) : int</code>
         * <p>Caution: Returning non-integer values from the comparison function, such
         * as float, will result in an internal cast to integer of the
         * callback's return value. So values such as 0.99 and 0.1 will both be
         * cast to an  integer value of 0, which will compare such values as
         * equal.</p>
         * @return Map Returns a copy of the map, sorted by key.
         * @link https://www.php.net/manual/en/ds-map.ksorted.php
         */
        public function ksorted(callable $comparator = null): Map
        {
        }

        /**
         * Returns the last pair of the map.
         * @return Pair The last pair of the map.
         * @throws UnderflowException if empty
         * @link https://www.php.net/manual/en/ds-map.last.php
         */
        public function last(): Pair
        {
        }

        /**
         * Returns the result of applying a callback function to each value of
         * the map.
         * @param callable $callback A callable to apply to each value in the
         * map. The callable should return what the key will be mapped to in the
         * resulting map.
         * <code>callback ( mixed $key , mixed $value ) : mixed</code>
         * @return Map The result of applying a callback to each value in the
         * map.
         *
         * Note: The keys and values of the current instance won't be affected.
         *
         * @link https://www.php.net/manual/en/ds-map.map.php
         */
        public function map(callable $callback): Map
        {
        }

        /**
         * Returns the result of associating all keys of a given traversable
         * object or array with their corresponding values, combined with the
         * current instance.
         * @param array|Traversable $values A traversable object or an array.
         * @return Map The result of associating all keys of a given traversable
         * object or array with their corresponding values, combined with the
         * current instance.
         *
         * Note: The current instance won't be affected.
         *
         * @link https://www.php.net/manual/en/ds-map.merge.php
         */
        public function merge($values): Map
        {
        }

        /**
         * Returns a Ds\Sequence containing all the pairs of the map.
         *
         * @return Sequence Ds\Sequence containing all the pairs of the map.
         *
         * @link https://www.php.net/manual/en/ds-map.pairs.php
         */
        public function pairs(): Sequence
        {
        }

        /**
         * Associates a key with a value, overwriting a previous association if
         * one exists.
         * @param mixed $key The key to associate the value with.
         * @param mixed $value The value to be associated with the key.
         *
         * Note: Keys of type object are supported. If an object implements
         * Ds\Hashable, equality will be determined by the object's equals
         * function. If an object does not implement Ds\Hashable, objects must
         * be references to the same instance to be considered equal.
         *
         * Note: You can also use array syntax to associate values by key, eg.
         * $map["key"] = $value.
         *
         * Caution: Be careful when using array syntax. Scalar keys will be
         * coerced to integers by the engine. For example, $map["1"] will
         * attempt to access int(1), while $map->get("1") will correctly look up
         * the string key.
         *
         * @link https://www.php.net/manual/en/ds-map.put.php
         */
        public function put($key, $value)
        {
        }

        /**
         * Associates all key-value pairs of a traversable object or array.
         *
         * Note: Keys of type object are supported. If an object implements
         * Ds\Hashable, equality will be determined
         * by the object's equals function. If an object does not implement
         * Ds\Hashable, objects must be references to the same instance to be
         * considered equal.
         *
         * @param array|Traversable $pairs traversable object or array.
         *
         * @link https://www.php.net/manual/en/ds-map.putall.php
         */
        public function putAll($pairs)
        {
        }

        /**
         * Reduces the map to a single value using a callback function.
         *
         * @param callable $callback
         * <code>callback ( mixed $carry , mixed $key , mixed $value ) : mixed</code>
         * <b>carry</b> The return value of the previous callback, or initial if
         * it's the first iteration.
         * <b>key</b> The key of the current iteration.
         * <b>value</b> The value of the current iteration.
         *
         * @param mixed $initial The initial value of the carry value. Can be
         * NULL.
         *
         * @link https://www.php.net/manual/en/ds-map.reduce.php
         */
        public function reduce(callable $callback, $initial)
        {
        }

        /**
         * Removes and returns a value by key, or return an optional default
         * value if the key could not be found.
         *
         * @param mixed $key The key to remove.
         * @param mixed $default The optional default value, returned if the key
         * could not be found.
         *
         * Note: Keys of type object are supported. If an object implements
         * Ds\Hashable, equality will be determined
         * by the object's equals function. If an object does not implement
         * Ds\Hashable, objects must be references to the same instance to be
         * considered equal.
         *
         * Note: You can also use array syntax to access values by key, eg.
         * $map["key"].
         *
         * Caution: Be careful when using array syntax. Scalar keys will be
         * coerced to integers by the engine. For example, $map["1"] will
         * attempt to access int(1), while $map->get("1") will correctly look up
         * the string key.
         *
         * @return mixed The value that was removed, or the default value if
         * provided and the key could not be found in the map.
         *
         * @throws OutOfBoundsException if the key could not be found and a
         * default value was not provided.
         *
         * @link https://www.php.net/manual/en/ds-map.remove.php
         */
        public function remove($key, $default)
        {
        }

        /**
         * Reverses the map in-place.
         *
         * @link https://www.php.net/manual/en/ds-map.reverse.php
         */
        public function reverse()
        {
        }

        /**
         * Returns a reversed copy of the map.
         *
         * @return Map A reversed copy of the map.
         *
         * <p>Note: The current instance is not affected.</p>
         *
         * @link https://www.php.net/manual/en/ds-map.reversed.php
         */
        public function reversed(): Map
        {
        }

        /**
         * Returns the pair at a given zero-based position.
         *
         * @param int $position The zero-based positional index to return.
         *
         * @return Pair Returns the Ds\Pair at the given position.
         *
         * @throws OutOfRangeException if the position is not valid.
         *
         * @link https://www.php.net/manual/en/ds-map.skip.php
         */
        public function skip(int $position): Pair
        {
        }

        /**
         * Returns a subset of the map defined by a starting index and length.
         *
         * @param int $index The index at which the range starts. If positive,
         * the range will start at that index in the map. If negative, the range
         * will start that far from the end.
         *
         * @param int|null $length If a length is given and is positive, the
         * resulting map will have up to that many pairs in it. If a length is
         * given and is negative, the range will stop that many pairs from the
         * end. If the length results in an overflow, only pairs up to the end
         * of the map will be included. If a length is not provided, the
         * resulting map will contain all pairs between the index and the end of
         * the map.
         *
         * @return Map A subset of the map defined by a starting index and
         * length.
         *
         * @link https://www.php.net/manual/en/ds-map.slice.php
         */
        public function slice(int $index, ?int $length = null): Map
        {
        }

        /**
         * Sorts the map in-place by value, using an optional comparator
         * function.
         *
         * @param callable|null $comparator The comparison function must return
         * an integer less than, equal to, or greater than zero if the first
         * argument is considered to be respectively less than, equal to, or
         * greater than the second. Note that before PHP 7.0.0 this integer had
         * to be in the range from -2147483648 to 2147483647.
         *
         * <code>callback ( mixed $a, mixed $b ) : int</code>
         *
         * Caution: Returning non-integer values from the comparison function,
         * such as float, will result in an internal cast to integer of the
         * callback's return value. So values such as 0.99 and 0.1 will both be
         * cast to an integer value of 0, which will compare such values as
         * equal.
         *
         * @link https://www.php.net/manual/en/ds-map.sort.php
         */
        public function sort(?callable $comparator = null)
        {
        }

        /**
         * Returns a copy, sorted by value using an optional comparator function.
         *
         * @param callable|null $comparator The comparison function must return
         * an integer less than, equal to, or greater than zero if the first
         * argument is considered to be respectively less than, equal to, or
         * greater than the second. Note that before PHP 7.0.0 this integer had
         * to be in the range from -2147483648 to 2147483647.
         *
         * <code>callback ( mixed $a, mixed $b ) : int</code>
         *
         * Caution: Returning non-integer values from the comparison function,
         * such as float, will result in an internal cast to integer of the
         * callback's return value. So values such as 0.99 and 0.1 will both be
         * cast to an integer value of 0, which will compare such values as
         * equal.
         *
         * @return Map
         *
         * @link https://www.php.net/manual/en/ds-map.sorted.php
         */
        public function sorted(?callable $comparator = null): Map
        {
        }

        /**
         * Returns the sum of all values in the map.
         *
         * Note: Arrays and objects are considered equal to zero when
         * calculating the sum.
         *
         * @return float|int The sum of all the values in the map as either a
         * float or int depending on the values in the map.
         *
         * @link https://www.php.net/manual/en/ds-map.sum.php
         */
        public function sum()
        {
        }

        /**
         * Creates a new map using values from the current instance and another
         * map.
         *
         * A ∪ B = {x: x ∈ A ∨ x ∈ B}
         *
         * <p>Note: Values of the current instance will be overwritten by those
         * provided where keys are equal.
         *
         * @param Map $map The other map, to combine with the current instance.
         *
         * @return Map A new map containing all the pairs of the current
         * instance as well as another map.
         *
         * @link https://www.php.net/manual/en/ds-map.union.php
         */
        public function union(Map $map): Map
        {
        }

        /**
         * Returns a sequence containing all the values of the map, in the same
         * order.
         *
         * @return Sequence A Ds\Sequence containing all the values of the map.
         *
         * @link https://www.php.net/manual/en/ds-map.values.php
         */
        public function values(): Sequence
        {
        }

        /**
         * Creates a new map containing keys of the current instance as well as
         * another map, but not of both.
         *
         * A ⊖ B = {x : x ∈ (A \ B) ∪ (B \ A)}
         *
         * @param Map $map The other map.
         *
         * @return Map A new map containing keys in the current instance as well
         * as another map, but not in both.
         *
         * @link https://www.php.net/manual/en/ds-map.xor.php
         */
        public function xor(Map $map): Map
        {
        }
    }

    /**
     * A pair is used by Ds\Map to pair keys with values.
     * @package Ds
     */
    class Pair implements JsonSerializable
    {
        /**
         * Creates a new instance using a given key and value.
         *
         * @param mixed $key
         * @param mixed $value
         *
         * @link https://php.net/manual/en/ds-pair.construct.php
         */
        public function __construct($key = null, $value = null)
        {
        }

        /**
         * Removes all values from the pair.
         *
         * @link https://php.net/manual/en/ds-pair.clear.php
         */
        public function clear()
        {
        }

        /**
         * Returns a shallow copy of the pair.
         *
         * @return Pair Returns a shallow copy of the pair.
         *
         * @link https://php.net/manual/en/ds-pair.copy.php
         */
        public function copy(): Pair
        {
        }

        /**
         * Returns whether the pair is empty.
         *
         * @return bool Returns TRUE if the pair is empty, FALSE otherwise.
         *
         * @link https://php.net/manual/en/ds-pair.isempty.php
         */
        public function isEmpty(): bool
        {
        }

        /**
         * Converts the pair to an array.
         *
         * <p>Note: Casting to an array is not supported yet.
         *
         * @return array An array containing all the values in the same order as
         * the pair.
         *
         * @link https://php.net/manual/en/ds-pair.toarray.php
         */
        public function toArray(): array
        {
        }

        /**
         * Specify data which should be serialized to JSON
         * @link https://php.net/manual/en/ds-pair.jsonserialize.php
         * @return mixed data which can be serialized by <b>json_encode</b>,
         * which is a value of any type other than a resource.
         */
        public function jsonSerialize()
        {
        }

    }

    /**
     * A Set is a sequence of unique values. This implementation uses the same
     * hash table as Ds\Map, where values are used as keys and the mapped value
     * is ignored.
     *
     * @link https://www.php.net/manual/en/class.ds-set.php
     *
     * @package Ds
     */
    class Set implements Collection
    {
        /**
         * Creates a new instance, using either a traversable object or an array
         * for the initial values.
         *
         * @param array|Traversable $values A traversable object of an array to
         * use the initial values.
         *
         * @link https://php.net/manual/en/ds-set.construct.php
         */
        public function __construct(...$values)
        {
        }

        /**
         * Adds all given values to the set that haven't already been added.
         *
         * <p>Note: Values of type object are supported. If an object implements
         * Ds\Hashable, equality will be determined by the object's equals
         * function. If an object does not implement Ds\Hashable, objects must
         * be references to the same instance to be considered equal.
         *
         * <p>Caution: All comparisons are strict (type and value).
         *
         * @param mixed ...$values Values to add to the set.
         *
         * @link https://php.net/manual/en/ds-set.add.php
         */
        public function add(...$values)
        {
        }

        /**
         * Allocates enough memory for a required capacity.
         *
         * @param int $capacity The number of values for which capacity should
         * be allocated.
         *
         * <p>Note: Capacity will stay the same if this value is less than or
         * equal to the current capacity.
         *
         * <p>Capacity will always be rounded up to the nearest power of 2.
         *
         * @link https://php.net/manual/en/ds-set.allocate.php
         */
        public function allocate(int $capacity)
        {
        }

        /**
         * Determines if the set contains all values.
         *
         * <p>Values of type object are supported. If an object implements
         * Ds\Hashable, equality will be determined by the object's equals
         * function. If an object does not implement Ds\Hashable, objects must
         * be references to the same instance to be considered equal.
         *
         * <p>Caution: All comparisons are strict (type and value).
         *
         * @param mixed ...$values  Values to check.
         *
         * @return bool
         *
         * @link https://php.net/manual/en/ds-set.contains.php
         */
        public function contains(...$values): bool
        {
        }


        /**
         * Returns the current capacity.
         * @link https://www.php.net/manual/en/ds-set.capacity.php
         *
         * @return int
         */
        public function capacity(): int
        {
        }

        /**
         * Removes all values from the set.
         * @link https://www.php.net/manual/en/ds-set.clear.php
         */
        public function clear(): void
        {
        }

        /**
         * Count elements of an object
         * @link https://php.net/manual/en/ds-set.count.php
         * @return int The custom count as an integer.
         * </p>
         * <p>
         * The return value is cast to an integer.
         * @since 5.1
         */
        public function count(): int
        {
        }

        /**
         * Returns a shallow copy of the set.
         * @link https://www.php.net/manual/en/ds-set.copy.php
         * @return Set
         */
        public function copy(): Set
        {
        }

        /**
         * Creates a new set using values that aren't in another set.
         *
         * A \ B = {x ∈ A | x ∉ B}
         *
         * @link https://www.php.net/manual/en/ds-set.diff.php
         *
         * @param Set $set Set containing the values to exclude.
         *
         * @return Set A new set containing all values that were not in the
         * other set.
         */
        public function diff(Set $set): Set
        {
        }

        /**
         * Creates a new set using a callable to determine which values to
         * include
         *
         * @link https://www.php.net/manual/en/ds-set.filter.php
         *
         * @param callable $callback Optional callable which returns TRUE if the
         * value should be included, FALSE otherwise.
         * If a callback is not provided, only values which are TRUE (see
         * converting to boolean) will be included.
         *
         * @return Set A new set containing all the values for which either the
         * callback returned TRUE, or all values that convert to TRUE if a
         * callback was not provided.
         */
        public function filter(callable $callback): Set
        {
        }

        /**
         * Returns the first value in the set.
         *
         * @link https://www.php.net/manual/en/ds-set.first.php
         *
         * @return mixed The first value in the set.
         */
        public function first()
        {
        }

        /**
         * Returns the value at a given index.
         *
         * @link https://www.php.net/manual/en/ds-set.get.php
         *
         * @param int $index The index to access, starting at 0.
         *
         * @return mixed The value at the requested index.
         */
        public function get(int $index)
        {
        }

        /**
         * Creates a new set using values common to both the current instance
         * and another set. In other words, returns a copy of the current
         * instance with all values removed that are not in the other set.
         *
         * A ∩ B = {x : x ∈ A ∧ x ∈ B}
         *
         * @link https://www.php.net/manual/en/ds-set.intersect.php
         *
         * @param Set $set The other set.
         *
         * @return Set The intersection of the current instance and another set.
         */
        public function intersect(Set $set): Set
        {
        }

        /**
         * Returns whether the set is empty.
         * @link https://www.php.net/manual/en/ds-set.isempty.php
         *
         * @return bool
         */
        public function isEmpty(): bool
        {
        }

        /**
         * Joins all values together as a string using an optional separator
         * between each value.
         *
         * @link https://www.php.net/manual/en/ds-set.join.php
         *
         * @param string $glue An optional string to separate each value.
         *
         * @return string
         */
        public function join(?string $glue = null): string
        {
        }

        /**
         * Returns the result of adding all given values to the set.
         *
         * <p>Note: The current instance won't be affected.
         *
         * @link https://www.php.net/manual/en/ds-set.merge.php
         *
         * @param array|Traversable $values A traversable object or an array.
         *
         * @return Set The result of adding all given values to the set,
         * effectively the same as adding the values to a copy, then returning
         * that copy.
         */
        public function merge($values): Set
        {
        }

        /**
         * Reduces the set to a single value using a callback function.
         *
         * @link https://www.php.net/manual/en/ds-set.reduce.php
         *
         * @param callable $callback
         * <code>callback ( mixed $carry , mixed $value ) : mixed</code>
         *  $carry  The return value of the previous callback, or initial if
         * it's the first iteration.
         *  $value   The value of the current iteration.
         *
         * @param null $initial The initial value of the carry value. Can be
         * NULL.
         *
         * @return mixed The return value of the final callback.
         */
        public function reduce(callable $callback, $initial = null)
        {
        }

        /**
         * Removes all given values from the set, ignoring any that are not in
         * the set.
         *
         * @link https://www.php.net/manual/en/ds-set.remove.php
         *
         * @param mixed ...$values The values to remove.
         */
        public function remove(...$values)
        {
        }

        /**
         * Reverses the set in-place.
         *
         * @link https://www.php.net/manual/en/ds-set.reverse.php
         */
        public function reverse()
        {
        }

        /**
         * Returns a reversed copy of the set.
         *
         * @link https://www.php.net/manual/en/ds-set.reversed.php
         *
         * <p>Note: The current instance is not affected.
         *
         * @return Set A reversed copy of the set.
         */
        public function reversed(): Set
        {
        }

        /**
         * Returns a sub-set of a given range
         *
         * @param int $index The index at which the sub-set starts. If positive,
         * the set will start at that index in
         * the set. If negative, the set will start that far from the end.
         *
         * @param int|null $length If a length is given and is positive, the
         * resulting set will have up to that many values in it. If the length
         * results in an overflow, only values up to the end of the set will be
         * included. If a length is given and is negative, the set will stop
         * that many values from the end. If a length is not provided, the
         * resulting set will contain all values between the index and the end
         * of the set.
         *
         * @return Set A sub-set of the given range.
         */
        public function slice(int $index, ?int $length = null): Set
        {
        }

        /**
         * Returns the last value in the set.
         *
         * @link https://www.php.net/manual/en/ds-set.last.php
         *
         * @return mixed The last value in the set.
         *
         * @throws UnderflowException if empty.
         */
        public function last()
        {
        }

        /**
         * Sorts the set in-place, using an optional comparator function.
         *
         * @param callable|null $comparator The comparison function must return
         * an integer less than, equal to, or greater than zero if the first
         * argument is considered to be respectively less than, equal to, or
         * greater than the second. Note that before PHP 7.0.0 this integer had
         * to be in the range from -2147483648 to 2147483647.
         * <code>callback ( mixed $a, mixed $b ) : int</code>
         * <note>Caution: Returning non-integer values from the comparison
         * function, such as float, will result in an internal cast to integer
         * of the callback's return value. So values such as 0.99 and 0.1 will
         * both be cast to an integer value of 0, which will compare such values
         * as equal.
         *
         * @link https://www.php.net/manual/en/ds-set.sort.php
         */
        public function sort(callable $comparator = null)
        {
        }

        /**
         * Returns a sorted copy, using an optional comparator function.
         *
         * @link https://www.php.net/manual/en/ds-set.sorted.php
         *
         * @param callable $comparator The comparison function must return an
         * integer less than, equal to, or greater than zero if the first
         * argument is considered to be respectively less than, equal to, or
         * greater than the second. Note  that before PHP 7.0.0 this integer had
         * to be in the range from -2147483648 to 2147483647.
         *
         * <code>callback ( mixed $a, mixed $b ) : int</code>
         *
         * <p>Caution: Returning non-integer values from the comparison
         * function, such as float, will result in an
         * internal cast to integer of the callback's return value. So values
         * such as 0.99 and 0.1 will both be cast to an integer value of 0,
         * which will compare such values as equal.
         *
         * @return Set Returns a sorted copy of the set.
         */
        public function sorted(callable $comparator = null): Set
        {
        }

        /**
         * Returns the sum of all values in the set.
         *
         * <p>Note: Arrays and objects are considered equal to zero when
         * calculating the sum.
         *
         * @link https://www.php.net/manual/en/ds-set.sum.php
         *
         * @return float|int The sum of all the values in the set as either a
         * float or int depending on the values in the set.
         */
        public function sum()
        {
        }

        /**
         * Creates a new set that contains the values of the current instance as
         * well as the values of another set.
         *
         * A ∪ B = {x: x ∈ A ∨ x ∈ B}
         *
         * @link https://www.php.net/manual/en/ds-set.union.php
         *
         * @param Set $set  The other set, to combine with the current instance.
         *
         * @return Set A new set containing all the values of the current
         * instance as well as another set.
         */
        public function union(Set $set): Set
        {
        }

        /**
         * Creates a new set using values in either the current instance or in
         * another set, but not in both.
         *
         * A ⊖ B = {x : x ∈ (A \ B) ∪ (B \ A)}
         *
         * @link https://www.php.net/manual/en/ds-set.xor.php
         *
         * @param Set $set The other set.
         *
         * @return Set A new set containing values in the current instance as
         * well as another set, but not in both.
         */
        public function xor(Set $set): Set
        {
        }

        /**
         * Converts the set to an array.
         * <p>Note: Casting to an array is not supported yet.
         * @link https://www.php.net/manual/en/ds-set.toarray.php
         * @return array An array containing all the values in the same order as
         * the collection.
         */
        public function toArray(): array
        {
        }

        /**
         * Specify data which should be serialized to JSON
         * @link https://php.net/manual/en/ds-set.jsonserialize.php
         * @return mixed data which can be serialized by <b>json_encode</b>,
         * which is a value of any type other than a resource.
         * @since 5.4
         */
        public function jsonSerialize()
        {
        }


    }

    /**
     * A Stack is a “last in, first out” or “LIFO” collection that only allows
     * access to the value at the top of the structure and iterates in that
     * order, destructively.
     *
     * @package Ds
     *
     * @link https://www.php.net/manual/en/class.ds-stack.php
     */
    class Stack implements Collection
    {
        /**
         * Creates a new instance, using either a traversable object or an array
         * for the initial values.
         *
         * @link https://www.php.net/manual/en/ds-stack.construct.php
         *
         * @param array|Traversable|null $values A traversable object or an
         * array to use for the initial values.
         */
        public function __construct($values = null)
        {
        }

        /**
         * Ensures that enough memory is allocated for a required capacity. This
         * removes the need to reallocate the internal as values are added.
         *
         * @link https://www.php.net/manual/en/ds-stack.allocate.php
         *
         * @param int $capacity The number of values for which capacity should
         * be allocated.
         *
         * <p>Note: Capacity will stay the same if this value is less than or
         * equal to the current capacity.
         */
        public function allocate(int $capacity)
        {
        }

        /**
         * Returns the current capacity.
         *
         * @link https://www.php.net/manual/en/ds-stack.capacity.php
         *
         * @return int The current capacity.
         */
        public function capacity(): int
        {
        }

        /**
         * Removes all values from the stack.
         * @link https://www.php.net/manual/en/ds-stack.clear.php
         */
        public function clear(): void
        {
        }

        /**
         * Count elements of an object
         * @link https://php.net/manual/en/ds-stack.count.php
         * @return int The custom count as an integer.
         * </p>
         * <p>
         * The return value is cast to an integer.
         * @since 5.1
         */
        public function count(): int
        {
        }

        /**
         * Returns a shallow copy of the collection.
         * @link https://www.php.net/manual/en/ds-stack.copy.php
         * @return Stack
         */
        public function copy(): Stack
        {
        }

        /**
         * Returns whether the collection is empty.
         * @link https://www.php.net/manual/en/ds-stack.isempty.php
         * @return bool
         */
        public function isEmpty(): bool
        {
        }

        /**
         * Converts the collection to an array.
         * <p>Note: Casting to an array is not supported yet.
         * @link https://www.php.net/manual/en/ds-stack.toarray.php
         * @return array An array containing all the values in the same order as
         * the collection.
         */
        public function toArray(): array
        {
        }

        /**
         * Specify data which should be serialized to JSON
         * @link https://php.net/manual/en/jsonserializable.jsonserialize.php
         * @return mixed data which can be serialized by <b>json_encode</b>,
         * which is a value of any type other than a resource.
         * @since 5.4
         */
        public function jsonSerialize()
        {
        }

        /**
         * Returns the value at the top of the stack, but does not remove it.
         *
         * @link https://www.php.net/manual/en/ds-queue.peek.php
         *
         * @return mixed The value at the top of the stack.
         *
         * @throws UnderflowException
         */
        public function peek()
        {
        }

        /**
         * Removes and returns the value at the top of the stack.
         *
         * @link https://www.php.net/manual/en/ds-queue.pop.php
         *
         * @return mixed The removed value which was at the top of the stack.
         *
         * @throws UnderflowException
         */
        public function pop()
        {
        }

        /**
         * Pushes values onto the stack.
         *
         * @link https://www.php.net/manual/en/ds-queue.push.php
         *
         * @param array $values The values to push onto the stack.
         */
        public function push(...$values)
        {
        }
    }

    /**
     * A Queue is a “first in, first out” or “FIFO” collection that only allows
     * access to the value at the front of the queue and iterates in that order,
     * destructively.
     *
     * Uses a Ds\Vector internally.
     *
     * @package Ds
     */
    class Queue implements Collection
    {
        /**
         * Creates a new instance, using either a traversable object or an array
         * for the initial values.
         *
         * @link https://www.php.net/manual/en/ds-queue.construct.php
         *
         * @param array|Traversable|null $values A traversable object or an
         * array to use for the initial values.
         */
        public function __construct($values = null)
        {
        }

        /**
         * Ensures that enough memory is allocated for a required capacity. This
         * removes the need to reallocate the internal as values are added.
         *
         * @link https://www.php.net/manual/en/ds-queue.allocate.php
         *
         * @param int $capacity The number of values for which capacity should
         * be allocated.
         *
         * <p>Note: Capacity will stay the same if this value is less than or
         * equal to the current capacity.
         */
        public function allocate(int $capacity)
        {
        }

        /**
         * Returns the current capacity.
         *
         * @link https://www.php.net/manual/en/ds-queue.capacity.php
         *
         * @return int The current capacity.
         */
        public function capacity(): int
        {
        }

        /**
         * Removes all values from the queue.
         * @link https://www.php.net/manual/en/ds-queue.clear.php
         */
        public function clear(): void
        {
        }

        /**
         * Count elements of an object
         * @link https://php.net/manual/en/ds-queue.count.php
         * @return int The custom count as an integer.
         * </p>
         * <p>
         * The return value is cast to an integer.
         * @since 5.1
         */
        public function count(): int
        {
        }

        /**
         * Returns a shallow copy of the collection.
         * @link https://www.php.net/manual/en/ds-queue.copy.php
         * @return Stack
         */
        public function copy(): Stack
        {
        }

        /**
         * Returns whether the collection is empty.
         * @link https://www.php.net/manual/en/ds-queue.isempty.php
         * @return bool
         */
        public function isEmpty(): bool
        {
        }

        /**
         * Converts the collection to an array.
         * <p>Note: Casting to an array is not supported yet.
         * @link https://www.php.net/manual/en/ds-queue.toarray.php
         * @return array An array containing all the values in the same order as
         * the collection.
         */
        public function toArray(): array
        {
        }

        /**
         * Specify data which should be serialized to JSON
         * @link https://php.net/manual/en/jsonserializable.jsonserialize.php
         * @return mixed data which can be serialized by <b>json_encode</b>,
         * which is a value of any type other than a resource.
         * @since 5.4
         */
        public function jsonSerialize()
        {
        }

        /**
         * Returns the value at the top of the queue, but does not remove it.
         *
         * @link https://www.php.net/manual/en/ds-queue.peek.php
         *
         * @return mixed The value at the top of the queue.
         *
         * @throws UnderflowException
         */
        public function peek()
        {
        }

        /**
         * Removes and returns the value at the top of the queue.
         *
         * @link https://www.php.net/manual/en/ds-queue.pop.php
         *
         * @return mixed The removed value which was at the top of the queue.
         *
         * @throws UnderflowException
         */
        public function pop()
        {
        }

        /**
         * Pushes values onto the queue.
         *
         * @link https://www.php.net/manual/en/ds-queue.push.php
         *
         * @param array $values The values to push onto the queue.
         */
        public function push(...$values)
        {
        }
    }

    /**
     * A PriorityQueue is very similar to a Queue. Values are pushed into the
     * queue with an assigned priority, and the value with the highest priority
     * will always be at the front of the queue.
     *
     * Implemented using a max heap.
     *
     * @package Ds
     *
     * @link https://www.php.net/manual/en/class.ds-priorityqueue.php
     */
    class PriorityQueue implements Collection
    {
        const MIN_CAPACITY = 8;

        /**
         * Count elements of an object
         * @link https://php.net/manual/en/countable.count.php
         * @return int The custom count as an integer.
         * </p>
         * <p>
         * The return value is cast to an integer.
         * @since 5.1
         */
        public function count(): int
        {
        }

        /**
         * Removes all values from the collection.
         * @link https://www.php.net/manual/en/ds-collection.clear.php
         */
        public function clear(): void
        {
        }

        /**
         * Returns a shallow copy of the collection.
         * @link https://www.php.net/manual/en/ds-collection.copy.php
         * @return Collection
         */
        public function copy()
        {
        }

        /**
         * Returns whether the collection is empty.
         * @link https://www.php.net/manual/en/ds-collection.isempty.php
         * @return bool
         */
        public function isEmpty(): bool
        {
        }

        /**
         * Converts the collection to an array.
         * <p>Note: Casting to an array is not supported yet.
         * @link https://www.php.net/manual/en/ds-collection.toarray.php
         * @return array An array containing all the values in the same order as
         * the collection.
         */
        public function toArray(): array
        {
        }

        /**
         * Specify data which should be serialized to JSON
         * @link https://php.net/manual/en/jsonserializable.jsonserialize.php
         * @return mixed data which can be serialized by <b>json_encode</b>,
         * which is a value of any type other than a resource.
         * @since 5.4
         */
        public function jsonSerialize()
        {
        }


    }
}
