<?php
/**
 * Returns FPM status info array
 * @since 7.3
 * @return array
 */
function fpm_get_status() : array { }
