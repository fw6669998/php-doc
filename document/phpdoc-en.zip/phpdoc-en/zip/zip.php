<?php

// Start of zip v.1.11.0

/**
*<div id="class.ziparchive" class="reference">  <h1 class="title">The <a href="https://www.php.net/manual/en/class.ziparchive.php" class="classname">ZipArchive</a> class</h1>      <div class="partintro"><p class="verinfo">(PHP 5 &gt;= 5.2.0, PHP 7, PECL zip &gt;= 1.1.0)</p>      <div class="section" id="ziparchive.intro">    <h2 class="title">Introduction</h2>    <p class="para">     A file archive, compressed with Zip.    </p>   </div>      <div class="section" id="ziparchive.synopsis">    <h2 class="title">Class synopsis</h2>      <div class="classsynopsis">     <div class="ooclass"></div>       <div class="classsynopsisinfo">      <span class="ooclass">       <strong class="classname">ZipArchive</strong>      </span>        <span class="oointerface">implements        <span class="interfacename"><a href="https://www.php.net/manual/en/class.countable.php" class="interfacename">Countable</a></span>      </span>      {</div>      <div class="classsynopsisinfo classsynopsisinfo_comment">// Properties </div>     <div class="fieldsynopsis"><span class="type" style="color:#EAB766">int</span> <var class="varname"><a href="https://www.php.net/manual/en/class.ziparchive.php#ziparchive.props.status">$<var class="varname">status</var></a></var>;</div>      <div class="fieldsynopsis"><span class="type" style="color:#EAB766">int</span> <var class="varname"><a href="https://www.php.net/manual/en/class.ziparchive.php#ziparchive.props.statussys">$<var class="varname">statusSys</var></a></var>;</div>      <div class="fieldsynopsis"><span class="type" style="color:#EAB766">int</span> <var class="varname"><a href="https://www.php.net/manual/en/class.ziparchive.php#ziparchive.props.numfiles">$<var class="varname">numFiles</var></a></var>;</div>      <div class="fieldsynopsis"><span class="type" style="color:#EAB766">string</span> <var class="varname"><a href="https://www.php.net/manual/en/class.ziparchive.php#ziparchive.props.filename">$<var class="varname">filename</var></a></var>;</div>      <div class="fieldsynopsis"><span class="type" style="color:#EAB766">string</span> <var class="varname"><a href="https://www.php.net/manual/en/class.ziparchive.php#ziparchive.props.comment">$<var class="varname">comment</var></a></var>;</div>            <div class="classsynopsisinfo classsynopsisinfo_comment">// Methods </div>     <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/ziparchive.addemptydir.php" class="methodname" style="color:#CC7832">addEmptyDir</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$dirname</span></span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/ziparchive.addfile.php" class="methodname" style="color:#CC7832">addFile</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$filename</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$localname</span><span class="initializer"> = <strong><span>NULL</span></strong></span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$start</span><span class="initializer"> = 0</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$length</span><span class="initializer"> = 0</span></span>   ]]] ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/ziparchive.addfromstring.php" class="methodname" style="color:#CC7832">addFromString</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$localname</span></span>    , <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$contents</span></span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/ziparchive.addglob.php" class="methodname" style="color:#CC7832">addGlob</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$pattern</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$flags</span><span class="initializer"> = 0</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">array</span> <span class="parameter" style="color:#2EACF9">$options</span><span class="initializer"> = array()</span></span>   ]] ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/ziparchive.addpattern.php" class="methodname" style="color:#CC7832">addPattern</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$pattern</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$path</span><span class="initializer"> = &quot;.&quot;</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">array</span> <span class="parameter" style="color:#2EACF9">$options</span><span class="initializer"> = array()</span></span>   ]] ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/ziparchive.close.php" class="methodname" style="color:#CC7832">close</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/ziparchive.count.php" class="methodname" style="color:#CC7832">count</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">int</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/ziparchive.deleteindex.php" class="methodname" style="color:#CC7832">deleteIndex</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$index</span></span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/ziparchive.deletename.php" class="methodname" style="color:#CC7832">deleteName</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/ziparchive.extractto.php" class="methodname" style="color:#CC7832">extractTo</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$destination</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span> <span class="parameter" style="color:#2EACF9">$entries</span></span>   ] ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/ziparchive.getarchivecomment.php" class="methodname" style="color:#CC7832">getArchiveComment</a></span>     ([ <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$flags</span></span>   ] ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/ziparchive.getcommentindex.php" class="methodname" style="color:#CC7832">getCommentIndex</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$index</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$flags</span></span>   ] ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/ziparchive.getcommentname.php" class="methodname" style="color:#CC7832">getCommentName</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$flags</span></span>   ] ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">        <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/ziparchive.getexternalattributesindex.php" class="methodname" style="color:#CC7832">GetExternalAttributesIndex</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$index</span></span>    , <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">&$opsys</span></span>    , <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">&$attr</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$flags</span></span>   ] ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">        <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/ziparchive.getexternalattributesname.php" class="methodname" style="color:#CC7832">getExternalAttributesName</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    , <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">&$opsys</span></span>    , <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">&$attr</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$flags</span></span>   ] ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/ziparchive.getfromindex.php" class="methodname" style="color:#CC7832">getFromIndex</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$index</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$length</span><span class="initializer"> = 0</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$flags</span></span>   ]] ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/ziparchive.getfromname.php" class="methodname" style="color:#CC7832">getFromName</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$length</span><span class="initializer"> = 0</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$flags</span></span>   ]] ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/ziparchive.getnameindex.php" class="methodname" style="color:#CC7832">getNameIndex</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$index</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$flags</span></span>   ] ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/ziparchive.getstatusstring.php" class="methodname" style="color:#CC7832">getStatusString</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/ziparchive.getstream.php" class="methodname" style="color:#CC7832">getStream</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    ) : <span class="type" style="color:#EAB766">resource</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/ziparchive.locatename.php" class="methodname" style="color:#CC7832">locateName</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$flags</span></span>   ] ) : <span class="type" style="color:#EAB766">int</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/ziparchive.open.php" class="methodname" style="color:#CC7832">open</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$filename</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$flags</span></span>   ] ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/ziparchive.renameindex.php" class="methodname" style="color:#CC7832">renameIndex</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$index</span></span>    , <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$newname</span></span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/ziparchive.renamename.php" class="methodname" style="color:#CC7832">renameName</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    , <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$newname</span></span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/ziparchive.setarchivecomment.php" class="methodname" style="color:#CC7832">setArchiveComment</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$comment</span></span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/ziparchive.setcommentindex.php" class="methodname" style="color:#CC7832">setCommentIndex</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$index</span></span>    , <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$comment</span></span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/ziparchive.setcommentname.php" class="methodname" style="color:#CC7832">setCommentName</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    , <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$comment</span></span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/ziparchive.setcompressionindex.php" class="methodname" style="color:#CC7832">setCompressionIndex</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$index</span></span>    , <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$comp_method</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$comp_flags</span><span class="initializer"> = 0</span></span>   ] ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/ziparchive.setcompressionname.php" class="methodname" style="color:#CC7832">setCompressionName</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    , <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$comp_method</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$comp_flags</span><span class="initializer"> = 0</span></span>   ] ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">        <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/ziparchive.setencryptionindex.php" class="methodname" style="color:#CC7832">setEncryptionIndex</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$index</span></span>    , <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$method</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$password</span></span>   ] ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">        <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/ziparchive.setencryptionname.php" class="methodname" style="color:#CC7832">setEncryptionName</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    , <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$method</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$password</span></span>   ] ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">        <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/ziparchive.setexternalattributesindex.php" class="methodname" style="color:#CC7832">setExternalAttributesIndex</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$index</span></span>    , <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$opsys</span></span>    , <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$attr</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$flags</span></span>   ] ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">        <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/ziparchive.setexternalattributesname.php" class="methodname" style="color:#CC7832">setExternalAttributesName</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    , <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$opsys</span></span>    , <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$attr</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$flags</span></span>   ] ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/ziparchive.setpassword.php" class="methodname" style="color:#CC7832">setPassword</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$password</span></span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/ziparchive.statindex.php" class="methodname" style="color:#CC7832">statIndex</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$index</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$flags</span></span>   ] ) : <span class="type" style="color:#EAB766">array</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/ziparchive.statname.php" class="methodname" style="color:#CC7832">statName</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$flags</span></span>   ] ) : <span class="type" style="color:#EAB766">array</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/ziparchive.unchangeall.php" class="methodname" style="color:#CC7832">unchangeAll</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/ziparchive.unchangearchive.php" class="methodname" style="color:#CC7832">unchangeArchive</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/ziparchive.unchangeindex.php" class="methodname" style="color:#CC7832">unchangeIndex</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$index</span></span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/ziparchive.unchangename.php" class="methodname" style="color:#CC7832">unchangeName</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    ) : <span class="type" style="color:#EAB766">bool</span></div>          }</div>     </div>     <div class="section" id="ziparchive.props">    <h2 class="title">Properties</h2>    <dl>            <dt id="ziparchive.props.status"><var class="varname"><var class="varname">status</var></var></dt>       <dd>        <p class="para">Status of the Zip Archive</p>      </dd>                 <dt id="ziparchive.props.statussys"><var class="varname"><var class="varname">statusSys</var></var></dt>       <dd>        <p class="para">System status of the Zip Archive</p>      </dd>                 <dt id="ziparchive.props.numfiles"><var class="varname"><var class="varname">numFiles</var></var></dt>       <dd>        <p class="para">Number of files in archive</p>      </dd>                 <dt id="ziparchive.props.filename"><var class="varname"><var class="varname">filename</var></var></dt>       <dd>        <p class="para">File name in the file system</p>      </dd>                 <dt id="ziparchive.props.comment"><var class="varname"><var class="varname">comment</var></var></dt>       <dd>        <p class="para">Comment for the archive</p>      </dd>          </dl>    </div>   </div>                                                                                                                                                                                                                                                      <h2>Table of Contents</h2><ul class="chunklist chunklist_reference"><li>{@link ZipArchive::addEmptyDir} — Add a new directory</li><li>{@link ZipArchive::addFile} — Adds a file to a ZIP archive from the given path</li><li>{@link ZipArchive::addFromString} — Add a file to a ZIP archive using its contents</li><li>{@link ZipArchive::addGlob} — Add files from a directory by glob pattern</li><li>{@link ZipArchive::addPattern} — Add files from a directory by PCRE pattern</li><li>{@link ZipArchive::close} — Close the active archive (opened or newly created)</li><li>{@link ZipArchive::count} — Counts the number of files in the achive</li><li>{@link ZipArchive::deleteIndex} — Delete an entry in the archive using its index</li><li>{@link ZipArchive::deleteName} — Delete an entry in the archive using its name</li><li>{@link ZipArchive::extractTo} — Extract the archive contents</li><li>{@link ZipArchive::getArchiveComment} — Returns the Zip archive comment</li><li>{@link ZipArchive::getCommentIndex} — Returns the comment of an entry using the entry index</li><li>{@link ZipArchive::getCommentName} — Returns the comment of an entry using the entry name</li><li>{@link ZipArchive::getExternalAttributesIndex} — Retrieve the external attributes of an entry defined by its index</li><li>{@link ZipArchive::getExternalAttributesName} — Retrieve the external attributes of an entry defined by its name</li><li>{@link ZipArchive::getFromIndex} — Returns the entry contents using its index</li><li>{@link ZipArchive::getFromName} — Returns the entry contents using its name</li><li>{@link ZipArchive::getNameIndex} — Returns the name of an entry using its index</li><li>{@link ZipArchive::getStatusString} — Returns the status error message, system and/or zip messages</li><li>{@link ZipArchive::getStream} — Get a file handler to the entry defined by its name (read only)</li><li>{@link ZipArchive::locateName} — Returns the index of the entry in the archive</li><li>{@link ZipArchive::open} — Open a ZIP file archive</li><li>{@link ZipArchive::renameIndex} — Renames an entry defined by its index</li><li>{@link ZipArchive::renameName} — Renames an entry defined by its name</li><li>{@link ZipArchive::setArchiveComment} — Set the comment of a ZIP archive</li><li>{@link ZipArchive::setCommentIndex} — Set the comment of an entry defined by its index</li><li>{@link ZipArchive::setCommentName} — Set the comment of an entry defined by its name</li><li>{@link ZipArchive::setCompressionIndex} — Set the compression method of an entry defined by its index</li><li>{@link ZipArchive::setCompressionName} — Set the compression method of an entry defined by its name</li><li>{@link ZipArchive::setEncryptionIndex} — Set the encryption method of an entry defined by its index</li><li>{@link ZipArchive::setEncryptionName} — Set the encryption method of an entry defined by its name</li><li>{@link ZipArchive::setExternalAttributesIndex} — Set the external attributes of an entry defined by its index</li><li>{@link ZipArchive::setExternalAttributesName} — Set the external attributes of an entry defined by its name</li><li>{@link ZipArchive::setPassword} — Set the password for the active archive</li><li>{@link ZipArchive::statIndex} — Get the details of an entry defined by its index</li><li>{@link ZipArchive::statName} — Get the details of an entry defined by its name</li><li>{@link ZipArchive::unchangeAll} — Undo all changes done in the archive</li><li>{@link ZipArchive::unchangeArchive} — Revert all global changes done in the archive</li><li>{@link ZipArchive::unchangeIndex} — Revert all changes done to an entry at the given index</li><li>{@link ZipArchive::unchangeName} — Revert all changes done to an entry with the given name</li></ul> </div>
*/
class ZipArchive  {

	/**
	 * Create the archive if it does not exist.
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const CREATE = 1;

	/**
	 * Error if archive already exists.
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const EXCL = 2;

	/**
	 * Perform additional consistency checks on the archive, and error if they fail.
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const CHECKCONS = 4;

	/**
	 * Always start a new archive, this mode will overwrite the file if
	 * it already exists.
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const OVERWRITE = 8;

	/**
	 * Ignore case on name lookup
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const FL_NOCASE = 1;

	/**
	 * Ignore directory component
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const FL_NODIR = 2;

	/**
	 * Read compressed data
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const FL_COMPRESSED = 4;

	/**
	 * Use original data, ignoring changes.
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const FL_UNCHANGED = 8;

	/**
	 * better of deflate or store.
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const CM_DEFAULT = -1;

	/**
	 * stored (uncompressed).
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const CM_STORE = 0;

	/**
	 * shrunk
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const CM_SHRINK = 1;

	/**
	 * reduced with factor 1
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const CM_REDUCE_1 = 2;

	/**
	 * reduced with factor 2
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const CM_REDUCE_2 = 3;

	/**
	 * reduced with factor 3
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const CM_REDUCE_3 = 4;

	/**
	 * reduced with factor 4
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const CM_REDUCE_4 = 5;

	/**
	 * imploded
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const CM_IMPLODE = 6;

	/**
	 * deflated
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const CM_DEFLATE = 8;

	/**
	 * deflate64
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const CM_DEFLATE64 = 9;

	/**
	 * PKWARE imploding
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const CM_PKWARE_IMPLODE = 10;

	/**
	 * BZIP2 algorithm
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const CM_BZIP2 = 12;
	const CM_LZMA = 14;
	const CM_TERSE = 18;
	const CM_LZ77 = 19;
	const CM_WAVPACK = 97;
	const CM_PPMD = 98;

	/**
	 * No error.
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const ER_OK = 0;

	/**
	 * Multi-disk zip archives not supported.
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const ER_MULTIDISK = 1;

	/**
	 * Renaming temporary file failed.
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const ER_RENAME = 2;

	/**
	 * Closing zip archive failed
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const ER_CLOSE = 3;

	/**
	 * Seek error
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const ER_SEEK = 4;

	/**
	 * Read error
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const ER_READ = 5;

	/**
	 * Write error
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const ER_WRITE = 6;

	/**
	 * CRC error
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const ER_CRC = 7;

	/**
	 * Containing zip archive was closed
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const ER_ZIPCLOSED = 8;

	/**
	 * No such file.
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const ER_NOENT = 9;

	/**
	 * File already exists
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const ER_EXISTS = 10;

	/**
	 * Can't open file
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const ER_OPEN = 11;

	/**
	 * Failure to create temporary file.
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const ER_TMPOPEN = 12;

	/**
	 * Zlib error
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const ER_ZLIB = 13;

	/**
	 * Memory allocation failure
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const ER_MEMORY = 14;

	/**
	 * Entry has been changed
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const ER_CHANGED = 15;

	/**
	 * Compression method not supported.
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const ER_COMPNOTSUPP = 16;

	/**
	 * Premature EOF
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const ER_EOF = 17;

	/**
	 * Invalid argument
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const ER_INVAL = 18;

	/**
	 * Not a zip archive
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const ER_NOZIP = 19;

	/**
	 * Internal error
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const ER_INTERNAL = 20;

	/**
	 * Zip archive inconsistent
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const ER_INCONS = 21;

	/**
	 * Can't remove file
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const ER_REMOVE = 22;

	/**
	 * Entry has been deleted
	 * @link http://php.net/manual/en/zip.constants.php
	 */
	const ER_DELETED = 23;

    /**
     * Status of the Zip Archive
     */
    public $status;
    /**
     * System status of the Zip Archive
     */
    public $statusSys;
    /**
     * Number of files in archive
     */
    public $numFiles;
    /**
     * File name in the file system
     */
    public $filename;
    /**
     * Comment for the archive
     */
    public $comment;

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.1.0)<br/>
	 * Open a ZIP file archive
	 * @link http://php.net/manual/en/ziparchive.open.php
	 * @param string $filename <p>
	 * The file name of the ZIP archive to open.
	 * </p>
	 * @param int $flags [optional] <p>
	 * The mode to use to open the archive.
	 * <p>
	 * <b>ZipArchive::OVERWRITE</b>
	 * </p>
	 * @return mixed <i>Error codes</i>
	 * <p>
	 * Returns <b>TRUE</b> on success or the error code.
	 * <p>
	 * <b>ZipArchive::ER_EXISTS</b>
	 * </p>
	 * <p>
	 * File already exists.
	 * </p>
	 * <p>
	 * <b>ZipArchive::ER_INCONS</b>
	 * </p>
	 * <p>
	 * Zip archive inconsistent.
	 * </p>
	 * <p>
	 * <b>ZipArchive::ER_INVAL</b>
	 * </p>
	 * <p>
	 * Invalid argument.
	 * </p>
	 * <p>
	 * <b>ZipArchive::ER_MEMORY</b>
	 * </p>
	 * <p>
	 * Malloc failure.
	 * </p>
	 * <p>
	 * <b>ZipArchive::ER_NOENT</b>
	 * </p>
	 * <p>
	 * No such file.
	 * </p>
	 * <p>
	 * <b>ZipArchive::ER_NOZIP</b>
	 * </p>
	 * <p>
	 * Not a zip archive.
	 * </p>
	 * <p>
	 * <b>ZipArchive::ER_OPEN</b>
	 * </p>
	 * <p>
	 * Can't open file.
	 * </p>
	 * <p>
	 * <b>ZipArchive::ER_READ</b>
	 * </p>
	 * <p>
	 * Read error.
	 * </p>
	 * <p>
	 * <b>ZipArchive::ER_SEEK</b>
	 * </p>
	 * <p>
	 * Seek error.
	 * </p>
	 * </p>
	 */
	public function open ($filename, $flags = null) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.1.0)<br/>
	 * Close the active archive (opened or newly created)
	 * @link http://php.net/manual/en/ziparchive.close.php
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 */
	public function close () {}

	/**
	 * Returns the status error message, system and/or zip messages
	 * @link http://php.net/manual/en/ziparchive.getstatusstring.php
	 * @return string a string with the status message on success or <b>FALSE</b> on failure.
	 * @since 5.2.7
	 */
	public function getStatusString () {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.8.0)<br/>
	 * Add a new directory
	 * @link http://php.net/manual/en/ziparchive.addemptydir.php
	 * @param string $dirname <p>
	 * The directory to add.
	 * </p>
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 */
	public function addEmptyDir ($dirname) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.1.0)<br/>
	 * Add a file to a ZIP archive using its contents
	 * @link http://php.net/manual/en/ziparchive.addfromstring.php
	 * @param string $localname <p>
	 * The name of the entry to create.
	 * </p>
	 * @param string $contents <p>
	 * The contents to use to create the entry. It is used in a binary
	 * safe mode.
	 * </p>
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 */
	public function addFromString ($localname, $contents) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.1.0)<br/>
	 * Adds a file to a ZIP archive from the given path
	 * @link http://php.net/manual/en/ziparchive.addfile.php
	 * @param string $filename <p>
	 * The path to the file to add.
	 * </p>
	 * @param string $localname [optional] <p>
	 * If supplied, this is the local name inside the ZIP archive that will override the <i>filename</i>.
	 * </p>
	 * @param int $start [optional] <p>
	 * This parameter is not used but is required to extend <b>ZipArchive</b>.
	 * </p>
	 * @param int $length [optional] <p>
	 * This parameter is not used but is required to extend <b>ZipArchive</b>.
	 * </p>
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 */
	public function addFile ($filename, $localname = null, $start = 0, $length = 0) {}

	/**
	 * (PHP 5 &gt;= 5.3.0, PECL zip &gt;= 1.9.0)<br/>
	 * Add files from a directory by glob pattern
	 * @link http://php.net/manual/en/ziparchive.addglob.php
	 * @param string $pattern <p>
	 * A <b>glob</b> pattern against which files will be matched.
	 * </p>
	 * @param int $flags [optional] <p>
	 * A bit mask of glob() flags.
	 * </p>
	 * @param array $options [optional] <p>
	 * An associative array of options. Available options are:
	 * <p>
	 * "add_path"
	 * </p>
	 * <p>
	 * Prefix to prepend when translating to the local path of the file within
	 * the archive. This is applied after any remove operations defined by the
	 * "remove_path" or "remove_all_path"
	 * options.
	 * </p>
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 */
	public function addGlob ($pattern, $flags = 0, array $options = array()) {}

	/**
	 * (PHP 5 &gt;= 5.3.0, PECL zip &gt;= 1.9.0)<br/>
	 * Add files from a directory by PCRE pattern
	 * @link http://php.net/manual/en/ziparchive.addpattern.php
	 * @param string $pattern <p>
	 * A PCRE pattern against which files will be matched.
	 * </p>
	 * @param string $path [optional] <p>
	 * The directory that will be scanned. Defaults to the current working directory.
	 * </p>
	 * @param array $options [optional] <p>
	 * An associative array of options accepted by <b>ZipArchive::addGlob</b>.
	 * </p>
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 */
	public function addPattern ($pattern, $path = '.', array $options = array()) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.5.0)<br/>
	 * Renames an entry defined by its index
	 * @link http://php.net/manual/en/ziparchive.renameindex.php
	 * @param int $index <p>
	 * Index of the entry to rename.
	 * </p>
	 * @param string $newname <p>
	 * New name.
	 * </p>
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 */
	public function renameIndex ($index, $newname) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.5.0)<br/>
	 * Renames an entry defined by its name
	 * @link http://php.net/manual/en/ziparchive.renamename.php
	 * @param string $name <p>
	 * Name of the entry to rename.
	 * </p>
	 * @param string $newname <p>
	 * New name.
	 * </p>
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 */
	public function renameName ($name, $newname) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.4.0)<br/>
	 * Set the comment of a ZIP archive
	 * @link http://php.net/manual/en/ziparchive.setarchivecomment.php
	 * @param string $comment <p>
	 * The contents of the comment.
	 * </p>
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 */
	public function setArchiveComment ($comment) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.1.0)<br/>
	 * Returns the Zip archive comment
	 * @link http://php.net/manual/en/ziparchive.getarchivecomment.php
	 * @param int $flags [optional] <p>
	 * If flags is set to <b>ZipArchive::FL_UNCHANGED</b>, the original unchanged
	 * comment is returned.
	 * </p>
	 * @return string the Zip archive comment or <b>FALSE</b> on failure.
	 */
	public function getArchiveComment ($flags = null) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.4.0)<br/>
	 * Set the comment of an entry defined by its index
	 * @link http://php.net/manual/en/ziparchive.setcommentindex.php
	 * @param int $index <p>
	 * Index of the entry.
	 * </p>
	 * @param string $comment <p>
	 * The contents of the comment.
	 * </p>
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 */
	public function setCommentIndex ($index, $comment) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.4.0)<br/>
	 * Set the comment of an entry defined by its name
	 * @link http://php.net/manual/en/ziparchive.setcommentname.php
	 * @param string $name <p>
	 * Name of the entry.
	 * </p>
	 * @param string $comment <p>
	 * The contents of the comment.
	 * </p>
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 */
	public function setCommentName ($name, $comment) {}

	/**
	 * Set the compression method of an entry defined by its index
	 * @link http://php.net/manual/en/ziparchive.setcompressionindex.php
	 * @param int $index Index of the entry.
	 * @param int $comp_method The compression method. Either ZipArchive::CM_DEFAULT, ZipArchive::CM_STORE or ZipArchive::CM_DEFLATE.
	 * @param int $comp_flags [optional] Compression flags. Currently unused.
	 * @return bool Returns TRUE on success or FALSE on failure.
	 * @since 7.0
	 */
	public function setCompressionIndex ($index, $comp_method, $comp_flags = 0) {}

	/**
	 * Set the compression method of an entry defined by its name
	 * http://php.net/manual/en/ziparchive.setcompressionname.php
	 * @param string $name Name of the entry.
	 * @param int $comp_method The compression method. Either ZipArchive::CM_DEFAULT, ZipArchive::CM_STORE or ZipArchive::CM_DEFLATE.
	 * @param int $comp_flags [optional] Compression flags. Currently unused.
	 * @return bool Returns TRUE on success or FALSE on failure.
	 * @since 7.0
	 */
	public function setCompressionName ($name, $comp_method, $comp_flags = 0){}

/**
*<div id="ziparchive.setencryptionindex" class="refentry">  <div class="refnamediv">   <h1 class="refname">ZipArchive::setEncryptionIndex</h1>   <p class="verinfo">(PHP &gt;= 7.2.0, PECL zip &gt;= 1.14.0)</p><p class="refpurpose"><span class="refname">ZipArchive::setEncryptionIndex</span> &mdash; <span class="dc-title">Set the encryption method of an entry defined by its index</span></p>   </div>  <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-ziparchive.setencryptionindex-description">   <h3 class="title">Description</h3>   <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">        <span class="methodname" style="color:#CC7832"><strong>ZipArchive::setEncryptionIndex</strong></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$index</span></span>    , <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$method</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$password</span></span>   ] ) : <span class="type" style="color:#EAB766">bool</span></div>    <p class="para rdfs-comment">    Set the encryption method of an entry defined by its index.   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-ziparchive.setencryptionindex-parameters">   <h3 class="title">Parameters</h3>   <span>    <dl>            <dt> <span class="parameter" style="color:#2EACF9">index</span></dt>       <dd>        <p class="para">        Index of the entry.       </p>      </dd>                 <dt> <span class="parameter" style="color:#2EACF9">method</span></dt>       <dd>        <p class="para">        The encryption method defined by one of the ZipArchive::EM_ constants.       </p>      </dd>                 <dt> <span class="parameter" style="color:#2EACF9">password</span></dt>       <dd>        <p class="para">        Optional password, default used when missing.       </p>      </dd>          </dl>    </span>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-ziparchive.setencryptionindex-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    Returns <strong><span>TRUE</span></strong> on success or <strong><span>FALSE</span></strong> on failure.   </p>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-ziparchive.setencryptionindex-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><span class="methodname" style="color:#CC7832">{@link ZipArchive::setPassword()} - Set the password for the active archive</span></li>     <li class="member"><span class="methodname" style="color:#CC7832">{@link ZipArchive::setEncryptionName()} - Set the encryption method of an entry defined by its name</span></li>    </ul>   </span>  </div>  </div>
     * @return bool Returns TRUE on success or FALSE on failure.*/
    public function setEncryptionIndex ($index, $method, $password = null) {}

/**
*<div id="ziparchive.setencryptionname" class="refentry">  <div class="refnamediv">   <h1 class="refname">ZipArchive::setEncryptionName</h1>   <p class="verinfo">(PHP &gt;= 7.2.0, PECL zip &gt;= 1.14.0)</p><p class="refpurpose"><span class="refname">ZipArchive::setEncryptionName</span> &mdash; <span class="dc-title">Set the encryption method of an entry defined by its name</span></p>   </div>  <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-ziparchive.setencryptionname-description">   <h3 class="title">Description</h3>   <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">        <span class="methodname" style="color:#CC7832"><strong>ZipArchive::setEncryptionName</strong></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    , <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$method</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$password</span></span>   ] ) : <span class="type" style="color:#EAB766">bool</span></div>    <p class="para rdfs-comment">    Set the encryption method of an entry defined by its name.   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-ziparchive.setencryptionname-parameters">   <h3 class="title">Parameters</h3>   <span>    <dl>            <dt> <span class="parameter" style="color:#2EACF9">name</span></dt>       <dd>        <p class="para">        Name of the entry.       </p>      </dd>                 <dt> <span class="parameter" style="color:#2EACF9">method</span></dt>       <dd>        <p class="para">        The encryption method defined by one of the ZipArchive::EM_ constants.       </p>      </dd>                 <dt> <span class="parameter" style="color:#2EACF9">password</span></dt>       <dd>        <p class="para">        Optional password, default used when missing.       </p>      </dd>          </dl>    </span>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-ziparchive.setencryptionname-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    Returns <strong><span>TRUE</span></strong> on success or <strong><span>FALSE</span></strong> on failure.   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-ziparchive.setencryptionname-examples">   <h3 class="title">Examples</h3>     <span>      This example creates a ZIP file archive      <var class="filename">test.zip</var> and add      the file <var class="filename">test.txt</var>      encrypted using the AES 256 method.     </span>     <div class="example" id="example-906">      <p><strong>Example #1 Archive and encrypt a file</strong></p>      <div class="example-contents"> <div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"> <span style="color: #9876AA">&lt;?php<br />$zip&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #9876AA">ZipArchive</span><span style="color: #007700">();<br />if&nbsp;(</span><span style="color: #9876AA">$zip</span><span style="color: #007700">-&gt;</span><span style="color: #9876AA">open</span><span style="color: #007700">(</span><span style="color: #DD0000">'test.zip'</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">ZipArchive</span><span style="color: #007700">::</span><span style="color: #9876AA">CREATE</span><span style="color: #007700">)&nbsp;===&nbsp;</span><span style="color: #9876AA">TRUE</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #9876AA">$zip</span><span style="color: #007700">-&gt;</span><span style="color: #9876AA">setPassword</span><span style="color: #007700">(</span><span style="color: #DD0000">'secret'</span><span style="color: #007700">);<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #9876AA">$zip</span><span style="color: #007700">-&gt;</span><span style="color: #9876AA">addFile</span><span style="color: #007700">(</span><span style="color: #DD0000">'text.txt'</span><span style="color: #007700">);<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #9876AA">$zip</span><span style="color: #007700">-&gt;</span><span style="color: #9876AA">setEncryptionName</span><span style="color: #007700">(</span><span style="color: #DD0000">'text.txt'</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">ZipArchive</span><span style="color: #007700">::</span><span style="color: #9876AA">EM_AES_256</span><span style="color: #007700">);<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #9876AA">$zip</span><span style="color: #007700">-&gt;</span><span style="color: #9876AA">close</span><span style="color: #007700">();<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"Ok\n"</span><span style="color: #007700">;<br />}&nbsp;else&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"KO\n"</span><span style="color: #007700">;<br />}<br /></span><span style="color: #9876AA">?&gt;</span> </span> </span></div>      </div>      </div>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-ziparchive.setencryptionname-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><span class="methodname" style="color:#CC7832">{@link ZipArchive::setPassword()} - Set the password for the active archive</span></li>     <li class="member"><span class="methodname" style="color:#CC7832">{@link ZipArchive::setEncryptionIndex()} - Set the encryption method of an entry defined by its index</span></li>    </ul>   </span>  </div>  </div>
     * @return bool Returns TRUE on success or FALSE on failure.*/
    public function setEncryptionName ($name, $method, $password = null) {}

/**
*<div id="ziparchive.setpassword" class="refentry">  <div class="refnamediv">   <h1 class="refname">ZipArchive::setPassword</h1>   <p class="verinfo">(PHP 5 &gt;= 5.6.0, PHP 7, PECL zip &gt;= 1.12.4)</p><p class="refpurpose"><span class="refname">ZipArchive::setPassword</span> &mdash; <span class="dc-title">Set the password for the active archive</span></p>   </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-ziparchive.setpassword-description">   <h3 class="title">Description</h3>   <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><strong>ZipArchive::setPassword</strong></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$password</span></span>    ) : <span class="type" style="color:#EAB766">bool</span></div>    <p class="para rdfs-comment">    Sets the password for the active archive.   </p>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-ziparchive.setpassword-parameters">   <h3 class="title">Parameters</h3>   <dl>          <dt> <span class="parameter" style="color:#2EACF9">password</span></dt>      <dd>       <span>       The password to be used for the archive.      </span>     </dd>        </dl>   </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-ziparchive.setpassword-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    Returns <strong><span>TRUE</span></strong> on success or <strong><span>FALSE</span></strong> on failure.   </p>  </div>     <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 notes" id="refsect1-ziparchive.setpassword-notes">   <h3 class="title">Notes</h3>   <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>:     <p class="para">     As of PHP 7.2.0 and libzip 1.2.0 the password is used to decompress the archive,     and is also the default password for <span class="methodname" style="color:#CC7832">{@link ZipArchive::setEncryptionName()}</span>     and <span class="methodname" style="color:#CC7832">{@link ZipArchive::setEncryptionIndex()}</span>.     Formerly, this function only set the password to be used to decompress the archive;     it did not turn a non-password-protected <a href="https://www.php.net/manual/en/class.ziparchive.php" class="classname">ZipArchive</a>     into a password-protected <a href="https://www.php.net/manual/en/class.ziparchive.php" class="classname">ZipArchive</a>.    </p>   </p></blockquote>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-ziparchive.setpassword-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><span class="methodname" style="color:#CC7832">{@link ZipArchive::setEncryptionIndex()} - Set the encryption method of an entry defined by its index</span></li>     <li class="member"><span class="methodname" style="color:#CC7832">{@link ZipArchive::setEncryptionName()} - Set the encryption method of an entry defined by its name</span></li>    </ul>   </span>  </div>   </div>
     * @return boolean*/
    public function setPassword($password) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.4.0)<br/>
	 * Returns the comment of an entry using the entry index
	 * @link http://php.net/manual/en/ziparchive.getcommentindex.php
	 * @param int $index <p>
	 * Index of the entry
	 * </p>
	 * @param int $flags [optional] <p>
	 * If flags is set to <b>ZipArchive::FL_UNCHANGED</b>, the original unchanged
	 * comment is returned.
	 * </p>
	 * @return string the comment on success or <b>FALSE</b> on failure.
	 */
	public function getCommentIndex ($index, $flags = null) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.4.0)<br/>
	 * Returns the comment of an entry using the entry name
	 * @link http://php.net/manual/en/ziparchive.getcommentname.php
	 * @param string $name <p>
	 * Name of the entry
	 * </p>
	 * @param int $flags [optional] <p>
	 * If flags is set to <b>ZipArchive::FL_UNCHANGED</b>, the original unchanged
	 * comment is returned.
	 * </p>
	 * @return string the comment on success or <b>FALSE</b> on failure.
	 */
	public function getCommentName ($name, $flags = null) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.5.0)<br/>
	 * delete an entry in the archive using its index
	 * @link http://php.net/manual/en/ziparchive.deleteindex.php
	 * @param int $index <p>
	 * Index of the entry to delete.
	 * </p>
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 */
	public function deleteIndex ($index) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.5.0)<br/>
	 * delete an entry in the archive using its name
	 * @link http://php.net/manual/en/ziparchive.deletename.php
	 * @param string $name <p>
	 * Name of the entry to delete.
	 * </p>
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 */
	public function deleteName ($name) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.5.0)<br/>
	 * Get the details of an entry defined by its name.
	 * @link http://php.net/manual/en/ziparchive.statname.php
	 * @param string $name <p>
	 * Name of the entry
	 * </p>
	 * @param int $flags [optional] <p>
	 * The flags argument specifies how the name lookup should be done.
	 * Also, <b>ZipArchive::FL_UNCHANGED</b> may be ORed to it to request
	 * information about the original file in the archive,
	 * ignoring any changes made.
	 * <p>
	 * <b>ZipArchive::FL_NOCASE</b>
	 * </p>
	 * @return array an array containing the entry details or <b>FALSE</b> on failure.
	 */
	public function statName ($name, $flags = null) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.1.0)<br/>
	 * Get the details of an entry defined by its index.
	 * @link http://php.net/manual/en/ziparchive.statindex.php
	 * @param int $index <p>
	 * Index of the entry
	 * </p>
	 * @param int $flags [optional] <p>
	 * <b>ZipArchive::FL_UNCHANGED</b> may be ORed to it to request
	 * information about the original file in the archive,
	 * ignoring any changes made.
	 * </p>
	 * @return array an array containing the entry details or <b>FALSE</b> on failure.
	 */
	public function statIndex ($index, $flags = null) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.5.0)<br/>
	 * Returns the index of the entry in the archive
	 * @link http://php.net/manual/en/ziparchive.locatename.php
	 * @param string $name <p>
	 * The name of the entry to look up
	 * </p>
	 * @param int $flags [optional] <p>
	 * The flags are specified by ORing the following values,
	 * or 0 for none of them.
	 * <p>
	 * <b>ZipArchive::FL_NOCASE</b>
	 * </p>
	 * @return int the index of the entry on success or <b>FALSE</b> on failure.
	 */
	public function locateName ($name, $flags = null) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.5.0)<br/>
	 * Returns the name of an entry using its index
	 * @link http://php.net/manual/en/ziparchive.getnameindex.php
	 * @param int $index <p>
	 * Index of the entry.
	 * </p>
	 * @param int $flags [optional] <p>
	 * If flags is set to <b>ZipArchive::FL_UNCHANGED</b>, the original unchanged
	 * name is returned.
	 * </p>
	 * @return string the name on success or <b>FALSE</b> on failure.
	 */
	public function getNameIndex ($index, $flags = null) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.1.0)<br/>
	 * Revert all global changes done in the archive.
	 * @link http://php.net/manual/en/ziparchive.unchangearchive.php
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 */
	public function unchangeArchive () {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.1.0)<br/>
	 * Undo all changes done in the archive
	 * @link http://php.net/manual/en/ziparchive.unchangeall.php
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 */
	public function unchangeAll () {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.1.0)<br/>
	 * Revert all changes done to an entry at the given index
	 * @link http://php.net/manual/en/ziparchive.unchangeindex.php
	 * @param int $index <p>
	 * Index of the entry.
	 * </p>
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 */
	public function unchangeIndex ($index) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.5.0)<br/>
	 * Revert all changes done to an entry with the given name.
	 * @link http://php.net/manual/en/ziparchive.unchangename.php
	 * @param string $name <p>
	 * Name of the entry.
	 * </p>
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 */
	public function unchangeName ($name) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.1.0)<br/>
	 * Extract the archive contents
	 * @link http://php.net/manual/en/ziparchive.extractto.php
	 * @param string $destination <p>
	 * Location where to extract the files.
	 * </p>
	 * @param mixed $entries [optional] <p>
	 * The entries to extract. It accepts either a single entry name or
	 * an array of names.
	 * </p>
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 */
	public function extractTo ($destination, $entries = null) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.1.0)<br/>
	 * Returns the entry contents using its name
	 * @link http://php.net/manual/en/ziparchive.getfromname.php
	 * @param string $name <p>
	 * Name of the entry
	 * </p>
	 * @param int $length [optional] <p>
	 * The length to be read from the entry. If 0, then the
	 * entire entry is read.
	 * </p>
	 * @param int $flags [optional] <p>
	 * The flags to use to open the archive. the following values may
	 * be ORed to it.
	 * <p>
	 * <b>ZipArchive::FL_UNCHANGED</b>
	 * </p>
	 * @return string the contents of the entry on success or <b>FALSE</b> on failure.
	 */
	public function getFromName ($name, $length = 0, $flags = null) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.3.0)<br/>
	 * Returns the entry contents using its index
	 * @link http://php.net/manual/en/ziparchive.getfromindex.php
	 * @param int $index <p>
	 * Index of the entry
	 * </p>
	 * @param int $length [optional] <p>
	 * The length to be read from the entry. If 0, then the
	 * entire entry is read.
	 * </p>
	 * @param int $flags [optional] <p>
	 * The flags to use to open the archive. the following values may
	 * be ORed to it.
	 * <p>
	 * <b>ZipArchive::FL_UNCHANGED</b>
	 * </p>
	 * @return string the contents of the entry on success or <b>FALSE</b> on failure.
	 */
	public function getFromIndex ($index, $length = 0, $flags = null) {}

	/**
	 * (PHP 5 &gt;= 5.2.0, PECL zip &gt;= 1.1.0)<br/>
	 * Get a file handler to the entry defined by its name (read only).
	 * @link http://php.net/manual/en/ziparchive.getstream.php
	 * @param string $name <p>
	 * The name of the entry to use.
	 * </p>
	 * @return resource a file pointer (resource) on success or <b>FALSE</b> on failure.
	 */
	public function getStream ($name) {}

}

/**
*<div id="function.zip-open" class="refentry">  <div class="refnamediv">   <h1 class="refname">zip_open</h1>   <p class="verinfo">(PHP 4 &gt;= 4.1.0, PHP 5 &gt;= 5.2.0, PHP 7, PECL zip &gt;= 1.0.0)</p><p class="refpurpose"><span class="refname">zip_open</span> &mdash; <span class="dc-title">Open a ZIP file archive</span></p>   </div>  <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.zip-open-description">   <h3 class="title">Description</h3>   <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><strong>zip_open</strong></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$filename</span></span>    ) : <span class="type" style="color:#EAB766">resource</span></div>    <p class="para rdfs-comment">    Opens a new zip archive for reading.    </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.zip-open-parameters">   <h3 class="title">Parameters</h3>   <span>    <dl>            <dt> <span class="parameter" style="color:#2EACF9">filename</span></dt>       <dd>        <p class="para">        The file name of the ZIP archive to open.       </p>      </dd>          </dl>    </span>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.zip-open-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    Returns a resource handle for later use with    <span class="function">{@link zip_read()}</span> and <span class="function">{@link zip_close()}</span>    or returns the number of error if <span class="parameter" style="color:#2EACF9">filename</span> does not    exist or in case of other error.   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.zip-open-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><span class="function">{@link zip_read()} - Read next entry in a ZIP file archive</span></li>     <li class="member"><span class="function">{@link zip_close()} - Close a ZIP file archive</span></li>    </ul>   </span>  </div>  </div>
 * @return resource a resource handle for later use with*/
function zip_open ($filename) {}

/**
*<div id="function.zip-close" class="refentry">  <div class="refnamediv">   <h1 class="refname">zip_close</h1>   <p class="verinfo">(PHP 4 &gt;= 4.1.0, PHP 5 &gt;= 5.2.0, PHP 7, PECL zip &gt;= 1.0.0)</p><p class="refpurpose"><span class="refname">zip_close</span> &mdash; <span class="dc-title">Close a ZIP file archive</span></p>   </div>  <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.zip-close-description">   <h3 class="title">Description</h3>   <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><strong>zip_close</strong></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">resource</span> <span class="parameter" style="color:#2EACF9">$zip</span></span>    ) : <span class="type" style="color:#EAB766"><span class="type void" style="color:#EAB766">void</span></span></div>    <p class="para rdfs-comment">    Closes the given ZIP file archive.   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.zip-close-parameters">   <h3 class="title">Parameters</h3>   <span>    <dl>            <dt> <span class="parameter" style="color:#2EACF9">zip</span></dt>       <dd>        <p class="para">        A ZIP file previously opened with <span class="function">{@link zip_open()}</span>.       </p>      </dd>          </dl>    </span>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.zip-close-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    No value is returned.   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.zip-close-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><span class="function">{@link zip_open()} - Open a ZIP file archive</span></li>     <li class="member"><span class="function">{@link zip_read()} - Read next entry in a ZIP file archive</span></li>    </ul>   </span>  </div>  </div>
 * @return void No value is returned.*/
function zip_close ($zip) {}

/**
*<div id="function.zip-read" class="refentry">  <div class="refnamediv">   <h1 class="refname">zip_read</h1>   <p class="verinfo">(PHP 4 &gt;= 4.1.0, PHP 5 &gt;= 5.2.0, PHP 7, PECL zip &gt;= 1.0.0)</p><p class="refpurpose"><span class="refname">zip_read</span> &mdash; <span class="dc-title">Read next entry in a ZIP file archive</span></p>   </div>  <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.zip-read-description">   <h3 class="title">Description</h3>   <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><strong>zip_read</strong></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">resource</span> <span class="parameter" style="color:#2EACF9">$zip</span></span>    ) : <span class="type" style="color:#EAB766">resource</span></div>    <p class="para rdfs-comment">    Reads the next entry in a zip file archive.   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.zip-read-parameters">   <h3 class="title">Parameters</h3>   <span>    <dl>            <dt> <span class="parameter" style="color:#2EACF9">zip</span></dt>       <dd>        <p class="para">        A ZIP file previously opened with <span class="function">{@link zip_open()}</span>.       </p>      </dd>          </dl>    </span>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.zip-read-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    Returns a directory entry resource for later use with the    <em>zip_entry_...</em> functions, or <strong><span>FALSE</span></strong> if    there are no more entries to read, or an error code if an error    occurred.   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.zip-read-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><span class="function">{@link zip_open()} - Open a ZIP file archive</span></li>     <li class="member"><span class="function">{@link zip_close()} - Close a ZIP file archive</span></li>     <li class="member"><span class="function">{@link zip_entry_open()} - Open a directory entry for reading</span></li>     <li class="member"><span class="function">{@link zip_entry_read()} - Read from an open directory entry</span></li>    </ul>   </span>  </div>  </div>
 * @return resource a directory entry resource for later use with the*/
function zip_read ($zip) {}

/**
*<div id="function.zip-entry-open" class="refentry">  <div class="refnamediv">   <h1 class="refname">zip_entry_open</h1>   <p class="verinfo">(PHP 4 &gt;= 4.1.0, PHP 5 &gt;= 5.2.0, PHP 7, PECL zip &gt;= 1.0.0)</p><p class="refpurpose"><span class="refname">zip_entry_open</span> &mdash; <span class="dc-title">Open a directory entry for reading</span></p>   </div>  <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.zip-entry-open-description">   <h3 class="title">Description</h3>   <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><strong>zip_entry_open</strong></span>           ( <span class="methodparam"><span class="type" style="color:#EAB766">resource</span> <span class="parameter" style="color:#2EACF9">$zip</span></span>    , <span class="methodparam"><span class="type" style="color:#EAB766">resource</span> <span class="parameter" style="color:#2EACF9">$zip_entry</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$mode</span></span>   ] ) : <span class="type" style="color:#EAB766">bool</span></div>    <p class="para rdfs-comment">    Opens a directory entry in a zip file for reading.   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.zip-entry-open-parameters">   <h3 class="title">Parameters</h3>   <span>    <dl>            <dt> <span class="parameter" style="color:#2EACF9">zip</span></dt>       <dd>        <p class="para">        A valid resource handle returned by <span class="function">{@link zip_open()}</span>.       </p>      </dd>                 <dt> <span class="parameter" style="color:#2EACF9">zip_entry</span></dt>       <dd>        <p class="para">        A directory entry returned by <span class="function">{@link zip_read()}</span>.       </p>      </dd>                 <dt> <span class="parameter" style="color:#2EACF9">mode</span></dt>       <dd>        <p class="para">        Any of the modes specified in the documentation of        <span class="function">{@link fopen()}</span>.       </p>       <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>:         <p class="para">         Currently, <span class="parameter" style="color:#2EACF9">mode</span> is ignored and is always         <em>&quot;rb&quot;</em>. This is due to the fact that zip support         in PHP is read only access.        </p>       </p></blockquote>      </dd>          </dl>    </span>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.zip-entry-open-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    Returns <strong><span>TRUE</span></strong> on success or <strong><span>FALSE</span></strong> on failure.   </p>   <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>:     <p class="para">     Unlike <span class="function">{@link fopen()}</span> and other similar functions,     the return value of <span class="function"><strong style="color:#CC7832">zip_entry_open()</strong></span> only     indicates the result of the operation and is not needed for     reading or closing the directory entry.    </p>   </p></blockquote>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.zip-entry-open-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><span class="function">{@link zip_entry_close()} - Close a directory entry</span></li>     <li class="member"><span class="function">{@link zip_entry_read()} - Read from an open directory entry</span></li>    </ul>   </span>  </div>  </div>
 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.*/
function zip_entry_open ($zip, $zip_entry, $mode = null) {}

/**
*<div id="function.zip-entry-close" class="refentry">  <div class="refnamediv">   <h1 class="refname">zip_entry_close</h1>   <p class="verinfo">(PHP 4 &gt;= 4.1.0, PHP 5 &gt;= 5.2.0, PHP 7, PECL zip &gt;= 1.0.0)</p><p class="refpurpose"><span class="refname">zip_entry_close</span> &mdash; <span class="dc-title">Close a directory entry</span></p>   </div>  <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.zip-entry-close-description">   <h3 class="title">Description</h3>   <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><strong>zip_entry_close</strong></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">resource</span> <span class="parameter" style="color:#2EACF9">$zip_entry</span></span>    ) : <span class="type" style="color:#EAB766">bool</span></div>    <p class="para rdfs-comment">    Closes the specified directory entry.   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.zip-entry-close-parameters">   <h3 class="title">Parameters</h3>   <span>    <dl>            <dt> <span class="parameter" style="color:#2EACF9">zip_entry</span></dt>       <dd>        <p class="para">        A directory entry previously opened <span class="function">{@link zip_entry_open()}</span>.       </p>      </dd>          </dl>    </span>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.zip-entry-close-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    Returns <strong><span>TRUE</span></strong> on success or <strong><span>FALSE</span></strong> on failure.   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.zip-entry-close-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><span class="function">{@link zip_entry_open()} - Open a directory entry for reading</span></li>     <li class="member"><span class="function">{@link zip_entry_read()} - Read from an open directory entry</span></li>    </ul>   </span>  </div>  </div>
 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.*/
function zip_entry_close ($zip_entry) {}

/**
*<div id="function.zip-entry-read" class="refentry">  <div class="refnamediv">   <h1 class="refname">zip_entry_read</h1>   <p class="verinfo">(PHP 4 &gt;= 4.1.0, PHP 5 &gt;= 5.2.0, PHP 7, PECL zip &gt;= 1.0.0)</p><p class="refpurpose"><span class="refname">zip_entry_read</span> &mdash; <span class="dc-title">Read from an open directory entry</span></p>   </div>  <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.zip-entry-read-description">   <h3 class="title">Description</h3>   <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><strong>zip_entry_read</strong></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">resource</span> <span class="parameter" style="color:#2EACF9">$zip_entry</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$length</span><span class="initializer"> = 1024</span></span>   ] ) : <span class="type" style="color:#EAB766">string</span></div>    <p class="para rdfs-comment">    Reads from an open directory entry.   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.zip-entry-read-parameters">   <h3 class="title">Parameters</h3>   <span>    <dl>            <dt> <span class="parameter" style="color:#2EACF9">zip_entry</span></dt>       <dd>        <p class="para">        A directory entry returned by <span class="function">{@link zip_read()}</span>.       </p>      </dd>                 <dt> <span class="parameter" style="color:#2EACF9">length</span></dt>       <dd>        <p class="para">        The number of bytes to return.       </p>       <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>:         <p class="para">         This should be the uncompressed length you wish to read.        </p>       </p></blockquote>      </dd>          </dl>    </span>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.zip-entry-read-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    Returns the data read, empty string on end of a file, or <strong><span>FALSE</span></strong> on error.   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.zip-entry-read-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><span class="function">{@link zip_entry_open()} - Open a directory entry for reading</span></li>     <li class="member"><span class="function">{@link zip_entry_close()} - Close a directory entry</span></li>     <li class="member"><span class="function">{@link zip_entry_filesize()} - Retrieve the actual file size of a directory entry</span></li>    </ul>   </span>  </div>  </div>
 * @return string the data read, empty string on end of a file, or <b>FALSE</b> on error.*/
function zip_entry_read ($zip_entry, $length = 1024) {}

/**
*<div id="function.zip-entry-filesize" class="refentry">  <div class="refnamediv">   <h1 class="refname">zip_entry_filesize</h1>   <p class="verinfo">(PHP 4 &gt;= 4.1.0, PHP 5 &gt;= 5.2.0, PHP 7, PECL zip &gt;= 1.0.0)</p><p class="refpurpose"><span class="refname">zip_entry_filesize</span> &mdash; <span class="dc-title">Retrieve the actual file size of a directory entry</span></p>   </div>  <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.zip-entry-filesize-description">   <h3 class="title">Description</h3>   <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><strong>zip_entry_filesize</strong></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">resource</span> <span class="parameter" style="color:#2EACF9">$zip_entry</span></span>    ) : <span class="type" style="color:#EAB766">int</span></div>    <p class="para rdfs-comment">    Returns the actual size of the specified directory entry.   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.zip-entry-filesize-parameters">   <h3 class="title">Parameters</h3>   <span>    <dl>            <dt> <span class="parameter" style="color:#2EACF9">zip_entry</span></dt>       <dd>        <p class="para">        A directory entry returned by <span class="function">{@link zip_read()}</span>.       </p>      </dd>          </dl>    </span>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.zip-entry-filesize-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    The size of the directory entry.   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.zip-entry-filesize-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><span class="function">{@link zip_open()} - Open a ZIP file archive</span></li>     <li class="member"><span class="function">{@link zip_read()} - Read next entry in a ZIP file archive</span></li>    </ul>   </span>  </div>  </div>
 * @return int The size of the directory entry.*/
function zip_entry_filesize ($zip_entry) {}

/**
*<div id="function.zip-entry-name" class="refentry">  <div class="refnamediv">   <h1 class="refname">zip_entry_name</h1>                    <p class="verinfo">(PHP 4 &gt;= 4.1.0, PHP 5 &gt;= 5.2.0, PHP 7, PECL zip &gt;= 1.0.0)</p><p class="refpurpose"><span class="refname">zip_entry_name</span> &mdash; <span class="dc-title">Retrieve the name of a directory entry</span></p>   </div>  <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.zip-entry-name-description">   <h3 class="title">Description</h3>   <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><strong>zip_entry_name</strong></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">resource</span> <span class="parameter" style="color:#2EACF9">$zip_entry</span></span>    ) : <span class="type" style="color:#EAB766">string</span></div>    <p class="para rdfs-comment">    Returns the name of the specified directory entry.   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.zip-entry-name-parameters">   <h3 class="title">Parameters</h3>   <span>    <dl>            <dt> <span class="parameter" style="color:#2EACF9">zip_entry</span></dt>       <dd>        <p class="para">        A directory entry returned by <span class="function">{@link zip_read()}</span>.       </p>      </dd>          </dl>    </span>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.zip-entry-name-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    The name of the directory entry.   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.zip-entry-name-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><span class="function">{@link zip_open()} - Open a ZIP file archive</span></li>     <li class="member"><span class="function">{@link zip_read()} - Read next entry in a ZIP file archive</span></li>    </ul>   </span>  </div>  </div>
 * @return string The name of the directory entry.*/
function zip_entry_name ($zip_entry) {}

/**
*<div id="function.zip-entry-compressedsize" class="refentry">  <div class="refnamediv">   <h1 class="refname">zip_entry_compressedsize</h1>   <p class="verinfo">(PHP 4 &gt;= 4.1.0, PHP 5 &gt;= 5.2.0, PHP 7, PECL zip &gt;= 1.0.0)</p><p class="refpurpose"><span class="refname">zip_entry_compressedsize</span> &mdash; <span class="dc-title">Retrieve the compressed size of a directory entry</span></p>   </div>  <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.zip-entry-compressedsize-description">   <h3 class="title">Description</h3>   <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><strong>zip_entry_compressedsize</strong></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">resource</span> <span class="parameter" style="color:#2EACF9">$zip_entry</span></span>    ) : <span class="type" style="color:#EAB766">int</span></div>    <p class="para rdfs-comment">    Returns the compressed size of the specified directory entry.   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.zip-entry-compressedsize-parameters">   <h3 class="title">Parameters</h3>   <span>    <dl>            <dt> <span class="parameter" style="color:#2EACF9">zip_entry</span></dt>       <dd>        <p class="para">        A directory entry returned by <span class="function">{@link zip_read()}</span>.       </p>      </dd>          </dl>    </span>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.zip-entry-compressedsize-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    The compressed size.   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.zip-entry-compressedsize-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><span class="function">{@link zip_open()} - Open a ZIP file archive</span></li>     <li class="member"><span class="function">{@link zip_read()} - Read next entry in a ZIP file archive</span></li>    </ul>   </span>  </div>  </div>
 * @return int The compressed size.*/
function zip_entry_compressedsize ($zip_entry) {}

/**
*<div id="function.zip-entry-compressionmethod" class="refentry">  <div class="refnamediv">   <h1 class="refname">zip_entry_compressionmethod</h1>   <p class="verinfo">(PHP 4 &gt;= 4.1.0, PHP 5 &gt;= 5.2.0, PHP 7, PECL zip &gt;= 1.0.0)</p><p class="refpurpose"><span class="refname">zip_entry_compressionmethod</span> &mdash; <span class="dc-title">Retrieve the compression method of a directory entry</span></p>   </div>  <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.zip-entry-compressionmethod-description">   <h3 class="title">Description</h3>   <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><strong>zip_entry_compressionmethod</strong></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">resource</span> <span class="parameter" style="color:#2EACF9">$zip_entry</span></span>    ) : <span class="type" style="color:#EAB766">string</span></div>    <p class="para rdfs-comment">    Returns the compression method of the directory entry specified    by <span class="parameter" style="color:#2EACF9">zip_entry</span>.   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.zip-entry-compressionmethod-parameters">   <h3 class="title">Parameters</h3>   <span>    <dl>            <dt> <span class="parameter" style="color:#2EACF9">zip_entry</span></dt>       <dd>        <p class="para">        A directory entry returned by <span class="function">{@link zip_read()}</span>.       </p>      </dd>          </dl>    </span>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.zip-entry-compressionmethod-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    The compression method.   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.zip-entry-compressionmethod-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><span class="function">{@link zip_open()} - Open a ZIP file archive</span></li>     <li class="member"><span class="function">{@link zip_read()} - Read next entry in a ZIP file archive</span></li>    </ul>   </span>  </div>  </div>
 * @return string The compression method.*/
function zip_entry_compressionmethod ($zip_entry) {}

// End of zip v.1.11.0
?>
