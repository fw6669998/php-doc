<?php

// Start of Reflection v.$Revision: 307971 $

/**
*<div id="class.reflectionexception" class="reference">   <h1 class="title">The ReflectionException class</h1>     <div class="partintro"><p class="verinfo">(PHP 5, PHP 7)</p>     <div class="section" id="reflectionexception.intro">    <h2 class="title">Introduction</h2>    <p class="para">     The ReflectionException class.    </p>   </div>     <div class="section" id="reflectionexception.synopsis">    <h2 class="title">Class synopsis</h2>      <div class="classsynopsis">     <div class="ooclass"></div>       <div class="classsynopsisinfo">      <span class="ooclass">       <strong class="classname">ReflectionException</strong>      </span>            <span class="ooclass">       <span class="modifier">extends</span>       <a href="https://www.php.net/manual/en/class.exception.php" class="classname">Exception</a>      </span>      {</div>      <div class="classsynopsisinfo classsynopsisinfo_comment">// Properties </div>     <div class="fieldsynopsis">      <span class="modifier">protected</span>      <span class="type" style="color:#EAB766">string</span>       <var class="varname"><a href="https://www.php.net/manual/en/class.exception.php#exception.props.message">$<var class="varname">message</var></a></var>     ;</div> <div class="fieldsynopsis">      <span class="modifier">protected</span>      <span class="type" style="color:#EAB766">int</span>       <var class="varname"><a href="https://www.php.net/manual/en/class.exception.php#exception.props.code">$<var class="varname">code</var></a></var>     ;</div> <div class="fieldsynopsis">      <span class="modifier">protected</span>      <span class="type" style="color:#EAB766">string</span>       <var class="varname"><a href="https://www.php.net/manual/en/class.exception.php#exception.props.file">$<var class="varname">file</var></a></var>     ;</div> <div class="fieldsynopsis">      <span class="modifier">protected</span>      <span class="type" style="color:#EAB766">int</span>       <var class="varname"><a href="https://www.php.net/manual/en/class.exception.php#exception.props.line">$<var class="varname">line</var></a></var>     ;</div>       <div class="classsynopsisinfo classsynopsisinfo_comment">// Inherited methods </div>     <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">final</span> <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link Exception::getMessage}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">final</span> <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link Exception::getPrevious}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/class.throwable.php" class="type Throwable" style="color:#EAB766">Throwable</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">final</span> <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link Exception::getCode}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">final</span> <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link Exception::getFile}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">final</span> <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link Exception::getLine}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">int</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">final</span> <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link Exception::getTrace}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">array</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">final</span> <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link Exception::getTraceAsString}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span>  <span class="methodname" style="color:#CC7832">{@link Exception::__toString}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">final</span> <span class="modifier">private</span> <span class="methodname" style="color:#CC7832">{@link Exception::__clone}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><span class="type void" style="color:#EAB766">void</span></span></div>      }</div>     </div>      </div>  </div>
*/
class ReflectionException extends Exception  {

}

/**
*<div id="class.reflection" class="reference">   <h1 class="title">The Reflection class</h1>     <div class="partintro"><p class="verinfo">(PHP 5, PHP 7)</p>     <div class="section" id="reflection.intro">    <h2 class="title">Introduction</h2>    <p class="para">     The reflection class.    </p>   </div>     <div class="section" id="reflection.synopsis">    <h2 class="title">Class synopsis</h2>      <div class="classsynopsis">     <div class="ooclass"></div>       <div class="classsynopsisinfo">      <span class="ooclass">       <strong class="classname">Reflection</strong>      </span>      {</div>           <div class="classsynopsisinfo classsynopsisinfo_comment">// Methods </div>     <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="modifier">static</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflection.export.php" class="methodname" style="color:#CC7832">export</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/class.reflector.php" class="type Reflector" style="color:#EAB766">Reflector</a></span> <span class="parameter" style="color:#2EACF9">$reflector</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">bool</span> <span class="parameter" style="color:#2EACF9">$return</span><span class="initializer"> = <strong><span>FALSE</span></strong></span></span>   ] ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="modifier">static</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflection.getmodifiernames.php" class="methodname" style="color:#CC7832">getModifierNames</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$modifiers</span></span>    ) : <span class="type" style="color:#EAB766">array</span></div>     }</div>     </div>   </div>                   <h2>Table of Contents</h2><ul class="chunklist chunklist_reference"><li>{@link Reflection::export} — Exports</li><li>{@link Reflection::getModifierNames} — Gets modifier names</li></ul> </div>
*/
class Reflection  {

	/**
	 * Gets modifier names
	 * @link http://php.net/manual/en/reflection.getmodifiernames.php
	 * @param int $modifiers <p>
	 * The modifiers to get, which is from a numeric value.
	 * </p>
	 * @return array An array of modifier names.
	 * @since 5.0
	 */
	public static function getModifierNames ($modifiers) {}

	/**
	 * Exports
	 * @link http://php.net/manual/en/reflection.export.php
	 * @param Reflector $reflector <p>
	 * The reflection to export.
	 * </p>
	 * @param bool $return [optional] <p>
	 * Setting to <b>TRUE</b> will return the export,
	 * as opposed to emitting it. Setting to <b>FALSE</b> (the default) will do the opposite.
	 * </p>
	 * @return string If the <i>return</i> parameter
	 * is set to <b>TRUE</b>, then the export is returned as a string,
	 * otherwise <b>NULL</b> is returned.
	 * @since 5.0
	 */
	public static function export (Reflector $reflector, $return = false) {}

}

/**
 * <b>Reflector</b> is an interface implemented by all
 * exportable Reflection classes.
 * @link http://php.net/manual/en/class.reflector.php
 */
interface Reflector  {

	/**
	 * Exports
	 * @link http://php.net/manual/en/reflector.export.php
	 * @return string
	 * @since 5.0
	 */
	static function export ();

	/**
	 * To string
	 * @link http://php.net/manual/en/reflector.tostring.php
	 * @return string 
	 * @since 5.0
	 */
	function __toString ();

}

/**
*<div id="class.reflectionfunctionabstract" class="reference">   <h1 class="title">The ReflectionFunctionAbstract class</h1>     <div class="partintro"><p class="verinfo">(PHP 5 &gt;= 5.2.0, PHP 7)</p>     <div class="section" id="reflectionfunctionabstract.intro">    <h2 class="title">Introduction</h2>    <p class="para">     A parent class to {@link ReflectionFunction}, read its     description for details.    </p>   </div>     <div class="section" id="reflectionfunctionabstract.synopsis">    <h2 class="title">Class synopsis</h2>      <div class="classsynopsis">     <div class="ooclass"></div>       <div class="classsynopsisinfo">      <span class="ooclass">       <strong class="classname">ReflectionFunctionAbstract</strong>      </span>            <span class="oointerface">implements        <span class="interfacename"><a href="https://www.php.net/manual/en/class.reflector.php" class="interfacename">Reflector</a></span>      </span>      {</div>      <div class="classsynopsisinfo classsynopsisinfo_comment">// Properties </div>     <div class="fieldsynopsis">      <span class="modifier">public</span>       <var class="varname"><a href="https://www.php.net/manual/en/class.reflectionfunctionabstract.php#reflectionfunctionabstract.props.name">$<var class="varname">name</var></a></var>     ;</div>            <div class="classsynopsisinfo classsynopsisinfo_comment">// Methods </div>     <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">final</span> <span class="modifier">private</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionfunctionabstract.clone.php" class="methodname" style="color:#CC7832">__clone</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><span class="type void" style="color:#EAB766">void</span></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionfunctionabstract.getclosurescopeclass.php" class="methodname" style="color:#CC7832">getClosureScopeClass</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/class.reflectionclass.php" class="type ReflectionClass" style="color:#EAB766">ReflectionClass</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionfunctionabstract.getclosurethis.php" class="methodname" style="color:#CC7832">getClosureThis</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">object</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionfunctionabstract.getdoccomment.php" class="methodname" style="color:#CC7832">getDocComment</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionfunctionabstract.getendline.php" class="methodname" style="color:#CC7832">getEndLine</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">int</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionfunctionabstract.getextension.php" class="methodname" style="color:#CC7832">getExtension</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/class.reflectionextension.php" class="type ReflectionExtension" style="color:#EAB766">ReflectionExtension</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionfunctionabstract.getextensionname.php" class="methodname" style="color:#CC7832">getExtensionName</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionfunctionabstract.getfilename.php" class="methodname" style="color:#CC7832">getFileName</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionfunctionabstract.getname.php" class="methodname" style="color:#CC7832">getName</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionfunctionabstract.getnamespacename.php" class="methodname" style="color:#CC7832">getNamespaceName</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionfunctionabstract.getnumberofparameters.php" class="methodname" style="color:#CC7832">getNumberOfParameters</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">int</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionfunctionabstract.getnumberofrequiredparameters.php" class="methodname" style="color:#CC7832">getNumberOfRequiredParameters</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">int</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionfunctionabstract.getparameters.php" class="methodname" style="color:#CC7832">getParameters</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">array</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionfunctionabstract.getreturntype.php" class="methodname" style="color:#CC7832">getReturnType</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/class.reflectiontype.php" class="type ReflectionType" style="color:#EAB766">ReflectionType</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionfunctionabstract.getshortname.php" class="methodname" style="color:#CC7832">getShortName</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionfunctionabstract.getstartline.php" class="methodname" style="color:#CC7832">getStartLine</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">int</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionfunctionabstract.getstaticvariables.php" class="methodname" style="color:#CC7832">getStaticVariables</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">array</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionfunctionabstract.hasreturntype.php" class="methodname" style="color:#CC7832">hasReturnType</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionfunctionabstract.innamespace.php" class="methodname" style="color:#CC7832">inNamespace</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionfunctionabstract.isclosure.php" class="methodname" style="color:#CC7832">isClosure</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionfunctionabstract.isdeprecated.php" class="methodname" style="color:#CC7832">isDeprecated</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionfunctionabstract.isgenerator.php" class="methodname" style="color:#CC7832">isGenerator</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionfunctionabstract.isinternal.php" class="methodname" style="color:#CC7832">isInternal</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionfunctionabstract.isuserdefined.php" class="methodname" style="color:#CC7832">isUserDefined</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionfunctionabstract.isvariadic.php" class="methodname" style="color:#CC7832">isVariadic</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionfunctionabstract.returnsreference.php" class="methodname" style="color:#CC7832">returnsReference</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">abstract</span> <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionfunctionabstract.tostring.php" class="methodname" style="color:#CC7832">__toString</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><span class="type void" style="color:#EAB766">void</span></span></div>     }</div>     </div>        <div class="section" id="reflectionfunctionabstract.props">    <h2 class="title">Properties</h2>    <dl>            <dt id="reflectionfunctionabstract.props.name"><var class="varname"><var class="varname">name</var></var></dt>       <dd>        <p class="para">        Name of the function. Read-only, throws        <a href="https://www.php.net/manual/en/class.reflectionexception.php" class="classname">ReflectionException</a> in attempt to write.       </p>      </dd>          </dl>    </div>     </div>                                                                                                                                                                                                  <h2>Table of Contents</h2><ul class="chunklist chunklist_reference"><li>{@link ReflectionFunctionAbstract::__clone} — Clones function</li><li>{@link ReflectionFunctionAbstract::getClosureScopeClass} — Returns the scope associated to the closure</li><li>{@link ReflectionFunctionAbstract::getClosureThis} — Returns this pointer bound to closure</li><li>{@link ReflectionFunctionAbstract::getDocComment} — Gets doc comment</li><li>{@link ReflectionFunctionAbstract::getEndLine} — Gets end line number</li><li>{@link ReflectionFunctionAbstract::getExtension} — Gets extension info</li><li>{@link ReflectionFunctionAbstract::getExtensionName} — Gets extension name</li><li>{@link ReflectionFunctionAbstract::getFileName} — Gets file name</li><li>{@link ReflectionFunctionAbstract::getName} — Gets function name</li><li>{@link ReflectionFunctionAbstract::getNamespaceName} — Gets namespace name</li><li>{@link ReflectionFunctionAbstract::getNumberOfParameters} — Gets number of parameters</li><li>{@link ReflectionFunctionAbstract::getNumberOfRequiredParameters} — Gets number of required parameters</li><li>{@link ReflectionFunctionAbstract::getParameters} — Gets parameters</li><li>{@link ReflectionFunctionAbstract::getReturnType} — Gets the specified return type of a function</li><li>{@link ReflectionFunctionAbstract::getShortName} — Gets function short name</li><li>{@link ReflectionFunctionAbstract::getStartLine} — Gets starting line number</li><li>{@link ReflectionFunctionAbstract::getStaticVariables} — Gets static variables</li><li>{@link ReflectionFunctionAbstract::hasReturnType} — Checks if the function has a specified return type</li><li>{@link ReflectionFunctionAbstract::inNamespace} — Checks if function in namespace</li><li>{@link ReflectionFunctionAbstract::isClosure} — Checks if closure</li><li>{@link ReflectionFunctionAbstract::isDeprecated} — Checks if deprecated</li><li>{@link ReflectionFunctionAbstract::isGenerator} — Returns whether this function is a generator</li><li>{@link ReflectionFunctionAbstract::isInternal} — Checks if is internal</li><li>{@link ReflectionFunctionAbstract::isUserDefined} — Checks if user defined</li><li>{@link ReflectionFunctionAbstract::isVariadic} — Checks if the function is variadic</li><li>{@link ReflectionFunctionAbstract::returnsReference} — Checks if returns reference</li><li>{@link ReflectionFunctionAbstract::__toString} — To string</li></ul> </div>
*/
abstract class ReflectionFunctionAbstract implements Reflector {
	public $name;


	/**
	 * Clones function
	 * @link http://php.net/manual/en/reflectionfunctionabstract.clone.php
	 * @return void
	 * @since 5.0
	 */
	final private function __clone () {}

	/**
	 * To string
	 * @link http://php.net/manual/en/reflectionfunctionabstract.tostring.php
	 * @since 5.0
	 */
	abstract public function __toString ();

	/**
	 * Checks if function in namespace
	 * @link http://php.net/manual/en/reflectionfunctionabstract.innamespace.php
	 * @return bool <b>TRUE</b> if it's in a namespace, otherwise <b>FALSE</b>
	 * @since 5.3.0
	 */
	public function inNamespace () {}

	/**
	 * Checks if closure
	 * @link http://php.net/manual/en/reflectionfunctionabstract.isclosure.php
	 * @return bool <b>TRUE</b> if it's a closure, otherwise <b>FALSE</b>
	 * @since 5.3.0
	 */
	public function isClosure () {}

	/**
	 * Checks if deprecated
	 * @link http://php.net/manual/en/reflectionfunctionabstract.isdeprecated.php
	 * @return bool <b>TRUE</b> if it's deprecated, otherwise <b>FALSE</b>
	 * @since 5.0
	 */
	public function isDeprecated () {}

	/**
	 * Checks if is internal
	 * @link http://php.net/manual/en/reflectionfunctionabstract.isinternal.php
	 * @return bool <b>TRUE</b> if it's internal, otherwise <b>FALSE</b>
	 * @since 5.0
	 */
	public function isInternal () {}

	/**
	 * Checks if user defined
	 * @link http://php.net/manual/en/reflectionfunctionabstract.isuserdefined.php
	 * @return bool <b>TRUE</b> if it's user-defined, otherwise false;
	 * @since 5.0
	 */
	public function isUserDefined () {}

	/**
	 * Returns this pointer bound to closure
	 * @link http://php.net/manual/en/reflectionfunctionabstract.getclosurethis.php
	 * @return object $this pointer.
	 * Returns <b>NULL</b> in case of an error.
	 * @since 5.0
	 */
	public function getClosureThis () {}

	/**
	 * Returns the scope associated to the closure
	 * @link http://php.net/manual/en/reflectionfunctionabstract.getclosurescopeclass.php
	 * @return ReflectionClass Returns the class on success.
	 * Returns <b>NULL</b> on failure.
	 * @since 5.4.0
	 */
	public function getClosureScopeClass () {}

	/**
	 * Gets doc comment
	 * @link http://php.net/manual/en/reflectionfunctionabstract.getdoccomment.php
	 * @return string|bool The doc comment if it exists, otherwise <b>FALSE</b>
	 * @since 5.1.0
	 */
	public function getDocComment () {}

	/**
	 * Gets end line number
	 * @link http://php.net/manual/en/reflectionfunctionabstract.getendline.php
	 * @return int The ending line number of the user defined function, or <b>FALSE</b> if unknown.
	 * @since 5.0
	 */
	public function getEndLine () {}

	/**
	 * Gets extension info
	 * @link http://php.net/manual/en/reflectionfunctionabstract.getextension.php
	 * @return ReflectionExtension The extension information, as a <b>ReflectionExtension</b> object.
	 * @since 5.0
	 */
	public function getExtension () {}

	/**
	 * Gets extension name
	 * @link http://php.net/manual/en/reflectionfunctionabstract.getextensionname.php
	 * @return string The extensions name.
	 * @since 5.0
	 */
	public function getExtensionName () {}

	/**
	 * Gets file name
	 * @link http://php.net/manual/en/reflectionfunctionabstract.getfilename.php
	 * @return string The file name.
	 * @since 5.0
	 */
	public function getFileName () {}

	/**
	 * Gets function name
	 * @link http://php.net/manual/en/reflectionfunctionabstract.getname.php
	 * @return string The name of the function.
	 * @since 5.0
	 */
	public function getName () {}

	/**
	 * Gets namespace name
	 * @link http://php.net/manual/en/reflectionfunctionabstract.getnamespacename.php
	 * @return string The namespace name.
	 * @since 5.3.0
	 */
	public function getNamespaceName () {}

	/**
	 * Gets number of parameters
	 * @link http://php.net/manual/en/reflectionfunctionabstract.getnumberofparameters.php
	 * @return int The number of parameters.
	 * @since 5.0.3
	 */
	public function getNumberOfParameters () {}

	/**
	 * Gets number of required parameters
	 * @link http://php.net/manual/en/reflectionfunctionabstract.getnumberofrequiredparameters.php
	 * @return int The number of required parameters.
	 * @since 5.0.3
	 */
	public function getNumberOfRequiredParameters () {}

	/**
	 * Gets parameters
	 * @link http://php.net/manual/en/reflectionfunctionabstract.getparameters.php
	 * @return ReflectionParameter[] The parameters, as a ReflectionParameter objects.
	 * @since 5.0
	 */
	public function getParameters () {}

	/**
	 * Gets the specified return type of a function
	 * @link http://php.net/manual/en/reflectionfunctionabstract.getreturntype.php
	 * @return ReflectionType|NULL Returns a ReflectionType object if a return type is specified, NULL otherwise.
	 * @since 7.0
	 */
	public function getReturnType () {}

	/**
	 * Gets function short name
	 * @link http://php.net/manual/en/reflectionfunctionabstract.getshortname.php
	 * @return string The short name of the function.
	 * @since 5.3.0
	 */
	public function getShortName () {}

	/**
	 * Gets starting line number
	 * @link http://php.net/manual/en/reflectionfunctionabstract.getstartline.php
	 * @return int The starting line number.
	 * @since 5.0
	 */
	public function getStartLine () {}

	/**
	 * Gets static variables
	 * @link http://php.net/manual/en/reflectionfunctionabstract.getstaticvariables.php
	 * @return array An array of static variables.
	 * @since 5.0
	 */
	public function getStaticVariables () {}

	/**
	 * Checks if the function has a specified return type
	 * @link http://php.net/manual/en/reflectionfunctionabstract.hasreturntype.php
	 * @return bool Returns TRUE if the function is a specified return type, otherwise FALSE.
	 * @since 7.0
	 */
	public function hasReturnType () {}

	/**
	 * Checks if returns reference
	 * @link http://php.net/manual/en/reflectionfunctionabstract.returnsreference.php
	 * @return bool <b>TRUE</b> if it returns a reference, otherwise <b>FALSE</b>
	 * @since 5.0
	 */
	public function returnsReference () {}

	/**
	 * Returns whether this function is a generator
	 * @link http://php.net/manual/en/reflectionfunctionabstract.isgenerator.php
	 * @return bool <b>TRUE</b> if the function is generator, otherwise <b>FALSE</b>
	 * @since 5.5.0
	 */
	public function isGenerator() {}

	/**
	 * Returns whether this function is variadic
	 * @link http://php.net/manual/en/reflectionfunctionabstract.isvariadic.php
	 * @return bool <b>TRUE</b> if the function is variadic, otherwise <b>FALSE</b>
	 * @since 5.6.0
	 */
	public function isVariadic() {}
}

/**
*<div id="class.reflectionfunction" class="reference">   <h1 class="title">The ReflectionFunction class</h1>     <div class="partintro"><p class="verinfo">(PHP 5, PHP 7)</p>     <div class="section" id="reflectionfunction.intro">    <h2 class="title">Introduction</h2>    <p class="para">     The <strong class="classname">ReflectionFunction</strong> class reports     information about a function.    </p>   </div>     <div class="section" id="reflectionfunction.synopsis">    <h2 class="title">Class synopsis</h2>      <div class="classsynopsis">     <div class="ooclass"></div>       <div class="classsynopsisinfo">      <span class="ooclass">       <strong class="classname">ReflectionFunction</strong>      </span>            <span class="ooclass">       <span class="modifier">extends</span>       <a href="https://www.php.net/manual/en/class.reflectionfunctionabstract.php" class="classname">ReflectionFunctionAbstract</a>      </span>            <span class="oointerface">implements        <span class="interfacename"><a href="https://www.php.net/manual/en/class.reflector.php" class="interfacename">Reflector</a></span>      </span>      {</div>      <div class="classsynopsisinfo classsynopsisinfo_comment">// Constants </div>     <div class="fieldsynopsis">      <span class="modifier">const</span>      <span class="type" style="color:#EAB766">integer</span>       <var class="fieldsynopsis_varname">{@link <var class="varname">IS_DEPRECATED</var>}</var>      <span class="initializer"> = 262144</span>     ;</div>       <div class="classsynopsisinfo classsynopsisinfo_comment">// Properties </div>     <div class="fieldsynopsis">      <span class="modifier">public</span>       <var class="varname">{@link $<var class="varname">name</var>}</var>     ;</div>            <div class="classsynopsisinfo classsynopsisinfo_comment">// Methods </div>     <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link __construct}</span>     ( <span class="methodparam"><span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span> <span class="parameter" style="color:#2EACF9">$name</span></span>    )</div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="modifier">static</span> <span class="methodname" style="color:#CC7832">{@link export}</span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$return</span></span>   ] ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link getClosure}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/class.closure.php" class="type Closure" style="color:#EAB766">Closure</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link invoke}</span>     ([ <span class="methodparam"><span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span> <span class="parameter" style="color:#2EACF9">$...</span></span>   ] ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link invokeArgs}</span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">array</span> <span class="parameter" style="color:#2EACF9">$args</span></span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link isDisabled}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link __toString}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div>           <div class="classsynopsisinfo classsynopsisinfo_comment">// Inherited methods </div>     <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">final</span> <span class="modifier">private</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::__clone}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><span class="type void" style="color:#EAB766">void</span></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::getClosureScopeClass}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/class.reflectionclass.php" class="type ReflectionClass" style="color:#EAB766">ReflectionClass</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::getClosureThis}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">object</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::getDocComment}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::getEndLine}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">int</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::getExtension}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/class.reflectionextension.php" class="type ReflectionExtension" style="color:#EAB766">ReflectionExtension</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::getExtensionName}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::getFileName}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::getName}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::getNamespaceName}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::getNumberOfParameters}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">int</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::getNumberOfRequiredParameters}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">int</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::getParameters}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">array</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::getReturnType}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/class.reflectiontype.php" class="type ReflectionType" style="color:#EAB766">ReflectionType</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::getShortName}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::getStartLine}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">int</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::getStaticVariables}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">array</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::hasReturnType}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::inNamespace}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::isClosure}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::isDeprecated}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::isGenerator}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::isInternal}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::isUserDefined}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::isVariadic}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::returnsReference}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">abstract</span> <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::__toString}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><span class="type void" style="color:#EAB766">void</span></span></div>      }</div>     </div>        <div class="section" id="reflectionfunction.props">    <h2 class="title">Properties</h2>    <dl>            <dt id="reflectionfunction.props.name"><var class="varname"><var class="varname">name</var></var></dt>       <dd>        <p class="para">        Name of the function. Read-only, throws        <a href="https://www.php.net/manual/en/class.reflectionexception.php" class="classname">ReflectionException</a> in attempt to write.       </p>      </dd>          </dl>    </div>         <div class="section" id="reflectionfunction.constants">    <h2 class="title">Predefined Constants</h2>    <div class="section" id="reflectionfunction.constants.modifiers">     <h2 class="title">ReflectionFunction Modifiers</h2>     <dl>               <dt id="reflectionfunction.constants.is-deprecated"><strong><span>ReflectionFunction::IS_DEPRECATED</span></strong></dt>        <dd>         <p class="para">         Indicates deprecated functions.        </p>       </dd>             </dl>     </div>   </div>     </div>                                                      <h2>Table of Contents</h2><ul class="chunklist chunklist_reference"><li>{@link ReflectionFunction::__construct} — Constructs a ReflectionFunction object</li><li>{@link ReflectionFunction::export} — Exports function</li><li>{@link ReflectionFunction::getClosure} — Returns a dynamically created closure for the function</li><li>{@link ReflectionFunction::invoke} — Invokes function</li><li>{@link ReflectionFunction::invokeArgs} — Invokes function args</li><li>{@link ReflectionFunction::isDisabled} — Checks if function is disabled</li><li>{@link ReflectionFunction::__toString} — To string</li></ul> </div>
*/
class ReflectionFunction extends ReflectionFunctionAbstract implements Reflector {
	const IS_DEPRECATED = 262144;

	public $name;


	/**
	 * Constructs a ReflectionFunction object
	 * @link http://php.net/manual/en/reflectionfunction.construct.php
	 * @param mixed $name <p>
	 * The name of the function to reflect or a closure.
	 * </p>
	 * @throws \ReflectionException if the function does not exist.
	 * @since 5.0
	 */
	public function __construct ($name) {}

	/**
	 * To string
	 * @link http://php.net/manual/en/reflectionfunction.tostring.php
	 * @return string <b>ReflectionFunction::export</b>-like output for
	 * the function.
	 * @since 5.0
	 */
	public function __toString () {}

	/**
	 * Exports function
	 * @link http://php.net/manual/en/reflectionfunction.export.php
	 * @param string $name <p>
	 * The reflection to export.
	 * </p>
	 * @param string $return [optional] <p>
	 * Setting to <b>TRUE</b> will return the export,
	 * as opposed to emitting it. Setting to <b>FALSE</b> (the default) will do the opposite.
	 * </p>
	 * @return string If the <i>return</i> parameter
	 * is set to <b>TRUE</b>, then the export is returned as a string,
	 * otherwise <b>NULL</b> is returned.
	 * @since 5.0
	 */
	public static function export ($name, $return = null) {}

	/**
	 * Checks if function is disabled
	 * @link http://php.net/manual/en/reflectionfunction.isdisabled.php
	 * @return bool <b>TRUE</b> if it's disable, otherwise <b>FALSE</b>
	 * @since 5.0
	 */
	public function isDisabled () {}

	/**
	 * Invokes function
	 * @link http://php.net/manual/en/reflectionfunction.invoke.php
	 * @param string $args [optional] <p>
	 * The passed in argument list. It accepts a variable number of
	 * arguments which are passed to the function much like
	 * call_user_func is.
	 * </p>
	 * @return mixed 
	 * @since 5.0
	 */
	public function invoke ($args = null) {}

	/**
	 * Invokes function args
	 * @link http://php.net/manual/en/reflectionfunction.invokeargs.php
	 * @param array $args <p>
	 * The passed arguments to the function as an array, much like
	 * <b>call_user_func_array</b> works.
	 * </p>
	 * @return mixed the result of the invoked function
	 * @since 5.1.0
	 */
	public function invokeArgs (array $args) {}

	/**
	 * Returns a dynamically created closure for the function
	 * @link http://php.net/manual/en/reflectionfunction.getclosure.php
	 * @return Closure <b>Closure</b>.
	 * Returns <b>NULL</b> in case of an error.
	 * @since 5.0
	 */
	public function getClosure () {}

}

/**
*<div id="class.reflectionparameter" class="reference">   <h1 class="title">The ReflectionParameter class</h1>     <div class="partintro"><p class="verinfo">(PHP 5, PHP 7)</p>     <div class="section" id="reflectionparameter.intro">    <h2 class="title">Introduction</h2>    <p class="para">     The <strong class="classname">ReflectionParameter</strong> class retrieves     information about function&#039;s or method&#039;s parameters.    </p>    <p class="para">     To introspect function parameters, first create an instance     of the {@link ReflectionFunction} or     <a href="https://www.php.net/manual/en/class.reflectionmethod.php" class="classname">ReflectionMethod</a> classes and then use their     <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::getParameters()}</span> method     to retrieve an array of parameters.    </p>   </div>     <div class="section" id="reflectionparameter.synopsis">    <h2 class="title">Class synopsis</h2>      <div class="classsynopsis">     <div class="ooclass"></div>       <div class="classsynopsisinfo">      <span class="ooclass">       <strong class="classname">ReflectionParameter</strong>      </span>            <span class="oointerface">implements        <span class="interfacename"><a href="https://www.php.net/manual/en/class.reflector.php" class="interfacename">Reflector</a></span>      </span>      {</div>      <div class="classsynopsisinfo classsynopsisinfo_comment">// Properties </div>     <div class="fieldsynopsis">      <span class="modifier">public</span>       <var class="varname"><a href="https://www.php.net/manual/en/class.reflectionparameter.php#reflectionparameter.props.name">$<var class="varname">name</var></a></var>     ;</div>            <div class="classsynopsisinfo classsynopsisinfo_comment">// Methods </div>     <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionparameter.allowsnull.php" class="methodname" style="color:#CC7832">allowsNull</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionparameter.canbepassedbyvalue.php" class="methodname" style="color:#CC7832">canBePassedByValue</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">final</span> <span class="modifier">private</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionparameter.clone.php" class="methodname" style="color:#CC7832">__clone</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><span class="type void" style="color:#EAB766">void</span></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionparameter.construct.php" class="methodname" style="color:#CC7832">__construct</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$function</span></span>    , <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$parameter</span></span>    )</div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="modifier">static</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionparameter.export.php" class="methodname" style="color:#CC7832">export</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$function</span></span>    , <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$parameter</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">bool</span> <span class="parameter" style="color:#2EACF9">$return</span></span>   ] ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionparameter.getclass.php" class="methodname" style="color:#CC7832">getClass</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/class.reflectionclass.php" class="type ReflectionClass" style="color:#EAB766">ReflectionClass</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionparameter.getdeclaringclass.php" class="methodname" style="color:#CC7832">getDeclaringClass</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/class.reflectionclass.php" class="type ReflectionClass" style="color:#EAB766">ReflectionClass</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link getDeclaringFunction}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/class.reflectionfunctionabstract.php" class="type ReflectionFunctionAbstract" style="color:#EAB766">ReflectionFunctionAbstract</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionparameter.getdefaultvalue.php" class="methodname" style="color:#CC7832">getDefaultValue</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionparameter.getdefaultvalueconstantname.php" class="methodname" style="color:#CC7832">getDefaultValueConstantName</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionparameter.getname.php" class="methodname" style="color:#CC7832">getName</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionparameter.getposition.php" class="methodname" style="color:#CC7832">getPosition</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">int</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionparameter.gettype.php" class="methodname" style="color:#CC7832">getType</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/class.reflectiontype.php" class="type ReflectionType" style="color:#EAB766">ReflectionType</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionparameter.hastype.php" class="methodname" style="color:#CC7832">hasType</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionparameter.isarray.php" class="methodname" style="color:#CC7832">isArray</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionparameter.iscallable.php" class="methodname" style="color:#CC7832">isCallable</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionparameter.isdefaultvalueavailable.php" class="methodname" style="color:#CC7832">isDefaultValueAvailable</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionparameter.isdefaultvalueconstant.php" class="methodname" style="color:#CC7832">isDefaultValueConstant</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionparameter.isoptional.php" class="methodname" style="color:#CC7832">isOptional</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionparameter.ispassedbyreference.php" class="methodname" style="color:#CC7832">isPassedByReference</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionparameter.isvariadic.php" class="methodname" style="color:#CC7832">isVariadic</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionparameter.tostring.php" class="methodname" style="color:#CC7832">__toString</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div>     }</div>     </div>        <div class="section" id="reflectionparameter.props">    <h2 class="title">Properties</h2>    <dl>            <dt id="reflectionparameter.props.name"><var class="varname"><var class="varname">name</var></var></dt>       <dd>        <p class="para">        Name of the parameter. Read-only, throws        <a href="https://www.php.net/manual/en/class.reflectionexception.php" class="classname">ReflectionException</a> in attempt to write.       </p>      </dd>          </dl>    </div>     </div>                                                                                                                                                               <h2>Table of Contents</h2><ul class="chunklist chunklist_reference"><li>{@link ReflectionParameter::allowsNull} — Checks if null is allowed</li><li>{@link ReflectionParameter::canBePassedByValue} — Returns whether this parameter can be passed by value</li><li>{@link ReflectionParameter::__clone} — Clone</li><li>{@link ReflectionParameter::__construct} — Construct</li><li>{@link ReflectionParameter::export} — Exports</li><li>{@link ReflectionParameter::getClass} — Get the type hinted class</li><li>{@link ReflectionParameter::getDeclaringClass} — Gets declaring class</li><li>{@link ReflectionParameter::getDeclaringFunction} — Gets declaring function</li><li>{@link ReflectionParameter::getDefaultValue} — Gets default parameter value</li><li>{@link ReflectionParameter::getDefaultValueConstantName} — Returns the default value's constant name if default value is constant or null</li><li>{@link ReflectionParameter::getName} — Gets parameter name</li><li>{@link ReflectionParameter::getPosition} — Gets parameter position</li><li>{@link ReflectionParameter::getType} — Gets a parameter's type</li><li>{@link ReflectionParameter::hasType} — Checks if parameter has a type</li><li>{@link ReflectionParameter::isArray} — Checks if parameter expects an array</li><li>{@link ReflectionParameter::isCallable} — Returns whether parameter MUST be callable</li><li>{@link ReflectionParameter::isDefaultValueAvailable} — Checks if a default value is available</li><li>{@link ReflectionParameter::isDefaultValueConstant} — Returns whether the default value of this parameter is a constant</li><li>{@link ReflectionParameter::isOptional} — Checks if optional</li><li>{@link ReflectionParameter::isPassedByReference} — Checks if passed by reference</li><li>{@link ReflectionParameter::isVariadic} — Checks if the parameter is variadic</li><li>{@link ReflectionParameter::__toString} — To string</li></ul> </div>
*/
class ReflectionParameter implements Reflector {
	public $name;


	/**
	 * Clone
	 * @link http://php.net/manual/en/reflectionparameter.clone.php
	 * @return void
	 * @since 5.0
	 */
	final private function __clone () {}

	/**
	 * Exports
	 * @link http://php.net/manual/en/reflectionparameter.export.php
	 * @param string $function <p>
	 * The function name.
	 * </p>
	 * @param string $parameter <p>
	 * The parameter name.
	 * </p>
	 * @param bool $return [optional] <p>
	 * Setting to <b>TRUE</b> will return the export,
	 * as opposed to emitting it. Setting to <b>FALSE</b> (the default) will do the opposite.
	 * </p>
	 * @return string The exported reflection.
	 * @since 5.0
	 */
	public static function export ($function, $parameter, $return = null) {}

	/**
	 * Construct
	 * @link http://php.net/manual/en/reflectionparameter.construct.php
	 * @param string $function <p>
	 * The function to reflect parameters from.
	 * </p>
	 * @param string $parameter <p>
	 * The parameter.
	 * </p>
	 * @throws \ReflectionException if the function or parameter does not exist.
	 * @since 5.0
	 */
	public function __construct ($function, $parameter) {}

	/**
	 * To string
	 * @link http://php.net/manual/en/reflectionparameter.tostring.php
	 * @return string
	 * @since 5.0
	 */
	public function __toString () {}

	/**
	 * Gets parameter name
	 * @link http://php.net/manual/en/reflectionparameter.getname.php
	 * @return string The name of the reflected parameter.
	 * @since 5.0
	 */
	public function getName () {}

	/**
	 * Gets a parameter's type
	 * @link http://php.net/manual/en/reflectionparameter.gettype.php
	 * @return ReflectionType|NULL Returns a ReflectionType object if a parameter type is specified, NULL otherwise.
	 * @since 7.0
	 */
/**
*<div id="function.gettype" class="refentry">  <div class="refnamediv">   <h1 class="refname">gettype</h1>   <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">gettype</span> &mdash; <span class="dc-title">Get the type of a variable</span></p>   </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.gettype-description">   <h3 class="title">Description</h3>   <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><strong>gettype</strong></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span> <span class="parameter" style="color:#2EACF9">$var</span></span>    ) : <span class="type" style="color:#EAB766">string</span></div>    <p class="para rdfs-comment">    Returns the type of the PHP variable <span class="parameter" style="color:#2EACF9">var</span>. For    type checking, use <em>is_*</em> functions.   </p>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.gettype-parameters">   <h3 class="title">Parameters</h3>   <span>    <dl>            <dt> <span class="parameter" style="color:#2EACF9">var</span></dt>       <dd>        <p class="para">        The variable being type checked.       </p>      </dd>          </dl>    </span>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.gettype-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    Possible values for the returned string are:    <ul class="itemizedlist">     <li class="listitem">      <span class="simpara">       &quot;<span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.boolean.php" class="type boolean" style="color:#EAB766">boolean</a></span>&quot;      </span>     </li>     <li class="listitem">      <span class="simpara">       &quot;<span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.integer.php" class="type integer" style="color:#EAB766">integer</a></span>&quot;      </span>     </li>     <li class="listitem">      <span class="simpara">       &quot;<span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.float.php" class="type double" style="color:#EAB766">double</a></span>&quot; (for historical reasons &quot;double&quot; is       returned in case of a <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.float.php" class="type float" style="color:#EAB766">float</a></span>, and not simply       &quot;float&quot;)      </span>     </li>     <li class="listitem">      <span class="simpara">       &quot;<span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.string.php" class="type string" style="color:#EAB766">string</a></span>&quot;      </span>     </li>     <li class="listitem">      <span class="simpara">       &quot;<span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.array.php" class="type array" style="color:#EAB766">array</a></span>&quot;      </span>     </li>     <li class="listitem">      <span class="simpara">       &quot;<span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.object.php" class="type object" style="color:#EAB766">object</a></span>&quot;      </span>     </li>     <li class="listitem">      <span class="simpara">       &quot;<span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.resource.php" class="type resource" style="color:#EAB766">resource</a></span>&quot;      </span>     </li>     <li class="listitem">      <span class="simpara">       &quot;resource (closed)&quot; as of PHP 7.2.0      </span>     </li>     <li class="listitem">      <span class="simpara">       &quot;<span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.null.php" class="type NULL" style="color:#EAB766">NULL</a></span>&quot;      </span>     </li>     <li class="listitem">      <span class="simpara">       &quot;unknown type&quot;      </span>     </li>    </ul>   </p>  </div>     <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.gettype-examples">   <h3 class="title">Examples</h3>   <span>    <div class="example" id="example-6552">     <p><strong>Example #1 <span class="function"><strong style="color:#CC7832">gettype()</strong></span> example</strong></p>     <div class="example-contents"> <div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"> <span style="color: #9876AA">&lt;?php<br /><br />$data&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #9876AA">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">1.</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">NULL</span><span style="color: #007700">,&nbsp;new&nbsp;</span><span style="color: #9876AA">stdClass</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'foo'</span><span style="color: #007700">);<br /><br />foreach&nbsp;(</span><span style="color: #9876AA">$data&nbsp;</span><span style="color: #007700">as&nbsp;</span><span style="color: #9876AA">$value</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #9876AA">gettype</span><span style="color: #007700">(</span><span style="color: #9876AA">$value</span><span style="color: #007700">),&nbsp;</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br />}<br /><br /></span><span style="color: #9876AA">?&gt;</span> </span> </span></div>     </div>      <div class="example-contents"><p>The above example will output something similar to:</p></div>     <div class="example-contents screen" style="background:black;padding-left:5px;"> <div class="cdata"><span> integer double NULL object string </span></div>     </div>    </div>   </span>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 changelog" id="refsect1-function.gettype-changelog">   <h3 class="title">Changelog</h3>   <span>    <table class="doctable informaltable">           <thead>       <tr>        <th>Version</th>        <th>Description</th>       </tr>       </thead>       <tbody class="tbody">       <tr>        <td>7.2.0</td>        <td>         Closed resources are now reported as <em>&#039;resource (closed)&#039;</em>.          Previously the returned value for closed resources were <em>&#039;unknown type&#039;</em>.        </td>       </tr>       </tbody>         </table>    </span>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.gettype-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><span class="function">{@link settype()} - Set the type of a variable</span></li>     <li class="member"><span class="function">{@link get_class()} - Returns the name of the class of an object</span></li>     <li class="member"><span class="function">{@link is_array()} - Finds whether a variable is an array</span></li>     <li class="member"><span class="function">{@link is_bool()} - Finds out whether a variable is a boolean</span></li>     <li class="member"><span class="function">{@link is_callable()} - Verify that the contents of a variable can be called as a function</span></li>     <li class="member"><span class="function">{@link is_float()} - Finds whether the type of a variable is float</span></li>     <li class="member"><span class="function">{@link is_int()} - Find whether the type of a variable is integer</span></li>     <li class="member"><span class="function">{@link is_null()} - Finds whether a variable is NULL</span></li>     <li class="member"><span class="function">{@link is_numeric()} - Finds whether a variable is a number or a numeric string</span></li>     <li class="member"><span class="function">{@link is_object()} - Finds whether a variable is an object</span></li>     <li class="member"><span class="function">{@link is_resource()} - Finds whether a variable is a resource</span></li>     <li class="member"><span class="function">{@link is_scalar()} - Finds whether a variable is a scalar</span></li>     <li class="member"><span class="function">{@link is_string()} - Find whether the type of a variable is string</span></li>     <li class="member"><span class="function">{@link function_exists()} - Return TRUE if the given function has been defined</span></li>     <li class="member"><span class="function">{@link method_exists()} - Checks if the class method exists</span></li>    </ul>   </span>  </div>  </div>
*/
	public function getType() {}

	/**
	 * Checks if the parameter has a type associated with it.
	 * @link http://php.net/manual/en/reflectionparameter.hastype.php
	 * @return bool TRUE if a type is specified, FALSE otherwise.
	 * @since 7.0
	 */
	public function hasType () {}


	/**
	 * Checks if passed by reference
	 * @link http://php.net/manual/en/reflectionparameter.ispassedbyreference.php
	 * @return bool <b>TRUE</b> if the parameter is passed in by reference, otherwise <b>FALSE</b>
	 * @since 5.0
	 */
	public function isPassedByReference () {}

	/**
	 * Returns whether this parameter can be passed by value
	 * @link http://php.net/manual/en/reflectionparameter.canbepassedbyvalue.php
	 * @return bool <b>TRUE</b> if the parameter can be passed by value, <b>FALSE</b> otherwise.
	 * Returns <b>NULL</b> in case of an error.
	 * @since 5.4.0
	 */
	public function canBePassedByValue () {}

	/**
	 * Gets declaring function
	 * @link http://php.net/manual/en/reflectionparameter.getdeclaringfunction.php
	 * @return ReflectionFunctionAbstract A <b>ReflectionFunctionAbstract</b> object.
	 * @since 5.2.3
	 */
	public function getDeclaringFunction () {}

	/**
	 * Gets declaring class
	 * @link http://php.net/manual/en/reflectionparameter.getdeclaringclass.php
	 * @return ReflectionClass A <b>ReflectionClass</b> object.
	 * @since 5.0
	 */
	public function getDeclaringClass () {}

	/**
	 * Get class
	 * @link http://php.net/manual/en/reflectionparameter.getclass.php
	 * @return ReflectionClass A <b>ReflectionClass</b> object.
	 * @since 5.0
	 */
	public function getClass () {}

	/**
	 * Checks if parameter expects an array
	 * @link http://php.net/manual/en/reflectionparameter.isarray.php
	 * @return bool <b>TRUE</b> if an array is expected, <b>FALSE</b> otherwise.
	 * @since 5.1.0
	 */
	public function isArray () {}

    /**
     * Returns whether parameter MUST be callable
     * @link http://php.net/manual/en/reflectionparameter.iscallable.php
     * @return bool Returns TRUE if the parameter is callable, FALSE if it is not or NULL on failure.
	 * @since 5.4.0
/**
*<div id="reflectionparameter.iscallable" class="refentry">  <div class="refnamediv">   <h1 class="refname">ReflectionParameter::isCallable</h1>   <p class="verinfo">(PHP 5 &gt;= 5.4.0, PHP 7)</p><p class="refpurpose"><span class="refname">ReflectionParameter::isCallable</span> &mdash; <span class="dc-title">Returns whether parameter MUST be callable</span></p>   </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-reflectionparameter.iscallable-description">   <h3 class="title">Description</h3>   <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><strong>ReflectionParameter::isCallable</strong></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div>    <p class="para rdfs-comment">    </p>    <div class="warning"><strong class="warning">Warning</strong><p class="simpara">This function is currently not documented; only its argument list is available. </p></div>   </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-reflectionparameter.iscallable-parameters">   <h3 class="title">Parameters</h3>   <span>This function has no parameters.</span>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-reflectionparameter.iscallable-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    Returns <strong><span>TRUE</span></strong> if the parameter is <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.callable.php" class="type callable" style="color:#EAB766">callable</a></span>, <strong><span>FALSE</span></strong> if it is    not or <strong><span>NULL</span></strong> on failure.   </p>  </div>    </div>
*/
    public function isCallable () {}

	/**
	 * Checks if null is allowed
	 * @link http://php.net/manual/en/reflectionparameter.allowsnull.php
	 * @return bool <b>TRUE</b> if <b>NULL</b> is allowed, otherwise <b>FALSE</b>
	 * @since 5.0
	 */
	public function allowsNull () {}

	/**
	 * Gets parameter position
	 * @link http://php.net/manual/en/reflectionparameter.getposition.php
	 * @return int The position of the parameter, left to right, starting at position #0.
	 * @since 5.2.3
	 */
	public function getPosition () {}

	/**
	 * Checks if optional
	 * @link http://php.net/manual/en/reflectionparameter.isoptional.php
	 * @return bool <b>TRUE</b> if the parameter is optional, otherwise <b>FALSE</b>
	 * @since 5.0.3
	 */
	public function isOptional () {}

	/**
	 * Checks if a default value is available
	 * @link http://php.net/manual/en/reflectionparameter.isdefaultvalueavailable.php
	 * @return bool <b>TRUE</b> if a default value is available, otherwise <b>FALSE</b>
	 * @since 5.0.3
	 */
	public function isDefaultValueAvailable () {}

	/**
	 * Gets default parameter value
	 * @link http://php.net/manual/en/reflectionparameter.getdefaultvalue.php
	 * @return mixed The parameters default value.
	 * @since 5.0.3
	 */
	public function getDefaultValue () {}

    /**
	 * Returns whether the default value of this parameter is constant
	 * @return boolean
	 * @since 5.4.6
/**
*<div id="reflectionparameter.isdefaultvalueconstant" class="refentry">  <div class="refnamediv">   <h1 class="refname">ReflectionParameter::isDefaultValueConstant</h1>   <p class="verinfo">(PHP 5 &gt;= 5.4.6, PHP 7)</p><p class="refpurpose"><span class="refname">ReflectionParameter::isDefaultValueConstant</span> &mdash; <span class="dc-title">Returns whether the default value of this parameter is a constant</span></p>   </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-reflectionparameter.isdefaultvalueconstant-description">   <h3 class="title">Description</h3>   <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><strong>ReflectionParameter::isDefaultValueConstant</strong></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div>    <p class="para rdfs-comment">    Returns whether the default value of this parameter is a constant.   </p>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-reflectionparameter.isdefaultvalueconstant-parameters">   <h3 class="title">Parameters</h3>   <span>This function has no parameters.</span>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-reflectionparameter.isdefaultvalueconstant-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    Returns <strong><span>TRUE</span></strong> if the default value is constant, and <strong><span>FALSE</span></strong> otherwise.   </p>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-reflectionparameter.isdefaultvalueconstant-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><span class="methodname" style="color:#CC7832">{@link ReflectionParameter::getDefaultValueConstantName()} - Returns the default value's constant name if default value is constant or null</span></li>     <li class="member"><span class="methodname" style="color:#CC7832">{@link ReflectionParameter::isDefaultValueAvailable()} - Checks if a default value is available</span></li>    </ul>   </span>  </div>    </div>
*/
    public function isDefaultValueConstant () {}

    /**
	 * Returns the default value's constant name if default value is constant or null
     * @return string
	 * @since 5.4.6
     */
	public function getDefaultValueConstantName () {}

	/**
	 * Returns whether this function is variadic
	 * @link http://php.net/manual/en/reflectionparameter.isvariadic.php
	 * @return bool <b>TRUE</b> if the function is variadic, otherwise <b>FALSE</b>
	 * @since 5.6.0
	 */
	public function isVariadic() {}

}

/**
*<div id="class.reflectionmethod" class="reference">   <h1 class="title">The ReflectionMethod class</h1>     <div class="partintro"><p class="verinfo">(PHP 5, PHP 7)</p>     <div class="section" id="reflectionmethod.intro">    <h2 class="title">Introduction</h2>    <p class="para">     The <strong class="classname">ReflectionMethod</strong> class reports     information about a method.    </p>   </div>     <div class="section" id="reflectionmethod.synopsis">    <h2 class="title">Class synopsis</h2>      <div class="classsynopsis">     <div class="ooclass"></div>       <div class="classsynopsisinfo">      <span class="ooclass">       <strong class="classname">ReflectionMethod</strong>      </span>            <span class="ooclass">       <span class="modifier">extends</span>       <a href="https://www.php.net/manual/en/class.reflectionfunctionabstract.php" class="classname">ReflectionFunctionAbstract</a>      </span>            <span class="oointerface">implements        <span class="interfacename"><a href="https://www.php.net/manual/en/class.reflector.php" class="interfacename">Reflector</a></span>      </span>      {</div>      <div class="classsynopsisinfo classsynopsisinfo_comment">// Constants </div>     <div class="fieldsynopsis">      <span class="modifier">const</span>      <span class="type" style="color:#EAB766">integer</span>       <var class="fieldsynopsis_varname"><a href="https://www.php.net/manual/en/class.reflectionmethod.php#reflectionmethod.constants.is-static"><var class="varname">IS_STATIC</var></a></var>      <span class="initializer"> = 1</span>     ;</div>      <div class="fieldsynopsis">      <span class="modifier">const</span>      <span class="type" style="color:#EAB766">integer</span>       <var class="fieldsynopsis_varname"><a href="https://www.php.net/manual/en/class.reflectionmethod.php#reflectionmethod.constants.is-public"><var class="varname">IS_PUBLIC</var></a></var>      <span class="initializer"> = 256</span>     ;</div>      <div class="fieldsynopsis">      <span class="modifier">const</span>      <span class="type" style="color:#EAB766">integer</span>       <var class="fieldsynopsis_varname"><a href="https://www.php.net/manual/en/class.reflectionmethod.php#reflectionmethod.constants.is-protected"><var class="varname">IS_PROTECTED</var></a></var>      <span class="initializer"> = 512</span>     ;</div>      <div class="fieldsynopsis">      <span class="modifier">const</span>      <span class="type" style="color:#EAB766">integer</span>       <var class="fieldsynopsis_varname"><a href="https://www.php.net/manual/en/class.reflectionmethod.php#reflectionmethod.constants.is-private"><var class="varname">IS_PRIVATE</var></a></var>      <span class="initializer"> = 1024</span>     ;</div>      <div class="fieldsynopsis">      <span class="modifier">const</span>      <span class="type" style="color:#EAB766">integer</span>       <var class="fieldsynopsis_varname"><a href="https://www.php.net/manual/en/class.reflectionmethod.php#reflectionmethod.constants.is-abstract"><var class="varname">IS_ABSTRACT</var></a></var>      <span class="initializer"> = 2</span>     ;</div>      <div class="fieldsynopsis">      <span class="modifier">const</span>      <span class="type" style="color:#EAB766">integer</span>       <var class="fieldsynopsis_varname"><a href="https://www.php.net/manual/en/class.reflectionmethod.php#reflectionmethod.constants.is-final"><var class="varname">IS_FINAL</var></a></var>      <span class="initializer"> = 4</span>     ;</div>       <div class="classsynopsisinfo classsynopsisinfo_comment">// Properties </div>     <div class="fieldsynopsis">      <span class="modifier">public</span>       <var class="varname"><a href="https://www.php.net/manual/en/class.reflectionmethod.php#reflectionmethod.props.name">$<var class="varname">name</var></a></var>     ;</div>      <div class="fieldsynopsis">      <span class="modifier">public</span>       <var class="varname"><a href="https://www.php.net/manual/en/class.reflectionmethod.php#reflectionmethod.props.class">$<var class="varname">class</var></a></var>     ;</div>            <div class="classsynopsisinfo classsynopsisinfo_comment">// Methods </div>     <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionmethod.construct.php" class="methodname" style="color:#CC7832">__construct</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span> <span class="parameter" style="color:#2EACF9">$class</span></span>    , <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    )</div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="modifier">static</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionmethod.export.php" class="methodname" style="color:#CC7832">export</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$class</span></span>    , <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">bool</span> <span class="parameter" style="color:#2EACF9">$return</span><span class="initializer"> = <strong><span>FALSE</span></strong></span></span>   ] ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionmethod.getclosure.php" class="methodname" style="color:#CC7832">getClosure</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">object</span> <span class="parameter" style="color:#2EACF9">$object</span></span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/class.closure.php" class="type Closure" style="color:#EAB766">Closure</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionmethod.getdeclaringclass.php" class="methodname" style="color:#CC7832">getDeclaringClass</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/class.reflectionclass.php" class="type ReflectionClass" style="color:#EAB766">ReflectionClass</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionmethod.getmodifiers.php" class="methodname" style="color:#CC7832">getModifiers</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">int</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionmethod.getprototype.php" class="methodname" style="color:#CC7832">getPrototype</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/class.reflectionmethod.php" class="type ReflectionMethod" style="color:#EAB766">ReflectionMethod</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionmethod.invoke.php" class="methodname" style="color:#CC7832">invoke</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">object</span> <span class="parameter" style="color:#2EACF9">$object</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span> <span class="parameter" style="color:#2EACF9">$...</span></span>   ] ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionmethod.invokeargs.php" class="methodname" style="color:#CC7832">invokeArgs</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">object</span> <span class="parameter" style="color:#2EACF9">$object</span></span>    , <span class="methodparam"><span class="type" style="color:#EAB766">array</span> <span class="parameter" style="color:#2EACF9">$args</span></span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionmethod.isabstract.php" class="methodname" style="color:#CC7832">isAbstract</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionmethod.isconstructor.php" class="methodname" style="color:#CC7832">isConstructor</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionmethod.isdestructor.php" class="methodname" style="color:#CC7832">isDestructor</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionmethod.isfinal.php" class="methodname" style="color:#CC7832">isFinal</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionmethod.isprivate.php" class="methodname" style="color:#CC7832">isPrivate</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionmethod.isprotected.php" class="methodname" style="color:#CC7832">isProtected</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionmethod.ispublic.php" class="methodname" style="color:#CC7832">isPublic</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionmethod.isstatic.php" class="methodname" style="color:#CC7832">isStatic</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionmethod.setaccessible.php" class="methodname" style="color:#CC7832">setAccessible</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">bool</span> <span class="parameter" style="color:#2EACF9">$accessible</span></span>    ) : <span class="type" style="color:#EAB766"><span class="type void" style="color:#EAB766">void</span></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionmethod.tostring.php" class="methodname" style="color:#CC7832">__toString</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div>           <div class="classsynopsisinfo classsynopsisinfo_comment">// Inherited methods </div>     <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">final</span> <span class="modifier">private</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::__clone}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><span class="type void" style="color:#EAB766">void</span></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::getClosureScopeClass}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/class.reflectionclass.php" class="type ReflectionClass" style="color:#EAB766">ReflectionClass</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::getClosureThis}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">object</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::getDocComment}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::getEndLine}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">int</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::getExtension}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/class.reflectionextension.php" class="type ReflectionExtension" style="color:#EAB766">ReflectionExtension</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::getExtensionName}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::getFileName}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::getName}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::getNamespaceName}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::getNumberOfParameters}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">int</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::getNumberOfRequiredParameters}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">int</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::getParameters}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">array</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::getReturnType}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/class.reflectiontype.php" class="type ReflectionType" style="color:#EAB766">ReflectionType</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::getShortName}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::getStartLine}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">int</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::getStaticVariables}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">array</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::hasReturnType}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::inNamespace}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::isClosure}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::isDeprecated}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::isGenerator}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::isInternal}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::isUserDefined}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::isVariadic}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::returnsReference}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">abstract</span> <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionFunctionAbstract::__toString}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><span class="type void" style="color:#EAB766">void</span></span></div>      }</div>     </div>        <div class="section" id="reflectionmethod.props">    <h2 class="title">Properties</h2>    <dl>            <dt id="reflectionmethod.props.name"><var class="varname"><var class="varname">name</var></var></dt>       <dd>        <p class="para">Method name</p>      </dd>                 <dt id="reflectionmethod.props.class"><var class="varname"><var class="varname">class</var></var></dt>       <dd>        <p class="para">Class name</p>      </dd>          </dl>    </div>       <div class="section" id="reflectionmethod.constants">    <h2 class="title">Predefined Constants</h2>    <div class="section" id="reflectionmethod.constants.modifiers">     <h2 class="title">ReflectionMethod Modifiers</h2>     <dl>               <dt id="reflectionmethod.constants.is-static"><strong><span>ReflectionMethod::IS_STATIC</span></strong></dt>        <dd>         <p class="para">Indicates that the method is static.</p>       </dd>                     <dt id="reflectionmethod.constants.is-public"><strong><span>ReflectionMethod::IS_PUBLIC</span></strong></dt>        <dd>         <p class="para">Indicates that the method is public.</p>       </dd>                     <dt id="reflectionmethod.constants.is-protected"><strong><span>ReflectionMethod::IS_PROTECTED</span></strong></dt>        <dd>         <p class="para">Indicates that the method is protected.</p>       </dd>                     <dt id="reflectionmethod.constants.is-private"><strong><span>ReflectionMethod::IS_PRIVATE</span></strong></dt>        <dd>         <p class="para">Indicates that the method is private.</p>       </dd>                     <dt id="reflectionmethod.constants.is-abstract"><strong><span>ReflectionMethod::IS_ABSTRACT</span></strong></dt>        <dd>         <p class="para">Indicates that the method is abstract.</p>       </dd>                     <dt id="reflectionmethod.constants.is-final"><strong><span>ReflectionMethod::IS_FINAL</span></strong></dt>        <dd>         <p class="para">Indicates that the method is final.</p>       </dd>             </dl>     </div>   </div>     </div>                                                                                                                                   <h2>Table of Contents</h2><ul class="chunklist chunklist_reference"><li>{@link ReflectionMethod::__construct} — Constructs a ReflectionMethod</li><li>{@link ReflectionMethod::export} — Export a reflection method</li><li>{@link ReflectionMethod::getClosure} — Returns a dynamically created closure for the method</li><li>{@link ReflectionMethod::getDeclaringClass} — Gets declaring class for the reflected method</li><li>{@link ReflectionMethod::getModifiers} — Gets the method modifiers</li><li>{@link ReflectionMethod::getPrototype} — Gets the method prototype (if there is one)</li><li>{@link ReflectionMethod::invoke} — Invoke</li><li>{@link ReflectionMethod::invokeArgs} — Invoke args</li><li>{@link ReflectionMethod::isAbstract} — Checks if method is abstract</li><li>{@link ReflectionMethod::isConstructor} — Checks if method is a constructor</li><li>{@link ReflectionMethod::isDestructor} — Checks if method is a destructor</li><li>{@link ReflectionMethod::isFinal} — Checks if method is final</li><li>{@link ReflectionMethod::isPrivate} — Checks if method is private</li><li>{@link ReflectionMethod::isProtected} — Checks if method is protected</li><li>{@link ReflectionMethod::isPublic} — Checks if method is public</li><li>{@link ReflectionMethod::isStatic} — Checks if method is static</li><li>{@link ReflectionMethod::setAccessible} — Set method accessibility</li><li>{@link ReflectionMethod::__toString} — Returns the string representation of the Reflection method object</li></ul> </div>
*/
class ReflectionMethod extends ReflectionFunctionAbstract implements Reflector {
	const IS_STATIC = 1;
	const IS_PUBLIC = 256;
	const IS_PROTECTED = 512;
	const IS_PRIVATE = 1024;
	const IS_ABSTRACT = 2;
	const IS_FINAL = 4;

	public $name;
	public $class;


	/**
	 * Export a reflection method.
	 * @link http://php.net/manual/en/reflectionmethod.export.php
	 * @param string $class <p>
	 * The class name.
	 * </p>
	 * @param string $name <p>
	 * The name of the method.
	 * </p>
	 * @param bool $return [optional] <p>
	 * Setting to <b>TRUE</b> will return the export,
	 * as opposed to emitting it. Setting to <b>FALSE</b> (the default) will do the opposite.
	 * </p>
	 * @return string If the <i>return</i> parameter
	 * is set to <b>TRUE</b>, then the export is returned as a string,
	 * otherwise <b>NULL</b> is returned.
	 * @since 5.0
	 */
	public static function export ($class, $name, $return = false) {}

	/**
	 * Constructs a ReflectionMethod
	 * @link http://php.net/manual/en/reflectionmethod.construct.php
	 * @param mixed $class [optional] <p>
	 * Classname or object (instance of the class) that contains the method.
	 * </p>
	 * @param string $name <p>
	 * Name of the method, or the method FQN in the form 'Foo::bar' if $class argument missing
	 * </p>
	 * @throws \ReflectionException if the class or method does not exist.
	 * @since 5.0
	 */
	public function __construct ($class, $name) {}

	/**
	 * Returns the string representation of the Reflection method object.
	 * @link http://php.net/manual/en/reflectionmethod.tostring.php
	 * @return string A string representation of this <b>ReflectionMethod</b> instance.
	 * @since 5.0
	 */
	public function __toString () {}

	/**
	 * Checks if method is public
	 * @link http://php.net/manual/en/reflectionmethod.ispublic.php
	 * @return bool <b>TRUE</b> if the method is public, otherwise <b>FALSE</b>
	 * @since 5.0
	 */
	public function isPublic () {}

	/**
	 * Checks if method is private
	 * @link http://php.net/manual/en/reflectionmethod.isprivate.php
	 * @return bool <b>TRUE</b> if the method is private, otherwise <b>FALSE</b>
	 * @since 5.0
	 */
	public function isPrivate () {}

	/**
	 * Checks if method is protected
	 * @link http://php.net/manual/en/reflectionmethod.isprotected.php
	 * @return bool <b>TRUE</b> if the method is protected, otherwise <b>FALSE</b>
	 * @since 5.0
	 */
	public function isProtected () {}

	/**
	 * Checks if method is abstract
	 * @link http://php.net/manual/en/reflectionmethod.isabstract.php
	 * @return bool <b>TRUE</b> if the method is abstract, otherwise <b>FALSE</b>
	 * @since 5.0
	 */
	public function isAbstract () {}

	/**
	 * Checks if method is final
	 * @link http://php.net/manual/en/reflectionmethod.isfinal.php
	 * @return bool <b>TRUE</b> if the method is final, otherwise <b>FALSE</b>
	 * @since 5.0
	 */
	public function isFinal () {}

	/**
	 * Checks if method is static
	 * @link http://php.net/manual/en/reflectionmethod.isstatic.php
	 * @return bool <b>TRUE</b> if the method is static, otherwise <b>FALSE</b>
	 * @since 5.0
	 */
	public function isStatic () {}

	/**
	 * Checks if method is a constructor
	 * @link http://php.net/manual/en/reflectionmethod.isconstructor.php
	 * @return bool <b>TRUE</b> if the method is a constructor, otherwise <b>FALSE</b>
	 * @since 5.0
	 */
	public function isConstructor () {}

	/**
	 * Checks if method is a destructor
	 * @link http://php.net/manual/en/reflectionmethod.isdestructor.php
	 * @return bool <b>TRUE</b> if the method is a destructor, otherwise <b>FALSE</b>
	 * @since 5.0
	 */
	public function isDestructor () {}

	/**
	 * Returns a dynamically created closure for the method
	 * @link http://php.net/manual/en/reflectionmethod.getclosure.php
	 * @param object $object [optional] Forbidden for static methods, required for other methods.
	 * @return Closure <b>Closure</b>.
	 * Returns <b>NULL</b> in case of an error.
	 * @since 5.4.0
	 */
	public function getClosure ($object) {}

	/**
	 * Gets the method modifiers
	 * @link http://php.net/manual/en/reflectionmethod.getmodifiers.php
	 * @return int A numeric representation of the modifiers. The modifiers are listed below.
	 * The actual meanings of these modifiers are described in the
	 * predefined constants.
	 * <table>
	 * ReflectionMethod modifiers
	 * <tr valign="top">
	 * <td>value</td>
	 * <td>constant</td>
	 * </tr>
	 * <tr valign="top">
	 * <td>1</td>
	 * <td>
	 * ReflectionMethod::IS_STATIC
	 * </td>
	 * </tr>
	 * <tr valign="top">
	 * <td>2</td>
	 * <td>
	 * ReflectionMethod::IS_ABSTRACT
	 * </td>
	 * </tr>
	 * <tr valign="top">
	 * <td>4</td>
	 * <td>
	 * ReflectionMethod::IS_FINAL
	 * </td>
	 * </tr>
	 * <tr valign="top">
	 * <td>256</td>
	 * <td>
	 * ReflectionMethod::IS_PUBLIC
	 * </td>
	 * </tr>
	 * <tr valign="top">
	 * <td>512</td>
	 * <td>
	 * ReflectionMethod::IS_PROTECTED
	 * </td>
	 * </tr>
	 * <tr valign="top">
	 * <td>1024</td>
	 * <td>
	 * ReflectionMethod::IS_PRIVATE
	 * </td>
	 * </tr>
	 * </table>
	 * @since 5.0
	 */
	public function getModifiers () {}

	/**
	 * Invoke
	 * @link http://php.net/manual/en/reflectionmethod.invoke.php
	 * @param object $object <p>
	 * The object to invoke the method on. For static methods, pass
	 * null to this parameter.
	 * </p>
	 * @param mixed $parameter [optional] <p>
	 * Zero or more parameters to be passed to the method.
	 * It accepts a variable number of parameters which are passed to the method.
	 * </p>
	 * @param mixed $_ [optional]
	 * @return mixed the method result.
	 * @since 5.0
	 */
	public function invoke ($object, $parameter = null, $_ = null) {}

	/**
	 * Invoke args
	 * @link http://php.net/manual/en/reflectionmethod.invokeargs.php
	 * @param object $object <p>
	 * The object to invoke the method on. In case of static methods, you can pass
	 * null to this parameter.
	 * </p>
	 * @param array $args <p>
	 * The parameters to be passed to the function, as an array.
	 * </p>
	 * @return mixed the method result.
	 * @since 5.1.0
	 */
	public function invokeArgs ($object, array $args) {}

	/**
	 * Gets declaring class for the reflected method.
	 * @link http://php.net/manual/en/reflectionmethod.getdeclaringclass.php
	 * @return ReflectionClass A <b>ReflectionClass</b> object of the class that the
	 * reflected method is part of.
	 * @since 5.0
	 */
	public function getDeclaringClass () {}

	/**
	 * Gets the method prototype (if there is one).
	 * @link http://php.net/manual/en/reflectionmethod.getprototype.php
	 * @return ReflectionMethod A <b>ReflectionMethod</b> instance of the method prototype.
	 * @since 5.0
	 */
	public function getPrototype () {}

	/**
	 * Set method accessibility
	 * @link http://php.net/manual/en/reflectionmethod.setaccessible.php
	 * @param bool $accessible <p>
	 * <b>TRUE</b> to allow accessibility, or <b>FALSE</b>.
	 * </p>
	 * @return void No value is returned.
	 * @since 5.3.2
	 */
	public function setAccessible ($accessible) {}

}

/**
*<div id="class.reflectionclass" class="reference">   <h1 class="title">The ReflectionClass class</h1>     <div class="partintro"><p class="verinfo">(PHP 5, PHP 7)</p>     <div class="section" id="reflectionclass.intro">    <h2 class="title">Introduction</h2>    <p class="para">     The <strong class="classname">ReflectionClass</strong> class reports     information about a class.    </p>   </div>     <div class="section" id="reflectionclass.synopsis">    <h2 class="title">Class synopsis</h2>      <div class="classsynopsis">     <div class="ooclass"></div>       <div class="classsynopsisinfo">      <span class="ooclass">       <strong class="classname">ReflectionClass</strong>      </span>            <span class="oointerface">implements        <span class="interfacename"><a href="https://www.php.net/manual/en/class.reflector.php" class="interfacename">Reflector</a></span>      </span>      {</div>      <div class="classsynopsisinfo classsynopsisinfo_comment">// Constants </div>     <div class="fieldsynopsis">      <span class="modifier">const</span>      <span class="type" style="color:#EAB766">integer</span>       <var class="fieldsynopsis_varname"><a href="https://www.php.net/manual/en/class.reflectionclass.php#reflectionclass.constants.is-implicit-abstract"><var class="varname">IS_IMPLICIT_ABSTRACT</var></a></var>      <span class="initializer"> = 16</span>     ;</div>      <div class="fieldsynopsis">      <span class="modifier">const</span>      <span class="type" style="color:#EAB766">integer</span>       <var class="fieldsynopsis_varname"><a href="https://www.php.net/manual/en/class.reflectionclass.php#reflectionclass.constants.is-explicit-abstract"><var class="varname">IS_EXPLICIT_ABSTRACT</var></a></var>      <span class="initializer"> = 32</span>     ;</div>      <div class="fieldsynopsis">      <span class="modifier">const</span>      <span class="type" style="color:#EAB766">integer</span>       <var class="fieldsynopsis_varname"><a href="https://www.php.net/manual/en/class.reflectionclass.php#reflectionclass.constants.is-final"><var class="varname">IS_FINAL</var></a></var>      <span class="initializer"> = 64</span>     ;</div>       <div class="classsynopsisinfo classsynopsisinfo_comment">// Properties </div>     <div class="fieldsynopsis">      <span class="modifier">public</span>       <var class="varname"><a href="https://www.php.net/manual/en/class.reflectionclass.php#reflectionclass.props.name">$<var class="varname">name</var></a></var>     ;</div>            <div class="classsynopsisinfo classsynopsisinfo_comment">// Methods </div>     <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.construct.php" class="methodname" style="color:#CC7832">__construct</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span> <span class="parameter" style="color:#2EACF9">$argument</span></span>    )</div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="modifier">static</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.export.php" class="methodname" style="color:#CC7832">export</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span> <span class="parameter" style="color:#2EACF9">$argument</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">bool</span> <span class="parameter" style="color:#2EACF9">$return</span><span class="initializer"> = <strong><span>FALSE</span></strong></span></span>   ] ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.getconstant.php" class="methodname" style="color:#CC7832">getConstant</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.getconstants.php" class="methodname" style="color:#CC7832">getConstants</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">array</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span>  <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.getconstructor.php" class="methodname" style="color:#CC7832">getConstructor</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/class.reflectionmethod.php" class="type ReflectionMethod" style="color:#EAB766">ReflectionMethod</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.getdefaultproperties.php" class="methodname" style="color:#CC7832">getDefaultProperties</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">array</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.getdoccomment.php" class="methodname" style="color:#CC7832">getDocComment</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.getendline.php" class="methodname" style="color:#CC7832">getEndLine</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">int</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.getextension.php" class="methodname" style="color:#CC7832">getExtension</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/class.reflectionextension.php" class="type ReflectionExtension" style="color:#EAB766">ReflectionExtension</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.getextensionname.php" class="methodname" style="color:#CC7832">getExtensionName</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.getfilename.php" class="methodname" style="color:#CC7832">getFileName</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.getinterfacenames.php" class="methodname" style="color:#CC7832">getInterfaceNames</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">array</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.getinterfaces.php" class="methodname" style="color:#CC7832">getInterfaces</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">array</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.getmethod.php" class="methodname" style="color:#CC7832">getMethod</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/class.reflectionmethod.php" class="type ReflectionMethod" style="color:#EAB766">ReflectionMethod</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.getmethods.php" class="methodname" style="color:#CC7832">getMethods</a></span>     ([ <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$filter</span></span>   ] ) : <span class="type" style="color:#EAB766">array</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.getmodifiers.php" class="methodname" style="color:#CC7832">getModifiers</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">int</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.getname.php" class="methodname" style="color:#CC7832">getName</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.getnamespacename.php" class="methodname" style="color:#CC7832">getNamespaceName</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.getparentclass.php" class="methodname" style="color:#CC7832">getParentClass</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/class.reflectionclass.php" class="type ReflectionClass" style="color:#EAB766">ReflectionClass</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.getproperties.php" class="methodname" style="color:#CC7832">getProperties</a></span>     ([ <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$filter</span></span>   ] ) : <span class="type" style="color:#EAB766">array</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.getproperty.php" class="methodname" style="color:#CC7832">getProperty</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/class.reflectionproperty.php" class="type ReflectionProperty" style="color:#EAB766">ReflectionProperty</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.getreflectionconstant.php" class="methodname" style="color:#CC7832">getReflectionConstant</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/class.reflectionclassconstant.php" class="type ReflectionClassConstant" style="color:#EAB766">ReflectionClassConstant</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.getreflectionconstants.php" class="methodname" style="color:#CC7832">getReflectionConstants</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">array</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.getshortname.php" class="methodname" style="color:#CC7832">getShortName</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.getstartline.php" class="methodname" style="color:#CC7832">getStartLine</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">int</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.getstaticproperties.php" class="methodname" style="color:#CC7832">getStaticProperties</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">array</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.getstaticpropertyvalue.php" class="methodname" style="color:#CC7832">getStaticPropertyValue</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span> <span class="parameter" style="color:#2EACF9">&$def_value</span></span>   ] ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.gettraitaliases.php" class="methodname" style="color:#CC7832">getTraitAliases</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">array</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.gettraitnames.php" class="methodname" style="color:#CC7832">getTraitNames</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">array</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.gettraits.php" class="methodname" style="color:#CC7832">getTraits</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">array</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.hasconstant.php" class="methodname" style="color:#CC7832">hasConstant</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.hasmethod.php" class="methodname" style="color:#CC7832">hasMethod</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.hasproperty.php" class="methodname" style="color:#CC7832">hasProperty</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.implementsinterface.php" class="methodname" style="color:#CC7832">implementsInterface</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$interface</span></span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.innamespace.php" class="methodname" style="color:#CC7832">inNamespace</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.isabstract.php" class="methodname" style="color:#CC7832">isAbstract</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.isanonymous.php" class="methodname" style="color:#CC7832">isAnonymous</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.iscloneable.php" class="methodname" style="color:#CC7832">isCloneable</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.isfinal.php" class="methodname" style="color:#CC7832">isFinal</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.isinstance.php" class="methodname" style="color:#CC7832">isInstance</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">object</span> <span class="parameter" style="color:#2EACF9">$object</span></span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.isinstantiable.php" class="methodname" style="color:#CC7832">isInstantiable</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.isinterface.php" class="methodname" style="color:#CC7832">isInterface</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.isinternal.php" class="methodname" style="color:#CC7832">isInternal</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.isiterable.php" class="methodname" style="color:#CC7832">isIterable</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.issubclassof.php" class="methodname" style="color:#CC7832">isSubclassOf</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span> <span class="parameter" style="color:#2EACF9">$class</span></span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.istrait.php" class="methodname" style="color:#CC7832">isTrait</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.isuserdefined.php" class="methodname" style="color:#CC7832">isUserDefined</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.newinstance.php" class="methodname" style="color:#CC7832">newInstance</a></span>     ([ <span class="methodparam"><span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span> <span class="parameter" style="color:#2EACF9">$...</span></span>   ] ) : <span class="type" style="color:#EAB766">object</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.newinstanceargs.php" class="methodname" style="color:#CC7832">newInstanceArgs</a></span>     ([ <span class="methodparam"><span class="type" style="color:#EAB766">array</span> <span class="parameter" style="color:#2EACF9">$args</span></span>   ] ) : <span class="type" style="color:#EAB766">object</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.newinstancewithoutconstructor.php" class="methodname" style="color:#CC7832">newInstanceWithoutConstructor</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">object</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.setstaticpropertyvalue.php" class="methodname" style="color:#CC7832">setStaticPropertyValue</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    , <span class="methodparam"><span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span> <span class="parameter" style="color:#2EACF9">$value</span></span>    ) : <span class="type" style="color:#EAB766"><span class="type void" style="color:#EAB766">void</span></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclass.tostring.php" class="methodname" style="color:#CC7832">__toString</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div>     }</div>     </div>        <div class="section" id="reflectionclass.props">    <h2 class="title">Properties</h2>    <dl>            <dt id="reflectionclass.props.name"><var class="varname"><var class="varname">name</var></var></dt>       <dd>        <p class="para">        Name of the class. Read-only, throws        <a href="https://www.php.net/manual/en/class.reflectionexception.php" class="classname">ReflectionException</a> in attempt to write.       </p>      </dd>          </dl>    </div>         <div class="section" id="reflectionclass.constants">    <h2 class="title">Predefined Constants</h2>    <div class="section" id="reflectionclass.constants.modifiers">     <h2 class="title">ReflectionClass Modifiers</h2>     <dl>               <dt id="reflectionclass.constants.is-implicit-abstract"><strong><span>ReflectionClass::IS_IMPLICIT_ABSTRACT</span></strong></dt>        <dd>         <p class="para">         Indicates class that is <a href="https://www.php.net/manual/en/language.oop5.abstract.php" class="link">         abstract</a> because it has some abstract methods.        </p>       </dd>                     <dt id="reflectionclass.constants.is-explicit-abstract"><strong><span>ReflectionClass::IS_EXPLICIT_ABSTRACT</span></strong></dt>        <dd>         <p class="para">         Indicates class that is <a href="https://www.php.net/manual/en/language.oop5.abstract.php" class="link">         abstract</a> because of its definition.        </p>       </dd>                     <dt id="reflectionclass.constants.is-final"><strong><span>ReflectionClass::IS_FINAL</span></strong></dt>        <dd>         <p class="para">         Indicates <a href="https://www.php.net/manual/en/language.oop5.final.php" class="link">final</a>         class.        </p>       </dd>             </dl>     </div>   </div>     </div>                                                                                                                                                                                                                                                                                                                                                                                        <h2>Table of Contents</h2><ul class="chunklist chunklist_reference"><li>{@link ReflectionClass::__construct} — Constructs a ReflectionClass</li><li>{@link ReflectionClass::export} — Exports a class</li><li>{@link ReflectionClass::getConstant} — Gets defined constant</li><li>{@link ReflectionClass::getConstants} — Gets constants</li><li>{@link ReflectionClass::getConstructor} — Gets the constructor of the class</li><li>{@link ReflectionClass::getDefaultProperties} — Gets default properties</li><li>{@link ReflectionClass::getDocComment} — Gets doc comments</li><li>{@link ReflectionClass::getEndLine} — Gets end line</li><li>{@link ReflectionClass::getExtension} — Gets a ReflectionExtension object for the extension which defined the class</li><li>{@link ReflectionClass::getExtensionName} — Gets the name of the extension which defined the class</li><li>{@link ReflectionClass::getFileName} — Gets the filename of the file in which the class has been defined</li><li>{@link ReflectionClass::getInterfaceNames} — Gets the interface names</li><li>{@link ReflectionClass::getInterfaces} — Gets the interfaces</li><li>{@link ReflectionClass::getMethod} — Gets a ReflectionMethod for a class method</li><li>{@link ReflectionClass::getMethods} — Gets an array of methods</li><li>{@link ReflectionClass::getModifiers} — Gets the class modifiers</li><li>{@link ReflectionClass::getName} — Gets class name</li><li>{@link ReflectionClass::getNamespaceName} — Gets namespace name</li><li>{@link ReflectionClass::getParentClass} — Gets parent class</li><li>{@link ReflectionClass::getProperties} — Gets properties</li><li>{@link ReflectionClass::getProperty} — Gets a ReflectionProperty for a class's property</li><li>{@link ReflectionClass::getReflectionConstant} — Gets a ReflectionClassConstant for a class's constant</li><li>{@link ReflectionClass::getReflectionConstants} — Gets class constants</li><li>{@link ReflectionClass::getShortName} — Gets short name</li><li>{@link ReflectionClass::getStartLine} — Gets starting line number</li><li>{@link ReflectionClass::getStaticProperties} — Gets static properties</li><li>{@link ReflectionClass::getStaticPropertyValue} — Gets static property value</li><li>{@link ReflectionClass::getTraitAliases} — Returns an array of trait aliases</li><li>{@link ReflectionClass::getTraitNames} — Returns an array of names of traits used by this class</li><li>{@link ReflectionClass::getTraits} — Returns an array of traits used by this class</li><li>{@link ReflectionClass::hasConstant} — Checks if constant is defined</li><li>{@link ReflectionClass::hasMethod} — Checks if method is defined</li><li>{@link ReflectionClass::hasProperty} — Checks if property is defined</li><li>{@link ReflectionClass::implementsInterface} — Implements interface</li><li>{@link ReflectionClass::inNamespace} — Checks if in namespace</li><li>{@link ReflectionClass::isAbstract} — Checks if class is abstract</li><li>{@link ReflectionClass::isAnonymous} — Checks if class is anonymous</li><li>{@link ReflectionClass::isCloneable} — Returns whether this class is cloneable</li><li>{@link ReflectionClass::isFinal} — Checks if class is final</li><li>{@link ReflectionClass::isInstance} — Checks class for instance</li><li>{@link ReflectionClass::isInstantiable} — Checks if the class is instantiable</li><li>{@link ReflectionClass::isInterface} — Checks if the class is an interface</li><li>{@link ReflectionClass::isInternal} — Checks if class is defined internally by an extension, or the core</li><li>{@link ReflectionClass::isIterable} — Check whether this class is iterable</li><li>{@link ReflectionClass::isIterateable} — Alias of ReflectionClass::isIterable</li><li>{@link ReflectionClass::isSubclassOf} — Checks if a subclass</li><li>{@link ReflectionClass::isTrait} — Returns whether this is a trait</li><li>{@link ReflectionClass::isUserDefined} — Checks if user defined</li><li>{@link ReflectionClass::newInstance} — Creates a new class instance from given arguments</li><li>{@link ReflectionClass::newInstanceArgs} — Creates a new class instance from given arguments</li><li>{@link ReflectionClass::newInstanceWithoutConstructor} — Creates a new class instance without invoking the constructor</li><li>{@link ReflectionClass::setStaticPropertyValue} — Sets static property value</li><li>{@link ReflectionClass::__toString} — Returns the string representation of the ReflectionClass object</li></ul> </div>
*/
class ReflectionClass implements Reflector {
	const IS_IMPLICIT_ABSTRACT = 16;
	const IS_EXPLICIT_ABSTRACT = 32;
	const IS_FINAL = 64;

	public $name;


	/**
	 * Clones object
	 * @link http://php.net/manual/en/reflectionclass.clone.php
	 * @return void 
	 * @since 5.0
	 */
	final private function __clone () {}

	/**
	 * Exports a class
	 * @link http://php.net/manual/en/reflectionclass.export.php
	 * @param mixed $argument <p>
	 * The reflection to export.
	 * </p>
	 * @param bool $return [optional] <p>
	 * Setting to <b>TRUE</b> will return the export,
	 * as opposed to emitting it. Setting to <b>FALSE</b> (the default) will do the opposite.
	 * </p>
	 * @return string If the <i>return</i> parameter
	 * is set to <b>TRUE</b>, then the export is returned as a string,
	 * otherwise <b>NULL</b> is returned.
	 * @since 5.0
	 */
	public static function export ($argument, $return = false) {}

	/**
	 * Constructs a ReflectionClass
	 * @link http://php.net/manual/en/reflectionclass.construct.php
	 * @param mixed $argument <p>
	 * Either a string containing the name of the class to
	 * reflect, or an object.
	 * </p>
	 * @throws \ReflectionException if the class does not exist.
	 * @since 5.0
	 */
	public function __construct ($argument) {}

	/**
	 * Returns the string representation of the ReflectionClass object.
	 * @link http://php.net/manual/en/reflectionclass.tostring.php
	 * @return string A string representation of this <b>ReflectionClass</b> instance.
	 * @since 5.0
	 */
	public function __toString () {}

	/**
	 * Gets class name
	 * @link http://php.net/manual/en/reflectionclass.getname.php
	 * @return string The class name.
	 * @since 5.0
	 */
	public function getName () {}

	/**
	 * Checks if class is defined internally by an extension, or the core
	 * @link http://php.net/manual/en/reflectionclass.isinternal.php
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 * @since 5.0
	 */
	public function isInternal () {}

	/**
	 * Checks if user defined
	 * @link http://php.net/manual/en/reflectionclass.isuserdefined.php
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 * @since 5.0
	 */
	public function isUserDefined () {}

	/**
	 * Checks if the class is instantiable
	 * @link http://php.net/manual/en/reflectionclass.isinstantiable.php
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 * @since 5.0
	 */
	public function isInstantiable () {}

	/**
	 * Returns whether this class is cloneable
	 * @link http://php.net/manual/en/reflectionclass.iscloneable.php
	 * @return bool <b>TRUE</b> if the class is cloneable, <b>FALSE</b> otherwise.
	 * @since 5.4.0
	 */
	public function isCloneable () {}

	/**
	 * Gets the filename of the file in which the class has been defined
	 * @link http://php.net/manual/en/reflectionclass.getfilename.php
	 * @return string the filename of the file in which the class has been defined.
	 * If the class is defined in the PHP core or in a PHP extension, <b>FALSE</b>
	 * is returned.
	 * @since 5.0
	 */
	public function getFileName () {}

	/**
	 * Gets starting line number
	 * @link http://php.net/manual/en/reflectionclass.getstartline.php
	 * @return int The starting line number, as an integer.
	 * @since 5.0
	 */
	public function getStartLine () {}

	/**
	 * Gets end line
	 * @link http://php.net/manual/en/reflectionclass.getendline.php
	 * @return int The ending line number of the user defined class, or <b>FALSE</b> if unknown.
	 * @since 5.0
	 */
	public function getEndLine () {}

	/**
	 * Gets doc comments
	 * @link http://php.net/manual/en/reflectionclass.getdoccomment.php
	 * @return string|bool The doc comment if it exists, otherwise <b>FALSE</b>
	 * @since 5.1.0
	 */
	public function getDocComment () {}

	/**
	 * Gets the constructor of the class
	 * @link http://php.net/manual/en/reflectionclass.getconstructor.php
	 * @return ReflectionMethod A <b>ReflectionMethod</b> object reflecting the class' constructor, or <b>NULL</b> if the class
	 * has no constructor.
	 * @since 5.0
	 */
	public function getConstructor () {}

	/**
	 * Checks if method is defined
	 * @link http://php.net/manual/en/reflectionclass.hasmethod.php
	 * @param string $name <p>
	 * Name of the method being checked for.
	 * </p>
	 * @return bool <b>TRUE</b> if it has the method, otherwise <b>FALSE</b>
	 * @since 5.1.0
	 */
	public function hasMethod ($name) {}

	/**
	 * Gets a <b>ReflectionMethod</b> for a class method.
	 * @link http://php.net/manual/en/reflectionclass.getmethod.php
	 * @param string $name <p>
	 * The method name to reflect.
	 * </p>
	 * @return ReflectionMethod A <b>ReflectionMethod</b>.
	 * @since 5.0
	 */
	public function getMethod ($name) {}

	/**
	 * Gets an array of methods
	 * @link http://php.net/manual/en/reflectionclass.getmethods.php
	 * @param string $filter [optional] <p>
	 * Filter the results to include only methods with certain attributes. Defaults
	 * to no filtering.
	 * </p>
	 * <p>
	 * Any combination of <b>ReflectionMethod::IS_STATIC</b>,
	 * <b>ReflectionMethod::IS_PUBLIC</b>,
	 * <b>ReflectionMethod::IS_PROTECTED</b>,
	 * <b>ReflectionMethod::IS_PRIVATE</b>,
	 * <b>ReflectionMethod::IS_ABSTRACT</b>,
	 * <b>ReflectionMethod::IS_FINAL</b>.
	 * </p>
         * @return ReflectionMethod[] An array of methods.
	 * @since 5.0
	 */
	public function getMethods ($filter = null) {}

	/**
	 * Checks if property is defined
	 * @link http://php.net/manual/en/reflectionclass.hasproperty.php
	 * @param string $name <p>
	 * Name of the property being checked for.
	 * </p>
	 * @return bool <b>TRUE</b> if it has the property, otherwise <b>FALSE</b>
	 * @since 5.1.0
	 */
	public function hasProperty ($name) {}

	/**
	 * Gets a <b>ReflectionProperty</b> for a class's property
	 * @link http://php.net/manual/en/reflectionclass.getproperty.php
	 * @param string $name <p>
	 * The property name.
	 * </p>
	 * @return ReflectionProperty A <b>ReflectionProperty</b>.
	 * @since 5.0
	 */
	public function getProperty ($name) {}

	/**
	 * Gets properties
	 * @link http://php.net/manual/en/reflectionclass.getproperties.php
	 * @param int $filter [optional] <p>
	 * The optional filter, for filtering desired property types. It's configured using
	 * the ReflectionProperty constants,
	 * and defaults to all property types.
	 * </p>
	 * @return ReflectionProperty[]
	 * @since 5.0
	 */
	public function getProperties ($filter = null) {}

	/**
	 * Gets a ReflectionClassConstant for a class's property
	 * @link http://php.net/manual/en/reflectionclass.getreflectionconstant.php
	 * @param string $name <p>
	 * The class constant name.
	 * </p>
	 * @return ReflectionClassConstant A ReflectionClassConstant.
	 * @since 7.1
	 */
	public function getReflectionConstant ($name) {}

	/**
	 * Gets class constants
	 * @link http://php.net/manual/en/reflectionclass.getreflectionconstants.php
	 * @return ReflectionClassConstant[] An array of ReflectionClassConstant objects.
	 * @since 7.1
	 */
	public function getReflectionConstants () {}

	/**
	 * Checks if constant is defined
	 * @link http://php.net/manual/en/reflectionclass.hasconstant.php
	 * @param string $name <p>
	 * The name of the constant being checked for.
	 * </p>
	 * @return bool <b>TRUE</b> if the constant is defined, otherwise <b>FALSE</b>.
	 * @since 5.1.0
	 */
	public function hasConstant ($name) {}

	/**
	 * Gets constants
	 * @link http://php.net/manual/en/reflectionclass.getconstants.php
	 * @return array An array of constants.
	 * Constant name in key, constant value in value.
	 * @since 5.0
	 */
	public function getConstants () {}

	/**
	 * Gets defined constant
	 * @link http://php.net/manual/en/reflectionclass.getconstant.php
	 * @param string $name <p>
	 * Name of the constant.
	 * </p>
	 * @return mixed Value of the constant.
	 * @since 5.0
	 */
	public function getConstant ($name) {}

	/**
	 * Gets the interfaces
	 * @link http://php.net/manual/en/reflectionclass.getinterfaces.php
         * @return ReflectionClass[] An associative array of interfaces, with keys as interface
	 * names and the array values as <b>ReflectionClass</b> objects.
	 * @since 5.0
	 */
	public function getInterfaces () {}

	/**
	 * Gets the interface names
	 * @link http://php.net/manual/en/reflectionclass.getinterfacenames.php
	 * @return array A numerical array with interface names as the values.
	 * @since 5.2.0
	 */
	public function getInterfaceNames () {}

	/**
	 * Checks if the class is anonymous
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 * @since 7.0
	 */
	public function isAnonymous () {}

	/**
	 * Checks if the class is an interface
	 * @link http://php.net/manual/en/reflectionclass.isinterface.php
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 * @since 5.0
	 */
	public function isInterface () {}

	/**
	 * Returns an array of traits used by this class
	 * @link http://php.net/manual/en/reflectionclass.gettraits.php
	 * @return ReflectionClass[] an array with trait names in keys and instances of trait's
	 * <b>ReflectionClass</b> in values.
	 * Returns <b>NULL</b> in case of an error.
	 * @since 5.4.0
	 */
	public function getTraits () {}

	/**
	 * Returns an array of names of traits used by this class
	 * @link http://php.net/manual/en/reflectionclass.gettraitnames.php
	 * @return array an array with trait names in values.
	 * Returns <b>NULL</b> in case of an error.
	 * @since 5.4.0
	 */
	public function getTraitNames () {}

	/**
	 * Returns an array of trait aliases
	 * @link http://php.net/manual/en/reflectionclass.gettraitaliases.php
	 * @return array an array with new method names in keys and original names (in the
	 * format "TraitName::original") in values.
	 * Returns <b>NULL</b> in case of an error.
	 * @since 5.4.0
	 */
	public function getTraitAliases () {}

	/**
	 * Returns whether this is a trait
	 * @link http://php.net/manual/en/reflectionclass.istrait.php
	 * @return bool <b>TRUE</b> if this is a trait, <b>FALSE</b> otherwise.
	 * Returns <b>NULL</b> in case of an error.
	 * @since 5.4.0
	 */
	public function isTrait () {}

	/**
	 * Checks if class is abstract
	 * @link http://php.net/manual/en/reflectionclass.isabstract.php
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 * @since 5.0
	 */
	public function isAbstract () {}

	/**
	 * Checks if class is final
	 * @link http://php.net/manual/en/reflectionclass.isfinal.php
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 * @since 5.0
	 */
	public function isFinal () {}

	/**
	 * Gets modifiers
	 * @link http://php.net/manual/en/reflectionclass.getmodifiers.php
	 * @return int bitmask of
	 * modifier constants.
	 * @since 5.0
	 */
	public function getModifiers () {}

	/**
	 * Checks class for instance
	 * @link http://php.net/manual/en/reflectionclass.isinstance.php
	 * @param object $object <p>
	 * The object being compared to.
	 * </p>
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 * @since 5.0
	 */
	public function isInstance ($object) {}

	/**
	 * Creates a new class instance from given arguments.
	 * @link http://php.net/manual/en/reflectionclass.newinstance.php
	 * @param mixed $args [optional]<p>
	 * Accepts a variable number of arguments which are passed to the class
	 * constructor, much like <b>call_user_func</b>.
	 * </p>
	 * @param mixed $_ [optional]
	 * @return object
	 * @since 5.0
	 */
	public function newInstance ($args = null, $_ = null) {}
	/**
	 * Creates a new class instance without invoking the constructor.
	 * @link http://php.net/manual/en/reflectionclass.newinstancewithoutconstructor.php
	 * @return object
	 * @since 5.4.0
	 */
	public function newInstanceWithoutConstructor() {}

	/**
	 * Creates a new class instance from given arguments.
	 * @link http://php.net/manual/en/reflectionclass.newinstanceargs.php
	 * @param array $args [optional] <p>
	 * The parameters to be passed to the class constructor as an array.
	 * </p>
	 * @return object a new instance of the class.
	 * @since 5.1.3
	 */
	public function newInstanceArgs (array $args = null) {}

	/**
	 * Gets parent class
	 * @link http://php.net/manual/en/reflectionclass.getparentclass.php
	 * @return ReflectionClass
	 * @since 5.0
	 */
	public function getParentClass () {}

	/**
	 * Checks if a subclass
	 * @link http://php.net/manual/en/reflectionclass.issubclassof.php
	 * @param string $class <p>
	 * The class name being checked against.
	 * </p>
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 * @since 5.0
	 */
	public function isSubclassOf ($class) {}

	/**
	 * Gets static properties
	 * @link http://php.net/manual/en/reflectionclass.getstaticproperties.php
	 * @return array The static properties, as an array.
	 * @since 5.0
	 */
	public function getStaticProperties () {}

	/**
	 * Gets static property value
	 * @link http://php.net/manual/en/reflectionclass.getstaticpropertyvalue.php
	 * @param string $name <p>
	 * The name of the static property for which to return a value.
	 * </p>
	 * @param string $default [optional] <p>
	 * </p>
	 * @return mixed The value of the static property.
	 * @since 5.1.0
	 */
	public function getStaticPropertyValue ($name, $default = null) {}

	/**
	 * Sets static property value
	 * @link http://php.net/manual/en/reflectionclass.setstaticpropertyvalue.php
	 * @param string $name <p>
	 * Property name.
	 * </p>
	 * @param mixed $value <p>
	 * New property value.
	 * </p>
	 * @return void No value is returned.
	 * @since 5.1.0
	 */
	public function setStaticPropertyValue ($name, $value) {}

	/**
	 * Gets default properties
	 * @link http://php.net/manual/en/reflectionclass.getdefaultproperties.php
	 * @return array An array of default properties, with the key being the name of
	 * the property and the value being the default value of the property or <b>NULL</b>
	 * if the property doesn't have a default value. The function does not distinguish
	 * between static and non static properties and does not take visibility modifiers
	 * into account.
	 * @since 5.0
	 */
	public function getDefaultProperties () {}

	/**
	 * Checks if iterateable
	 * @link http://php.net/manual/en/reflectionclass.isiterateable.php
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 * @since 5.0
	 */
	public function isIterateable () {}

	/**
	 * Checks if iterateable
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 * @since 7.2
	 */
	public function isIterable () {}

	/**
	 * Implements interface
	 * @link http://php.net/manual/en/reflectionclass.implementsinterface.php
	 * @param string $interface <p>
	 * The interface name.
	 * </p>
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 * @since 5.0
	 */
	public function implementsInterface ($interface) {}

	/**
	 * Gets a <b>ReflectionExtension</b> object for the extension which defined the class
	 * @link http://php.net/manual/en/reflectionclass.getextension.php
	 * @return ReflectionExtension A <b>ReflectionExtension</b> object representing the extension which defined the class,
	 * or <b>NULL</b> for user-defined classes.
	 * @since 5.0
	 */
	public function getExtension () {}

	/**
	 * Gets the name of the extension which defined the class
	 * @link http://php.net/manual/en/reflectionclass.getextensionname.php
	 * @return string The name of the extension which defined the class, or <b>FALSE</b> for user-defined classes.
	 * @since 5.0
	 */
	public function getExtensionName () {}

	/**
	 * Checks if in namespace
	 * @link http://php.net/manual/en/reflectionclass.innamespace.php
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 * @since 5.3.0
	 */
	public function inNamespace () {}

	/**
	 * Gets namespace name
	 * @link http://php.net/manual/en/reflectionclass.getnamespacename.php
	 * @return string The namespace name.
	 * @since 5.3.0
	 */
	public function getNamespaceName () {}

	/**
	 * Gets short name
	 * @link http://php.net/manual/en/reflectionclass.getshortname.php
	 * @return string The class short name.
	 * @since 5.3.0
	 */
	public function getShortName () {}

}

/**
*<div id="class.reflectionobject" class="reference">   <h1 class="title">The ReflectionObject class</h1>     <div class="partintro"><p class="verinfo">(PHP 5, PHP 7)</p>     <div class="section" id="reflectionobject.intro">    <h2 class="title">Introduction</h2>    <p class="para">     The <strong class="classname">ReflectionObject</strong> class reports     information about an <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.object.php" class="type object" style="color:#EAB766">object</a></span>.    </p>   </div>     <div class="section" id="reflectionobject.synopsis">    <h2 class="title">Class synopsis</h2>      <div class="classsynopsis">     <div class="ooclass"></div>       <div class="classsynopsisinfo">      <span class="ooclass">       <strong class="classname">ReflectionObject</strong>      </span>            <span class="ooclass">       <span class="modifier">extends</span>       <a href="https://www.php.net/manual/en/class.reflectionclass.php" class="classname">ReflectionClass</a>      </span>            <span class="oointerface">implements        <span class="interfacename"><a href="https://www.php.net/manual/en/class.reflector.php" class="interfacename">Reflector</a></span>      </span>      {</div>      <div class="classsynopsisinfo classsynopsisinfo_comment">// Inherited constants </div>     <div class="fieldsynopsis">      <span class="modifier">const</span>      <span class="type" style="color:#EAB766">integer</span>       <var class="fieldsynopsis_varname">{@link <var class="varname">ReflectionClass::IS_IMPLICIT_ABSTRACT</var>}</var>      <span class="initializer"> = 16</span>     ;</div> <div class="fieldsynopsis">      <span class="modifier">const</span>      <span class="type" style="color:#EAB766">integer</span>       <var class="fieldsynopsis_varname">{@link <var class="varname">ReflectionClass::IS_EXPLICIT_ABSTRACT</var>}</var>      <span class="initializer"> = 32</span>     ;</div> <div class="fieldsynopsis">      <span class="modifier">const</span>      <span class="type" style="color:#EAB766">integer</span>       <var class="fieldsynopsis_varname">{@link <var class="varname">ReflectionClass::IS_FINAL</var>}</var>      <span class="initializer"> = 64</span>     ;</div>       <div class="classsynopsisinfo classsynopsisinfo_comment">// Properties </div>     <div class="fieldsynopsis">      <span class="modifier">public</span>       <var class="varname"><a href="https://www.php.net/manual/en/class.reflectionobject.php#reflectionobject.props.name">$<var class="varname">name</var></a></var>     ;</div>           <div class="classsynopsisinfo classsynopsisinfo_comment">// Methods </div>     <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionobject.construct.php" class="methodname" style="color:#CC7832">__construct</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">object</span> <span class="parameter" style="color:#2EACF9">$argument</span></span>    )</div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="modifier">static</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionobject.export.php" class="methodname" style="color:#CC7832">export</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$argument</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">bool</span> <span class="parameter" style="color:#2EACF9">$return</span></span>   ] ) : <span class="type" style="color:#EAB766">string</span></div>           <div class="classsynopsisinfo classsynopsisinfo_comment">// Inherited methods </div>     <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::__construct}</span>     ( <span class="methodparam"><span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span> <span class="parameter" style="color:#2EACF9">$argument</span></span>    )</div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="modifier">static</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::export}</span>     ( <span class="methodparam"><span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span> <span class="parameter" style="color:#2EACF9">$argument</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">bool</span> <span class="parameter" style="color:#2EACF9">$return</span><span class="initializer"> = <strong><span>FALSE</span></strong></span></span>   ] ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::getConstant}</span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::getConstants}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">array</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span>  <span class="methodname" style="color:#CC7832">{@link ReflectionClass::getConstructor}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/class.reflectionmethod.php" class="type ReflectionMethod" style="color:#EAB766">ReflectionMethod</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::getDefaultProperties}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">array</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::getDocComment}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::getEndLine}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">int</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::getExtension}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/class.reflectionextension.php" class="type ReflectionExtension" style="color:#EAB766">ReflectionExtension</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::getExtensionName}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::getFileName}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::getInterfaceNames}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">array</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::getInterfaces}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">array</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::getMethod}</span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/class.reflectionmethod.php" class="type ReflectionMethod" style="color:#EAB766">ReflectionMethod</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::getMethods}</span>     ([ <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$filter</span></span>   ] ) : <span class="type" style="color:#EAB766">array</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::getModifiers}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">int</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::getName}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::getNamespaceName}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::getParentClass}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/class.reflectionclass.php" class="type ReflectionClass" style="color:#EAB766">ReflectionClass</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::getProperties}</span>     ([ <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$filter</span></span>   ] ) : <span class="type" style="color:#EAB766">array</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::getProperty}</span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/class.reflectionproperty.php" class="type ReflectionProperty" style="color:#EAB766">ReflectionProperty</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::getReflectionConstant}</span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/class.reflectionclassconstant.php" class="type ReflectionClassConstant" style="color:#EAB766">ReflectionClassConstant</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::getReflectionConstants}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">array</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::getShortName}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::getStartLine}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">int</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::getStaticProperties}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">array</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::getStaticPropertyValue}</span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span> <span class="parameter" style="color:#2EACF9">&$def_value</span></span>   ] ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::getTraitAliases}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">array</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::getTraitNames}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">array</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::getTraits}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">array</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::hasConstant}</span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::hasMethod}</span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::hasProperty}</span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::implementsInterface}</span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$interface</span></span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::inNamespace}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::isAbstract}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::isAnonymous}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::isCloneable}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::isFinal}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::isInstance}</span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">object</span> <span class="parameter" style="color:#2EACF9">$object</span></span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::isInstantiable}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::isInterface}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::isInternal}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::isIterable}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::isSubclassOf}</span>     ( <span class="methodparam"><span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span> <span class="parameter" style="color:#2EACF9">$class</span></span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::isTrait}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::isUserDefined}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::newInstance}</span>     ([ <span class="methodparam"><span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span> <span class="parameter" style="color:#2EACF9">$...</span></span>   ] ) : <span class="type" style="color:#EAB766">object</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::newInstanceArgs}</span>     ([ <span class="methodparam"><span class="type" style="color:#EAB766">array</span> <span class="parameter" style="color:#2EACF9">$args</span></span>   ] ) : <span class="type" style="color:#EAB766">object</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::newInstanceWithoutConstructor}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">object</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::setStaticPropertyValue}</span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    , <span class="methodparam"><span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span> <span class="parameter" style="color:#2EACF9">$value</span></span>    ) : <span class="type" style="color:#EAB766"><span class="type void" style="color:#EAB766">void</span></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionClass::__toString}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div>      }</div>     </div>        <div class="section" id="reflectionobject.props">    <h2 class="title">Properties</h2>    <dl>            <dt id="reflectionobject.props.name"><var class="varname"><var class="varname">name</var></var></dt>       <dd>        <p class="para">        Name of the object&#039;s class. Read-only, throws        <a href="https://www.php.net/manual/en/class.reflectionexception.php" class="classname">ReflectionException</a> in attempt to write.       </p>      </dd>          </dl>    </div>     </div>                   <h2>Table of Contents</h2><ul class="chunklist chunklist_reference"><li>{@link ReflectionObject::__construct} — Constructs a ReflectionObject</li><li>{@link ReflectionObject::export} — Export</li></ul> </div>
*/
class ReflectionObject extends ReflectionClass implements Reflector {

	/**
	 * Export
	 * @link http://php.net/manual/en/reflectionobject.export.php
	 * @param string $argument <p>
	 * The reflection to export.
	 * </p>
	 * @param bool $return [optional] <p>
	 * Setting to <b>TRUE</b> will return the export,
	 * as opposed to emitting it. Setting to <b>FALSE</b> (the default) will do the opposite.
	 * </p>
	 * @return string If the <i>return</i> parameter
	 * is set to <b>TRUE</b>, then the export is returned as a string,
	 * otherwise <b>NULL</b> is returned.
	 * @since 5.0
	 */
	public static function export ($argument, $return = null) {}

	/**
	 * Constructs a ReflectionObject
	 * @link http://php.net/manual/en/reflectionobject.construct.php
	 * @param object $argument <p>
	 * An object instance.
	 * </p>
	 * @since 5.0
	 */
	public function __construct ($argument) {}

}

/**
*<div id="class.reflectionproperty" class="reference">   <h1 class="title">The ReflectionProperty class</h1>     <div class="partintro"><p class="verinfo">(PHP 5, PHP 7)</p>     <div class="section" id="reflectionproperty.intro">    <h2 class="title">Introduction</h2>    <p class="para">     The <strong class="classname">ReflectionProperty</strong> class reports     information about classes properties.    </p>   </div>     <div class="section" id="reflectionproperty.synopsis">    <h2 class="title">Class synopsis</h2>      <div class="classsynopsis">     <div class="ooclass"></div>       <div class="classsynopsisinfo">      <span class="ooclass">       <strong class="classname">ReflectionProperty</strong>      </span>            <span class="oointerface">implements        <span class="interfacename"><a href="https://www.php.net/manual/en/class.reflector.php" class="interfacename">Reflector</a></span>      </span>      {</div>      <div class="classsynopsisinfo classsynopsisinfo_comment">// Constants </div>     <div class="fieldsynopsis">      <span class="modifier">const</span>      <span class="type" style="color:#EAB766">integer</span>       <var class="fieldsynopsis_varname"><a href="https://www.php.net/manual/en/class.reflectionproperty.php#reflectionproperty.constants.is-static"><var class="varname">IS_STATIC</var></a></var>      <span class="initializer"> = 1</span>     ;</div>      <div class="fieldsynopsis">      <span class="modifier">const</span>      <span class="type" style="color:#EAB766">integer</span>       <var class="fieldsynopsis_varname"><a href="https://www.php.net/manual/en/class.reflectionproperty.php#reflectionproperty.constants.is-public"><var class="varname">IS_PUBLIC</var></a></var>      <span class="initializer"> = 256</span>     ;</div>      <div class="fieldsynopsis">      <span class="modifier">const</span>      <span class="type" style="color:#EAB766">integer</span>       <var class="fieldsynopsis_varname"><a href="https://www.php.net/manual/en/class.reflectionproperty.php#reflectionproperty.constants.is-protected"><var class="varname">IS_PROTECTED</var></a></var>      <span class="initializer"> = 512</span>     ;</div>      <div class="fieldsynopsis">      <span class="modifier">const</span>      <span class="type" style="color:#EAB766">integer</span>       <var class="fieldsynopsis_varname"><a href="https://www.php.net/manual/en/class.reflectionproperty.php#reflectionproperty.constants.is-private"><var class="varname">IS_PRIVATE</var></a></var>      <span class="initializer"> = 1024</span>     ;</div>       <div class="classsynopsisinfo classsynopsisinfo_comment">// Properties </div>     <div class="fieldsynopsis">      <span class="modifier">public</span>       <var class="varname"><a href="https://www.php.net/manual/en/class.reflectionproperty.php#reflectionproperty.props.name">$<var class="varname">name</var></a></var>     ;</div>      <div class="fieldsynopsis">      <span class="modifier">public</span>       <var class="varname"><a href="https://www.php.net/manual/en/class.reflectionproperty.php#reflectionproperty.props.class">$<var class="varname">class</var></a></var>     ;</div>            <div class="classsynopsisinfo classsynopsisinfo_comment">// Methods </div>     <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">final</span> <span class="modifier">private</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionproperty.clone.php" class="methodname" style="color:#CC7832">__clone</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><span class="type void" style="color:#EAB766">void</span></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionproperty.construct.php" class="methodname" style="color:#CC7832">__construct</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span> <span class="parameter" style="color:#2EACF9">$class</span></span>    , <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    )</div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="modifier">static</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionproperty.export.php" class="methodname" style="color:#CC7832">export</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span> <span class="parameter" style="color:#2EACF9">$class</span></span>    , <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">bool</span> <span class="parameter" style="color:#2EACF9">$return</span></span>   ] ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionproperty.getdeclaringclass.php" class="methodname" style="color:#CC7832">getDeclaringClass</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/class.reflectionclass.php" class="type ReflectionClass" style="color:#EAB766">ReflectionClass</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionproperty.getdoccomment.php" class="methodname" style="color:#CC7832">getDocComment</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionproperty.getmodifiers.php" class="methodname" style="color:#CC7832">getModifiers</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">int</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionproperty.getname.php" class="methodname" style="color:#CC7832">getName</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionproperty.gettype.php" class="methodname" style="color:#CC7832">getType</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><span class="type ?ReflectionType" style="color:#EAB766">?ReflectionType</span></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionproperty.getvalue.php" class="methodname" style="color:#CC7832">getValue</a></span>     ([ <span class="methodparam"><span class="type" style="color:#EAB766">object</span> <span class="parameter" style="color:#2EACF9">$object</span></span>   ] ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionproperty.hastype.php" class="methodname" style="color:#CC7832">hasType</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionproperty.isdefault.php" class="methodname" style="color:#CC7832">isDefault</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionproperty.isinitialized.php" class="methodname" style="color:#CC7832">isInitialized</a></span>     ([ <span class="methodparam"><span class="type" style="color:#EAB766">object</span> <span class="parameter" style="color:#2EACF9">$object</span></span>   ] ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionproperty.isprivate.php" class="methodname" style="color:#CC7832">isPrivate</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionproperty.isprotected.php" class="methodname" style="color:#CC7832">isProtected</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionproperty.ispublic.php" class="methodname" style="color:#CC7832">isPublic</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionproperty.isstatic.php" class="methodname" style="color:#CC7832">isStatic</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionproperty.setaccessible.php" class="methodname" style="color:#CC7832">setAccessible</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">bool</span> <span class="parameter" style="color:#2EACF9">$accessible</span></span>    ) : <span class="type" style="color:#EAB766"><span class="type void" style="color:#EAB766">void</span></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionproperty.setvalue.php" class="methodname" style="color:#CC7832">setValue</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">object</span> <span class="parameter" style="color:#2EACF9">$object</span></span>    , <span class="methodparam"><span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span> <span class="parameter" style="color:#2EACF9">$value</span></span>    ) : <span class="type" style="color:#EAB766"><span class="type void" style="color:#EAB766">void</span></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionproperty.tostring.php" class="methodname" style="color:#CC7832">__toString</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div>     }</div>     </div>        <div class="section" id="reflectionproperty.props">    <h2 class="title">Properties</h2>    <dl>            <dt id="reflectionproperty.props.name"><var class="varname"><var class="varname">name</var></var></dt>       <dd>        <p class="para">        Name of the property. Read-only, throws        <a href="https://www.php.net/manual/en/class.reflectionexception.php" class="classname">ReflectionException</a> in attempt to write.       </p>      </dd>                 <dt id="reflectionproperty.props.class"><var class="varname"><var class="varname">class</var></var></dt>       <dd>        <p class="para">        Name of the class where the property is defined. Read-only, throws        <a href="https://www.php.net/manual/en/class.reflectionexception.php" class="classname">ReflectionException</a> in attempt to write.       </p>      </dd>          </dl>    </div>         <div class="section" id="reflectionproperty.constants">    <h2 class="title">Predefined Constants</h2>    <div class="section" id="reflectionproperty.constants.modifiers">     <h2 class="title">ReflectionProperty Modifiers</h2>     <dl>               <dt id="reflectionproperty.constants.is-static"><strong><span>ReflectionProperty::IS_STATIC</span></strong></dt>        <dd>         <p class="para">         Indicates <a href="https://www.php.net/manual/en/language.oop5.static.php" class="link">static</a>         properties.        </p>       </dd>                     <dt id="reflectionproperty.constants.is-public"><strong><span>ReflectionProperty::IS_PUBLIC</span></strong></dt>        <dd>         <p class="para">         Indicates <a href="https://www.php.net/manual/en/language.oop5.visibility.php" class="link">public</a>         properties.        </p>       </dd>                     <dt id="reflectionproperty.constants.is-protected"><strong><span>ReflectionProperty::IS_PROTECTED</span></strong></dt>        <dd>         <p class="para">         Indicates <a href="https://www.php.net/manual/en/language.oop5.visibility.php" class="link">protected</a>         properties.        </p>       </dd>                     <dt id="reflectionproperty.constants.is-private"><strong><span>ReflectionProperty::IS_PRIVATE</span></strong></dt>        <dd>         <p class="para">         Indicates <a href="https://www.php.net/manual/en/language.oop5.visibility.php" class="link">private</a>         properties.        </p>       </dd>             </dl>     </div>   </div>     </div>                                                                                                                                          <h2>Table of Contents</h2><ul class="chunklist chunklist_reference"><li>{@link ReflectionProperty::__clone} — Clone</li><li>{@link ReflectionProperty::__construct} — Construct a ReflectionProperty object</li><li>{@link ReflectionProperty::export} — Export</li><li>{@link ReflectionProperty::getDeclaringClass} — Gets declaring class</li><li>{@link ReflectionProperty::getDocComment} — Gets the property doc comment</li><li>{@link ReflectionProperty::getModifiers} — Gets the property modifiers</li><li>{@link ReflectionProperty::getName} — Gets property name</li><li>{@link ReflectionProperty::getType} — Gets a property's type</li><li>{@link ReflectionProperty::getValue} — Gets value</li><li>{@link ReflectionProperty::hasType} — Checks if property has a type</li><li>{@link ReflectionProperty::isDefault} — Checks if property is a default property</li><li>{@link ReflectionProperty::isInitialized} — Checks whether a property is initialized</li><li>{@link ReflectionProperty::isPrivate} — Checks if property is private</li><li>{@link ReflectionProperty::isProtected} — Checks if property is protected</li><li>{@link ReflectionProperty::isPublic} — Checks if property is public</li><li>{@link ReflectionProperty::isStatic} — Checks if property is static</li><li>{@link ReflectionProperty::setAccessible} — Set property accessibility</li><li>{@link ReflectionProperty::setValue} — Set property value</li><li>{@link ReflectionProperty::__toString} — To string</li></ul> </div>
*/
class ReflectionProperty implements Reflector {
	const IS_STATIC = 1;
	const IS_PUBLIC = 256;
	const IS_PROTECTED = 512;
	const IS_PRIVATE = 1024;

	public $name;
	public $class;


	/**
	 * Clone
	 * @link http://php.net/manual/en/reflectionproperty.clone.php
	 * @return void 
	 * @since 5.0
	 */
	final private function __clone () {}

	/**
	 * Export
	 * @link http://php.net/manual/en/reflectionproperty.export.php
	 * @param mixed $class 
	 * @param string $name <p>
	 * The property name.
	 * </p>
	 * @param bool $return [optional] <p>
	 * Setting to <b>TRUE</b> will return the export,
	 * as opposed to emitting it. Setting to <b>FALSE</b> (the default) will do the opposite.
	 * </p>
	 * @return string
	 * @since 5.0
	 */
	public static function export ($class, $name, $return = null) {}

	/**
	 * Construct a ReflectionProperty object
	 * @link http://php.net/manual/en/reflectionproperty.construct.php
	 * @param mixed $class <p>
	 * The class name, that contains the property.
	 * </p>
	 * @param string $name <p>
	 * The name of the property being reflected.
	 * </p>
	 * @throws \ReflectionException if the class or property does not exist.
	 * @since 5.0
	 */
	public function __construct ($class, $name) {}

	/**
	 * To string
	 * @link http://php.net/manual/en/reflectionproperty.tostring.php
	 * @return string
	 * @since 5.0
	 */
	public function __toString () {}

	/**
	 * Gets property name
	 * @link http://php.net/manual/en/reflectionproperty.getname.php
	 * @return string The name of the reflected property.
	 * @since 5.0
	 */
	public function getName () {}

	/**
	 * Gets value
	 * @link http://php.net/manual/en/reflectionproperty.getvalue.php
	 * @param object $object [optional]<p>
	 * If the property is non-static an object must be provided to fetch the
	 * property from. If you want to fetch the default property without
	 * providing an object use <b>ReflectionClass::getDefaultProperties</b>
	 * instead.
	 * </p>
	 * @return mixed The current value of the property.
	 * @since 5.0
	 */
	public function getValue ($object) {}

	/**
	 * Set property value
	 * @link http://php.net/manual/en/reflectionproperty.setvalue.php
	 * @param object $object [optional]<p>
	 * If the property is non-static an object must be provided to change
	 * the property on. If the property is static this parameter is left
	 * out and only <i>value</i> needs to be provided.
	 * </p>
	 * @param mixed $value <p>
	 * The new value.
	 * </p>
	 * @return void No value is returned.
	 * @since 5.0
	 */
	public function setValue ($object, $value) {}

	/**
	 * Set static property value
	 * @link http://php.net/manual/en/reflectionproperty.setvalue.php
	 * @param mixed $value The new value.
	 * @return void No value is returned.
	 * @since 5.0
	 */
	public function setValue ($value) {}

	/**
	 * Checks if property is public
	 * @link http://php.net/manual/en/reflectionproperty.ispublic.php
	 * @return bool <b>TRUE</b> if the property is public, <b>FALSE</b> otherwise.
	 * @since 5.0
	 */
	public function isPublic () {}

	/**
	 * Checks if property is private
	 * @link http://php.net/manual/en/reflectionproperty.isprivate.php
	 * @return bool <b>TRUE</b> if the property is private, <b>FALSE</b> otherwise.
	 * @since 5.0
	 */
	public function isPrivate () {}

	/**
	 * Checks if property is protected
	 * @link http://php.net/manual/en/reflectionproperty.isprotected.php
	 * @return bool <b>TRUE</b> if the property is protected, <b>FALSE</b> otherwise.
	 * @since 5.0
	 */
	public function isProtected () {}

	/**
	 * Checks if property is static
	 * @link http://php.net/manual/en/reflectionproperty.isstatic.php
	 * @return bool <b>TRUE</b> if the property is static, <b>FALSE</b> otherwise.
	 * @since 5.0
	 */
	public function isStatic () {}

	/**
	 * Checks if default value
	 * @link http://php.net/manual/en/reflectionproperty.isdefault.php
	 * @return bool <b>TRUE</b> if the property was declared at compile-time, or <b>FALSE</b> if
	 * it was created at run-time.
	 * @since 5.0
	 */
	public function isDefault () {}

	/**
	 * Gets modifiers
	 * @link http://php.net/manual/en/reflectionproperty.getmodifiers.php
	 * @return int A numeric representation of the modifiers.
	 * @since 5.0
	 */
	public function getModifiers () {}

	/**
	 * Gets declaring class
	 * @link http://php.net/manual/en/reflectionproperty.getdeclaringclass.php
	 * @return ReflectionClass A <b>ReflectionClass</b> object.
	 * @since 5.0
	 */
	public function getDeclaringClass () {}

	/**
	 * Gets doc comment
	 * @link http://php.net/manual/en/reflectionproperty.getdoccomment.php
	 * @return string|bool The doc comment if it exists, otherwise <b>FALSE</b>
	 * @since 5.1.0
	 */
	public function getDocComment () {}

	/**
	 * Set property accessibility
	 * @link http://php.net/manual/en/reflectionproperty.setaccessible.php
	 * @param bool $accessible <p>
	 * <b>TRUE</b> to allow accessibility, or <b>FALSE</b>.
	 * </p>
	 * @return void No value is returned.
	 * @since 5.3.0
	 */
	public function setAccessible ($accessible) {}

}

/**
*<div id="class.reflectionextension" class="reference">   <h1 class="title">The ReflectionExtension class</h1>     <div class="partintro"><p class="verinfo">(PHP 5, PHP 7)</p>     <div class="section" id="reflectionextension.intro">    <h2 class="title">Introduction</h2>    <p class="para">     The <strong class="classname">ReflectionExtension</strong> class reports     information about an extension.    </p>   </div>     <div class="section" id="reflectionextension.synopsis">    <h2 class="title">Class synopsis</h2>      <div class="classsynopsis">     <div class="ooclass"></div>       <div class="classsynopsisinfo">      <span class="ooclass">       <strong class="classname">ReflectionExtension</strong>      </span>            <span class="oointerface">implements        <span class="interfacename"><a href="https://www.php.net/manual/en/class.reflector.php" class="interfacename">Reflector</a></span>      </span>      {</div>      <div class="classsynopsisinfo classsynopsisinfo_comment">// Properties </div>     <div class="fieldsynopsis">      <span class="modifier">public</span>       <var class="varname"><a href="https://www.php.net/manual/en/class.reflectionextension.php#reflectionextension.props.name">$<var class="varname">name</var></a></var>     ;</div>            <div class="classsynopsisinfo classsynopsisinfo_comment">// Methods </div>     <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">final</span> <span class="modifier">private</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionextension.clone.php" class="methodname" style="color:#CC7832">__clone</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><span class="type void" style="color:#EAB766">void</span></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionextension.construct.php" class="methodname" style="color:#CC7832">__construct</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    )</div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="modifier">static</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionextension.export.php" class="methodname" style="color:#CC7832">export</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$return</span><span class="initializer"> = <strong><span>FALSE</span></strong></span></span>   ] ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionextension.getclasses.php" class="methodname" style="color:#CC7832">getClasses</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">array</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionextension.getclassnames.php" class="methodname" style="color:#CC7832">getClassNames</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">array</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionextension.getconstants.php" class="methodname" style="color:#CC7832">getConstants</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">array</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionextension.getdependencies.php" class="methodname" style="color:#CC7832">getDependencies</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">array</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionextension.getfunctions.php" class="methodname" style="color:#CC7832">getFunctions</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">array</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionextension.getinientries.php" class="methodname" style="color:#CC7832">getINIEntries</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">array</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionextension.getname.php" class="methodname" style="color:#CC7832">getName</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionextension.getversion.php" class="methodname" style="color:#CC7832">getVersion</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionextension.info.php" class="methodname" style="color:#CC7832">info</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><span class="type void" style="color:#EAB766">void</span></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionextension.ispersistent.php" class="methodname" style="color:#CC7832">isPersistent</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><span class="type void" style="color:#EAB766">void</span></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionextension.istemporary.php" class="methodname" style="color:#CC7832">isTemporary</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><span class="type void" style="color:#EAB766">void</span></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionextension.tostring.php" class="methodname" style="color:#CC7832">__toString</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div>     }</div>     </div>        <div class="section" id="reflectionextension.props">    <h2 class="title">Properties</h2>    <dl>            <dt id="reflectionextension.props.name"><var class="varname"><var class="varname">name</var></var></dt>       <dd>        <p class="para">        Name of the extension, same as calling the         <span class="methodname" style="color:#CC7832">{@link ReflectionExtension::getName()}</span>         method.       </p>      </dd>          </dl>    </div>     </div>                                                                                                              <h2>Table of Contents</h2><ul class="chunklist chunklist_reference"><li>{@link ReflectionExtension::__clone} — Clones</li><li>{@link ReflectionExtension::__construct} — Constructs a ReflectionExtension</li><li>{@link ReflectionExtension::export} — Export</li><li>{@link ReflectionExtension::getClasses} — Gets classes</li><li>{@link ReflectionExtension::getClassNames} — Gets class names</li><li>{@link ReflectionExtension::getConstants} — Gets constants</li><li>{@link ReflectionExtension::getDependencies} — Gets dependencies</li><li>{@link ReflectionExtension::getFunctions} — Gets extension functions</li><li>{@link ReflectionExtension::getINIEntries} — Gets extension ini entries</li><li>{@link ReflectionExtension::getName} — Gets extension name</li><li>{@link ReflectionExtension::getVersion} — Gets extension version</li><li>{@link ReflectionExtension::info} — Print extension info</li><li>{@link ReflectionExtension::isPersistent} — Returns whether this extension is persistent</li><li>{@link ReflectionExtension::isTemporary} — Returns whether this extension is temporary</li><li>{@link ReflectionExtension::__toString} — To string</li></ul> </div>
*/
class ReflectionExtension implements Reflector {
	public $name;


	/**
	 * Clones
	 * @link http://php.net/manual/en/reflectionextension.clone.php
	 * @return void No value is returned, if called a fatal error will occur.
	 * @since 5.0
	 */
	final private function __clone () {}

	/**
	 * Export
	 * @link http://php.net/manual/en/reflectionextension.export.php
	 * @param string $name <p>
	 * The reflection to export.
	 * </p>
	 * @param string $return [optional] <p>
	 * Setting to <b>TRUE</b> will return the export,
	 * as opposed to emitting it. Setting to <b>FALSE</b> (the default) will do the opposite.
	 * </p>
	 * @return string If the <i>return</i> parameter
	 * is set to <b>TRUE</b>, then the export is returned as a string,
	 * otherwise <b>NULL</b> is returned.
	 * @since 5.0
	 */
	public static function export ($name, $return = false) {}

	/**
	 * Constructs a ReflectionExtension
	 * @link http://php.net/manual/en/reflectionextension.construct.php
	 * @param string $name <p>
	 * Name of the extension.
	 * </p>
	 * @throws \ReflectionException if the extension does not exist.
	 * @since 5.0
	 */
	public function __construct ($name) {}

	/**
	 * To string
	 * @link http://php.net/manual/en/reflectionextension.tostring.php
	 * @return string the exported extension as a string, in the same way as the
	 * <b>ReflectionExtension::export</b>.
	 * @since 5.0
	 */
	public function __toString () {}

	/**
	 * Gets extension name
	 * @link http://php.net/manual/en/reflectionextension.getname.php
	 * @return string The extensions name.
	 * @since 5.0
	 */
	public function getName () {}

	/**
	 * Gets extension version
	 * @link http://php.net/manual/en/reflectionextension.getversion.php
	 * @return string The version of the extension.
	 * @since 5.0
	 */
	public function getVersion () {}

	/**
	 * Gets extension functions
	 * @link http://php.net/manual/en/reflectionextension.getfunctions.php
/**
*<div id="function.defined" class="refentry">  <div class="refnamediv">   <h1 class="refname">defined</h1>   <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">defined</span> &mdash; <span class="dc-title">Checks whether a given named constant exists</span></p>   </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.defined-description">   <h3 class="title">Description</h3>   <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><strong>defined</strong></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    ) : <span class="type" style="color:#EAB766">bool</span></div>    <p class="para rdfs-comment">    Checks whether the given constant exists and is defined.   </p>   <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>:     <p class="para">     If you want to see if a variable exists, use <span class="function">{@link isset()}</span>     as <span class="function"><strong style="color:#CC7832">defined()</strong></span> only applies to <a href="https://www.php.net/manual/en/language.constants.php" class="link">constants</a>. If you want to see if a     function exists, use <span class="function">{@link function_exists()}</span>.    </p>   </p></blockquote>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.defined-parameters">   <h3 class="title">Parameters</h3>   <span>    <dl>            <dt> <span class="parameter" style="color:#2EACF9">name</span></dt>       <dd>        <p class="para">        The constant name.       </p>      </dd>          </dl>    </span>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.defined-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    Returns <strong><span>TRUE</span></strong> if the named constant given by <span class="parameter" style="color:#2EACF9">name</span>    has been defined, <strong><span>FALSE</span></strong> otherwise.   </p>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.defined-examples">   <h3 class="title">Examples</h3>   <span>    <div class="example" id="example-4699">     <p><strong>Example #1 Checking Constants</strong></p>     <div class="example-contents"> <div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"> <span style="color: #9876AA">&lt;?php<br /></span><span style="color: #FF8000">//&nbsp;Note&nbsp;the&nbsp;use&nbsp;of&nbsp;quotes,&nbsp;this&nbsp;is&nbsp;important.&nbsp;&nbsp;This&nbsp;example&nbsp;is&nbsp;checking<br />&nbsp;*&nbsp;if&nbsp;the&nbsp;string&nbsp;'TEST'&nbsp;is&nbsp;the&nbsp;name&nbsp;of&nbsp;a&nbsp;constant&nbsp;named&nbsp;TEST&nbsp;<br /></span><span style="color: #007700">if&nbsp;(</span><span style="color: #9876AA">defined</span><span style="color: #007700">(</span><span style="color: #DD0000">'TEST'</span><span style="color: #007700">))&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #9876AA">TEST</span><span style="color: #007700">;<br />}<br /></span><span style="color: #9876AA">?&gt;</span> </span> </span></div>     </div>     </div>   </span>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.defined-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><span class="function">{@link define()} - Defines a named constant</span></li>     <li class="member"><span class="function">{@link constant()} - Returns the value of a constant</span></li>     <li class="member"><span class="function">{@link get_defined_constants()} - Returns an associative array with the names of all the constants and their values</span></li>     <li class="member"><span class="function">{@link function_exists()} - Return TRUE if the given function has been defined</span></li>     <li class="member">The section on <a href="https://www.php.net/manual/en/language.constants.php" class="link">Constants</a></li>    </ul>   </span>  </div>   </div>
         * @return ReflectionFunction[] An associative array of <b>ReflectionFunction</b> objects,*/
	 * for each function defined in the extension with the keys being the function
	 * names. If no function are defined, an empty array is returned.
	 * @since 5.0
	 */
	public function getFunctions () {}

	/**
	 * Gets constants
	 * @link http://php.net/manual/en/reflectionextension.getconstants.php
	 * @return array An associative array with constant names as keys.
	 * @since 5.0
	 */
	public function getConstants () {}

	/**
	 * Gets extension ini entries
	 * @link http://php.net/manual/en/reflectionextension.getinientries.php
	 * @return array An associative array with the ini entries as keys,
	 * with their defined values as values.
	 * @since 5.0
	 */
	public function getINIEntries () {}

	/**
	 * Gets classes
	 * @link http://php.net/manual/en/reflectionextension.getclasses.php
         * @return ReflectionClass[] An array of <b>ReflectionClass</b> objects, one
	 * for each class within the extension. If no classes are defined,
	 * an empty array is returned.
	 * @since 5.0
	 */
	public function getClasses () {}

	/**
	 * Gets class names
	 * @link http://php.net/manual/en/reflectionextension.getclassnames.php
	 * @return array An array of class names, as defined in the extension.
	 * If no classes are defined, an empty array is returned.
	 * @since 5.0
	 */
	public function getClassNames () {}

	/**
	 * Gets dependencies
	 * @link http://php.net/manual/en/reflectionextension.getdependencies.php
	 * @return array An associative array with dependencies as keys and
	 * either Required, Optional
	 * or Conflicts as the values.
	 * @since 5.0
	 */
	public function getDependencies () {}

	/**
	 * Gets extension info
	 * @link http://php.net/manual/en/reflectionextension.info.php
	 * @return string Information about the extension.
	 * @since 5.0
	 */
	public function info () {}

	/**
	 * Returns whether this extension is persistent
	 * @link http://php.net/manual/en/reflectionextension.ispersistent.php
	 * @return bool <b>TRUE</b> for extensions loaded by extension, <b>FALSE</b>
	 * otherwise.
	 * @since 5.4.0
	 */
	public function isPersistent () {}

	/**
	 * Returns whether this extension is temporary
	 * @link http://php.net/manual/en/reflectionextension.istemporary.php
	 * @return bool <b>TRUE</b> for extensions loaded by <b>dl</b>,
	 * <b>FALSE</b> otherwise.
	 * @since 5.4.0
	 */
	public function isTemporary () {}


}

/**
*<div id="class.reflectionzendextension" class="reference">   <h1 class="title">The ReflectionZendExtension class</h1>     <div class="partintro"><p class="verinfo">(PHP 5 &gt;= 5.4.0, PHP 7)</p>     <div class="section" id="reflectionzendextension.intro">    <h2 class="title">Introduction</h2>    <p class="para">     </p>   </div>     <div class="section" id="reflectionzendextension.synopsis">    <h2 class="title">Class synopsis</h2>      <div class="classsynopsis">     <div class="ooclass"></div>       <div class="classsynopsisinfo">      <span class="ooclass">       <strong class="classname">ReflectionZendExtension</strong>      </span>            <span class="oointerface">implements        <span class="interfacename"><a href="https://www.php.net/manual/en/class.reflector.php" class="interfacename">Reflector</a></span>      </span>      {</div>      <div class="classsynopsisinfo classsynopsisinfo_comment">// Properties </div>     <div class="fieldsynopsis">      <span class="modifier">public</span>       <var class="varname"><a href="https://www.php.net/manual/en/class.reflectionzendextension.php#reflectionzendextension.props.name">$<var class="varname">name</var></a></var>     ;</div>            <div class="classsynopsisinfo classsynopsisinfo_comment">// Methods </div>     <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">final</span> <span class="modifier">private</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionzendextension.clone.php" class="methodname" style="color:#CC7832">__clone</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><span class="type void" style="color:#EAB766">void</span></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionzendextension.construct.php" class="methodname" style="color:#CC7832">__construct</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    )</div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="modifier">static</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionzendextension.export.php" class="methodname" style="color:#CC7832">export</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">bool</span> <span class="parameter" style="color:#2EACF9">$return</span></span>   ] ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionzendextension.getauthor.php" class="methodname" style="color:#CC7832">getAuthor</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionzendextension.getcopyright.php" class="methodname" style="color:#CC7832">getCopyright</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionzendextension.getname.php" class="methodname" style="color:#CC7832">getName</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionzendextension.geturl.php" class="methodname" style="color:#CC7832">getURL</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionzendextension.getversion.php" class="methodname" style="color:#CC7832">getVersion</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionzendextension.tostring.php" class="methodname" style="color:#CC7832">__toString</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div>     }</div>     </div>        <div class="section" id="reflectionzendextension.props">    <h2 class="title">Properties</h2>    <dl>            <dt id="reflectionzendextension.props.name"><var class="varname"><var class="varname">name</var></var></dt>       <dd>        <p class="para">        Name of the extension. Read-only, throws        <a href="https://www.php.net/manual/en/class.reflectionexception.php" class="classname">ReflectionException</a> in attempt to write.       </p>      </dd>          </dl>    </div>     </div>                                                                    <h2>Table of Contents</h2><ul class="chunklist chunklist_reference"><li>{@link ReflectionZendExtension::__clone} — Clone handler</li><li>{@link ReflectionZendExtension::__construct} — Constructor</li><li>{@link ReflectionZendExtension::export} — Export</li><li>{@link ReflectionZendExtension::getAuthor} — Gets author</li><li>{@link ReflectionZendExtension::getCopyright} — Gets copyright</li><li>{@link ReflectionZendExtension::getName} — Gets name</li><li>{@link ReflectionZendExtension::getURL} — Gets URL</li><li>{@link ReflectionZendExtension::getVersion} — Gets version</li><li>{@link ReflectionZendExtension::__toString} — To string handler</li></ul> </div>
*/
class ReflectionZendExtension implements Reflector {
	public $name;


	/**
	 * Clone handler
	 * @link http://php.net/manual/en/reflectionzendextension.clone.php
	 * @return void
	 * @since 5.4.0
	 */
	final private function __clone () {}

	/**
	 * Export
	 * @link http://php.net/manual/en/reflectionzendextension.export.php
	 * @param string $name <p>
	 * </p>
	 * @param string $return [optional] <p>
	 * </p>
	 * @return string
	 * @since 5.4.0
	 */
	public static function export ($name, $return = null) {}

	/**
	 * Constructor
	 * @link http://php.net/manual/en/reflectionzendextension.construct.php
	 * @param string $name <p>
	 * </p>
	 * @throws \ReflectionException if the extension does not exist.
	 * @since 5.4.0
	 */
	public function __construct ($name) {}

	/**
	 * To string handler
	 * @link http://php.net/manual/en/reflectionzendextension.tostring.php
	 * @return string
	 * @since 5.4.0
	 */
	public function __toString () {}

	/**
	 * Gets name
	 * @link http://php.net/manual/en/reflectionzendextension.getname.php
	 * @return string
	 * @since 5.4.0
	 */
	public function getName () {}

	/**
	 * Gets version
	 * @link http://php.net/manual/en/reflectionzendextension.getversion.php
	 * @return string
	 * @since 5.4.0
	 */
	public function getVersion () {}

	/**
	 * Gets author
	 * @link http://php.net/manual/en/reflectionzendextension.getauthor.php
	 * @return string
	 * @since 5.4.0
	 */
	public function getAuthor () {}

	/**
	 * Gets URL
	 * @link http://php.net/manual/en/reflectionzendextension.geturl.php
	 * @return string
	 * @since 5.4.0
	 */
	public function getURL () {}

	/**
	 * Gets copyright
	 * @link http://php.net/manual/en/reflectionzendextension.getcopyright.php
	 * @return string
	 * @since 5.4.0
	 */
	public function getCopyright () {}

}

/**
*<div id="class.reflectiongenerator" class="reference">   <h1 class="title">The ReflectionGenerator class</h1>     <div class="partintro"><p class="verinfo">(PHP 7)</p>     <div class="section" id="reflectiongenerator.intro">    <h2 class="title">Introduction</h2>    <p class="para">     The <strong class="classname">ReflectionGenerator</strong> class reports     information about a generator.    </p>   </div>     <div class="section" id="reflectiongenerator.synopsis">    <h2 class="title">Class synopsis</h2>      <div class="classsynopsis">     <div class="ooclass"></div>       <div class="classsynopsisinfo">      <span class="ooclass">       <strong class="classname">ReflectionGenerator</strong>      </span>      {</div>      <div class="classsynopsisinfo classsynopsisinfo_comment">// Methods </div>     <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectiongenerator.construct.php" class="methodname" style="color:#CC7832">__construct</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/class.generator.php" class="type Generator" style="color:#EAB766">Generator</a></span> <span class="parameter" style="color:#2EACF9">$generator</span></span>    )</div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectiongenerator.getexecutingfile.php" class="methodname" style="color:#CC7832">getExecutingFile</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectiongenerator.getexecutinggenerator.php" class="methodname" style="color:#CC7832">getExecutingGenerator</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/class.generator.php" class="type Generator" style="color:#EAB766">Generator</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectiongenerator.getexecutingline.php" class="methodname" style="color:#CC7832">getExecutingLine</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">int</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link getFunction}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/class.reflectionfunctionabstract.php" class="type ReflectionFunctionAbstract" style="color:#EAB766">ReflectionFunctionAbstract</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectiongenerator.getthis.php" class="methodname" style="color:#CC7832">getThis</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">object</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectiongenerator.gettrace.php" class="methodname" style="color:#CC7832">getTrace</a></span>     ([ <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$options</span><span class="initializer"> = DEBUG_BACKTRACE_PROVIDE_OBJECT</span></span>   ] ) : <span class="type" style="color:#EAB766">array</span></div>      }</div>    </div>   </div>                                                      <h2>Table of Contents</h2><ul class="chunklist chunklist_reference"><li>{@link ReflectionGenerator::__construct} — Constructs a ReflectionGenerator object</li><li>{@link ReflectionGenerator::getExecutingFile} — Gets the file name of the currently executing generator</li><li>{@link ReflectionGenerator::getExecutingGenerator} — Gets the executing Generator object</li><li>{@link ReflectionGenerator::getExecutingLine} — Gets the currently executing line of the generator</li><li>{@link ReflectionGenerator::getFunction} — Gets the function name of the generator</li><li>{@link ReflectionGenerator::getThis} — Gets the $this value of the generator</li><li>{@link ReflectionGenerator::getTrace} — Gets the trace of the executing generator</li></ul> </div>
*/
class ReflectionGenerator
{
	/* Methods */
	/**
	 * Constructs a ReflectionGenerator object
	 * @link http://php.net/manual/en/reflectiongenerator.construct.php
	 * @param Generator $generator A generator object.
	 * @since 7.0
	 */
	public function __construct(Generator $generator)
	{
	}

	/**
	 *  Gets the file name of the currently executing generator
	 * @link http://php.net/manual/en/reflectiongenerator.getexecutingfile.php
	 * @return string Returns the full path and file name of the currently executing generator.
	 * @since 7.0
	 *
	 */
	public function getExecutingFile()
	{
	}

	/**
	 * Gets the executing Generator object
	 * @link http://php.net/manual/en/reflectiongenerator.construct.php
	 * @return Generator Returns the currently executing Generator object.
	 * @since 7.0
	 *
	 */
	public function getExecutingGenerator()
	{
	}

	/**
	 * Gets the currently executing line of the generator
	 * @link http://php.net/manual/en/reflectiongenerator.getexecutingline.php
	 * @return int Returns the line number of the currently executing statement in the generator.
	 * @since 7.0
	 */
	public function getExecutingLine()
	{
	}

	/**
	 * Gets the function name of the generator
	 * @link http://php.net/manual/en/reflectiongenerator.getfunction.php
	 * @return ReflectionFunctionAbstract Returns a ReflectionFunctionAbstract class. This will be ReflectionFunction for functions, or ReflectionMethod for methods.
	 * @since 7.0
	 */
	public function getFunction()
	{
	}

	/**
	 * Gets the function name of the generator
	 * @link http://php.net/manual/en/reflectiongenerator.getthis.php
	 * @return object|null Returns the $this value, or NULL if the generator was not created in a class context.
	 * @since 7.0
	 */
	public function getThis()
	{
	}

	/**
	 * Gets the trace of the executing generator
	 * @link http://php.net/manual/en/reflectiongenerator.gettrace.php
	 * @param int $options [optional] <p>
	 * The value of <em>options</em> can be any of the following
	 * the following flags.
	 * </p>
	 * <table>
	 * <b>Available options</b>
	 *
	 * <thead>
	 * <tr>
	 * <th>Option</th>
	 * <th>Description</th>
	 * </tr>
	 *
	 * </thead>
	 *
	 * <tbody class="tbody">
	 * <tr>
	 * <td>
	 * <b>DEBUG_BACKTRACE_PROVIDE_OBJECT</b>
	 * </td>
	 * <td>
	 * Default.
	 * </td>
	 * </tr>
	 *
	 * <tr>
	 * <td>
	 * <b>DEBUG_BACKTRACE_IGNORE_ARGS</B>
	 * </td>
	 * <td>
	 * Don't include the argument information for functions in the stack
	 * trace.
	 * </td>
	 * </tr>
	 *
	 * </tbody>
	 *
	 * </table>
	 * @return array Returns the trace of the currently executing generator.
	 * @since 7.0
	 */
	public function getTrace($options = DEBUG_BACKTRACE_PROVIDE_OBJECT)
	{
	}
}

/**
*<div id="class.reflectiontype" class="reference">   <h1 class="title">The ReflectionType class</h1>     <div class="partintro"><p class="verinfo">(PHP 7)</p>     <div class="section" id="reflectiontype.intro">    <h2 class="title">Introduction</h2>    <p class="para">     The <strong class="classname">ReflectionType</strong> class reports     information about a function&#039;s return type.    </p>   </div>     <div class="section" id="reflectiontype.synopsis">    <h2 class="title">Class synopsis</h2>      <div class="classsynopsis">     <div class="ooclass"></div>       <div class="classsynopsisinfo">      <span class="ooclass">       <strong class="classname">ReflectionType</strong>      </span>      {</div>      <div class="classsynopsisinfo classsynopsisinfo_comment">// Methods </div>     <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectiontype.allowsnull.php" class="methodname" style="color:#CC7832">allowsNull</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectiontype.isbuiltin.php" class="methodname" style="color:#CC7832">isBuiltin</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectiontype.tostring.php" class="methodname" style="color:#CC7832">__toString</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div>      }</div>    </div>   </div>                          <h2>Table of Contents</h2><ul class="chunklist chunklist_reference"><li>{@link ReflectionType::allowsNull} — Checks if null is allowed</li><li>{@link ReflectionType::isBuiltin} — Checks if it is a built-in type</li><li>{@link ReflectionType::__toString} — To string</li></ul> </div>
*/
class ReflectionType
{
	/* Methods */
	/**
	 * Checks if null is allowed
	 * @link http://php.net/manual/en/reflectiontype.allowsnull.php
	 * @return bool TRUE if NULL is allowed, otherwise FALSE
	 * @since 7.0
	 */
	public function allowsNull()
	{
	}

	/**
	 * Checks if it is a built-in type
	 * @link http://php.net/manual/en/reflectiontype.isbuiltin.php
	 * @return bool TRUE if it's a built-in type, otherwise FALSE
	 * @since 7.0
	 */
	public function isBuiltin()
	{
	}

	/**
	 * To string
	 * @link http://php.net/manual/en/reflectiontype.tostring.php
	 * @return string Returns the type of the parameter.
	 * @since 7.0
	 * @deprecated 7.1.0:8.0.0 Please use getName()
	 * @see \ReflectionType::getName()
	 */
	public function __toString()
	{
	}

	/**
	 * Get type of the parameter.
	 * @return string Returns the type of the parameter.
	 * @since 7.1.0
	 */
	public function getName()
	{
	}

    private final function __clone() {}

}

/**
*<div id="class.reflectionclassconstant" class="reference">   <h1 class="title">The ReflectionClassConstant class</h1>     <div class="partintro"><p class="verinfo">(PHP 7 &gt;= 7.1.0)</p>     <div class="section" id="reflectionclassconstant.intro">    <h2 class="title">Introduction</h2>    <p class="para">     The <strong class="classname">ReflectionClassConstant</strong> class reports     information about a class constant.    </p>   </div>     <div class="section" id="reflectionclassconstant.synopsis">    <h2 class="title">Class synopsis</h2>      <div class="classsynopsis">     <div class="ooclass"></div>       <div class="classsynopsisinfo">      <span class="ooclass">       <strong class="classname">ReflectionClassConstant</strong>      </span>            <span class="oointerface">implements        <span class="interfacename"><a href="https://www.php.net/manual/en/class.reflector.php" class="interfacename">Reflector</a></span>      </span>      {</div>      <div class="classsynopsisinfo classsynopsisinfo_comment">// Properties </div>     <div class="fieldsynopsis">      <span class="modifier">public</span>       <var class="varname"><a href="https://www.php.net/manual/en/class.reflectionclassconstant.php#reflectionclassconstant.props.name">$<var class="varname">name</var></a></var>     ;</div>      <div class="fieldsynopsis">      <span class="modifier">public</span>       <var class="varname"><a href="https://www.php.net/manual/en/class.reflectionclassconstant.php#reflectionclassconstant.props.class">$<var class="varname">class</var></a></var>     ;</div>            <div class="classsynopsisinfo classsynopsisinfo_comment">// Methods </div>     <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclassconstant.construct.php" class="methodname" style="color:#CC7832">__construct</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span> <span class="parameter" style="color:#2EACF9">$class</span></span>    , <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    )</div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="modifier">static</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclassconstant.export.php" class="methodname" style="color:#CC7832">export</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span> <span class="parameter" style="color:#2EACF9">$class</span></span>    , <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">bool</span> <span class="parameter" style="color:#2EACF9">$return</span></span>   ] ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclassconstant.getdeclaringclass.php" class="methodname" style="color:#CC7832">getDeclaringClass</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/class.reflectionclass.php" class="type ReflectionClass" style="color:#EAB766">ReflectionClass</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclassconstant.getdoccomment.php" class="methodname" style="color:#CC7832">getDocComment</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclassconstant.getmodifiers.php" class="methodname" style="color:#CC7832">getModifiers</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">int</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclassconstant.getname.php" class="methodname" style="color:#CC7832">getName</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclassconstant.getvalue.php" class="methodname" style="color:#CC7832">getValue</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclassconstant.isprivate.php" class="methodname" style="color:#CC7832">isPrivate</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclassconstant.isprotected.php" class="methodname" style="color:#CC7832">isProtected</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclassconstant.ispublic.php" class="methodname" style="color:#CC7832">isPublic</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionclassconstant.tostring.php" class="methodname" style="color:#CC7832">__toString</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div>     }</div>     </div>        <div class="section" id="reflectionclassconstant.props">    <h2 class="title">Properties</h2>    <dl>            <dt id="reflectionclassconstant.props.name"><var class="varname"><var class="varname">name</var></var></dt>       <dd>        <p class="para">        Name of the class constant. Read-only, throws        <a href="https://www.php.net/manual/en/class.reflectionexception.php" class="classname">ReflectionException</a> in attempt to write.       </p>      </dd>                 <dt id="reflectionclassconstant.props.class"><var class="varname"><var class="varname">class</var></var></dt>       <dd>        <p class="para">        Name of the class where the class constant is defined. Read-only, throws        <a href="https://www.php.net/manual/en/class.reflectionexception.php" class="classname">ReflectionException</a> in attempt to write.       </p>      </dd>          </dl>    </div>    </div>                                                                                  <h2>Table of Contents</h2><ul class="chunklist chunklist_reference"><li>{@link ReflectionClassConstant::__construct} — Constructs a ReflectionClassConstant</li><li>{@link ReflectionClassConstant::export} — Export</li><li>{@link ReflectionClassConstant::getDeclaringClass} — Gets declaring class</li><li>{@link ReflectionClassConstant::getDocComment} — Gets doc comments</li><li>{@link ReflectionClassConstant::getModifiers} — Gets the class constant modifiers</li><li>{@link ReflectionClassConstant::getName} — Get name of the constant</li><li>{@link ReflectionClassConstant::getValue} — Gets value</li><li>{@link ReflectionClassConstant::isPrivate} — Checks if class constant is private</li><li>{@link ReflectionClassConstant::isProtected} — Checks if class constant is protected</li><li>{@link ReflectionClassConstant::isPublic} — Checks if class constant is public</li><li>{@link ReflectionClassConstant::__toString} — Returns the string representation of the ReflectionClassConstant object</li></ul> </div>
*/
class ReflectionClassConstant implements Reflector {

    public $name ;
    public $class ;

    /**
     * ReflectionClassConstant constructor.
     * @since 7.1
     * @link http://php.net/manual/en/reflectionclassconstant.construct.php
     * @param mixed $class Either a string containing the name of the class to reflect, or an object.
     * @param string $name The name of the class constant.
     * @return ReflectionClassConstant
     */
    public function __construct($class, $name) {}

    /**
     * @since 7.1
     * @link http://php.net/manual/en/reflectionclassconstant.export.php
     * @param mixed $class The reflection to export.
     * @param string $name The class constant name.
     * @param bool $return Setting to TRUE will return the export, as opposed to emitting it. Setting to FALSE (the default) will do the opposite.
     * @return string
     */
	public static function export($class, $name, $return) {}

    /**
     * Gets declaring class
     * @since 7.1
     * @link http://php.net/manual/en/reflectionclassconstant.getdeclaringclass.php
     * @return ReflectionClass
     */
	public function getDeclaringClass() {}

    /**
     * Gets doc comments
     * @since 7.1
     * @link http://php.net/manual/en/reflectionclassconstant.getdoccomment.php
     * @return string|bool The doc comment if it exists, otherwise <b>FALSE</b>
     */
	public function getDocComment() {}

    /**
     * Gets the class constant modifiers
     * @since 7.1
     * @link http://php.net/manual/en/reflectionclassconstant.getmodifiers.php
     * @return int
     */
	public function getModifiers() {}

    /**
     * Get name of the constant
     * @since 7.1
     * @link http://php.net/manual/en/reflectionclassconstant.getname.php
     * @return string
     */
	public function getName() {}

    /**
     * Gets value
     * @since 7.1
     * @link http://php.net/manual/en/reflectionclassconstant.getvalue.php
     * @return mixed
     */
	public function getValue() {}

    /**
     * Checks if class constant is private
     * @since 7.1
     * @link http://php.net/manual/en/reflectionclassconstant.isprivate.php
     * @return bool
     */
	public function isPrivate() {}

    /**
     * Checks if class constant is protected
     * @since 7.1
     * @link http://php.net/manual/en/reflectionclassconstant.isprotected.php
     * @return bool
     */
	public function isProtected() {}

    /**
     * Checks if class constant is public
     * @since 7.1
     * @link http://php.net/manual/en/reflectionclassconstant.ispublic.php
     * @param bool
     */
	public function isPublic() {}

    /**
     * Returns the string representation of the ReflectionClassConstant object.
     * @since 7.1
     * @link http://php.net/manual/en/reflectionclassconstant.tostring.php
     * @return string|void
     */
	public function __toString() {}

    private final function __clone() {}

}

/**
*<div id="class.reflectionnamedtype" class="reference">   <h1 class="title">The ReflectionNamedType class</h1>     <div class="partintro"><p class="verinfo">(PHP 7 &gt;= 7.1.0)</p>     <div class="section" id="reflectionnamedtype.intro">    <h2 class="title">Introduction</h2>    <p class="para">     </p>   </div>     <div class="section" id="reflectionnamedtype.synopsis">    <h2 class="title">Class synopsis</h2>      <div class="classsynopsis">     <div class="ooclass"></div>       <div class="classsynopsisinfo">      <span class="ooclass">       <strong class="classname">ReflectionNamedType</strong>      </span>            <span class="ooclass">       <span class="modifier">extends</span>       <a href="https://www.php.net/manual/en/class.reflectiontype.php" class="classname">ReflectionType</a>      </span>      {</div>           <div class="classsynopsisinfo classsynopsisinfo_comment">// Methods </div>     <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/reflectionnamedtype.getname.php" class="methodname" style="color:#CC7832">getName</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div>           <div class="classsynopsisinfo classsynopsisinfo_comment">// Inherited methods </div>     <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionType::allowsNull}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionType::isBuiltin}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link ReflectionType::__toString}</span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div>      }</div>     </div>   </div>            <h2>Table of Contents</h2><ul class="chunklist chunklist_reference"><li>{@link ReflectionNamedType::getName} — Get the text of the type hint</li></ul> </div>
*/
class ReflectionNamedType extends ReflectionType{

}

// End of Reflection v.$Id: bcdcdaeea3aba34a8083bb62c6eda69ff3c3eab5 $
?>
