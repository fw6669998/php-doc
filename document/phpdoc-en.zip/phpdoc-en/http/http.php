<?php

// Start of http v.1.6.6

class HttpException extends Exception  {
	public $innerException;
}
class HttpRuntimeException extends HttpException  {
}
class HttpInvalidParamException extends HttpException  {
}
class HttpHeaderException extends HttpException  {
}
class HttpMalformedHeadersException extends HttpException  {
}
class HttpRequestMethodException extends HttpException  {
}
class HttpMessageTypeException extends HttpException  {
}
class HttpEncodingException extends HttpException  {
}
class HttpRequestException extends HttpException  {
}
class HttpRequestPoolException extends HttpException  {
}
class HttpSocketException extends HttpException  {
}
class HttpResponseException extends HttpException  {
}
class HttpUrlException extends HttpException  {
}
class HttpQueryStringException extends HttpException  {
}

/**
 * @link http://php.net/manual/en/class.httpdeflatestream.php
 */
class HttpDeflateStream  {
	const TYPE_GZIP = 16;
	const TYPE_ZLIB = 0;
	const TYPE_RAW = 32;
	const LEVEL_DEF = 0;
	const LEVEL_MIN = 1;
	const LEVEL_MAX = 9;
	const STRATEGY_DEF = 0;
	const STRATEGY_FILT = 256;
	const STRATEGY_HUFF = 512;
	const STRATEGY_RLE = 768;
	const STRATEGY_FIXED = 1024;
	const FLUSH_NONE = 0;
	const FLUSH_SYNC = 1048576;
	const FLUSH_FULL = 2097152;


	/**
	 * (PECL pecl_http &gt;= 0.21.0)<br/>
	 * HttpDeflateStream class constructor
	 * @link http://php.net/manual/en/function.httpdeflatestream-construct.php
	 * @param int $flags [optional] <p>
	 * initialization flags
	 * </p>
	 * @return void 
	 */
	public function __construct ($flags = null) {}

	/**
	 * (PECL pecl_http &gt;= 0.21.0)<br/>
	 * Update deflate stream
	 * @link http://php.net/manual/en/function.httpdeflatestream-update.php
	 * @param string $data <p>
	 * data to deflate
	 * </p>
	 * @return string deflated data on success or false on failure.
	 */
	public function update ($data) {}

	/**
	 * (PECL pecl_http &gt;= 0.21.0)<br/>
	 * Flush deflate stream
	 * @link http://php.net/manual/en/function.httpdeflatestream-flush.php
	 * @param string $data [optional] <p>
	 * more data to deflate
	 * </p>
	 * @return string some deflated data as string on success or false on failure.
	 */
/**
*<div id="function.flush" class="refentry">  <div class="refnamediv">   <h1 class="refname">flush</h1>   <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">flush</span> &mdash; <span class="dc-title">Flush system output buffer</span></p>   </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.flush-description">   <h3 class="title">Description</h3>   <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><strong>flush</strong></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><span class="type void" style="color:#EAB766">void</span></span></div>    <p class="para rdfs-comment">    Flushes the system write buffers of PHP and whatever backend PHP is using (CGI,    a web server, etc).  This attempts to push current output all the way to    the browser with a few caveats.   </p>   <p class="para">    <span class="function"><strong style="color:#CC7832">flush()</strong></span> may not be able to override the buffering scheme    of your web server and it has no effect on any client-side buffering in the    browser.  It also doesn&#039;t affect PHP&#039;s userspace output buffering mechanism.    This means you will have to call both <span class="function">{@link ob_flush()}</span> and    <span class="function"><strong style="color:#CC7832">flush()</strong></span> to flush the ob output buffers if you are using    those.   </p>   <p class="para">    Several servers, especially on Win32, will still buffer the output from    your script until it terminates before transmitting the results to the    browser.   </p>   <p class="para">    Server modules for Apache like mod_gzip may do buffering of their own that    will cause <span class="function"><strong style="color:#CC7832">flush()</strong></span> to not result in data being sent    immediately to the client.   </p>   <p class="para">    Even the browser may buffer its input before displaying it. Netscape, for    example, buffers text until it receives an end-of-line or the beginning of    a tag, and it won&#039;t render tables until the &lt;/table&gt; tag of the    outermost table is seen.   </p>   <p class="para">    Some versions of Microsoft Internet Explorer will only start to display    the page after they have received 256 bytes of output, so you may need to    send extra whitespace before flushing to get those browsers to display the    page.   </p>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.flush-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    No value is returned.   </p>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.flush-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><span class="function">{@link ob_flush()} - Flush (send) the output buffer</span></li>     <li class="member"><span class="function">{@link ob_clean()} - Clean (erase) the output buffer</span></li>     <li class="member"><span class="function">{@link ob_end_flush()} - Flush (send) the output buffer and turn off output buffering</span></li>     <li class="member"><span class="function">{@link ob_end_clean()} - Clean (erase) the output buffer and turn off output buffering</span></li>    </ul>   </span>  </div>    </div>
*/
	public function flush ($data = null) {}

	/**
	 * (PECL pecl_http &gt;= 0.21.0)<br/>
	 * Finalize deflate stream
	 * @link http://php.net/manual/en/function.httpdeflatestream-finish.php
	 * @param string $data [optional] <p>
	 * data to deflate
	 * </p>
	 * @return string the final part of deflated data.
	 */
	public function finish ($data = null) {}

	/**
	 * (PECL pecl_http &gt;= 1.4.0)<br/>
	 * HttpDeflateStream class factory
	 * @link http://php.net/manual/en/function.httpdeflatestream-factory.php
	 * @param int $flags [optional] <p>
	 * initialization flags
	 * </p>
	 * @param string $class_name [optional] <p>
	 * name of a subclass of HttpDeflateStream
	 * </p>
	 * @return HttpDeflateStream 
	 */
	public static function factory ($flags = null, $class_name = null) {}

}

/**
 * @link http://php.net/manual/en/class.httpinflatestream.php
 */
class HttpInflateStream  {
	const FLUSH_NONE = 0;
	const FLUSH_SYNC = 1048576;
	const FLUSH_FULL = 2097152;


	/**
	 * (PECL pecl_http &gt;= 1.0.0)<br/>
	 * HttpInflateStream class constructor
	 * @link http://php.net/manual/en/function.httpinflatestream-construct.php
	 * @param int $flags [optional] <p>
	 * initialization flags
	 * </p>
	 * @return void 
	 */
	public function __construct ($flags = null) {}

	/**
	 * (PECL pecl_http &gt;= 0.21.0)<br/>
	 * Update inflate stream
	 * @link http://php.net/manual/en/function.httpinflatestream-update.php
	 * @param string $data <p>
	 * data to inflate
	 * </p>
	 * @return string inflated data on success or false on failure.
	 */
	public function update ($data) {}

	/**
	 * (PECL pecl_http &gt;= 0.21.0)<br/>
	 * Flush inflate stream
	 * @link http://php.net/manual/en/function.httpinflatestream-flush.php
	 * @param string $data [optional] <p>
	 * more data to inflate
	 * </p>
	 * @return string some inflated data as string on success or false on failure.
	 */
/**
*<div id="function.flush" class="refentry">  <div class="refnamediv">   <h1 class="refname">flush</h1>   <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">flush</span> &mdash; <span class="dc-title">Flush system output buffer</span></p>   </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.flush-description">   <h3 class="title">Description</h3>   <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><strong>flush</strong></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><span class="type void" style="color:#EAB766">void</span></span></div>    <p class="para rdfs-comment">    Flushes the system write buffers of PHP and whatever backend PHP is using (CGI,    a web server, etc).  This attempts to push current output all the way to    the browser with a few caveats.   </p>   <p class="para">    <span class="function"><strong style="color:#CC7832">flush()</strong></span> may not be able to override the buffering scheme    of your web server and it has no effect on any client-side buffering in the    browser.  It also doesn&#039;t affect PHP&#039;s userspace output buffering mechanism.    This means you will have to call both <span class="function">{@link ob_flush()}</span> and    <span class="function"><strong style="color:#CC7832">flush()</strong></span> to flush the ob output buffers if you are using    those.   </p>   <p class="para">    Several servers, especially on Win32, will still buffer the output from    your script until it terminates before transmitting the results to the    browser.   </p>   <p class="para">    Server modules for Apache like mod_gzip may do buffering of their own that    will cause <span class="function"><strong style="color:#CC7832">flush()</strong></span> to not result in data being sent    immediately to the client.   </p>   <p class="para">    Even the browser may buffer its input before displaying it. Netscape, for    example, buffers text until it receives an end-of-line or the beginning of    a tag, and it won&#039;t render tables until the &lt;/table&gt; tag of the    outermost table is seen.   </p>   <p class="para">    Some versions of Microsoft Internet Explorer will only start to display    the page after they have received 256 bytes of output, so you may need to    send extra whitespace before flushing to get those browsers to display the    page.   </p>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.flush-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    No value is returned.   </p>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.flush-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><span class="function">{@link ob_flush()} - Flush (send) the output buffer</span></li>     <li class="member"><span class="function">{@link ob_clean()} - Clean (erase) the output buffer</span></li>     <li class="member"><span class="function">{@link ob_end_flush()} - Flush (send) the output buffer and turn off output buffering</span></li>     <li class="member"><span class="function">{@link ob_end_clean()} - Clean (erase) the output buffer and turn off output buffering</span></li>    </ul>   </span>  </div>    </div>
*/
	public function flush ($data = null) {}

	/**
	 * (PECL pecl_http &gt;= 0.21.0)<br/>
	 * Finalize inflate stream
	 * @link http://php.net/manual/en/function.httpinflatestream-finish.php
	 * @param string $data [optional] <p>
	 * data to inflate
	 * </p>
	 * @return string the final part of inflated data.
	 */
	public function finish ($data = null) {}

	/**
	 * (PECL pecl_http &gt;= 1.4.0)<br/>
	 * HttpInflateStream class factory
	 * @link http://php.net/manual/en/function.httpinflatestream-factory.php
	 * @param int $flags [optional] <p>
	 * initialization flags
	 * </p>
	 * @param string $class_name [optional] <p>
	 * name of a subclass of HttpInflateStream
	 * </p>
	 * @return HttpInflateStream 
	 */
	public static function factory ($flags = null, $class_name = null) {}

}

/**
 * @link http://php.net/manual/en/class.httpmessage.php
 */
class HttpMessage implements Countable, Serializable, Iterator {
	const TYPE_NONE = 0;
	const TYPE_REQUEST = 1;
	const TYPE_RESPONSE = 2;

	protected $type;
	protected $body;
	protected $requestMethod;
	protected $requestUrl;
	protected $responseStatus;
	protected $responseCode;
	protected $httpVersion;
	protected $headers;
	protected $parentMessage;


	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * HttpMessage constructor
	 * @link http://php.net/manual/en/function.httpmessage-construct.php
	 * @param string $message [optional] <p>
	 * a single or several consecutive HTTP messages
	 * </p>
	 * @return void 
	 */
	public function __construct ($message = null) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Get message body
	 * @link http://php.net/manual/en/function.httpmessage-getbody.php
	 * @return string the message body as string.
	 */
	public function getBody () {}

	/**
	 * (PECL pecl_http &gt;= 0.14.0)<br/>
	 * Set message body
	 * @link http://php.net/manual/en/function.httpmessage-setbody.php
	 * @param string $body <p>
	 * the new body of the message
	 * </p>
	 * @return void 
	 */
	public function setBody ($body) {}

	/**
	 * (PECL pecl_http &gt;= 1.1.0)<br/>
	 * Get header
	 * @link http://php.net/manual/en/function.httpmessage-getheader.php
	 * @param string $header <p>
	 * header name
	 * </p>
	 * @return string the header value on success or NULL if the header does not exist.
	 */
	public function getHeader ($header) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Get message headers
	 * @link http://php.net/manual/en/function.httpmessage-getheaders.php
	 * @return array an associative array containing the messages HTTP headers.
	 */
	public function getHeaders () {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Set headers
	 * @link http://php.net/manual/en/function.httpmessage-setheaders.php
	 * @param array $headers <p>
	 * associative array containing the new HTTP headers, which will replace all previous HTTP headers of the message
	 * </p>
	 * @return void 
	 */
	public function setHeaders (sarray $header) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Add headers
	 * @link http://php.net/manual/en/function.httpmessage-addheaders.php
	 * @param array $headers <p>
	 * associative array containing the additional HTTP headers to add to the messages existing headers
	 * </p>
	 * @param bool $append [optional] <p>
	 * if true, and a header with the same name of one to add exists already, this respective
	 * header will be converted to an array containing both header values, otherwise
	 * it will be overwritten with the new header value
	 * </p>
	 * @return void true on success or false on failure.
	 */
	public function addHeaders (array $headers, $append = null) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Get message type
	 * @link http://php.net/manual/en/function.httpmessage-gettype.php
	 * @return int the HttpMessage::TYPE.
	 */
/**
*<div id="function.gettype" class="refentry">  <div class="refnamediv">   <h1 class="refname">gettype</h1>   <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">gettype</span> &mdash; <span class="dc-title">Get the type of a variable</span></p>   </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.gettype-description">   <h3 class="title">Description</h3>   <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><strong>gettype</strong></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span> <span class="parameter" style="color:#2EACF9">$var</span></span>    ) : <span class="type" style="color:#EAB766">string</span></div>    <p class="para rdfs-comment">    Returns the type of the PHP variable <span class="parameter" style="color:#2EACF9">var</span>. For    type checking, use <em>is_*</em> functions.   </p>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.gettype-parameters">   <h3 class="title">Parameters</h3>   <span>    <dl>            <dt> <span class="parameter" style="color:#2EACF9">var</span></dt>       <dd>        <p class="para">        The variable being type checked.       </p>      </dd>          </dl>    </span>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.gettype-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    Possible values for the returned string are:    <ul class="itemizedlist">     <li class="listitem">      <span class="simpara">       &quot;<span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.boolean.php" class="type boolean" style="color:#EAB766">boolean</a></span>&quot;      </span>     </li>     <li class="listitem">      <span class="simpara">       &quot;<span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.integer.php" class="type integer" style="color:#EAB766">integer</a></span>&quot;      </span>     </li>     <li class="listitem">      <span class="simpara">       &quot;<span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.float.php" class="type double" style="color:#EAB766">double</a></span>&quot; (for historical reasons &quot;double&quot; is       returned in case of a <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.float.php" class="type float" style="color:#EAB766">float</a></span>, and not simply       &quot;float&quot;)      </span>     </li>     <li class="listitem">      <span class="simpara">       &quot;<span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.string.php" class="type string" style="color:#EAB766">string</a></span>&quot;      </span>     </li>     <li class="listitem">      <span class="simpara">       &quot;<span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.array.php" class="type array" style="color:#EAB766">array</a></span>&quot;      </span>     </li>     <li class="listitem">      <span class="simpara">       &quot;<span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.object.php" class="type object" style="color:#EAB766">object</a></span>&quot;      </span>     </li>     <li class="listitem">      <span class="simpara">       &quot;<span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.resource.php" class="type resource" style="color:#EAB766">resource</a></span>&quot;      </span>     </li>     <li class="listitem">      <span class="simpara">       &quot;resource (closed)&quot; as of PHP 7.2.0      </span>     </li>     <li class="listitem">      <span class="simpara">       &quot;<span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.null.php" class="type NULL" style="color:#EAB766">NULL</a></span>&quot;      </span>     </li>     <li class="listitem">      <span class="simpara">       &quot;unknown type&quot;      </span>     </li>    </ul>   </p>  </div>     <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.gettype-examples">   <h3 class="title">Examples</h3>   <span>    <div class="example" id="example-6552">     <p><strong>Example #1 <span class="function"><strong style="color:#CC7832">gettype()</strong></span> example</strong></p>     <div class="example-contents"> <div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"> <span style="color: #9876AA">&lt;?php<br /><br />$data&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #9876AA">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">1.</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">NULL</span><span style="color: #007700">,&nbsp;new&nbsp;</span><span style="color: #9876AA">stdClass</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'foo'</span><span style="color: #007700">);<br /><br />foreach&nbsp;(</span><span style="color: #9876AA">$data&nbsp;</span><span style="color: #007700">as&nbsp;</span><span style="color: #9876AA">$value</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #9876AA">gettype</span><span style="color: #007700">(</span><span style="color: #9876AA">$value</span><span style="color: #007700">),&nbsp;</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br />}<br /><br /></span><span style="color: #9876AA">?&gt;</span> </span> </span></div>     </div>      <div class="example-contents"><p>The above example will output something similar to:</p></div>     <div class="example-contents screen" style="background:black;padding-left:5px;"> <div class="cdata"><span> integer double NULL object string </span></div>     </div>    </div>   </span>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 changelog" id="refsect1-function.gettype-changelog">   <h3 class="title">Changelog</h3>   <span>    <table class="doctable informaltable">           <thead>       <tr>        <th>Version</th>        <th>Description</th>       </tr>       </thead>       <tbody class="tbody">       <tr>        <td>7.2.0</td>        <td>         Closed resources are now reported as <em>&#039;resource (closed)&#039;</em>.          Previously the returned value for closed resources were <em>&#039;unknown type&#039;</em>.        </td>       </tr>       </tbody>         </table>    </span>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.gettype-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><span class="function">{@link settype()} - Set the type of a variable</span></li>     <li class="member"><span class="function">{@link get_class()} - Returns the name of the class of an object</span></li>     <li class="member"><span class="function">{@link is_array()} - Finds whether a variable is an array</span></li>     <li class="member"><span class="function">{@link is_bool()} - Finds out whether a variable is a boolean</span></li>     <li class="member"><span class="function">{@link is_callable()} - Verify that the contents of a variable can be called as a function</span></li>     <li class="member"><span class="function">{@link is_float()} - Finds whether the type of a variable is float</span></li>     <li class="member"><span class="function">{@link is_int()} - Find whether the type of a variable is integer</span></li>     <li class="member"><span class="function">{@link is_null()} - Finds whether a variable is NULL</span></li>     <li class="member"><span class="function">{@link is_numeric()} - Finds whether a variable is a number or a numeric string</span></li>     <li class="member"><span class="function">{@link is_object()} - Finds whether a variable is an object</span></li>     <li class="member"><span class="function">{@link is_resource()} - Finds whether a variable is a resource</span></li>     <li class="member"><span class="function">{@link is_scalar()} - Finds whether a variable is a scalar</span></li>     <li class="member"><span class="function">{@link is_string()} - Find whether the type of a variable is string</span></li>     <li class="member"><span class="function">{@link function_exists()} - Return TRUE if the given function has been defined</span></li>     <li class="member"><span class="function">{@link method_exists()} - Checks if the class method exists</span></li>    </ul>   </span>  </div>  </div>
*/
	public function getType () {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Set message type
	 * @link http://php.net/manual/en/function.httpmessage-settype.php
	 * @param int $type <p>
	 * the HttpMessage::TYPE
	 * </p>
	 * @return void 
	 */
/**
*<div id="function.settype" class="refentry">  <div class="refnamediv">   <h1 class="refname">settype</h1>   <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">settype</span> &mdash; <span class="dc-title">Set the type of a variable</span></p>   </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.settype-description">   <h3 class="title">Description</h3>   <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><strong>settype</strong></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span> <span class="parameter" style="color:#2EACF9">&$var</span></span>    , <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$type</span></span>    ) : <span class="type" style="color:#EAB766">bool</span></div>    <p class="para rdfs-comment">    Set the type of variable <span class="parameter" style="color:#2EACF9">var</span> to    <span class="parameter" style="color:#2EACF9">type</span>.   </p>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.settype-parameters">   <h3 class="title">Parameters</h3>   <span>    <dl>            <dt> <span class="parameter" style="color:#2EACF9">var</span></dt>       <dd>        <p class="para">        The variable being converted.       </p>      </dd>                 <dt> <span class="parameter" style="color:#2EACF9">type</span></dt>       <dd>        <p class="para">        Possibles values of <span class="parameter" style="color:#2EACF9">type</span> are:        <ul class="itemizedlist">         <li class="listitem">          <span class="simpara">           &quot;boolean&quot; or &quot;bool&quot;          </span>         </li>         <li class="listitem">          <span class="simpara">           &quot;integer&quot; or &quot;int&quot;          </span>         </li>         <li class="listitem">          <span class="simpara">           &quot;float&quot; or &quot;double&quot;          </span>         </li>         <li class="listitem">          <span class="simpara">           &quot;string&quot;          </span>         </li>         <li class="listitem">          <span class="simpara">           &quot;array&quot;          </span>         </li>         <li class="listitem">          <span class="simpara">           &quot;object&quot;          </span>         </li>         <li class="listitem">          <span class="simpara">           &quot;null&quot;          </span>         </li>        </ul>       </p>      </dd>          </dl>    </span>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.settype-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    Returns <strong><span>TRUE</span></strong> on success or <strong><span>FALSE</span></strong> on failure.   </p>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.settype-examples">   <h3 class="title">Examples</h3>   <span>    <div class="example" id="example-6574">     <p><strong>Example #1 <span class="function"><strong style="color:#CC7832">settype()</strong></span> example</strong></p>     <div class="example-contents"> <div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"> <span style="color: #9876AA">&lt;?php<br />$foo&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">"5bar"</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;string<br /></span><span style="color: #9876AA">$bar&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">true</span><span style="color: #007700">;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;boolean<br /><br /></span><span style="color: #9876AA">settype</span><span style="color: #007700">(</span><span style="color: #9876AA">$foo</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">"integer"</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;$foo&nbsp;is&nbsp;now&nbsp;5&nbsp;&nbsp;&nbsp;(integer)<br /></span><span style="color: #9876AA">settype</span><span style="color: #007700">(</span><span style="color: #9876AA">$bar</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">"string"</span><span style="color: #007700">);&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$bar&nbsp;is&nbsp;now&nbsp;"1"&nbsp;(string)<br /></span><span style="color: #9876AA">?&gt;</span> </span> </span></div>     </div>     </div>   </span>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 notes" id="refsect1-function.settype-notes">   <h3 class="title">Notes</h3>   <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>:     <p class="para">     Maximum value for &quot;int&quot; is <strong><span>PHP_INT_MAX</span></strong>.    </p>   </p></blockquote>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.settype-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><span class="function">{@link gettype()} - Get the type of a variable</span></li>     <li class="member"><a href="https://www.php.net/manual/en/language.types.type-juggling.php#language.types.typecasting" class="link">type-casting</a></li>     <li class="member"><a href="https://www.php.net/manual/en/language.types.type-juggling.php" class="link">type-juggling</a></li>    </ul>   </span>  </div>   </div>
*/
	public function setType ($type) {}

	public function getInfo () {}

	/**
	 * @param $http_info
	 */
	public function setInfo ($http_info) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Get response code
	 * @link http://php.net/manual/en/function.httpmessage-getresponsecode.php
	 * @return int the HTTP response code if the message is of type HttpMessage::TYPE_RESPONSE, else FALSE.
	 */
	public function getResponseCode () {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Set response code
	 * @link http://php.net/manual/en/function.httpmessage-setresponsecode.php
	 * @param int $code <p>
	 * HTTP response code
	 * </p>
	 * @return bool TRUE on success, or FALSE if the message is not of type
	 * HttpMessage::TYPE_RESPONSE or the response code is out of range (100-510).
	 */
	public function setResponseCode ($code) {}

	/**
	 * (PECL pecl_http &gt;= 0.23.0)<br/>
	 * Get response status
	 * @link http://php.net/manual/en/function.httpmessage-getresponsestatus.php
	 * @return string the HTTP response status string if the message is of type 
	 * HttpMessage::TYPE_RESPONSE, else FALSE.
	 */
	public function getResponseStatus () {}

	/**
	 * (PECL pecl_http &gt;= 0.23.0)<br/>
	 * Set response status
	 * @link http://php.net/manual/en/function.httpmessage-setresponsestatus.php
	 * @param string $status <p>
	 * the response status text
	 * </p>
	 * @return bool TRUE on success or FALSE if the message is not of type
	 * HttpMessage::TYPE_RESPONSE.
	 */
	public function setResponseStatus ($status) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Get request method
	 * @link http://php.net/manual/en/function.httpmessage-getrequestmethod.php
	 * @return string the request method name on success, or FALSE if the message is
	 * not of type HttpMessage::TYPE_REQUEST.
	 */
	public function getRequestMethod () {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Set request method
	 * @link http://php.net/manual/en/function.httpmessage-setrequestmethod.php
	 * @param string $method <p>
	 * the request method name
	 * </p>
	 * @return bool TRUE on success, or FALSE if the message is not of type
	 * HttpMessage::TYPE_REQUEST or an invalid request method was supplied.
	 */
	public function setRequestMethod ($method) {}

	/**
	 * (PECL pecl_http &gt;= 0.21.0)<br/>
	 * Get request URL
	 * @link http://php.net/manual/en/function.httpmessage-getrequesturl.php
	 * @return string the request URL as string on success, or FALSE if the message
	 * is not of type HttpMessage::TYPE_REQUEST.
	 */
	public function getRequestUrl () {}

	/**
	 * (PECL pecl_http &gt;= 0.21.0)<br/>
	 * Set request URL
	 * @link http://php.net/manual/en/function.httpmessage-setrequesturl.php
	 * @param string $url <p>
	 * the request URL
	 * </p>
	 * @return bool TRUE on success, or FALSE if the message is not of type
	 * HttpMessage::TYPE_REQUEST or supplied URL was empty.
	 */
	public function setRequestUrl ($url) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Get HTTP version
	 * @link http://php.net/manual/en/function.httpmessage-gethttpversion.php
	 * @return string the HTTP protocol version as string.
	 */
	public function getHttpVersion () {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Set HTTP version
	 * @link http://php.net/manual/en/function.httpmessage-sethttpversion.php
	 * @param string $version <p>
	 * the HTTP protocol version
	 * </p>
	 * @return bool TRUE on success, or FALSE if supplied version is out of range (1.0/1.1).
	 */
	public function setHttpVersion ($version) {}

	/**
	 * (PECL pecl_http &gt;= 1.0.0)<br/>
	 * Guess content type
	 * @link http://php.net/manual/en/function.httpmessage-guesscontenttype.php
	 * @param string $magic_file <p>
	 * the magic.mime database to use
	 * </p>
	 * @param int $magic_mode [optional] <p>
	 * flags for libmagic
	 * </p>
	 * @return string the guessed content type on success or false on failure.
	 */
	public function guessContentType ($magic_file, $magic_mode = null) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Get parent message
	 * @link http://php.net/manual/en/function.httpmessage-getparentmessage.php
	 * @return HttpMessage the parent HttpMessage object.
	 */
	public function getParentMessage () {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Send message
	 * @link http://php.net/manual/en/function.httpmessage-send.php
	 * @return bool true on success or false on failure.
	 */
	public function send () {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Get string representation
	 * @link http://php.net/manual/en/function.httpmessage-tostring.php
	 * @param bool $include_parent [optional] <p>
	 * specifies whether the returned string should also contain any parent messages
	 * </p>
	 * @return string the message as string.
	 */
	public function toString ($include_parent = null) {}

	/**
	 * (PECL pecl_http &gt;= 0.22.0)<br/>
	 * Create HTTP object regarding message type
	 * @link http://php.net/manual/en/function.httpmessage-tomessagetypeobject.php
	 * @return HttpRequest|HttpResponse either an HttpRequest or HttpResponse object on success, or NULL on failure.
	 */
	public function toMessageTypeObject () {}

/**
*<div id="function.count" class="refentry">  <div class="refnamediv">   <h1 class="refname">count</h1>   <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">count</span> &mdash; <span class="dc-title">Count all elements in an array, or something in an object</span></p>   </div>  <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.count-description">   <h3 class="title">Description</h3>   <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><strong>count</strong></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span> <span class="parameter" style="color:#2EACF9">$array_or_countable</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$mode</span><span class="initializer"> = COUNT_NORMAL</span></span>   ] ) : <span class="type" style="color:#EAB766">int</span></div>    <p class="para rdfs-comment">    Counts all elements in an array, or something in an object.   </p>   <p class="para">    For objects, if you have    <a href="https://www.php.net/manual/en/ref.spl.php" class="link">SPL</a> installed, you can hook into    <span class="function"><strong style="color:#CC7832">count()</strong></span> by implementing interface    <a href="https://www.php.net/manual/en/class.countable.php" class="classname">Countable</a>. The interface has exactly one method,    <span class="methodname" style="color:#CC7832">{@link Countable::count()}</span>, which returns the return value for the    <span class="function"><strong style="color:#CC7832">count()</strong></span> function.   </p>   <p class="para">    Please see the <a href="https://www.php.net/manual/en/language.types.array.php" class="link">Array</a>    section of the manual for a detailed explanation of how arrays    are implemented and used in PHP.   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.count-parameters">   <h3 class="title">Parameters</h3>   <span>    <dl>            <dt> <span class="parameter" style="color:#2EACF9">array_or_countable</span></dt>       <dd>        <p class="para">        An array or <a href="https://www.php.net/manual/en/class.countable.php" class="classname">Countable</a> object.       </p>      </dd>                 <dt> <span class="parameter" style="color:#2EACF9">mode</span></dt>       <dd>        <p class="para">        If the optional <span class="parameter" style="color:#2EACF9">mode</span> parameter is set to        <strong><span>COUNT_RECURSIVE</span></strong> (or 1), <span class="function"><strong style="color:#CC7832">count()</strong></span>        will recursively count the array.  This is particularly useful for        counting all the elements of a multidimensional array.       </p>       <div class="caution"><strong class="caution">Caution</strong>        <p class="para">         <span class="function"><strong style="color:#CC7832">count()</strong></span> can detect recursion to avoid an infinite         loop, but will emit an <strong><span>E_WARNING</span></strong> every time it         does (in case the array contains itself more than once) and return a         count higher than may be expected.        </p>       </div>      </dd>          </dl>    </span>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.count-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    Returns the number of elements in <span class="parameter" style="color:#2EACF9">array_or_countable</span>.    When the parameter is neither an array nor an object with    implemented <a href="https://www.php.net/manual/en/class.countable.php" class="classname">Countable</a> interface,    <em>1</em> will be returned.    There is one exception, if <span class="parameter" style="color:#2EACF9">array_or_countable</span> is <strong><span>NULL</span></strong>,    <em>0</em> will be returned.   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.count-examples">   <h3 class="title">Examples</h3>   <span>    <div class="example" id="example-6276">     <p><strong>Example #1 <span class="function"><strong style="color:#CC7832">count()</strong></span> example</strong></p>     <div class="example-contents"> <div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"> <span style="color: #9876AA">&lt;?php<br />$a</span><span style="color: #007700">[</span><span style="color: #9876AA">0</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #9876AA">1</span><span style="color: #007700">;<br /></span><span style="color: #9876AA">$a</span><span style="color: #007700">[</span><span style="color: #9876AA">1</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #9876AA">3</span><span style="color: #007700">;<br /></span><span style="color: #9876AA">$a</span><span style="color: #007700">[</span><span style="color: #9876AA">2</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #9876AA">5</span><span style="color: #007700">;<br /></span><span style="color: #9876AA">var_dump</span><span style="color: #007700">(</span><span style="color: #9876AA">count</span><span style="color: #007700">(</span><span style="color: #9876AA">$a</span><span style="color: #007700">));<br /><br /></span><span style="color: #9876AA">$b</span><span style="color: #007700">[</span><span style="color: #9876AA">0</span><span style="color: #007700">]&nbsp;&nbsp;=&nbsp;</span><span style="color: #9876AA">7</span><span style="color: #007700">;<br /></span><span style="color: #9876AA">$b</span><span style="color: #007700">[</span><span style="color: #9876AA">5</span><span style="color: #007700">]&nbsp;&nbsp;=&nbsp;</span><span style="color: #9876AA">9</span><span style="color: #007700">;<br /></span><span style="color: #9876AA">$b</span><span style="color: #007700">[</span><span style="color: #9876AA">10</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #9876AA">11</span><span style="color: #007700">;<br /></span><span style="color: #9876AA">var_dump</span><span style="color: #007700">(</span><span style="color: #9876AA">count</span><span style="color: #007700">(</span><span style="color: #9876AA">$b</span><span style="color: #007700">));<br /><br /></span><span style="color: #9876AA">var_dump</span><span style="color: #007700">(</span><span style="color: #9876AA">count</span><span style="color: #007700">(</span><span style="color: #9876AA">null</span><span style="color: #007700">));<br /><br /></span><span style="color: #9876AA">var_dump</span><span style="color: #007700">(</span><span style="color: #9876AA">count</span><span style="color: #007700">(</span><span style="color: #9876AA">false</span><span style="color: #007700">));<br /></span><span style="color: #9876AA">?&gt;</span> </span> </span></div>     </div>      <div class="example-contents"><p>The above example will output:</p></div>     <div class="example-contents screen" style="background:black;padding-left:5px;"> <div class="cdata"><span> int(3) int(3)  Warning: count(): Parameter must be an array or an object that implements Countable in … on line 12 // as of PHP 7.2 int(0)  Warning: count(): Parameter must be an array or an object that implements Countable in … on line 14 // as of PHP 7.2 int(1) </span></div>     </div>    </div>   </span>   <p class="para">    <div class="example" id="example-6277">     <p><strong>Example #2 Recursive <span class="function"><strong style="color:#CC7832">count()</strong></span> example</strong></p>     <div class="example-contents"> <div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"> <span style="color: #9876AA">&lt;?php<br />$food&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #DD0000">'fruits'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;array(</span><span style="color: #DD0000">'orange'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'banana'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'apple'</span><span style="color: #007700">),<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'veggie'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;array(</span><span style="color: #DD0000">'carrot'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'collard'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'pea'</span><span style="color: #007700">));<br /><br /></span><span style="color: #FF8000">//&nbsp;recursive&nbsp;count<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #9876AA">count</span><span style="color: #007700">(</span><span style="color: #9876AA">$food</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">COUNT_RECURSIVE</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;output&nbsp;8<br /><br />//&nbsp;normal&nbsp;count<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #9876AA">count</span><span style="color: #007700">(</span><span style="color: #9876AA">$food</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;output&nbsp;2<br /><br /></span><span style="color: #9876AA">?&gt;</span> </span> </span></div>     </div>     </div>   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 changelog" id="refsect1-function.count-changelog">   <h3 class="title">Changelog</h3>   <table class="doctable informaltable">         <thead>      <tr>       <th>Version</th>       <th>Description</th>      </tr>      </thead>      <tbody class="tbody">      <tr>       <td>7.2.0</td>       <td>        <span class="function"><strong style="color:#CC7832">count()</strong></span> will now yield a warning on invalid countable types         passed to the <span class="parameter" style="color:#2EACF9">array_or_countable</span> parameter.       </td>      </tr>      </tbody>       </table>   </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.count-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><span class="function">{@link is_array()} - Finds whether a variable is an array</span></li>     <li class="member"><span class="function">{@link isset()} - Determine if a variable is declared and is different than NULL</span></li>     <li class="member"><span class="function">{@link empty()} - Determine whether a variable is empty</span></li>     <li class="member"><span class="function">{@link strlen()} - Get string length</span></li>     <li class="member"><span class="function">{@link is_countable()} - Verify that the contents of a variable is a countable value</span></li>    </ul>   </span>  </div>  </div>
*/
	public function count () {}

/**
*<div id="function.serialize" class="refentry">  <div class="refnamediv">   <h1 class="refname">serialize</h1>   <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">serialize</span> &mdash; <span class="dc-title">Generates a storable representation of a value</span></p>   </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.serialize-description">   <h3 class="title">Description</h3>    <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">     <span class="methodname" style="color:#CC7832"><strong>serialize</strong></span>      ( <span class="methodparam"><span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span> <span class="parameter" style="color:#2EACF9">$value</span></span>     ) : <span class="type" style="color:#EAB766">string</span></div>    <p class="para rdfs-comment">    Generates a storable representation of a value.   </p>   <p class="para">    This is useful for storing or passing PHP values around without    losing their type and structure.   </p>   <p class="para">    To make the serialized string into a PHP value again, use    <span class="function">{@link unserialize()}</span>.     </p>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.serialize-parameters">   <h3 class="title">Parameters</h3>   <span>    <dl>            <dt> <span class="parameter" style="color:#2EACF9">value</span></dt>       <dd>        <p class="para">        The value to be serialized. <span class="function"><strong style="color:#CC7832">serialize()</strong></span>        handles all types, except the <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.resource.php" class="type resource" style="color:#EAB766">resource</a></span>-type and some <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.object.php" class="type object" style="color:#EAB766">object</a></span>s (see note below).        You can even <span class="function"><strong style="color:#CC7832">serialize()</strong></span> arrays that contain        references to itself. Circular references inside the array/object you         are serializing will also be stored. Any other         reference will be lost.       </p>       <p class="para">        When serializing objects, PHP will attempt to call the member function        <a href="https://www.php.net/manual/en/language.oop5.magic.php#object.sleep" class="link">__sleep()</a> prior to serialization.         This is to allow the object to do any last minute clean-up, etc. prior         to being serialized. Likewise, when the object is restored using         <span class="function">{@link unserialize()}</span> the <a href="https://www.php.net/manual/en/language.oop5.magic.php#object.wakeup" class="link">__wakeup()</a> member function is called.       </p>       <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>:         <p class="para">        Object&#039;s private members have the class name prepended to the member        name; protected members have a &#039;*&#039; prepended to the member name.        These prepended values have null bytes on either side.        </p>       </p></blockquote>      </dd>          </dl>    </span>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.serialize-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    Returns a string containing a byte-stream representation of     <span class="parameter" style="color:#2EACF9">value</span> that can be stored anywhere.   </p>   <p class="para">    Note that this is a binary string which may include null bytes, and needs    to be stored and handled as such. For example,    <span class="function"><strong style="color:#CC7832">serialize()</strong></span> output should generally be stored in a BLOB    field in a database, rather than a CHAR or TEXT field.   </p>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.serialize-examples">   <h3 class="title">Examples</h3>   <span>    <div class="example" id="example-6573">     <p><strong>Example #1 <span class="function"><strong style="color:#CC7832">serialize()</strong></span> example</strong></p>     <div class="example-contents"> <div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"> <span style="color: #9876AA">&lt;?php<br /></span><span style="color: #FF8000">//&nbsp;$session_data&nbsp;contains&nbsp;a&nbsp;multi-dimensional&nbsp;array&nbsp;with&nbsp;session<br />//&nbsp;information&nbsp;for&nbsp;the&nbsp;current&nbsp;user.&nbsp;&nbsp;We&nbsp;use&nbsp;serialize()&nbsp;to&nbsp;store<br />//&nbsp;it&nbsp;in&nbsp;a&nbsp;database&nbsp;at&nbsp;the&nbsp;end&nbsp;of&nbsp;the&nbsp;request.<br /><br /></span><span style="color: #9876AA">$conn&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">odbc_connect</span><span style="color: #007700">(</span><span style="color: #DD0000">"webdb"</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">"php"</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">"chicken"</span><span style="color: #007700">);<br /></span><span style="color: #9876AA">$stmt&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">odbc_prepare</span><span style="color: #007700">(</span><span style="color: #9876AA">$conn</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">"UPDATE&nbsp;sessions&nbsp;SET&nbsp;data&nbsp;=&nbsp;?&nbsp;WHERE&nbsp;id&nbsp;=&nbsp;?"</span><span style="color: #007700">);<br /></span><span style="color: #9876AA">$sqldata&nbsp;</span><span style="color: #007700">=&nbsp;array&nbsp;(</span><span style="color: #9876AA">serialize</span><span style="color: #007700">(</span><span style="color: #9876AA">$session_data</span><span style="color: #007700">),&nbsp;</span><span style="color: #9876AA">$_SERVER</span><span style="color: #007700">[</span><span style="color: #DD0000">'PHP_AUTH_USER'</span><span style="color: #007700">]);<br />if&nbsp;(!</span><span style="color: #9876AA">odbc_execute</span><span style="color: #007700">(</span><span style="color: #9876AA">$stmt</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">$sqldata</span><span style="color: #007700">))&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #9876AA">$stmt&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">odbc_prepare</span><span style="color: #007700">(</span><span style="color: #9876AA">$conn</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">"INSERT&nbsp;INTO&nbsp;sessions&nbsp;(id,&nbsp;data)&nbsp;VALUES(?,&nbsp;?)"</span><span style="color: #007700">);<br />&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(!</span><span style="color: #9876AA">odbc_execute</span><span style="color: #007700">(</span><span style="color: #9876AA">$stmt</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">$sqldata</span><span style="color: #007700">))&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;Something&nbsp;went&nbsp;wrong..&nbsp;<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">}<br />}<br /></span><span style="color: #9876AA">?&gt;</span> </span> </span></div>     </div>     </div>   </span>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 notes" id="refsect1-function.serialize-notes">   <h3 class="title">Notes</h3>   <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>:     <p class="para">     Note that many built-in PHP objects cannot be serialized. However, those with      this ability either implement the <span class="interfacename"><a href="https://www.php.net/manual/en/class.serializable.php" class="interfacename">Serializable</a></span> interface or the      magic <a href="https://www.php.net/manual/en/language.oop5.magic.php#object.sleep" class="link">__sleep()</a> and     <a href="https://www.php.net/manual/en/language.oop5.magic.php#object.wakeup" class="link">__wakeup()</a> methods. If an      internal class does not fulfill any of those requirements, it cannot reliably be      serialized.    </p>    <p class="para">     There are some historical exceptions to the above rule, where some internal objects      could be serialized without implementing the interface or exposing the methods. Notably,      the <a href="https://www.php.net/manual/en/class.arrayobject.php" class="classname">ArrayObject</a> prior to PHP 5.2.0.    </p>   </p></blockquote>   <div class="warning"><strong class="warning">Warning</strong>    <p class="para">     When <span class="function"><strong style="color:#CC7832">serialize()</strong></span> serializes objects, the leading backslash is not included in the class name of namespaced classes for maximum compatibility.    </p>   </div>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.serialize-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><span class="function">{@link unserialize()} - Creates a PHP value from a stored representation</span></li>     <li class="member"><span class="function">{@link var_export()} - Outputs or returns a parsable string representation of a variable</span></li>     <li class="member"><span class="function">{@link json_encode()} - Returns the JSON representation of a value</span></li>     <li class="member"><a href="https://www.php.net/manual/en/language.oop5.serialization.php" class="link">Serializing Objects</a></li>     <li class="member"><a href="https://www.php.net/manual/en/language.oop5.magic.php#object.sleep" class="link">__sleep()</a></li>     <li class="member"><a href="https://www.php.net/manual/en/language.oop5.magic.php#object.wakeup" class="link">__wakeup()</a></li>    </ul>   </span>  </div>   </div>
*/
	public function serialize () {}

	/**
	 * @param $serialized
	 */
/**
*<div id="function.unserialize" class="refentry">  <div class="refnamediv">   <h1 class="refname">unserialize</h1>   <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">unserialize</span> &mdash; <span class="dc-title">    Creates a PHP value from a stored representation   </span></p>   </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.unserialize-description">   <h3 class="title">Description</h3>   <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><strong>unserialize</strong></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$str</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">array</span> <span class="parameter" style="color:#2EACF9">$options</span></span>   ] ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span></div>    <p class="simpara">    <span class="function"><strong style="color:#CC7832">unserialize()</strong></span> takes a single serialized variable and    converts it back into a PHP value.     </p>   <div class="warning"><strong class="warning">Warning</strong>    <p class="para">     Do not pass untrusted user input to <span class="function"><strong style="color:#CC7832">unserialize()</strong></span> regardless     of the <span class="parameter" style="color:#2EACF9">options</span> value of <em>allowed_classes</em>.     Unserialization can result in code being loaded and executed due to object     instantiation and autoloading, and a malicious user may be able to exploit     this. Use a safe, standard data interchange format such as JSON (via     <span class="function">{@link json_decode()}</span> and <span class="function">{@link json_encode()}</span>) if     you need to pass serialized data to the user.    </p>    <p class="para">     If you need to unserialize externally-stored serialized data, consider using     <span class="function">{@link hash_hmac()}</span> for data validation. Make sure data is     not modified by anyone but you.    </p>   </div>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.unserialize-parameters">   <h3 class="title">Parameters</h3>   <span>    <dl>            <dt> <span class="parameter" style="color:#2EACF9">str</span></dt>       <dd>        <p class="para">        The serialized string.       </p>       <p class="para">        If the variable being unserialized is an object, after successfully         reconstructing the object PHP will automatically attempt to call the        <a href="https://www.php.net/manual/en/language.oop5.magic.php#object.wakeup" class="link">__wakeup()</a> member        function (if it exists).       </p>       <p class="para">        <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>:          <strong>unserialize_callback_func directive</strong><br />         <p class="para">          It&#039;s possible to set a callback-function which will be called,          if an undefined class should be instantiated during unserializing.          (to prevent getting an incomplete <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.object.php" class="type object" style="color:#EAB766">object</a></span> &quot;__PHP_Incomplete_Class&quot;.)          Use your <var class="filename">php.ini</var>, <span class="function">{@link ini_set()}</span> or <var class="filename">.htaccess</var>           to define <a href="https://www.php.net/manual/en/var.configuration.php#ini.unserialize-callback-func" class="link">unserialize_callback_func</a>.          Everytime an undefined class should be instantiated, it&#039;ll be called.  To disable this feature just          empty this setting.         </p>        </p></blockquote>       </p>      </dd>                 <dt> <span class="parameter" style="color:#2EACF9">options</span></dt>       <dd>        <p class="para">        Any options to be provided to <span class="function"><strong style="color:#CC7832">unserialize()</strong></span>, as an        associative array.       </p>       <table class="doctable table">        <caption><strong>Valid options</strong></caption>                 <thead>          <tr>           <th>Name</th>           <th>Type</th>           <th>Description</th>          </tr>          </thead>          <tbody class="tbody">          <tr>           <td><em>allowed_classes</em></td>           <td><span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span></td>           <td>            <span class="simpara">             Either an <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.array.php" class="type array" style="color:#EAB766">array</a></span> of class names which should be             accepted, <strong><span>FALSE</span></strong> to accept no classes, or <strong><span>TRUE</span></strong> to accept all             classes. If this option is defined and             <span class="function"><strong style="color:#CC7832">unserialize()</strong></span> encounters an object of a class             that isn&#039;t to be accepted, then the object will be instantiated as             <strong class="classname">__PHP_Incomplete_Class</strong> instead.            </span>            <span class="simpara">             Omitting this option is the same as defining it as <strong><span>TRUE</span></strong>: PHP             will attempt to instantiate objects of any class.            </span>           </td>          </tr>          </tbody>               </table>       </dd>          </dl>    </span>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.unserialize-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    The converted value is returned, and can be a <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.boolean.php" class="type boolean" style="color:#EAB766">boolean</a></span>,    <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.integer.php" class="type integer" style="color:#EAB766">integer</a></span>, <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.float.php" class="type float" style="color:#EAB766">float</a></span>, <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.string.php" class="type string" style="color:#EAB766">string</a></span>,    <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.array.php" class="type array" style="color:#EAB766">array</a></span> or <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.object.php" class="type object" style="color:#EAB766">object</a></span>.   </p>   <p class="para">    In case the passed string is not unserializeable, <strong><span>FALSE</span></strong> is returned and    <strong><span>E_NOTICE</span></strong> is issued.   </p>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 changelog" id="refsect1-function.unserialize-changelog">   <h3 class="title">Changelog</h3>   <span>    <table class="doctable informaltable">           <thead>       <tr>        <th>Version</th>        <th>Description</th>       </tr>       </thead>       <tbody class="tbody">       <tr>        <td>7.1.0</td>        <td>         The <em>allowed_classes</em> element of         <span class="parameter" style="color:#2EACF9">options</span>) is now strictly typed, i.e. if anything         other than an <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.array.php" class="type array" style="color:#EAB766">array</a></span> or a <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.boolean.php" class="type boolean" style="color:#EAB766">boolean</a></span> is given,         <span class="function"><strong style="color:#CC7832">unserialize()</strong></span> returns <strong><span>FALSE</span></strong> and issues an         <strong><span>E_WARNING</span></strong>.        </td>       </tr>        <tr>        <td>7.0.0</td>        <td>         The <span class="parameter" style="color:#2EACF9">options</span> parameter has been added.        </td>       </tr>        <tr>        <td>5.6.0</td>        <td>         Manipulating the serialised data by replacing <em>C:</em>         with <em>O:</em> to force object instantiation without         calling the constructor will now fail.        </td>       </tr>       </tbody>         </table>    </span>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.unserialize-examples">   <h3 class="title">Examples</h3>   <span>    <div class="example" id="example-6576">     <p><strong>Example #1 <span class="function"><strong style="color:#CC7832">unserialize()</strong></span> example</strong></p>     <div class="example-contents"> <div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"> <span style="color: #9876AA">&lt;?php<br /></span><span style="color: #FF8000">//&nbsp;Here,&nbsp;we&nbsp;use&nbsp;unserialize()&nbsp;to&nbsp;load&nbsp;session&nbsp;data&nbsp;to&nbsp;the<br />//&nbsp;$session_data&nbsp;array&nbsp;from&nbsp;the&nbsp;string&nbsp;selected&nbsp;from&nbsp;a&nbsp;database.<br />//&nbsp;This&nbsp;example&nbsp;complements&nbsp;the&nbsp;one&nbsp;described&nbsp;with&nbsp;serialize().<br /><br /></span><span style="color: #9876AA">$conn&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">odbc_connect</span><span style="color: #007700">(</span><span style="color: #DD0000">"webdb"</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">"php"</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">"chicken"</span><span style="color: #007700">);<br /></span><span style="color: #9876AA">$stmt&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">odbc_prepare</span><span style="color: #007700">(</span><span style="color: #9876AA">$conn</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">"SELECT&nbsp;data&nbsp;FROM&nbsp;sessions&nbsp;WHERE&nbsp;id&nbsp;=&nbsp;?"</span><span style="color: #007700">);<br /></span><span style="color: #9876AA">$sqldata&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #9876AA">$_SERVER</span><span style="color: #007700">[</span><span style="color: #DD0000">'PHP_AUTH_USER'</span><span style="color: #007700">]);<br />if&nbsp;(!</span><span style="color: #9876AA">odbc_execute</span><span style="color: #007700">(</span><span style="color: #9876AA">$stmt</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">$sqldata</span><span style="color: #007700">)&nbsp;||&nbsp;!</span><span style="color: #9876AA">odbc_fetch_into</span><span style="color: #007700">(</span><span style="color: #9876AA">$stmt</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">$tmp</span><span style="color: #007700">))&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;if&nbsp;the&nbsp;execute&nbsp;or&nbsp;fetch&nbsp;fails,&nbsp;initialize&nbsp;to&nbsp;empty&nbsp;array<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #9876AA">$session_data&nbsp;</span><span style="color: #007700">=&nbsp;array();<br />}&nbsp;else&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;we&nbsp;should&nbsp;now&nbsp;have&nbsp;the&nbsp;serialized&nbsp;data&nbsp;in&nbsp;$tmp[0].<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #9876AA">$session_data&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">unserialize</span><span style="color: #007700">(</span><span style="color: #9876AA">$tmp</span><span style="color: #007700">[</span><span style="color: #9876AA">0</span><span style="color: #007700">]);<br />&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(!</span><span style="color: #9876AA">is_array</span><span style="color: #007700">(</span><span style="color: #9876AA">$session_data</span><span style="color: #007700">))&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;something&nbsp;went&nbsp;wrong,&nbsp;initialize&nbsp;to&nbsp;empty&nbsp;array<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #9876AA">$session_data&nbsp;</span><span style="color: #007700">=&nbsp;array();<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /></span><span style="color: #9876AA">?&gt;</span> </span> </span></div>     </div>     </div>   </span>   <p class="para">    <div class="example" id="example-6577">     <p><strong>Example #2 unserialize_callback_func example</strong></p>     <div class="example-contents"> <div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"> <span style="color: #9876AA">&lt;?php<br />$serialized_object</span><span style="color: #007700">=</span><span style="color: #DD0000">'O:1:"a":1:{s:5:"value";s:3:"100";}'</span><span style="color: #007700">;<br /><br /></span><span style="color: #9876AA">ini_set</span><span style="color: #007700">(</span><span style="color: #DD0000">'unserialize_callback_func'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'mycallback'</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;set&nbsp;your&nbsp;callback_function<br /><br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #9876AA">mycallback</span><span style="color: #007700">(</span><span style="color: #9876AA">$classname</span><span style="color: #007700">)&nbsp;<br />{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;just&nbsp;include&nbsp;a&nbsp;file&nbsp;containing&nbsp;your&nbsp;classdefinition<br />&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;you&nbsp;get&nbsp;$classname&nbsp;to&nbsp;figure&nbsp;out&nbsp;which&nbsp;classdefinition&nbsp;is&nbsp;required<br /></span><span style="color: #007700">}<br /></span><span style="color: #9876AA">?&gt;</span> </span> </span></div>     </div>     </div>   </p>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 notes" id="refsect1-function.unserialize-notes">   <h3 class="title">Notes</h3>   <div class="warning"><strong class="warning">Warning</strong>    <p class="para">     <strong><span>FALSE</span></strong> is returned both in the case of an error and if unserializing     the serialized <strong><span>FALSE</span></strong> value. It is possible to catch this special case by     comparing <span class="parameter" style="color:#2EACF9">str</span> with     <em>serialize(false)</em> or by catching the issued     <strong><span>E_NOTICE</span></strong>.    </p>   </div>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.unserialize-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><span class="function">{@link json_encode()} - Returns the JSON representation of a value</span></li>     <li class="member"><span class="function">{@link json_decode()} - Decodes a JSON string</span></li>     <li class="member"><span class="function">{@link hash_hmac()} - Generate a keyed hash value using the HMAC method</span></li>     <li class="member"><span class="function">{@link serialize()} - Generates a storable representation of a value</span></li>     <li class="member"><a href="https://www.php.net/manual/en/language.oop5.autoload.php" class="link">Autoloading Classes</a></li>     <li class="member"><a href="https://www.php.net/manual/en/var.configuration.php#ini.unserialize-callback-func" class="link">unserialize_callback_func</a></li>     <li class="member"><a href="https://www.php.net/manual/en/language.oop5.magic.php#object.wakeup" class="link">__wakeup()</a></li>    </ul>   </span>  </div>   </div>
*/
	public function unserialize ($serialized) {}

/**
*<div id="function.rewind" class="refentry">  <div class="refnamediv">   <h1 class="refname">rewind</h1>   <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">rewind</span> &mdash; <span class="dc-title">Rewind the position of a file pointer</span></p>   </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.rewind-description">   <h3 class="title">Description</h3>   <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><strong>rewind</strong></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">resource</span> <span class="parameter" style="color:#2EACF9">$handle</span></span>    ) : <span class="type" style="color:#EAB766">bool</span></div>    <p class="para rdfs-comment">    Sets the file position indicator for <span class="parameter" style="color:#2EACF9">handle</span>    to the beginning of the file stream.   </p>   <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>:     <p class="para">     If you have opened the file in append (&quot;a&quot; or &quot;a+&quot;) mode, any data you     write to the file will always be appended, regardless of the file pointer position.    </p>   </p></blockquote>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.rewind-parameters">   <h3 class="title">Parameters</h3>   <span>    <dl>            <dt> <span class="parameter" style="color:#2EACF9">handle</span></dt>       <dd>        <p class="para">        The file pointer must be valid, and must point to a file        successfully opened by <span class="function">{@link fopen()}</span>.       </p>      </dd>          </dl>    </span>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.rewind-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    Returns <strong><span>TRUE</span></strong> on success or <strong><span>FALSE</span></strong> on failure.   </p>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.rewind-examples">   <h3 class="title">Examples</h3>   <span>    <div class="example" id="example-2953">     <p><strong>Example #1 <span class="function"><strong style="color:#CC7832">rewind()</strong></span> overwriting example</strong></p>     <div class="example-contents"> <div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"> <span style="color: #9876AA">&lt;?php<br />$handle&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">fopen</span><span style="color: #007700">(</span><span style="color: #DD0000">'output.txt'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'r+'</span><span style="color: #007700">);<br /><br /></span><span style="color: #9876AA">fwrite</span><span style="color: #007700">(</span><span style="color: #9876AA">$handle</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'Really&nbsp;long&nbsp;sentence.'</span><span style="color: #007700">);<br /></span><span style="color: #9876AA">rewind</span><span style="color: #007700">(</span><span style="color: #9876AA">$handle</span><span style="color: #007700">);<br /></span><span style="color: #9876AA">fwrite</span><span style="color: #007700">(</span><span style="color: #9876AA">$handle</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'Foo'</span><span style="color: #007700">);<br /></span><span style="color: #9876AA">rewind</span><span style="color: #007700">(</span><span style="color: #9876AA">$handle</span><span style="color: #007700">);<br /><br />echo&nbsp;</span><span style="color: #9876AA">fread</span><span style="color: #007700">(</span><span style="color: #9876AA">$handle</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">filesize</span><span style="color: #007700">(</span><span style="color: #DD0000">'output.txt'</span><span style="color: #007700">));<br /><br /></span><span style="color: #9876AA">fclose</span><span style="color: #007700">(</span><span style="color: #9876AA">$handle</span><span style="color: #007700">);<br /></span><span style="color: #9876AA">?&gt;</span> </span> </span></div>     </div>      <div class="example-contents"><p>The above example will output something similar to:</p></div>     <div class="example-contents screen" style="background:black;padding-left:5px;"> <div class="cdata"><span> Foolly long sentence. </span></div>     </div>    </div>   </span>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.rewind-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><span class="function">{@link fread()} - Binary-safe file read</span></li>     <li class="member"><span class="function">{@link fseek()} - Seeks on a file pointer</span></li>     <li class="member"><span class="function">{@link ftell()} - Returns the current position of the file read/write pointer</span></li>     <li class="member"><span class="function">{@link fwrite()} - Binary-safe file write</span></li>    </ul>   </span>  </div>   </div>
*/
	public function rewind () {}

	public function valid () {}

/**
*<div id="function.current" class="refentry">  <div class="refnamediv">   <h1 class="refname">current</h1>   <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">current</span> &mdash; <span class="dc-title">Return the current element in an array</span></p>   </div>  <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.current-description">   <h3 class="title">Description</h3>   <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><strong>current</strong></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">array</span> <span class="parameter" style="color:#2EACF9">$array</span></span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span></div>    <p class="para rdfs-comment">    Every array has an internal pointer to its &quot;current&quot; element,    which is initialized to the first element inserted into the    array.   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.current-parameters">   <h3 class="title">Parameters</h3>   <span>    <dl>            <dt> <span class="parameter" style="color:#2EACF9">array</span></dt>       <dd>        <p class="para">        The array.       </p>      </dd>          </dl>    </span>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.current-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    The <span class="function"><strong style="color:#CC7832">current()</strong></span> function simply returns the    value of the array element that&#039;s currently being pointed to by the    internal pointer.  It does not move the pointer in any way.  If the    internal pointer points beyond the end of the elements list or the array is     empty, <span class="function"><strong style="color:#CC7832">current()</strong></span> returns <strong><span>FALSE</span></strong>.   </p>   <div class="warning"><strong class="warning">Warning</strong><p class="simpara">This function may return Boolean <strong><span>FALSE</span></strong>, but may also return a non-Boolean value which evaluates to <strong><span>FALSE</span></strong>. Please read the section on <a href="https://www.php.net/manual/en/language.types.boolean.php" class="link">Booleans</a> for more information. Use <a href="https://www.php.net/manual/en/language.operators.comparison.php" class="link">the === operator</a> for testing the return value of this function.</p></div>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 changelog" id="refsect1-function.current-changelog">   <h3 class="title">Changelog</h3>   <span>    <table class="doctable informaltable">           <thead>       <tr>        <th>Version</th>        <th>Description</th>       </tr>       </thead>       <tbody class="tbody">       <tr>        <td>7.0.0</td>        <td>         <span class="parameter" style="color:#2EACF9">array</span> is now always passed by value.         Prior to this version, it was passed by reference if possible,         and by value otherwise.        </td>       </tr>       </tbody>         </table>    </span>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.current-examples">   <h3 class="title">Examples</h3>   <span>    <div class="example" id="example-6278">     <p><strong>Example #1 Example use of <span class="function"><strong style="color:#CC7832">current()</strong></span> and friends</strong></p>     <div class="example-contents"> <div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"> <span style="color: #9876AA">&lt;?php<br />$transport&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #DD0000">'foot'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'bike'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'car'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'plane'</span><span style="color: #007700">);<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'foot';<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">next</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'bike';<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'bike';<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">prev</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'foot';<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">end</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'plane';<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'plane';<br /><br /></span><span style="color: #9876AA">$arr&nbsp;</span><span style="color: #007700">=&nbsp;array();<br /></span><span style="color: #9876AA">var_dump</span><span style="color: #007700">(</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$arr</span><span style="color: #007700">));&nbsp;</span><span style="color: #FF8000">//&nbsp;bool(false)<br /><br /></span><span style="color: #9876AA">$arr&nbsp;</span><span style="color: #007700">=&nbsp;array(array());<br /></span><span style="color: #9876AA">var_dump</span><span style="color: #007700">(</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$arr</span><span style="color: #007700">));&nbsp;</span><span style="color: #FF8000">//&nbsp;array(0)&nbsp;{&nbsp;}<br /></span><span style="color: #9876AA">?&gt;</span> </span> </span></div>     </div>     </div>   </span>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 notes" id="refsect1-function.current-notes">   <h3 class="title">Notes</h3>   <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>:     <span class="simpara">     The end of an array and the result of calling      <span class="function"><strong style="color:#CC7832">current()</strong></span> on an empty array      are indistinguishable from a <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.boolean.php" class="type boolean" style="color:#EAB766">boolean</a></span> <strong><span>FALSE</span></strong> element.      To properly traverse an array which may contain <strong><span>FALSE</span></strong> elements, see the      <span class="function"><strong style="color:#CC7832">foreach()</strong></span> function.    </span>    <span class="simpara">     To still use <span class="function"><strong style="color:#CC7832">current()</strong></span> and properly check if the value      is really an element of the array, the <span class="function">{@link key()}</span>      of the <span class="function"><strong style="color:#CC7832">current()</strong></span> element should be checked to be strictly      different from <strong><span>NULL</span></strong>.    </span>   </p></blockquote>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.current-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><span class="function">{@link end()} - Set the internal pointer of an array to its last element</span></li>     <li class="member"><span class="function">{@link key()} - Fetch a key from an array</span></li>     <li class="member"><span class="function">{@link each()} - Return the current key and value pair from an array and advance the array cursor</span></li>     <li class="member"><span class="function">{@link prev()} - Rewind the internal array pointer</span></li>     <li class="member"><span class="function">{@link reset()} - Set the internal pointer of an array to its first element</span></li>     <li class="member"><span class="function">{@link next()} - Advance the internal pointer of an array</span></li>    </ul>   </span>  </div>  </div>
*/
	public function current () {}

/**
*<div id="function.key" class="refentry">  <div class="refnamediv">   <h1 class="refname">key</h1>   <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">key</span> &mdash; <span class="dc-title">Fetch a key from an array</span></p>   </div>  <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.key-description">   <h3 class="title">Description</h3>   <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><strong>key</strong></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">array</span> <span class="parameter" style="color:#2EACF9">$array</span></span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span></div>    <p class="para rdfs-comment">    <span class="function"><strong style="color:#CC7832">key()</strong></span> returns the index element of the current array    position.   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.key-parameters">   <h3 class="title">Parameters</h3>   <span>    <dl>            <dt> <span class="parameter" style="color:#2EACF9">array</span></dt>       <dd>        <p class="para">        The array.       </p>      </dd>          </dl>    </span>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.key-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    The <span class="function"><strong style="color:#CC7832">key()</strong></span> function simply returns the    key of the array element that&#039;s currently being pointed to by the    internal pointer.  It does not move the pointer in any way.  If the    internal pointer points beyond the end of the elements list or the array is     empty, <span class="function"><strong style="color:#CC7832">key()</strong></span> returns <strong><span>NULL</span></strong>.   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 changelog" id="refsect1-function.key-changelog">   <h3 class="title">Changelog</h3>   <span>    <table class="doctable informaltable">           <thead>       <tr>        <th>Version</th>        <th>Description</th>       </tr>       </thead>       <tbody class="tbody">       <tr>        <td>7.0.0</td>        <td>         <span class="parameter" style="color:#2EACF9">array</span> is now always passed by value.         Prior to this version, it was passed by reference if possible,         and by value otherwise.        </td>       </tr>       </tbody>         </table>    </span>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.key-examples">   <h3 class="title">Examples</h3>   <span>    <div class="example" id="example-6286">     <p><strong>Example #1 <span class="function"><strong style="color:#CC7832">key()</strong></span> example</strong></p>     <div class="example-contents"> <div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"> <span style="color: #9876AA">&lt;?php<br />$array&nbsp;</span><span style="color: #007700">=&nbsp;array(<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'fruit1'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">'apple'</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'fruit2'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">'orange'</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'fruit3'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">'grape'</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'fruit4'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">'apple'</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'fruit5'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">'apple'</span><span style="color: #007700">);<br /><br /></span><span style="color: #FF8000">//&nbsp;this&nbsp;cycle&nbsp;echoes&nbsp;all&nbsp;associative&nbsp;array<br />//&nbsp;key&nbsp;where&nbsp;value&nbsp;equals&nbsp;"apple"<br /></span><span style="color: #007700">while&nbsp;(</span><span style="color: #9876AA">$fruit_name&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">))&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(</span><span style="color: #9876AA">$fruit_name&nbsp;</span><span style="color: #007700">==&nbsp;</span><span style="color: #DD0000">'apple'</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #9876AA">key</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">).</span><span style="color: #DD0000">'&lt;br&nbsp;/&gt;'</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #9876AA">next</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">);<br />}<br /></span><span style="color: #9876AA">?&gt;</span> </span> </span></div>     </div>      <div class="example-contents"><p>The above example will output:</p></div>     <div class="example-contents screen" style="background:black;padding-left:5px;"> <div class="cdata"><span> fruit1&lt;br /&gt; fruit4&lt;br /&gt; fruit5&lt;br /&gt; </span></div>     </div>    </div>   </span>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.key-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><span class="function">{@link current()} - Return the current element in an array</span></li>     <li class="member"><span class="function">{@link next()} - Advance the internal pointer of an array</span></li>     <li class="member"><a href="https://www.php.net/manual/en/control-structures.foreach.php" class="link">foreach</a></li>    </ul>   </span>  </div>  </div>
*/
	public function key () {}

/**
*<div id="function.next" class="refentry">  <div class="refnamediv">   <h1 class="refname">next</h1>   <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">next</span> &mdash; <span class="dc-title">Advance the internal pointer of an array</span></p>   </div>  <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.next-description">   <h3 class="title">Description</h3>   <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><strong>next</strong></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">array</span> <span class="parameter" style="color:#2EACF9">&$array</span></span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span></div>    <p class="para rdfs-comment">    <span class="function"><strong style="color:#CC7832">next()</strong></span> behaves like    <span class="function">{@link current()}</span>, with one difference.  It advances    the internal array pointer one place forward before returning the    element value.  That means it returns the next array value and    advances the internal array pointer by one.   </p>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.next-parameters">   <h3 class="title">Parameters</h3>   <span>    <dl>            <dt> <span class="parameter" style="color:#2EACF9">array</span></dt>       <dd>        <p class="para">        The <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.array.php" class="type array" style="color:#EAB766">array</a></span> being affected.       </p>      </dd>          </dl>    </span>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.next-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    Returns the array value in the next place that&#039;s pointed to by the    internal array pointer, or <strong><span>FALSE</span></strong> if there are no more elements.   </p>   <div class="warning"><strong class="warning">Warning</strong><p class="simpara">This function may return Boolean <strong><span>FALSE</span></strong>, but may also return a non-Boolean value which evaluates to <strong><span>FALSE</span></strong>. Please read the section on <a href="https://www.php.net/manual/en/language.types.boolean.php" class="link">Booleans</a> for more information. Use <a href="https://www.php.net/manual/en/language.operators.comparison.php" class="link">the === operator</a> for testing the return value of this function.</p></div>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.next-examples">   <h3 class="title">Examples</h3>   <span>    <div class="example" id="example-6298">     <p><strong>Example #1 Example use of <span class="function"><strong style="color:#CC7832">next()</strong></span> and friends</strong></p>     <div class="example-contents"> <div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"> <span style="color: #9876AA">&lt;?php<br />$transport&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #DD0000">'foot'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'bike'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'car'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'plane'</span><span style="color: #007700">);<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'foot';<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">next</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'bike';<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">next</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'car';<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">prev</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'bike';<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">end</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'plane';<br /></span><span style="color: #9876AA">?&gt;</span> </span> </span></div>     </div>     </div>   </span>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 notes" id="refsect1-function.next-notes">   <h3 class="title">Notes</h3>   <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>:     <span class="simpara">     The end of an array is indistinguishable from a <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.boolean.php" class="type boolean" style="color:#EAB766">boolean</a></span> <strong><span>FALSE</span></strong> element.      To properly traverse an array which may contain <strong><span>FALSE</span></strong> elements, see the      <span class="function"><strong style="color:#CC7832">foreach()</strong></span> function.    </span>    <span class="simpara">     To still use <span class="function"><strong style="color:#CC7832">next()</strong></span> and properly check if the end of the array      has been reached, verify that the <span class="function">{@link key()}</span> is <strong><span>NULL</span></strong>.    </span>   </p></blockquote>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.next-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><span class="function">{@link current()} - Return the current element in an array</span></li>     <li class="member"><span class="function">{@link end()} - Set the internal pointer of an array to its last element</span></li>     <li class="member"><span class="function">{@link prev()} - Rewind the internal array pointer</span></li>     <li class="member"><span class="function">{@link reset()} - Set the internal pointer of an array to its first element</span></li>     <li class="member"><span class="function">{@link each()} - Return the current key and value pair from an array and advance the array cursor</span></li>    </ul>   </span>  </div>  </div>
*/
	public function next () {}

	/**
	 * @return string
	 */
	public function __toString () {}

	/**
	 * (PECL pecl_http &gt;= 1.4.0)<br/>
	 * Create HttpMessage from string
	 * @link http://php.net/manual/en/function.httpmessage-factory.php
	 * @param string $raw_message [optional] <p>
	 * a single or several consecutive HTTP messages
	 * </p>
	 * @param string $class_name [optional] <p>
	 * a class extending HttpMessage
	 * </p>
	 * @return HttpMessage an HttpMessage object on success or NULL on failure.
	 */
	public static function factory ($raw_message = null, $class_name = null) {}

	/**
	 * (PECL pecl_http 0.10.0-1.3.3)<br/>
	 * Create HttpMessage from string
	 * @link http://php.net/manual/en/function.httpmessage-fromstring.php
	 * @param string $raw_message [optional] <p>
	 * a single or several consecutive HTTP messages
	 * </p>
	 * @param string $class_name [optional] <p>
	 * a class extending HttpMessage
	 * </p>
	 * @return HttpMessage an HttpMessage object on success or NULL on failure.
	 */
	public static function fromString ($raw_message = null, $class_name = null) {}

	/**
	 * (PECL pecl_http &gt;= 1.5.0)<br/>
	 * Create HttpMessage from environment
	 * @link http://php.net/manual/en/function.httpmessage-fromenv.php
	 * @param int $message_type <p>
	 * The message type. See HttpMessage type constants.
	 * </p>
	 * @param string $class_name [optional] <p>
	 * a class extending HttpMessage
	 * </p>
	 * @return HttpMessage an HttpMessage object on success or NULL on failure.
	 */
	public static function fromEnv ($message_type, $class_name = null) {}

	/**
	 * (PECL pecl_http &gt;= 0.22.0)<br/>
	 * Detach HttpMessage
	 * @link http://php.net/manual/en/function.httpmessage-detach.php
	 * @return HttpMessage detached HttpMessage object copy.
	 */
	public function detach () {}

	/**
	 * (PECL pecl_http &gt;= 0.22.0)<br/>
	 * Prepend message(s)
	 * @link http://php.net/manual/en/function.httpmessage-prepend.php
	 * @param HttpMessage $message <p>
	 * HttpMessage object to prepend
	 * </p>
	 * @param bool $top [optional] <p>
	 * whether to prepend to the top most or right this message
	 * </p>
	 * @return void 
	 */
	public function prepend (HttpMessage $message, $top = null) {}

	/**
	 * (PECL pecl_http &gt;= 0.23.0)<br/>
	 * Reverse message chain
	 * @link http://php.net/manual/en/function.httpmessage-reverse.php
	 * @return HttpMessage the most parent HttpMessage object.
	 */
	public function reverse () {}

}

/**
 * @link http://php.net/manual/en/class.httpquerystring.php
 */
class HttpQueryString implements Serializable, ArrayAccess {
	const TYPE_BOOL = 3;
	const TYPE_INT = 1;
	const TYPE_FLOAT = 2;
	const TYPE_STRING = 6;
	const TYPE_ARRAY = 4;
	const TYPE_OBJECT = 5;

	private static $instance;
	private $queryArray;
	private $queryString;


	/**
	 * (PECL pecl_http &gt;= 0.22.0)<br/>
	 * HttpQueryString constructor
	 * @link http://php.net/manual/en/function.httpquerystring-construct.php
	 * @param bool $global [optional] <p>
	 * whether to operate on $_GET and
	 * $_SERVER['QUERY_STRING']
	 * </p>
	 * @param mixed $add [optional] <p>
	 * additional/initial query string parameters
	 * </p>
	 */
	final public function __construct ($global = null, $add = null) {}

	/**
	 * (PECL pecl_http &gt;= 0.22.0)<br/>
	 * Get query string as array
	 * @link http://php.net/manual/en/function.httpquerystring-toarray.php
	 * @return array the array representation of the query string.
	 */
	public function toArray () {}

	/**
	 * (PECL pecl_http &gt;= 0.22.0)<br/>
	 * Get query string
	 * @link http://php.net/manual/en/function.httpquerystring-tostring.php
	 * @return string the string representation of the query string.
	 */
	public function toString () {}

	/**
	 * @return string
	 */
	public function __toString () {}

	/**
	 * (PECL pecl_http &gt;= 0.22.0)<br/>
	 * Get (part of) query string
	 * @link http://php.net/manual/en/function.httpquerystring-get.php
	 * @param string $key [optional] <p>
	 * key of the query string param to retrieve
	 * </p>
	 * @param mixed $type [optional] <p>
	 * which variable type to enforce
	 * </p>
	 * @param mixed $defval [optional] <p>
	 * default value if key does not exist
	 * </p>
	 * @param bool $delete [optional] <p>
	 * whether to remove the key/value pair from the query string
	 * </p>
	 * @return mixed the value of the query string param or the whole query string if no key was specified on success or defval if key does not exist.
	 */
	public function get ($key = null, $type = null, $defval = null, $delete = null) {}

	/**
	 * (PECL pecl_http &gt;= 0.22.0)<br/>
	 * Set query string params
	 * @link http://php.net/manual/en/function.httpquerystring-set.php
	 * @param mixed $params <p>
	 * query string params to add
	 * </p>
	 * @return string the current query string.
	 */
	public function set ($params) {}

	/**
	 * (PECL pecl_http &gt;= 1.1.0)<br/>
	 * Modifiy query string copy
	 * @link http://php.net/manual/en/function.httpquerystring-mod.php
	 * @param mixed $params <p>
	 * query string params to add
	 * </p>
	 * @return HttpQueryString a new HttpQueryString object
	 */
	public function mod ($params) {}

	/**
	 * @param $name
	 * @param $defval [optional]
	 * @param $delete [optional]
	 */
	public function getBool ($name, $defval, $delete) {}

	/**
	 * @param $name
	 * @param $defval [optional]
	 * @param $delete [optional]
	 */
	public function getInt ($name, $defval, $delete) {}

	/**
	 * @param $name
	 * @param $defval [optional]
	 * @param $delete [optional]
	 */
	public function getFloat ($name, $defval, $delete) {}

	/**
	 * @param $name
	 * @param $defval [optional]
	 * @param $delete [optional]
	 */
	public function getString ($name, $defval, $delete) {}

	/**
	 * @param $name
	 * @param $defval [optional]
	 * @param $delete [optional]
	 */
	public function getArray ($name, $defval, $delete) {}

	/**
	 * @param $name
	 * @param $defval [optional]
	 * @param $delete [optional]
	 */
	public function getObject ($name, $defval, $delete) {}

	/**
	 * @param $global [optional]
	 * @param $params [optional]
	 * @param $class_name [optional]
	 */
	public static function factory ($global, $params, $class_name) {}

	/**
	 * (PECL pecl_http &gt;= 0.25.0)<br/>
	 * HttpQueryString singleton
	 * @link http://php.net/manual/en/function.httpquerystring-singleton.php
	 * @param bool $global [optional] <p>
	 * whether to operate on $_GET and
	 * $_SERVER['QUERY_STRING']
	 * </p>
	 * @return HttpQueryString always the same HttpQueryString instance regarding the global setting.
	 */
	public static function singleton ($global = null) {}

	/**
	 * (PECL pecl_http &gt;= 0.25.0)<br/>
	 * Change query strings charset
	 * @link http://php.net/manual/en/function.httpquerystring-xlate.php
	 * @param string $ie <p>
	 * input encoding
	 * </p>
	 * @param string $oe <p>
	 * output encoding
	 * </p>
	 * @return bool true on success or false on failure.
	 */
	public function xlate ($ie, $oe) {}

	/**
	 * String representation of object
	 * @link http://php.net/manual/en/serializable.serialize.php
	 * @return string the string representation of the object or null
	 * @since 5.1.0
	 */
/**
*<div id="function.serialize" class="refentry">  <div class="refnamediv">   <h1 class="refname">serialize</h1>   <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">serialize</span> &mdash; <span class="dc-title">Generates a storable representation of a value</span></p>   </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.serialize-description">   <h3 class="title">Description</h3>    <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">     <span class="methodname" style="color:#CC7832"><strong>serialize</strong></span>      ( <span class="methodparam"><span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span> <span class="parameter" style="color:#2EACF9">$value</span></span>     ) : <span class="type" style="color:#EAB766">string</span></div>    <p class="para rdfs-comment">    Generates a storable representation of a value.   </p>   <p class="para">    This is useful for storing or passing PHP values around without    losing their type and structure.   </p>   <p class="para">    To make the serialized string into a PHP value again, use    <span class="function">{@link unserialize()}</span>.     </p>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.serialize-parameters">   <h3 class="title">Parameters</h3>   <span>    <dl>            <dt> <span class="parameter" style="color:#2EACF9">value</span></dt>       <dd>        <p class="para">        The value to be serialized. <span class="function"><strong style="color:#CC7832">serialize()</strong></span>        handles all types, except the <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.resource.php" class="type resource" style="color:#EAB766">resource</a></span>-type and some <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.object.php" class="type object" style="color:#EAB766">object</a></span>s (see note below).        You can even <span class="function"><strong style="color:#CC7832">serialize()</strong></span> arrays that contain        references to itself. Circular references inside the array/object you         are serializing will also be stored. Any other         reference will be lost.       </p>       <p class="para">        When serializing objects, PHP will attempt to call the member function        <a href="https://www.php.net/manual/en/language.oop5.magic.php#object.sleep" class="link">__sleep()</a> prior to serialization.         This is to allow the object to do any last minute clean-up, etc. prior         to being serialized. Likewise, when the object is restored using         <span class="function">{@link unserialize()}</span> the <a href="https://www.php.net/manual/en/language.oop5.magic.php#object.wakeup" class="link">__wakeup()</a> member function is called.       </p>       <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>:         <p class="para">        Object&#039;s private members have the class name prepended to the member        name; protected members have a &#039;*&#039; prepended to the member name.        These prepended values have null bytes on either side.        </p>       </p></blockquote>      </dd>          </dl>    </span>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.serialize-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    Returns a string containing a byte-stream representation of     <span class="parameter" style="color:#2EACF9">value</span> that can be stored anywhere.   </p>   <p class="para">    Note that this is a binary string which may include null bytes, and needs    to be stored and handled as such. For example,    <span class="function"><strong style="color:#CC7832">serialize()</strong></span> output should generally be stored in a BLOB    field in a database, rather than a CHAR or TEXT field.   </p>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.serialize-examples">   <h3 class="title">Examples</h3>   <span>    <div class="example" id="example-6573">     <p><strong>Example #1 <span class="function"><strong style="color:#CC7832">serialize()</strong></span> example</strong></p>     <div class="example-contents"> <div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"> <span style="color: #9876AA">&lt;?php<br /></span><span style="color: #FF8000">//&nbsp;$session_data&nbsp;contains&nbsp;a&nbsp;multi-dimensional&nbsp;array&nbsp;with&nbsp;session<br />//&nbsp;information&nbsp;for&nbsp;the&nbsp;current&nbsp;user.&nbsp;&nbsp;We&nbsp;use&nbsp;serialize()&nbsp;to&nbsp;store<br />//&nbsp;it&nbsp;in&nbsp;a&nbsp;database&nbsp;at&nbsp;the&nbsp;end&nbsp;of&nbsp;the&nbsp;request.<br /><br /></span><span style="color: #9876AA">$conn&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">odbc_connect</span><span style="color: #007700">(</span><span style="color: #DD0000">"webdb"</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">"php"</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">"chicken"</span><span style="color: #007700">);<br /></span><span style="color: #9876AA">$stmt&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">odbc_prepare</span><span style="color: #007700">(</span><span style="color: #9876AA">$conn</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">"UPDATE&nbsp;sessions&nbsp;SET&nbsp;data&nbsp;=&nbsp;?&nbsp;WHERE&nbsp;id&nbsp;=&nbsp;?"</span><span style="color: #007700">);<br /></span><span style="color: #9876AA">$sqldata&nbsp;</span><span style="color: #007700">=&nbsp;array&nbsp;(</span><span style="color: #9876AA">serialize</span><span style="color: #007700">(</span><span style="color: #9876AA">$session_data</span><span style="color: #007700">),&nbsp;</span><span style="color: #9876AA">$_SERVER</span><span style="color: #007700">[</span><span style="color: #DD0000">'PHP_AUTH_USER'</span><span style="color: #007700">]);<br />if&nbsp;(!</span><span style="color: #9876AA">odbc_execute</span><span style="color: #007700">(</span><span style="color: #9876AA">$stmt</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">$sqldata</span><span style="color: #007700">))&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #9876AA">$stmt&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">odbc_prepare</span><span style="color: #007700">(</span><span style="color: #9876AA">$conn</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">"INSERT&nbsp;INTO&nbsp;sessions&nbsp;(id,&nbsp;data)&nbsp;VALUES(?,&nbsp;?)"</span><span style="color: #007700">);<br />&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(!</span><span style="color: #9876AA">odbc_execute</span><span style="color: #007700">(</span><span style="color: #9876AA">$stmt</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">$sqldata</span><span style="color: #007700">))&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;Something&nbsp;went&nbsp;wrong..&nbsp;<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">}<br />}<br /></span><span style="color: #9876AA">?&gt;</span> </span> </span></div>     </div>     </div>   </span>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 notes" id="refsect1-function.serialize-notes">   <h3 class="title">Notes</h3>   <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>:     <p class="para">     Note that many built-in PHP objects cannot be serialized. However, those with      this ability either implement the <span class="interfacename"><a href="https://www.php.net/manual/en/class.serializable.php" class="interfacename">Serializable</a></span> interface or the      magic <a href="https://www.php.net/manual/en/language.oop5.magic.php#object.sleep" class="link">__sleep()</a> and     <a href="https://www.php.net/manual/en/language.oop5.magic.php#object.wakeup" class="link">__wakeup()</a> methods. If an      internal class does not fulfill any of those requirements, it cannot reliably be      serialized.    </p>    <p class="para">     There are some historical exceptions to the above rule, where some internal objects      could be serialized without implementing the interface or exposing the methods. Notably,      the <a href="https://www.php.net/manual/en/class.arrayobject.php" class="classname">ArrayObject</a> prior to PHP 5.2.0.    </p>   </p></blockquote>   <div class="warning"><strong class="warning">Warning</strong>    <p class="para">     When <span class="function"><strong style="color:#CC7832">serialize()</strong></span> serializes objects, the leading backslash is not included in the class name of namespaced classes for maximum compatibility.    </p>   </div>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.serialize-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><span class="function">{@link unserialize()} - Creates a PHP value from a stored representation</span></li>     <li class="member"><span class="function">{@link var_export()} - Outputs or returns a parsable string representation of a variable</span></li>     <li class="member"><span class="function">{@link json_encode()} - Returns the JSON representation of a value</span></li>     <li class="member"><a href="https://www.php.net/manual/en/language.oop5.serialization.php" class="link">Serializing Objects</a></li>     <li class="member"><a href="https://www.php.net/manual/en/language.oop5.magic.php#object.sleep" class="link">__sleep()</a></li>     <li class="member"><a href="https://www.php.net/manual/en/language.oop5.magic.php#object.wakeup" class="link">__wakeup()</a></li>    </ul>   </span>  </div>   </div>
*/
	public function serialize()
	{}

	/**
	 * Offset to retrieve
	 * @link http://php.net/manual/en/arrayaccess.offsetget.php
	 * @param mixed $offset <p>
	 * The offset to retrieve.
	 * </p>
	 * @return mixed Can return all value types.
	 * @since 5.0.0
	 */
	public function offsetGet($offset)
	{}

	/**
	 * Constructs the object
	 * @link http://php.net/manual/en/serializable.unserialize.php
	 * @param string $serialized <p>
	 * The string representation of the object.
	 * </p>
	 * @return void
	 * @since 5.1.0
	 */
/**
*<div id="function.unserialize" class="refentry">  <div class="refnamediv">   <h1 class="refname">unserialize</h1>   <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">unserialize</span> &mdash; <span class="dc-title">    Creates a PHP value from a stored representation   </span></p>   </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.unserialize-description">   <h3 class="title">Description</h3>   <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><strong>unserialize</strong></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$str</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">array</span> <span class="parameter" style="color:#2EACF9">$options</span></span>   ] ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span></div>    <p class="simpara">    <span class="function"><strong style="color:#CC7832">unserialize()</strong></span> takes a single serialized variable and    converts it back into a PHP value.     </p>   <div class="warning"><strong class="warning">Warning</strong>    <p class="para">     Do not pass untrusted user input to <span class="function"><strong style="color:#CC7832">unserialize()</strong></span> regardless     of the <span class="parameter" style="color:#2EACF9">options</span> value of <em>allowed_classes</em>.     Unserialization can result in code being loaded and executed due to object     instantiation and autoloading, and a malicious user may be able to exploit     this. Use a safe, standard data interchange format such as JSON (via     <span class="function">{@link json_decode()}</span> and <span class="function">{@link json_encode()}</span>) if     you need to pass serialized data to the user.    </p>    <p class="para">     If you need to unserialize externally-stored serialized data, consider using     <span class="function">{@link hash_hmac()}</span> for data validation. Make sure data is     not modified by anyone but you.    </p>   </div>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.unserialize-parameters">   <h3 class="title">Parameters</h3>   <span>    <dl>            <dt> <span class="parameter" style="color:#2EACF9">str</span></dt>       <dd>        <p class="para">        The serialized string.       </p>       <p class="para">        If the variable being unserialized is an object, after successfully         reconstructing the object PHP will automatically attempt to call the        <a href="https://www.php.net/manual/en/language.oop5.magic.php#object.wakeup" class="link">__wakeup()</a> member        function (if it exists).       </p>       <p class="para">        <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>:          <strong>unserialize_callback_func directive</strong><br />         <p class="para">          It&#039;s possible to set a callback-function which will be called,          if an undefined class should be instantiated during unserializing.          (to prevent getting an incomplete <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.object.php" class="type object" style="color:#EAB766">object</a></span> &quot;__PHP_Incomplete_Class&quot;.)          Use your <var class="filename">php.ini</var>, <span class="function">{@link ini_set()}</span> or <var class="filename">.htaccess</var>           to define <a href="https://www.php.net/manual/en/var.configuration.php#ini.unserialize-callback-func" class="link">unserialize_callback_func</a>.          Everytime an undefined class should be instantiated, it&#039;ll be called.  To disable this feature just          empty this setting.         </p>        </p></blockquote>       </p>      </dd>                 <dt> <span class="parameter" style="color:#2EACF9">options</span></dt>       <dd>        <p class="para">        Any options to be provided to <span class="function"><strong style="color:#CC7832">unserialize()</strong></span>, as an        associative array.       </p>       <table class="doctable table">        <caption><strong>Valid options</strong></caption>                 <thead>          <tr>           <th>Name</th>           <th>Type</th>           <th>Description</th>          </tr>          </thead>          <tbody class="tbody">          <tr>           <td><em>allowed_classes</em></td>           <td><span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span></td>           <td>            <span class="simpara">             Either an <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.array.php" class="type array" style="color:#EAB766">array</a></span> of class names which should be             accepted, <strong><span>FALSE</span></strong> to accept no classes, or <strong><span>TRUE</span></strong> to accept all             classes. If this option is defined and             <span class="function"><strong style="color:#CC7832">unserialize()</strong></span> encounters an object of a class             that isn&#039;t to be accepted, then the object will be instantiated as             <strong class="classname">__PHP_Incomplete_Class</strong> instead.            </span>            <span class="simpara">             Omitting this option is the same as defining it as <strong><span>TRUE</span></strong>: PHP             will attempt to instantiate objects of any class.            </span>           </td>          </tr>          </tbody>               </table>       </dd>          </dl>    </span>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.unserialize-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    The converted value is returned, and can be a <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.boolean.php" class="type boolean" style="color:#EAB766">boolean</a></span>,    <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.integer.php" class="type integer" style="color:#EAB766">integer</a></span>, <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.float.php" class="type float" style="color:#EAB766">float</a></span>, <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.string.php" class="type string" style="color:#EAB766">string</a></span>,    <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.array.php" class="type array" style="color:#EAB766">array</a></span> or <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.object.php" class="type object" style="color:#EAB766">object</a></span>.   </p>   <p class="para">    In case the passed string is not unserializeable, <strong><span>FALSE</span></strong> is returned and    <strong><span>E_NOTICE</span></strong> is issued.   </p>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 changelog" id="refsect1-function.unserialize-changelog">   <h3 class="title">Changelog</h3>   <span>    <table class="doctable informaltable">           <thead>       <tr>        <th>Version</th>        <th>Description</th>       </tr>       </thead>       <tbody class="tbody">       <tr>        <td>7.1.0</td>        <td>         The <em>allowed_classes</em> element of         <span class="parameter" style="color:#2EACF9">options</span>) is now strictly typed, i.e. if anything         other than an <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.array.php" class="type array" style="color:#EAB766">array</a></span> or a <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.boolean.php" class="type boolean" style="color:#EAB766">boolean</a></span> is given,         <span class="function"><strong style="color:#CC7832">unserialize()</strong></span> returns <strong><span>FALSE</span></strong> and issues an         <strong><span>E_WARNING</span></strong>.        </td>       </tr>        <tr>        <td>7.0.0</td>        <td>         The <span class="parameter" style="color:#2EACF9">options</span> parameter has been added.        </td>       </tr>        <tr>        <td>5.6.0</td>        <td>         Manipulating the serialised data by replacing <em>C:</em>         with <em>O:</em> to force object instantiation without         calling the constructor will now fail.        </td>       </tr>       </tbody>         </table>    </span>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.unserialize-examples">   <h3 class="title">Examples</h3>   <span>    <div class="example" id="example-6576">     <p><strong>Example #1 <span class="function"><strong style="color:#CC7832">unserialize()</strong></span> example</strong></p>     <div class="example-contents"> <div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"> <span style="color: #9876AA">&lt;?php<br /></span><span style="color: #FF8000">//&nbsp;Here,&nbsp;we&nbsp;use&nbsp;unserialize()&nbsp;to&nbsp;load&nbsp;session&nbsp;data&nbsp;to&nbsp;the<br />//&nbsp;$session_data&nbsp;array&nbsp;from&nbsp;the&nbsp;string&nbsp;selected&nbsp;from&nbsp;a&nbsp;database.<br />//&nbsp;This&nbsp;example&nbsp;complements&nbsp;the&nbsp;one&nbsp;described&nbsp;with&nbsp;serialize().<br /><br /></span><span style="color: #9876AA">$conn&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">odbc_connect</span><span style="color: #007700">(</span><span style="color: #DD0000">"webdb"</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">"php"</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">"chicken"</span><span style="color: #007700">);<br /></span><span style="color: #9876AA">$stmt&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">odbc_prepare</span><span style="color: #007700">(</span><span style="color: #9876AA">$conn</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">"SELECT&nbsp;data&nbsp;FROM&nbsp;sessions&nbsp;WHERE&nbsp;id&nbsp;=&nbsp;?"</span><span style="color: #007700">);<br /></span><span style="color: #9876AA">$sqldata&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #9876AA">$_SERVER</span><span style="color: #007700">[</span><span style="color: #DD0000">'PHP_AUTH_USER'</span><span style="color: #007700">]);<br />if&nbsp;(!</span><span style="color: #9876AA">odbc_execute</span><span style="color: #007700">(</span><span style="color: #9876AA">$stmt</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">$sqldata</span><span style="color: #007700">)&nbsp;||&nbsp;!</span><span style="color: #9876AA">odbc_fetch_into</span><span style="color: #007700">(</span><span style="color: #9876AA">$stmt</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">$tmp</span><span style="color: #007700">))&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;if&nbsp;the&nbsp;execute&nbsp;or&nbsp;fetch&nbsp;fails,&nbsp;initialize&nbsp;to&nbsp;empty&nbsp;array<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #9876AA">$session_data&nbsp;</span><span style="color: #007700">=&nbsp;array();<br />}&nbsp;else&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;we&nbsp;should&nbsp;now&nbsp;have&nbsp;the&nbsp;serialized&nbsp;data&nbsp;in&nbsp;$tmp[0].<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #9876AA">$session_data&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">unserialize</span><span style="color: #007700">(</span><span style="color: #9876AA">$tmp</span><span style="color: #007700">[</span><span style="color: #9876AA">0</span><span style="color: #007700">]);<br />&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(!</span><span style="color: #9876AA">is_array</span><span style="color: #007700">(</span><span style="color: #9876AA">$session_data</span><span style="color: #007700">))&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;something&nbsp;went&nbsp;wrong,&nbsp;initialize&nbsp;to&nbsp;empty&nbsp;array<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #9876AA">$session_data&nbsp;</span><span style="color: #007700">=&nbsp;array();<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /></span><span style="color: #9876AA">?&gt;</span> </span> </span></div>     </div>     </div>   </span>   <p class="para">    <div class="example" id="example-6577">     <p><strong>Example #2 unserialize_callback_func example</strong></p>     <div class="example-contents"> <div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"> <span style="color: #9876AA">&lt;?php<br />$serialized_object</span><span style="color: #007700">=</span><span style="color: #DD0000">'O:1:"a":1:{s:5:"value";s:3:"100";}'</span><span style="color: #007700">;<br /><br /></span><span style="color: #9876AA">ini_set</span><span style="color: #007700">(</span><span style="color: #DD0000">'unserialize_callback_func'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'mycallback'</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;set&nbsp;your&nbsp;callback_function<br /><br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #9876AA">mycallback</span><span style="color: #007700">(</span><span style="color: #9876AA">$classname</span><span style="color: #007700">)&nbsp;<br />{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;just&nbsp;include&nbsp;a&nbsp;file&nbsp;containing&nbsp;your&nbsp;classdefinition<br />&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;you&nbsp;get&nbsp;$classname&nbsp;to&nbsp;figure&nbsp;out&nbsp;which&nbsp;classdefinition&nbsp;is&nbsp;required<br /></span><span style="color: #007700">}<br /></span><span style="color: #9876AA">?&gt;</span> </span> </span></div>     </div>     </div>   </p>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 notes" id="refsect1-function.unserialize-notes">   <h3 class="title">Notes</h3>   <div class="warning"><strong class="warning">Warning</strong>    <p class="para">     <strong><span>FALSE</span></strong> is returned both in the case of an error and if unserializing     the serialized <strong><span>FALSE</span></strong> value. It is possible to catch this special case by     comparing <span class="parameter" style="color:#2EACF9">str</span> with     <em>serialize(false)</em> or by catching the issued     <strong><span>E_NOTICE</span></strong>.    </p>   </div>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.unserialize-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><span class="function">{@link json_encode()} - Returns the JSON representation of a value</span></li>     <li class="member"><span class="function">{@link json_decode()} - Decodes a JSON string</span></li>     <li class="member"><span class="function">{@link hash_hmac()} - Generate a keyed hash value using the HMAC method</span></li>     <li class="member"><span class="function">{@link serialize()} - Generates a storable representation of a value</span></li>     <li class="member"><a href="https://www.php.net/manual/en/language.oop5.autoload.php" class="link">Autoloading Classes</a></li>     <li class="member"><a href="https://www.php.net/manual/en/var.configuration.php#ini.unserialize-callback-func" class="link">unserialize_callback_func</a></li>     <li class="member"><a href="https://www.php.net/manual/en/language.oop5.magic.php#object.wakeup" class="link">__wakeup()</a></li>    </ul>   </span>  </div>   </div>
*/
	public function unserialize($serialized)
	{}

	/**
	 * Whether a offset exists
	 * @link http://php.net/manual/en/arrayaccess.offsetexists.php
	 * @param mixed $offset <p>
	 * An offset to check for.
	 * </p>
	 * @return boolean true on success or false on failure.
	 * </p>
	 * <p>
	 * The return value will be casted to boolean if non-boolean was returned.
	 * @since 5.0.0
	 */
	public function offsetExists($offset)
	{}

	/**
	 * Offset to set
	 * @link http://php.net/manual/en/arrayaccess.offsetset.php
	 * @param mixed $offset <p>
	 * The offset to assign the value to.
	 * </p>
	 * @param mixed $value <p>
	 * The value to set.
	 * </p>
	 * @return void
	 * @since 5.0.0
	 */
	public function offsetSet($offset, $value)
	{}

	/**
	 * Offset to unset
	 * @link http://php.net/manual/en/arrayaccess.offsetunset.php
	 * @param mixed $offset <p>
	 * The offset to unset.
	 * </p>
	 * @return void
	 * @since 5.0.0
	 */
	public function offsetUnset($offset)
	{}
}

/**
 * @link http://php.net/manual/en/class.httprequest.php
 */
class HttpRequest  {
	const METH_GET = 1;
	const METH_HEAD = 2;
	const METH_POST = 3;
	const METH_PUT = 4;
	const METH_DELETE = 5;
	const METH_OPTIONS = 6;
	const METH_TRACE = 7;
	const METH_CONNECT = 8;
	const METH_PROPFIND = 9;
	const METH_PROPPATCH = 10;
	const METH_MKCOL = 11;
	const METH_COPY = 12;
	const METH_MOVE = 13;
	const METH_LOCK = 14;
	const METH_UNLOCK = 15;
	const METH_VERSION_CONTROL = 16;
	const METH_REPORT = 17;
	const METH_CHECKOUT = 18;
	const METH_CHECKIN = 19;
	const METH_UNCHECKOUT = 20;
	const METH_MKWORKSPACE = 21;
	const METH_UPDATE = 22;
	const METH_LABEL = 23;
	const METH_MERGE = 24;
	const METH_BASELINE_CONTROL = 25;
	const METH_MKACTIVITY = 26;
	const METH_ACL = 27;
	const VERSION_1_0 = 1;
	const VERSION_1_1 = 2;
	const VERSION_NONE = 0;
	const VERSION_ANY = 0;
	const SSL_VERSION_TLSv1 = 1;
	const SSL_VERSION_SSLv2 = 2;
	const SSL_VERSION_SSLv3 = 3;
	const SSL_VERSION_ANY = 0;
	const IPRESOLVE_V4 = 1;
	const IPRESOLVE_V6 = 2;
	const IPRESOLVE_ANY = 0;
	const AUTH_BASIC = 1;
	const AUTH_DIGEST = 2;
	const AUTH_NTLM = 8;
	const AUTH_GSSNEG = 4;
	const AUTH_ANY = -1;
	const PROXY_SOCKS4 = 4;
	const PROXY_SOCKS5 = 5;
	const PROXY_HTTP = 0;

	private $options;
	private $postFields;
	private $postFiles;
	private $responseInfo;
	private $responseMessage;
	private $responseCode;
	private $responseStatus;
	private $method;
	private $url;
	private $contentType;
	private $requestBody;
	private $queryData;
	private $putFile;
	private $putData;
	private $history;
	public $recordHistory;


	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * HttpRequest constructor
	 * @link http://php.net/manual/en/function.httprequest-construct.php
	 * @param string $url [optional] <p>
	 * the target request url
	 * </p>
	 * @param int $request_method [optional] <p>
	 * the request method to use
	 * </p>
	 * @param array $options [optional] <p>
	 * an associative array with request options
	 * </p>
	 * @return void 
	 */
	public function __construct ($url = null, $request_method = null, array $options = null ) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Set options
	 * @link http://php.net/manual/en/function.httprequest-setoptions.php
	 * @param array $options [optional] <p>
	 * an associative array, which values will overwrite the 
	 * currently set request options;
	 * if empty or omitted, the options of the HttpRequest object will be reset
	 * </p>
	 * @return bool true on success or false on failure.
	 */
	public function setOptions (array $options = null ) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Get options
	 * @link http://php.net/manual/en/function.httprequest-getoptions.php
	 * @return array an associative array containing currently set options.
	 */
	public function getOptions () {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Set ssl options
	 * @link http://php.net/manual/en/function.httprequest-setssloptions.php
	 * @param array $options [optional] <p>
	 * an associative array containing any SSL specific options;
	 * if empty or omitted, the SSL options will be reset
	 * </p>
	 * @return bool true on success or false on failure.
	 */
	public function setSslOptions (array $options = null ) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Get ssl options
	 * @link http://php.net/manual/en/function.httprequest-getssloptions.php
	 * @return array an associative array containing any previously set SSL options.
	 */
	public function getSslOptions () {}

	/**
	 * (PECL pecl_http &gt;= 0.12.0)<br/>
	 * Add ssl options
	 * @link http://php.net/manual/en/function.httprequest-addssloptions.php
	 * @param array $options <p>
	 * an associative array as parameter containing additional SSL specific options
	 * </p>
	 * @return bool true on success or false on failure.
	 */
	public function addSslOptions (sarray $option) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Add headers
	 * @link http://php.net/manual/en/function.httprequest-addheaders.php
	 * @param array $headers <p>
	 * an associative array as parameter containing additional header name/value pairs
	 * </p>
	 * @return bool true on success or false on failure.
	 */
	public function addHeaders (array $headers) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Get headers
	 * @link http://php.net/manual/en/function.httprequest-getheaders.php
	 * @return array an associative array containing all currently set headers.
	 */
	public function getHeaders () {}

	/**
	 * (PECL pecl_http &gt;= 0.12.0)<br/>
	 * Set headers
	 * @link http://php.net/manual/en/function.httprequest-setheaders.php
	 * @param array $headers [optional] <p>
	 * an associative array as parameter containing header name/value pairs;
	 * if empty or omitted, all previously set headers will be unset
	 * </p>
	 * @return bool true on success or false on failure.
	 */
	public function setHeaders ( array $headers = null ) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Add cookies
	 * @link http://php.net/manual/en/function.httprequest-addcookies.php
	 * @param array $cookies <p>
	 * an associative array containing any cookie name/value pairs to add
	 * </p>
	 * @return bool true on success or false on failure.
	 */
	public function addCookies (array $cookies) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Get cookies
	 * @link http://php.net/manual/en/function.httprequest-getcookies.php
	 * @return array an associative array containing any previously set cookies.
	 */
	public function getCookies () {}

	/**
	 * (PECL pecl_http &gt;= 0.12.0)<br/>
	 * Set cookies
	 * @link http://php.net/manual/en/function.httprequest-setcookies.php
	 * @param array $cookies [optional] <p>
	 * an associative array as parameter containing cookie name/value pairs;
	 * if empty or omitted, all previously set cookies will be unset
	 * </p>
	 * @return bool true on success or false on failure.
	 */
	public function setCookies ( array $cookies = null ) {}

	/**
	 * (PECL pecl_http &gt;= 1.0.0)<br/>
	 * Enable cookies
	 * @link http://php.net/manual/en/function.httprequest-enablecookies.php
	 * @return bool true on success or false on failure.
	 */
	public function enableCookies () {}

	/**
	 * (PECL pecl_http &gt;= 1.0.0)<br/>
	 * Reset cookies
	 * @link http://php.net/manual/en/function.httprequest-resetcookies.php
	 * @param bool $session_only [optional] <p>
	 * whether only session cookies should be reset (needs libcurl >= v7.15.4, else libcurl >= v7.14.1)
	 * </p>
	 * @return bool true on success or false on failure.
	 */
	public function resetCookies ($session_only = null) {}

	public function flushCookies () {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Set method
	 * @link http://php.net/manual/en/function.httprequest-setmethod.php
	 * @param int $request_method <p>
	 * the request method to use
	 * </p>
	 * @return bool true on success or false on failure.
	 */
	public function setMethod ($request_method) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Get method
	 * @link http://php.net/manual/en/function.httprequest-getmethod.php
	 * @return int the currently set request method.
	 */
	public function getMethod () {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Set URL
	 * @link http://php.net/manual/en/function.httprequest-seturl.php
	 * @param string $url <p>
	 * the request url
	 * </p>
	 * @return bool true on success or false on failure.
	 */
	public function setUrl ($url) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Get url
	 * @link http://php.net/manual/en/function.httprequest-geturl.php
	 * @return string the currently set request url as string.
	 */
	public function getUrl () {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Set content type
	 * @link http://php.net/manual/en/function.httprequest-setcontenttype.php
	 * @param string $content_type <p>
	 * the content type of the request (primary/secondary)
	 * </p>
	 * @return bool TRUE on success, or FALSE if the content type does not seem to
	 * contain a primary and a secondary part.
	 */
	public function setContentType ($content_type) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Get content type
	 * @link http://php.net/manual/en/function.httprequest-getcontenttype.php
	 * @return string the previously set content type as string.
	 */
	public function getContentType () {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Set query data
	 * @link http://php.net/manual/en/function.httprequest-setquerydata.php
	 * @param mixed $query_data <p>
	 * a string or associative array parameter containing the pre-encoded 
	 * query string or to be encoded query fields;
	 * if empty, the query data will be unset
	 * </p>
	 * @return bool true on success or false on failure.
	 */
	public function setQueryData ($query_data) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Get query data
	 * @link http://php.net/manual/en/function.httprequest-getquerydata.php
	 * @return string a string containing the urlencoded query.
	 */
	public function getQueryData () {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Add query data
	 * @link http://php.net/manual/en/function.httprequest-addquerydata.php
	 * @param array $query_params <p>
	 * an associative array as parameter containing the query fields to add
	 * </p>
	 * @return bool true on success or false on failure.
	 */
	public function addQueryData (array $query_params) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Set post fields
	 * @link http://php.net/manual/en/function.httprequest-setpostfields.php
	 * @param array $post_data <p>
	 * an associative array containing the post fields;
	 * if empty, the post data will be unset
	 * </p>
	 * @return bool true on success or false on failure.
	 */
	public function setPostFields (array $post_data) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Get post fields
	 * @link http://php.net/manual/en/function.httprequest-getpostfields.php
	 * @return array the currently set post fields as associative array.
	 */
	public function getPostFields () {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Add post fields
	 * @link http://php.net/manual/en/function.httprequest-addpostfields.php
	 * @param array $post_data <p>
	 * an associative array as parameter containing the post fields
	 * </p>
	 * @return bool true on success or false on failure.
	 */
	public function addPostFields (array $post_data) {}

	/**
	 * @param $request_body_data [optional]
	 */
	public function setBody ($request_body_data) {}

	public function getBody () {}

	/**
	 * @param $request_body_data
	 */
	public function addBody ($request_body_data) {}

	/**
	 * (PECL pecl_http 0.14.0-1.4.1)<br/>
	 * Set raw post data
	 * @link http://php.net/manual/en/function.httprequest-setrawpostdata.php
	 * @param string $raw_post_data [optional] <p>
	 * raw post data
	 * </p>
	 * @return bool true on success or false on failure.
	 */
	public function setRawPostData ($raw_post_data = null) {}

	/**
	 * (PECL pecl_http 0.14.0-1.4.1)<br/>
	 * Get raw post data
	 * @link http://php.net/manual/en/function.httprequest-getrawpostdata.php
	 * @return string a string containing the currently set raw post data.
	 */
	public function getRawPostData () {}

	/**
	 * (PECL pecl_http 0.14.0-1.4.1)<br/>
	 * Add raw post data
	 * @link http://php.net/manual/en/function.httprequest-addrawpostdata.php
	 * @param string $raw_post_data <p>
	 * the raw post data to concatenate
	 * </p>
	 * @return bool true on success or false on failure.
	 */
	public function addRawPostData ($raw_post_data) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Set post files
	 * @link http://php.net/manual/en/function.httprequest-setpostfiles.php
	 * @param array $post_files <p>
	 * an array containing the files to post;
	 * if empty, the post files will be unset
	 * </p>
	 * @return bool true on success or false on failure.
	 */
	public function setPostFiles (array $post_files) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Add post file
	 * @link http://php.net/manual/en/function.httprequest-addpostfile.php
	 * @param string $name <p>
	 * the form element name
	 * </p>
	 * @param string $file <p>
	 * the path to the file
	 * </p>
	 * @param string $content_type [optional] <p>
	 * the content type of the file
	 * </p>
	 * @return bool TRUE on success, or FALSE if the content type seems not to contain a 
	 * primary and a secondary content type part.
	 */
	public function addPostFile ($name, $file, $content_type = null) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Get post files
	 * @link http://php.net/manual/en/function.httprequest-getpostfiles.php
	 * @return array an array containing currently set post files.
	 */
	public function getPostFiles () {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Set put file
	 * @link http://php.net/manual/en/function.httprequest-setputfile.php
	 * @param string $file [optional] <p>
	 * the path to the file to send;
	 * if empty or omitted the put file will be unset
	 * </p>
	 * @return bool true on success or false on failure.
	 */
	public function setPutFile ($file = null) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Get put file
	 * @link http://php.net/manual/en/function.httprequest-getputfile.php
	 * @return string a string containing the path to the currently set put file.
	 */
	public function getPutFile () {}

	/**
	 * (PECL pecl_http &gt;= 0.25.0)<br/>
	 * Set put data
	 * @link http://php.net/manual/en/function.httprequest-setputdata.php
	 * @param string $put_data [optional] <p>
	 * the data to upload
	 * </p>
	 * @return bool true on success or false on failure.
	 */
	public function setPutData ($put_data = null) {}

	/**
	 * (PECL pecl_http &gt;= 0.25.0)<br/>
	 * Get put data
	 * @link http://php.net/manual/en/function.httprequest-getputdata.php
	 * @return string a string containing the currently set PUT data.
	 */
	public function getPutData () {}

	/**
	 * (PECL pecl_http &gt;= 0.25.0)<br/>
	 * Add put data
	 * @link http://php.net/manual/en/function.httprequest-addputdata.php
	 * @param string $put_data <p>
	 * the data to concatenate
	 * </p>
	 * @return bool true on success or false on failure.
	 */
	public function addPutData ($put_data) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Send request
	 * @link http://php.net/manual/en/function.httprequest-send.php
	 * @return HttpMessage the received response as HttpMessage object.
	 */
	public function send () {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Get response data
	 * @link http://php.net/manual/en/function.httprequest-getresponsedata.php
	 * @return array an associative array with the key "headers" containing an associative
	 * array holding all response headers, as well as the key "body" containing a
	 * string with the response body.
	 */
	public function getResponseData () {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Get response header(s)
	 * @link http://php.net/manual/en/function.httprequest-getresponseheader.php
	 * @param string $name [optional] <p>
	 * header to read; if empty, all response headers will be returned
	 * </p>
	 * @return mixed either a string with the value of the header matching name if requested, 
	 * FALSE on failure, or an associative array containing all response headers.
	 */
	public function getResponseHeader ($name = null) {}

	/**
	 * (PECL pecl_http &gt;= 0.23.0)<br/>
	 * Get response cookie(s)
	 * @link http://php.net/manual/en/function.httprequest-getresponsecookies.php
	 * @param int $flags [optional] <p>
	 * http_parse_cookie flags
	 * </p>
	 * @param array $allowed_extras [optional] <p>
	 * allowed keys treated as extra information instead of cookie names
	 * </p>
	 * @return stdClass[] an array of stdClass objects like http_parse_cookie would return.
	 */
	public function getResponseCookies ($flags = null,  array $allowed_extras = null ) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Get response code
	 * @link http://php.net/manual/en/function.httprequest-getresponsecode.php
	 * @return int an int representing the response code.
	 */
	public function getResponseCode () {}

	/**
	 * (PECL pecl_http &gt;= 0.23.0)<br/>
	 * Get response status
	 * @link http://php.net/manual/en/function.httprequest-getresponsestatus.php
	 * @return string a string containing the response status text.
	 */
	public function getResponseStatus () {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Get response body
	 * @link http://php.net/manual/en/function.httprequest-getresponsebody.php
	 * @return string a string containing the response body.
	 */
	public function getResponseBody () {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Get response info
	 * @link http://php.net/manual/en/function.httprequest-getresponseinfo.php
	 * @param string $name [optional] <p>
	 * the info to read; if empty or omitted, an associative array containing
	 * all available info will be returned
	 * </p>
	 * @return mixed either a scalar containing the value of the info matching name if
	 * requested, FALSE on failure, or an associative array containing all
	 * available info.
	 */
	public function getResponseInfo ($name = null) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Get response message
	 * @link http://php.net/manual/en/function.httprequest-getresponsemessage.php
	 * @return HttpMessage an HttpMessage object of the response.
	 */
	public function getResponseMessage () {}

	/**
	 * (PECL pecl_http &gt;= 0.21.0)<br/>
	 * Get raw response message
	 * @link http://php.net/manual/en/function.httprequest-getrawresponsemessage.php
	 * @return string the complete web server response, including the headers in a form of a string.
	 */
	public function getRawResponseMessage () {}

	/**
	 * (PECL pecl_http &gt;= 0.11.0)<br/>
	 * Get request message
	 * @link http://php.net/manual/en/function.httprequest-getrequestmessage.php
	 * @return HttpMessage an HttpMessage object representing the sent request.
	 */
	public function getRequestMessage () {}

	/**
	 * (PECL pecl_http &gt;= 0.21.0)<br/>
	 * Get raw request message
	 * @link http://php.net/manual/en/function.httprequest-getrawrequestmessage.php
	 * @return string an HttpMessage in a form of a string.
	 */
	public function getRawRequestMessage () {}

	/**
	 * (PECL pecl_http &gt;= 0.15.0)<br/>
	 * Get history
	 * @link http://php.net/manual/en/function.httprequest-gethistory.php
	 * @return HttpMessage an HttpMessage object representing the complete request/response history.
	 */
	public function getHistory () {}

	/**
	 * (PECL pecl_http &gt;= 0.15.0)<br/>
	 * Clear history
	 * @link http://php.net/manual/en/function.httprequest-clearhistory.php
	 * @return void 
	 */
	public function clearHistory () {}

	/**
	 * @param $url [optional]
	 * @param $method [optional]
	 * @param $options [optional]
	 * @param $class_name [optional]
	 */
	public static function factory ($url, $method, $options, $class_name) {}

	/**
	 * @param $url
	 * @param $options [optional]
	 * @param $info [optional]
	 */
	public static function get ($url, $options, &$info) {}

	/**
	 * @param $url
	 * @param $options [optional]
	 * @param $info [optional]
	 */
	public static function head ($url, $options, &$info) {}

	/**
	 * @param $url
	 * @param $data
	 * @param $options [optional]
	 * @param $info [optional]
	 */
	public static function postData ($url, $data, $options, &$info) {}

	/**
	 * @param $url
	 * @param $data
	 * @param $options [optional]
	 * @param $info [optional]
	 */
	public static function postFields ($url, $data, $options, &$info) {}

	/**
	 * @param $url
	 * @param $data
	 * @param $options [optional]
	 * @param $info [optional]
	 */
	public static function putData ($url, $data, $options, &$info) {}

	/**
	 * @param $url
	 * @param $file
	 * @param $options [optional]
	 * @param $info [optional]
	 */
	public static function putFile ($url, $file, $options, &$info) {}

	/**
	 * @param $url
	 * @param $stream
	 * @param $options [optional]
	 * @param $info [optional]
	 */
	public static function putStream ($url, $stream, $options, &$info) {}

	/**
	 * @param $method_name
	 */
	public static function methodRegister ($method_name) {}

	/**
	 * @param $method
	 */
	public static function methodUnregister ($method) {}

	/**
	 * @param $method_id
	 */
	public static function methodName ($method_id) {}

	/**
	 * @param $method
	 */
	public static function methodExists ($method) {}

	/**
	 * @param $fields
	 * @param $files
	 */
	public static function encodeBody ($fields, $files) {}

}

class HttpRequestDataShare implements Countable {
	private static $instance;
	public $cookie;
	public $dns;
	public $ssl;
	public $connect;


	public function __destruct () {}

/**
*<div id="function.count" class="refentry">  <div class="refnamediv">   <h1 class="refname">count</h1>   <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">count</span> &mdash; <span class="dc-title">Count all elements in an array, or something in an object</span></p>   </div>  <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.count-description">   <h3 class="title">Description</h3>   <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><strong>count</strong></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span> <span class="parameter" style="color:#2EACF9">$array_or_countable</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$mode</span><span class="initializer"> = COUNT_NORMAL</span></span>   ] ) : <span class="type" style="color:#EAB766">int</span></div>    <p class="para rdfs-comment">    Counts all elements in an array, or something in an object.   </p>   <p class="para">    For objects, if you have    <a href="https://www.php.net/manual/en/ref.spl.php" class="link">SPL</a> installed, you can hook into    <span class="function"><strong style="color:#CC7832">count()</strong></span> by implementing interface    <a href="https://www.php.net/manual/en/class.countable.php" class="classname">Countable</a>. The interface has exactly one method,    <span class="methodname" style="color:#CC7832">{@link Countable::count()}</span>, which returns the return value for the    <span class="function"><strong style="color:#CC7832">count()</strong></span> function.   </p>   <p class="para">    Please see the <a href="https://www.php.net/manual/en/language.types.array.php" class="link">Array</a>    section of the manual for a detailed explanation of how arrays    are implemented and used in PHP.   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.count-parameters">   <h3 class="title">Parameters</h3>   <span>    <dl>            <dt> <span class="parameter" style="color:#2EACF9">array_or_countable</span></dt>       <dd>        <p class="para">        An array or <a href="https://www.php.net/manual/en/class.countable.php" class="classname">Countable</a> object.       </p>      </dd>                 <dt> <span class="parameter" style="color:#2EACF9">mode</span></dt>       <dd>        <p class="para">        If the optional <span class="parameter" style="color:#2EACF9">mode</span> parameter is set to        <strong><span>COUNT_RECURSIVE</span></strong> (or 1), <span class="function"><strong style="color:#CC7832">count()</strong></span>        will recursively count the array.  This is particularly useful for        counting all the elements of a multidimensional array.       </p>       <div class="caution"><strong class="caution">Caution</strong>        <p class="para">         <span class="function"><strong style="color:#CC7832">count()</strong></span> can detect recursion to avoid an infinite         loop, but will emit an <strong><span>E_WARNING</span></strong> every time it         does (in case the array contains itself more than once) and return a         count higher than may be expected.        </p>       </div>      </dd>          </dl>    </span>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.count-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    Returns the number of elements in <span class="parameter" style="color:#2EACF9">array_or_countable</span>.    When the parameter is neither an array nor an object with    implemented <a href="https://www.php.net/manual/en/class.countable.php" class="classname">Countable</a> interface,    <em>1</em> will be returned.    There is one exception, if <span class="parameter" style="color:#2EACF9">array_or_countable</span> is <strong><span>NULL</span></strong>,    <em>0</em> will be returned.   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.count-examples">   <h3 class="title">Examples</h3>   <span>    <div class="example" id="example-6276">     <p><strong>Example #1 <span class="function"><strong style="color:#CC7832">count()</strong></span> example</strong></p>     <div class="example-contents"> <div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"> <span style="color: #9876AA">&lt;?php<br />$a</span><span style="color: #007700">[</span><span style="color: #9876AA">0</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #9876AA">1</span><span style="color: #007700">;<br /></span><span style="color: #9876AA">$a</span><span style="color: #007700">[</span><span style="color: #9876AA">1</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #9876AA">3</span><span style="color: #007700">;<br /></span><span style="color: #9876AA">$a</span><span style="color: #007700">[</span><span style="color: #9876AA">2</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #9876AA">5</span><span style="color: #007700">;<br /></span><span style="color: #9876AA">var_dump</span><span style="color: #007700">(</span><span style="color: #9876AA">count</span><span style="color: #007700">(</span><span style="color: #9876AA">$a</span><span style="color: #007700">));<br /><br /></span><span style="color: #9876AA">$b</span><span style="color: #007700">[</span><span style="color: #9876AA">0</span><span style="color: #007700">]&nbsp;&nbsp;=&nbsp;</span><span style="color: #9876AA">7</span><span style="color: #007700">;<br /></span><span style="color: #9876AA">$b</span><span style="color: #007700">[</span><span style="color: #9876AA">5</span><span style="color: #007700">]&nbsp;&nbsp;=&nbsp;</span><span style="color: #9876AA">9</span><span style="color: #007700">;<br /></span><span style="color: #9876AA">$b</span><span style="color: #007700">[</span><span style="color: #9876AA">10</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #9876AA">11</span><span style="color: #007700">;<br /></span><span style="color: #9876AA">var_dump</span><span style="color: #007700">(</span><span style="color: #9876AA">count</span><span style="color: #007700">(</span><span style="color: #9876AA">$b</span><span style="color: #007700">));<br /><br /></span><span style="color: #9876AA">var_dump</span><span style="color: #007700">(</span><span style="color: #9876AA">count</span><span style="color: #007700">(</span><span style="color: #9876AA">null</span><span style="color: #007700">));<br /><br /></span><span style="color: #9876AA">var_dump</span><span style="color: #007700">(</span><span style="color: #9876AA">count</span><span style="color: #007700">(</span><span style="color: #9876AA">false</span><span style="color: #007700">));<br /></span><span style="color: #9876AA">?&gt;</span> </span> </span></div>     </div>      <div class="example-contents"><p>The above example will output:</p></div>     <div class="example-contents screen" style="background:black;padding-left:5px;"> <div class="cdata"><span> int(3) int(3)  Warning: count(): Parameter must be an array or an object that implements Countable in … on line 12 // as of PHP 7.2 int(0)  Warning: count(): Parameter must be an array or an object that implements Countable in … on line 14 // as of PHP 7.2 int(1) </span></div>     </div>    </div>   </span>   <p class="para">    <div class="example" id="example-6277">     <p><strong>Example #2 Recursive <span class="function"><strong style="color:#CC7832">count()</strong></span> example</strong></p>     <div class="example-contents"> <div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"> <span style="color: #9876AA">&lt;?php<br />$food&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #DD0000">'fruits'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;array(</span><span style="color: #DD0000">'orange'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'banana'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'apple'</span><span style="color: #007700">),<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'veggie'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;array(</span><span style="color: #DD0000">'carrot'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'collard'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'pea'</span><span style="color: #007700">));<br /><br /></span><span style="color: #FF8000">//&nbsp;recursive&nbsp;count<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #9876AA">count</span><span style="color: #007700">(</span><span style="color: #9876AA">$food</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">COUNT_RECURSIVE</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;output&nbsp;8<br /><br />//&nbsp;normal&nbsp;count<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #9876AA">count</span><span style="color: #007700">(</span><span style="color: #9876AA">$food</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;output&nbsp;2<br /><br /></span><span style="color: #9876AA">?&gt;</span> </span> </span></div>     </div>     </div>   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 changelog" id="refsect1-function.count-changelog">   <h3 class="title">Changelog</h3>   <table class="doctable informaltable">         <thead>      <tr>       <th>Version</th>       <th>Description</th>      </tr>      </thead>      <tbody class="tbody">      <tr>       <td>7.2.0</td>       <td>        <span class="function"><strong style="color:#CC7832">count()</strong></span> will now yield a warning on invalid countable types         passed to the <span class="parameter" style="color:#2EACF9">array_or_countable</span> parameter.       </td>      </tr>      </tbody>       </table>   </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.count-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><span class="function">{@link is_array()} - Finds whether a variable is an array</span></li>     <li class="member"><span class="function">{@link isset()} - Determine if a variable is declared and is different than NULL</span></li>     <li class="member"><span class="function">{@link empty()} - Determine whether a variable is empty</span></li>     <li class="member"><span class="function">{@link strlen()} - Get string length</span></li>     <li class="member"><span class="function">{@link is_countable()} - Verify that the contents of a variable is a countable value</span></li>    </ul>   </span>  </div>  </div>
*/
	public function count () {}

	/**
	 * @param HttpRequest $request
	 */
	public function attach (HttpRequest $request) {}

	/**
	 * @param HttpRequest $request
	 */
	public function detach (HttpRequest $request) {}

/**
*<div id="function.reset" class="refentry">  <div class="refnamediv">   <h1 class="refname">reset</h1>   <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">reset</span> &mdash; <span class="dc-title">Set the internal pointer of an array to its first element</span></p>   </div>  <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.reset-description">   <h3 class="title">Description</h3>   <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><strong>reset</strong></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">array</span> <span class="parameter" style="color:#2EACF9">&$array</span></span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span></div>    <p class="para rdfs-comment">    <span class="function"><strong style="color:#CC7832">reset()</strong></span> rewinds <span class="parameter" style="color:#2EACF9">array</span>&#039;s internal    pointer to the first element and returns the value of the first array    element.   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.reset-parameters">   <h3 class="title">Parameters</h3>   <span>    <dl>            <dt> <span class="parameter" style="color:#2EACF9">array</span></dt>       <dd>        <p class="para">        The input array.       </p>      </dd>          </dl>    </span>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.reset-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    Returns the value of the first array element, or <strong><span>FALSE</span></strong> if the array is    empty.   </p>   <div class="warning"><strong class="warning">Warning</strong><p class="simpara">This function may return Boolean <strong><span>FALSE</span></strong>, but may also return a non-Boolean value which evaluates to <strong><span>FALSE</span></strong>. Please read the section on <a href="https://www.php.net/manual/en/language.types.boolean.php" class="link">Booleans</a> for more information. Use <a href="https://www.php.net/manual/en/language.operators.comparison.php" class="link">the === operator</a> for testing the return value of this function.</p></div>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.reset-examples">   <h3 class="title">Examples</h3>   <span>    <div class="example" id="example-6301">     <p><strong>Example #1 <span class="function"><strong style="color:#CC7832">reset()</strong></span> example</strong></p>     <div class="example-contents"> <div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"> <span style="color: #9876AA">&lt;?php<br /><br />$array&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #DD0000">'step&nbsp;one'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'step&nbsp;two'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'step&nbsp;three'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'step&nbsp;four'</span><span style="color: #007700">);<br /><br /></span><span style="color: #FF8000">//&nbsp;by&nbsp;default,&nbsp;the&nbsp;pointer&nbsp;is&nbsp;on&nbsp;the&nbsp;first&nbsp;element<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">)&nbsp;.&nbsp;</span><span style="color: #DD0000">"&lt;br&nbsp;/&gt;\n"</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;"step&nbsp;one"<br /><br />//&nbsp;skip&nbsp;two&nbsp;steps<br /></span><span style="color: #9876AA">next</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">);<br /></span><span style="color: #9876AA">next</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">);<br />echo&nbsp;</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">)&nbsp;.&nbsp;</span><span style="color: #DD0000">"&lt;br&nbsp;/&gt;\n"</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;"step&nbsp;three"<br /><br />//&nbsp;reset&nbsp;pointer,&nbsp;start&nbsp;again&nbsp;on&nbsp;step&nbsp;one<br /></span><span style="color: #9876AA">reset</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">);<br />echo&nbsp;</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">)&nbsp;.&nbsp;</span><span style="color: #DD0000">"&lt;br&nbsp;/&gt;\n"</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;"step&nbsp;one"<br /><br /></span><span style="color: #9876AA">?&gt;</span> </span> </span></div>     </div>     </div>   </span>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 notes" id="refsect1-function.reset-notes">   <h3 class="title">Notes</h3>   <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>:     <span class="simpara">     The return value for an empty array is indistinguishable from      the return value in case of an array which has a <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.boolean.php" class="type boolean" style="color:#EAB766">boolean</a></span> <strong><span>FALSE</span></strong>      first element. To properly check the value of the first element of an array     which may contain <strong><span>FALSE</span></strong> elements, first check the <span class="function">{@link count()}</span>     of the array, or check that <span class="function">{@link key()}</span> is not     <strong><span>NULL</span></strong>, after calling <span class="function"><strong style="color:#CC7832">reset()</strong></span>.    </span>   </p></blockquote>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.reset-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><span class="function">{@link current()} - Return the current element in an array</span></li>     <li class="member"><span class="function">{@link each()} - Return the current key and value pair from an array and advance the array cursor</span></li>     <li class="member"><span class="function">{@link end()} - Set the internal pointer of an array to its last element</span></li>     <li class="member"><span class="function">{@link next()} - Advance the internal pointer of an array</span></li>     <li class="member"><span class="function">{@link prev()} - Rewind the internal array pointer</span></li>     <li class="member"><span class="function">{@link array_key_first()} - Gets the first key of an array</span></li>    </ul>   </span>  </div>  </div>
*/
	public function reset () {}

	/**
	 * @param $global [optional]
	 * @param $class_name [optional]
	 */
	public static function factory ($global, $class_name) {}

	/**
	 * @param $global [optional]
	 */
	public static function singleton ($global) {}

}

/**
 * @link http://php.net/manual/en/class.httprequestpool.php
 */
class HttpRequestPool implements Countable, Iterator {

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * HttpRequestPool constructor
	 * @link http://php.net/manual/en/function.httprequestpool-construct.php
	 * @param HttpRequest $request [optional] <p>
	 * HttpRequest object to attach
	 * </p>
	 */
	public function __construct ( HttpRequest $request = null) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * HttpRequestPool destructor
	 * @link http://php.net/manual/en/function.httprequestpool-destruct.php
	 * @return void 
	 */
	public function __destruct () {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Attach HttpRequest
	 * @link http://php.net/manual/en/function.httprequestpool-attach.php
	 * @param HttpRequest $request <p>
	 * an HttpRequest object not already attached to any HttpRequestPool object
	 * </p>
	 * @return bool true on success or false on failure.
	 */
	public function attach ( HttpRequest $request) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Detach HttpRequest
	 * @link http://php.net/manual/en/function.httprequestpool-detach.php
	 * @param HttpRequest $request <p>
	 * an HttpRequest object attached to this HttpRequestPool object
	 * </p>
	 * @return bool true on success or false on failure.
	 */
	public function detach ( HttpRequest $request ) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Send all requests
	 * @link http://php.net/manual/en/function.httprequestpool-send.php
	 * @return bool true on success or false on failure.
	 */
	public function send () {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Reset request pool
	 * @link http://php.net/manual/en/function.httprequestpool-reset.php
	 * @return void 
	 */
/**
*<div id="function.reset" class="refentry">  <div class="refnamediv">   <h1 class="refname">reset</h1>   <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">reset</span> &mdash; <span class="dc-title">Set the internal pointer of an array to its first element</span></p>   </div>  <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.reset-description">   <h3 class="title">Description</h3>   <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><strong>reset</strong></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">array</span> <span class="parameter" style="color:#2EACF9">&$array</span></span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span></div>    <p class="para rdfs-comment">    <span class="function"><strong style="color:#CC7832">reset()</strong></span> rewinds <span class="parameter" style="color:#2EACF9">array</span>&#039;s internal    pointer to the first element and returns the value of the first array    element.   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.reset-parameters">   <h3 class="title">Parameters</h3>   <span>    <dl>            <dt> <span class="parameter" style="color:#2EACF9">array</span></dt>       <dd>        <p class="para">        The input array.       </p>      </dd>          </dl>    </span>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.reset-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    Returns the value of the first array element, or <strong><span>FALSE</span></strong> if the array is    empty.   </p>   <div class="warning"><strong class="warning">Warning</strong><p class="simpara">This function may return Boolean <strong><span>FALSE</span></strong>, but may also return a non-Boolean value which evaluates to <strong><span>FALSE</span></strong>. Please read the section on <a href="https://www.php.net/manual/en/language.types.boolean.php" class="link">Booleans</a> for more information. Use <a href="https://www.php.net/manual/en/language.operators.comparison.php" class="link">the === operator</a> for testing the return value of this function.</p></div>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.reset-examples">   <h3 class="title">Examples</h3>   <span>    <div class="example" id="example-6301">     <p><strong>Example #1 <span class="function"><strong style="color:#CC7832">reset()</strong></span> example</strong></p>     <div class="example-contents"> <div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"> <span style="color: #9876AA">&lt;?php<br /><br />$array&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #DD0000">'step&nbsp;one'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'step&nbsp;two'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'step&nbsp;three'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'step&nbsp;four'</span><span style="color: #007700">);<br /><br /></span><span style="color: #FF8000">//&nbsp;by&nbsp;default,&nbsp;the&nbsp;pointer&nbsp;is&nbsp;on&nbsp;the&nbsp;first&nbsp;element<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">)&nbsp;.&nbsp;</span><span style="color: #DD0000">"&lt;br&nbsp;/&gt;\n"</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;"step&nbsp;one"<br /><br />//&nbsp;skip&nbsp;two&nbsp;steps<br /></span><span style="color: #9876AA">next</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">);<br /></span><span style="color: #9876AA">next</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">);<br />echo&nbsp;</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">)&nbsp;.&nbsp;</span><span style="color: #DD0000">"&lt;br&nbsp;/&gt;\n"</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;"step&nbsp;three"<br /><br />//&nbsp;reset&nbsp;pointer,&nbsp;start&nbsp;again&nbsp;on&nbsp;step&nbsp;one<br /></span><span style="color: #9876AA">reset</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">);<br />echo&nbsp;</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">)&nbsp;.&nbsp;</span><span style="color: #DD0000">"&lt;br&nbsp;/&gt;\n"</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;"step&nbsp;one"<br /><br /></span><span style="color: #9876AA">?&gt;</span> </span> </span></div>     </div>     </div>   </span>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 notes" id="refsect1-function.reset-notes">   <h3 class="title">Notes</h3>   <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>:     <span class="simpara">     The return value for an empty array is indistinguishable from      the return value in case of an array which has a <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.boolean.php" class="type boolean" style="color:#EAB766">boolean</a></span> <strong><span>FALSE</span></strong>      first element. To properly check the value of the first element of an array     which may contain <strong><span>FALSE</span></strong> elements, first check the <span class="function">{@link count()}</span>     of the array, or check that <span class="function">{@link key()}</span> is not     <strong><span>NULL</span></strong>, after calling <span class="function"><strong style="color:#CC7832">reset()</strong></span>.    </span>   </p></blockquote>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.reset-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><span class="function">{@link current()} - Return the current element in an array</span></li>     <li class="member"><span class="function">{@link each()} - Return the current key and value pair from an array and advance the array cursor</span></li>     <li class="member"><span class="function">{@link end()} - Set the internal pointer of an array to its last element</span></li>     <li class="member"><span class="function">{@link next()} - Advance the internal pointer of an array</span></li>     <li class="member"><span class="function">{@link prev()} - Rewind the internal array pointer</span></li>     <li class="member"><span class="function">{@link array_key_first()} - Gets the first key of an array</span></li>    </ul>   </span>  </div>  </div>
*/
	public function reset () {}

	/**
	 * (PECL pecl_http &gt;= 0.15.0)<br/>
	 * Perform socket actions
	 * @link http://php.net/manual/en/function.httprequestpool-socketperform.php
	 * @return bool TRUE until each request has finished its transaction.
	 */
	protected function socketPerform () {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Perform socket select
	 * @link http://php.net/manual/en/function.httprequestpool-socketselect.php
	 * @return bool true on success or false on failure.
	 */
	protected function socketSelect () {}

	public function valid () {}

/**
*<div id="function.current" class="refentry">  <div class="refnamediv">   <h1 class="refname">current</h1>   <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">current</span> &mdash; <span class="dc-title">Return the current element in an array</span></p>   </div>  <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.current-description">   <h3 class="title">Description</h3>   <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><strong>current</strong></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">array</span> <span class="parameter" style="color:#2EACF9">$array</span></span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span></div>    <p class="para rdfs-comment">    Every array has an internal pointer to its &quot;current&quot; element,    which is initialized to the first element inserted into the    array.   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.current-parameters">   <h3 class="title">Parameters</h3>   <span>    <dl>            <dt> <span class="parameter" style="color:#2EACF9">array</span></dt>       <dd>        <p class="para">        The array.       </p>      </dd>          </dl>    </span>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.current-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    The <span class="function"><strong style="color:#CC7832">current()</strong></span> function simply returns the    value of the array element that&#039;s currently being pointed to by the    internal pointer.  It does not move the pointer in any way.  If the    internal pointer points beyond the end of the elements list or the array is     empty, <span class="function"><strong style="color:#CC7832">current()</strong></span> returns <strong><span>FALSE</span></strong>.   </p>   <div class="warning"><strong class="warning">Warning</strong><p class="simpara">This function may return Boolean <strong><span>FALSE</span></strong>, but may also return a non-Boolean value which evaluates to <strong><span>FALSE</span></strong>. Please read the section on <a href="https://www.php.net/manual/en/language.types.boolean.php" class="link">Booleans</a> for more information. Use <a href="https://www.php.net/manual/en/language.operators.comparison.php" class="link">the === operator</a> for testing the return value of this function.</p></div>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 changelog" id="refsect1-function.current-changelog">   <h3 class="title">Changelog</h3>   <span>    <table class="doctable informaltable">           <thead>       <tr>        <th>Version</th>        <th>Description</th>       </tr>       </thead>       <tbody class="tbody">       <tr>        <td>7.0.0</td>        <td>         <span class="parameter" style="color:#2EACF9">array</span> is now always passed by value.         Prior to this version, it was passed by reference if possible,         and by value otherwise.        </td>       </tr>       </tbody>         </table>    </span>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.current-examples">   <h3 class="title">Examples</h3>   <span>    <div class="example" id="example-6278">     <p><strong>Example #1 Example use of <span class="function"><strong style="color:#CC7832">current()</strong></span> and friends</strong></p>     <div class="example-contents"> <div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"> <span style="color: #9876AA">&lt;?php<br />$transport&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #DD0000">'foot'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'bike'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'car'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'plane'</span><span style="color: #007700">);<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'foot';<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">next</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'bike';<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'bike';<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">prev</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'foot';<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">end</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'plane';<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'plane';<br /><br /></span><span style="color: #9876AA">$arr&nbsp;</span><span style="color: #007700">=&nbsp;array();<br /></span><span style="color: #9876AA">var_dump</span><span style="color: #007700">(</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$arr</span><span style="color: #007700">));&nbsp;</span><span style="color: #FF8000">//&nbsp;bool(false)<br /><br /></span><span style="color: #9876AA">$arr&nbsp;</span><span style="color: #007700">=&nbsp;array(array());<br /></span><span style="color: #9876AA">var_dump</span><span style="color: #007700">(</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$arr</span><span style="color: #007700">));&nbsp;</span><span style="color: #FF8000">//&nbsp;array(0)&nbsp;{&nbsp;}<br /></span><span style="color: #9876AA">?&gt;</span> </span> </span></div>     </div>     </div>   </span>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 notes" id="refsect1-function.current-notes">   <h3 class="title">Notes</h3>   <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>:     <span class="simpara">     The end of an array and the result of calling      <span class="function"><strong style="color:#CC7832">current()</strong></span> on an empty array      are indistinguishable from a <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.boolean.php" class="type boolean" style="color:#EAB766">boolean</a></span> <strong><span>FALSE</span></strong> element.      To properly traverse an array which may contain <strong><span>FALSE</span></strong> elements, see the      <span class="function"><strong style="color:#CC7832">foreach()</strong></span> function.    </span>    <span class="simpara">     To still use <span class="function"><strong style="color:#CC7832">current()</strong></span> and properly check if the value      is really an element of the array, the <span class="function">{@link key()}</span>      of the <span class="function"><strong style="color:#CC7832">current()</strong></span> element should be checked to be strictly      different from <strong><span>NULL</span></strong>.    </span>   </p></blockquote>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.current-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><span class="function">{@link end()} - Set the internal pointer of an array to its last element</span></li>     <li class="member"><span class="function">{@link key()} - Fetch a key from an array</span></li>     <li class="member"><span class="function">{@link each()} - Return the current key and value pair from an array and advance the array cursor</span></li>     <li class="member"><span class="function">{@link prev()} - Rewind the internal array pointer</span></li>     <li class="member"><span class="function">{@link reset()} - Set the internal pointer of an array to its first element</span></li>     <li class="member"><span class="function">{@link next()} - Advance the internal pointer of an array</span></li>    </ul>   </span>  </div>  </div>
*/
	public function current () {}

/**
*<div id="function.key" class="refentry">  <div class="refnamediv">   <h1 class="refname">key</h1>   <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">key</span> &mdash; <span class="dc-title">Fetch a key from an array</span></p>   </div>  <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.key-description">   <h3 class="title">Description</h3>   <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><strong>key</strong></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">array</span> <span class="parameter" style="color:#2EACF9">$array</span></span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span></div>    <p class="para rdfs-comment">    <span class="function"><strong style="color:#CC7832">key()</strong></span> returns the index element of the current array    position.   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.key-parameters">   <h3 class="title">Parameters</h3>   <span>    <dl>            <dt> <span class="parameter" style="color:#2EACF9">array</span></dt>       <dd>        <p class="para">        The array.       </p>      </dd>          </dl>    </span>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.key-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    The <span class="function"><strong style="color:#CC7832">key()</strong></span> function simply returns the    key of the array element that&#039;s currently being pointed to by the    internal pointer.  It does not move the pointer in any way.  If the    internal pointer points beyond the end of the elements list or the array is     empty, <span class="function"><strong style="color:#CC7832">key()</strong></span> returns <strong><span>NULL</span></strong>.   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 changelog" id="refsect1-function.key-changelog">   <h3 class="title">Changelog</h3>   <span>    <table class="doctable informaltable">           <thead>       <tr>        <th>Version</th>        <th>Description</th>       </tr>       </thead>       <tbody class="tbody">       <tr>        <td>7.0.0</td>        <td>         <span class="parameter" style="color:#2EACF9">array</span> is now always passed by value.         Prior to this version, it was passed by reference if possible,         and by value otherwise.        </td>       </tr>       </tbody>         </table>    </span>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.key-examples">   <h3 class="title">Examples</h3>   <span>    <div class="example" id="example-6286">     <p><strong>Example #1 <span class="function"><strong style="color:#CC7832">key()</strong></span> example</strong></p>     <div class="example-contents"> <div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"> <span style="color: #9876AA">&lt;?php<br />$array&nbsp;</span><span style="color: #007700">=&nbsp;array(<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'fruit1'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">'apple'</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'fruit2'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">'orange'</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'fruit3'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">'grape'</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'fruit4'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">'apple'</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'fruit5'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">'apple'</span><span style="color: #007700">);<br /><br /></span><span style="color: #FF8000">//&nbsp;this&nbsp;cycle&nbsp;echoes&nbsp;all&nbsp;associative&nbsp;array<br />//&nbsp;key&nbsp;where&nbsp;value&nbsp;equals&nbsp;"apple"<br /></span><span style="color: #007700">while&nbsp;(</span><span style="color: #9876AA">$fruit_name&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">))&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(</span><span style="color: #9876AA">$fruit_name&nbsp;</span><span style="color: #007700">==&nbsp;</span><span style="color: #DD0000">'apple'</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #9876AA">key</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">).</span><span style="color: #DD0000">'&lt;br&nbsp;/&gt;'</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #9876AA">next</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">);<br />}<br /></span><span style="color: #9876AA">?&gt;</span> </span> </span></div>     </div>      <div class="example-contents"><p>The above example will output:</p></div>     <div class="example-contents screen" style="background:black;padding-left:5px;"> <div class="cdata"><span> fruit1&lt;br /&gt; fruit4&lt;br /&gt; fruit5&lt;br /&gt; </span></div>     </div>    </div>   </span>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.key-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><span class="function">{@link current()} - Return the current element in an array</span></li>     <li class="member"><span class="function">{@link next()} - Advance the internal pointer of an array</span></li>     <li class="member"><a href="https://www.php.net/manual/en/control-structures.foreach.php" class="link">foreach</a></li>    </ul>   </span>  </div>  </div>
*/
	public function key () {}

/**
*<div id="function.next" class="refentry">  <div class="refnamediv">   <h1 class="refname">next</h1>   <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">next</span> &mdash; <span class="dc-title">Advance the internal pointer of an array</span></p>   </div>  <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.next-description">   <h3 class="title">Description</h3>   <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><strong>next</strong></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">array</span> <span class="parameter" style="color:#2EACF9">&$array</span></span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span></div>    <p class="para rdfs-comment">    <span class="function"><strong style="color:#CC7832">next()</strong></span> behaves like    <span class="function">{@link current()}</span>, with one difference.  It advances    the internal array pointer one place forward before returning the    element value.  That means it returns the next array value and    advances the internal array pointer by one.   </p>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.next-parameters">   <h3 class="title">Parameters</h3>   <span>    <dl>            <dt> <span class="parameter" style="color:#2EACF9">array</span></dt>       <dd>        <p class="para">        The <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.array.php" class="type array" style="color:#EAB766">array</a></span> being affected.       </p>      </dd>          </dl>    </span>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.next-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    Returns the array value in the next place that&#039;s pointed to by the    internal array pointer, or <strong><span>FALSE</span></strong> if there are no more elements.   </p>   <div class="warning"><strong class="warning">Warning</strong><p class="simpara">This function may return Boolean <strong><span>FALSE</span></strong>, but may also return a non-Boolean value which evaluates to <strong><span>FALSE</span></strong>. Please read the section on <a href="https://www.php.net/manual/en/language.types.boolean.php" class="link">Booleans</a> for more information. Use <a href="https://www.php.net/manual/en/language.operators.comparison.php" class="link">the === operator</a> for testing the return value of this function.</p></div>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.next-examples">   <h3 class="title">Examples</h3>   <span>    <div class="example" id="example-6298">     <p><strong>Example #1 Example use of <span class="function"><strong style="color:#CC7832">next()</strong></span> and friends</strong></p>     <div class="example-contents"> <div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"> <span style="color: #9876AA">&lt;?php<br />$transport&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #DD0000">'foot'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'bike'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'car'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'plane'</span><span style="color: #007700">);<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'foot';<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">next</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'bike';<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">next</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'car';<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">prev</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'bike';<br /></span><span style="color: #9876AA">$mode&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">end</span><span style="color: #007700">(</span><span style="color: #9876AA">$transport</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$mode&nbsp;=&nbsp;'plane';<br /></span><span style="color: #9876AA">?&gt;</span> </span> </span></div>     </div>     </div>   </span>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 notes" id="refsect1-function.next-notes">   <h3 class="title">Notes</h3>   <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>:     <span class="simpara">     The end of an array is indistinguishable from a <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.boolean.php" class="type boolean" style="color:#EAB766">boolean</a></span> <strong><span>FALSE</span></strong> element.      To properly traverse an array which may contain <strong><span>FALSE</span></strong> elements, see the      <span class="function"><strong style="color:#CC7832">foreach()</strong></span> function.    </span>    <span class="simpara">     To still use <span class="function"><strong style="color:#CC7832">next()</strong></span> and properly check if the end of the array      has been reached, verify that the <span class="function">{@link key()}</span> is <strong><span>NULL</span></strong>.    </span>   </p></blockquote>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.next-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><span class="function">{@link current()} - Return the current element in an array</span></li>     <li class="member"><span class="function">{@link end()} - Set the internal pointer of an array to its last element</span></li>     <li class="member"><span class="function">{@link prev()} - Rewind the internal array pointer</span></li>     <li class="member"><span class="function">{@link reset()} - Set the internal pointer of an array to its first element</span></li>     <li class="member"><span class="function">{@link each()} - Return the current key and value pair from an array and advance the array cursor</span></li>    </ul>   </span>  </div>  </div>
*/
	public function next () {}

/**
*<div id="function.rewind" class="refentry">  <div class="refnamediv">   <h1 class="refname">rewind</h1>   <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">rewind</span> &mdash; <span class="dc-title">Rewind the position of a file pointer</span></p>   </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.rewind-description">   <h3 class="title">Description</h3>   <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><strong>rewind</strong></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">resource</span> <span class="parameter" style="color:#2EACF9">$handle</span></span>    ) : <span class="type" style="color:#EAB766">bool</span></div>    <p class="para rdfs-comment">    Sets the file position indicator for <span class="parameter" style="color:#2EACF9">handle</span>    to the beginning of the file stream.   </p>   <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>:     <p class="para">     If you have opened the file in append (&quot;a&quot; or &quot;a+&quot;) mode, any data you     write to the file will always be appended, regardless of the file pointer position.    </p>   </p></blockquote>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.rewind-parameters">   <h3 class="title">Parameters</h3>   <span>    <dl>            <dt> <span class="parameter" style="color:#2EACF9">handle</span></dt>       <dd>        <p class="para">        The file pointer must be valid, and must point to a file        successfully opened by <span class="function">{@link fopen()}</span>.       </p>      </dd>          </dl>    </span>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.rewind-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    Returns <strong><span>TRUE</span></strong> on success or <strong><span>FALSE</span></strong> on failure.   </p>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.rewind-examples">   <h3 class="title">Examples</h3>   <span>    <div class="example" id="example-2953">     <p><strong>Example #1 <span class="function"><strong style="color:#CC7832">rewind()</strong></span> overwriting example</strong></p>     <div class="example-contents"> <div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"> <span style="color: #9876AA">&lt;?php<br />$handle&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">fopen</span><span style="color: #007700">(</span><span style="color: #DD0000">'output.txt'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'r+'</span><span style="color: #007700">);<br /><br /></span><span style="color: #9876AA">fwrite</span><span style="color: #007700">(</span><span style="color: #9876AA">$handle</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'Really&nbsp;long&nbsp;sentence.'</span><span style="color: #007700">);<br /></span><span style="color: #9876AA">rewind</span><span style="color: #007700">(</span><span style="color: #9876AA">$handle</span><span style="color: #007700">);<br /></span><span style="color: #9876AA">fwrite</span><span style="color: #007700">(</span><span style="color: #9876AA">$handle</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'Foo'</span><span style="color: #007700">);<br /></span><span style="color: #9876AA">rewind</span><span style="color: #007700">(</span><span style="color: #9876AA">$handle</span><span style="color: #007700">);<br /><br />echo&nbsp;</span><span style="color: #9876AA">fread</span><span style="color: #007700">(</span><span style="color: #9876AA">$handle</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">filesize</span><span style="color: #007700">(</span><span style="color: #DD0000">'output.txt'</span><span style="color: #007700">));<br /><br /></span><span style="color: #9876AA">fclose</span><span style="color: #007700">(</span><span style="color: #9876AA">$handle</span><span style="color: #007700">);<br /></span><span style="color: #9876AA">?&gt;</span> </span> </span></div>     </div>      <div class="example-contents"><p>The above example will output something similar to:</p></div>     <div class="example-contents screen" style="background:black;padding-left:5px;"> <div class="cdata"><span> Foolly long sentence. </span></div>     </div>    </div>   </span>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.rewind-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><span class="function">{@link fread()} - Binary-safe file read</span></li>     <li class="member"><span class="function">{@link fseek()} - Seeks on a file pointer</span></li>     <li class="member"><span class="function">{@link ftell()} - Returns the current position of the file read/write pointer</span></li>     <li class="member"><span class="function">{@link fwrite()} - Binary-safe file write</span></li>    </ul>   </span>  </div>   </div>
*/
	public function rewind () {}

/**
*<div id="function.count" class="refentry">  <div class="refnamediv">   <h1 class="refname">count</h1>   <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">count</span> &mdash; <span class="dc-title">Count all elements in an array, or something in an object</span></p>   </div>  <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.count-description">   <h3 class="title">Description</h3>   <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><strong>count</strong></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span> <span class="parameter" style="color:#2EACF9">$array_or_countable</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$mode</span><span class="initializer"> = COUNT_NORMAL</span></span>   ] ) : <span class="type" style="color:#EAB766">int</span></div>    <p class="para rdfs-comment">    Counts all elements in an array, or something in an object.   </p>   <p class="para">    For objects, if you have    <a href="https://www.php.net/manual/en/ref.spl.php" class="link">SPL</a> installed, you can hook into    <span class="function"><strong style="color:#CC7832">count()</strong></span> by implementing interface    <a href="https://www.php.net/manual/en/class.countable.php" class="classname">Countable</a>. The interface has exactly one method,    <span class="methodname" style="color:#CC7832">{@link Countable::count()}</span>, which returns the return value for the    <span class="function"><strong style="color:#CC7832">count()</strong></span> function.   </p>   <p class="para">    Please see the <a href="https://www.php.net/manual/en/language.types.array.php" class="link">Array</a>    section of the manual for a detailed explanation of how arrays    are implemented and used in PHP.   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.count-parameters">   <h3 class="title">Parameters</h3>   <span>    <dl>            <dt> <span class="parameter" style="color:#2EACF9">array_or_countable</span></dt>       <dd>        <p class="para">        An array or <a href="https://www.php.net/manual/en/class.countable.php" class="classname">Countable</a> object.       </p>      </dd>                 <dt> <span class="parameter" style="color:#2EACF9">mode</span></dt>       <dd>        <p class="para">        If the optional <span class="parameter" style="color:#2EACF9">mode</span> parameter is set to        <strong><span>COUNT_RECURSIVE</span></strong> (or 1), <span class="function"><strong style="color:#CC7832">count()</strong></span>        will recursively count the array.  This is particularly useful for        counting all the elements of a multidimensional array.       </p>       <div class="caution"><strong class="caution">Caution</strong>        <p class="para">         <span class="function"><strong style="color:#CC7832">count()</strong></span> can detect recursion to avoid an infinite         loop, but will emit an <strong><span>E_WARNING</span></strong> every time it         does (in case the array contains itself more than once) and return a         count higher than may be expected.        </p>       </div>      </dd>          </dl>    </span>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.count-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    Returns the number of elements in <span class="parameter" style="color:#2EACF9">array_or_countable</span>.    When the parameter is neither an array nor an object with    implemented <a href="https://www.php.net/manual/en/class.countable.php" class="classname">Countable</a> interface,    <em>1</em> will be returned.    There is one exception, if <span class="parameter" style="color:#2EACF9">array_or_countable</span> is <strong><span>NULL</span></strong>,    <em>0</em> will be returned.   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.count-examples">   <h3 class="title">Examples</h3>   <span>    <div class="example" id="example-6276">     <p><strong>Example #1 <span class="function"><strong style="color:#CC7832">count()</strong></span> example</strong></p>     <div class="example-contents"> <div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"> <span style="color: #9876AA">&lt;?php<br />$a</span><span style="color: #007700">[</span><span style="color: #9876AA">0</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #9876AA">1</span><span style="color: #007700">;<br /></span><span style="color: #9876AA">$a</span><span style="color: #007700">[</span><span style="color: #9876AA">1</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #9876AA">3</span><span style="color: #007700">;<br /></span><span style="color: #9876AA">$a</span><span style="color: #007700">[</span><span style="color: #9876AA">2</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #9876AA">5</span><span style="color: #007700">;<br /></span><span style="color: #9876AA">var_dump</span><span style="color: #007700">(</span><span style="color: #9876AA">count</span><span style="color: #007700">(</span><span style="color: #9876AA">$a</span><span style="color: #007700">));<br /><br /></span><span style="color: #9876AA">$b</span><span style="color: #007700">[</span><span style="color: #9876AA">0</span><span style="color: #007700">]&nbsp;&nbsp;=&nbsp;</span><span style="color: #9876AA">7</span><span style="color: #007700">;<br /></span><span style="color: #9876AA">$b</span><span style="color: #007700">[</span><span style="color: #9876AA">5</span><span style="color: #007700">]&nbsp;&nbsp;=&nbsp;</span><span style="color: #9876AA">9</span><span style="color: #007700">;<br /></span><span style="color: #9876AA">$b</span><span style="color: #007700">[</span><span style="color: #9876AA">10</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #9876AA">11</span><span style="color: #007700">;<br /></span><span style="color: #9876AA">var_dump</span><span style="color: #007700">(</span><span style="color: #9876AA">count</span><span style="color: #007700">(</span><span style="color: #9876AA">$b</span><span style="color: #007700">));<br /><br /></span><span style="color: #9876AA">var_dump</span><span style="color: #007700">(</span><span style="color: #9876AA">count</span><span style="color: #007700">(</span><span style="color: #9876AA">null</span><span style="color: #007700">));<br /><br /></span><span style="color: #9876AA">var_dump</span><span style="color: #007700">(</span><span style="color: #9876AA">count</span><span style="color: #007700">(</span><span style="color: #9876AA">false</span><span style="color: #007700">));<br /></span><span style="color: #9876AA">?&gt;</span> </span> </span></div>     </div>      <div class="example-contents"><p>The above example will output:</p></div>     <div class="example-contents screen" style="background:black;padding-left:5px;"> <div class="cdata"><span> int(3) int(3)  Warning: count(): Parameter must be an array or an object that implements Countable in … on line 12 // as of PHP 7.2 int(0)  Warning: count(): Parameter must be an array or an object that implements Countable in … on line 14 // as of PHP 7.2 int(1) </span></div>     </div>    </div>   </span>   <p class="para">    <div class="example" id="example-6277">     <p><strong>Example #2 Recursive <span class="function"><strong style="color:#CC7832">count()</strong></span> example</strong></p>     <div class="example-contents"> <div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"> <span style="color: #9876AA">&lt;?php<br />$food&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #DD0000">'fruits'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;array(</span><span style="color: #DD0000">'orange'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'banana'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'apple'</span><span style="color: #007700">),<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'veggie'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;array(</span><span style="color: #DD0000">'carrot'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'collard'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'pea'</span><span style="color: #007700">));<br /><br /></span><span style="color: #FF8000">//&nbsp;recursive&nbsp;count<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #9876AA">count</span><span style="color: #007700">(</span><span style="color: #9876AA">$food</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">COUNT_RECURSIVE</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;output&nbsp;8<br /><br />//&nbsp;normal&nbsp;count<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #9876AA">count</span><span style="color: #007700">(</span><span style="color: #9876AA">$food</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;output&nbsp;2<br /><br /></span><span style="color: #9876AA">?&gt;</span> </span> </span></div>     </div>     </div>   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 changelog" id="refsect1-function.count-changelog">   <h3 class="title">Changelog</h3>   <table class="doctable informaltable">         <thead>      <tr>       <th>Version</th>       <th>Description</th>      </tr>      </thead>      <tbody class="tbody">      <tr>       <td>7.2.0</td>       <td>        <span class="function"><strong style="color:#CC7832">count()</strong></span> will now yield a warning on invalid countable types         passed to the <span class="parameter" style="color:#2EACF9">array_or_countable</span> parameter.       </td>      </tr>      </tbody>       </table>   </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.count-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><span class="function">{@link is_array()} - Finds whether a variable is an array</span></li>     <li class="member"><span class="function">{@link isset()} - Determine if a variable is declared and is different than NULL</span></li>     <li class="member"><span class="function">{@link empty()} - Determine whether a variable is empty</span></li>     <li class="member"><span class="function">{@link strlen()} - Get string length</span></li>     <li class="member"><span class="function">{@link is_countable()} - Verify that the contents of a variable is a countable value</span></li>    </ul>   </span>  </div>  </div>
*/
	public function count () {}

	/**
	 * (PECL pecl_http &gt;= 0.16.0)<br/>
	 * Get attached requests
	 * @link http://php.net/manual/en/function.httprequestpool-getattachedrequests.php
	 * @return array an array containing all currently attached HttpRequest objects.
	 */
	public function getAttachedRequests () {}

	/**
	 * (PECL pecl_http &gt;= 0.16.0)<br/>
	 * Get finished requests
	 * @link http://php.net/manual/en/function.httprequestpool-getfinishedrequests.php
	 * @return array an array containing all attached HttpRequest objects that already have finished their work.
	 */
	public function getFinishedRequests () {}

	/**
	 * @param $enable [optional]
	 */
	public function enablePipelining ($enable) {}

	/**
	 * @param $enable [optional]
	 */
	public function enableEvents ($enable) {}

}

/**
 * @link http://php.net/manual/en/class.httpresponse.php
 */
class HttpResponse  {
	const REDIRECT = 0;
	const REDIRECT_PERM = 301;
	const REDIRECT_FOUND = 302;
	const REDIRECT_POST = 303;
	const REDIRECT_PROXY = 305;
	const REDIRECT_TEMP = 307;

	private static $sent;
	private static $catch;
	private static $mode;
	private static $stream;
	private static $file;
	private static $data;
	protected static $cache;
	protected static $gzip;
	protected static $eTag;
	protected static $lastModified;
	protected static $cacheControl;
	protected static $contentType;
	protected static $contentDisposition;
	protected static $bufferSize;
	protected static $throttleDelay;


	/**
	 * (PECL pecl_http &gt;= 0.12.0)<br/>
	 * Set header
	 * @link http://php.net/manual/en/function.httpresponse-setheader.php
	 * @param string $name <p>
	 * the name of the header
	 * </p>
	 * @param mixed $value [optional] <p>
	 * the value of the header;
	 * if not set, no header with this name will be sent
	 * </p>
	 * @param bool $replace [optional] <p>
	 * whether an existing header should be replaced
	 * </p>
	 * @return bool true on success or false on failure.
	 */
	public static function setHeader ($name, $value = null, $replace = null) {}

	/**
	 * (PECL pecl_http &gt;= 0.12.0)<br/>
	 * Get header
	 * @link http://php.net/manual/en/function.httpresponse-getheader.php
	 * @param string $name [optional] <p>
	 * specifies the name of the header to read;
	 * if empty or omitted, an associative array with all headers will be returned
	 * </p>
	 * @return mixed either a string containing the value of the header matching name,
	 * false on failure, or an associative array with all headers.
	 */
	public static function getHeader ($name = null) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Set ETag
	 * @link http://php.net/manual/en/function.httpresponse-setetag.php
	 * @param string $etag <p>
	 * unquoted string as parameter containing the ETag
	 * </p>
	 * @return bool true on success or false on failure.
	 */
	public static function setETag ($etag) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Get ETag
	 * @link http://php.net/manual/en/function.httpresponse-getetag.php
	 * @return string the calculated or previously set ETag as unquoted string.
	 */
	public static function getETag () {}

	/**
	 * (PECL pecl_http &gt;= 0.12.0)<br/>
	 * Set last modified
	 * @link http://php.net/manual/en/function.httpresponse-setlastmodified.php
	 * @param int $timestamp <p>
	 * Unix timestamp representing the last modification time of the sent entity
	 * </p>
	 * @return bool true on success or false on failure.
	 */
	public static function setLastModified ($timestamp) {}

	/**
	 * (PECL pecl_http &gt;= 0.12.0)<br/>
	 * Get last modified
	 * @link http://php.net/manual/en/function.httpresponse-getlastmodified.php
	 * @return int the calculated or previously set Unix timestamp.
	 */
	public static function getLastModified () {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Set content disposition
	 * @link http://php.net/manual/en/function.httpresponse-setcontentdisposition.php
	 * @param string $filename <p>
	 * the file name the &quot;Save as...&quot; dialog should display
	 * </p>
	 * @param bool $inline [optional] <p>
	 * if set to true and the user agent knows how to handle the content type,
	 * it will probably not cause the popup window to be shown
	 * </p>
	 * @return bool true on success or false on failure.
	 */
	public static function setContentDisposition ($filename, $inline = null) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Get content disposition
	 * @link http://php.net/manual/en/function.httpresponse-getcontentdisposition.php
	 * @return string the current content disposition as string like sent in a header.
	 */
	public static function getContentDisposition () {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Set content type
	 * @link http://php.net/manual/en/function.httpresponse-setcontenttype.php
	 * @param string $content_type <p>
	 * the content type of the sent entity (primary/secondary)
	 * </p>
	 * @return bool true on success, or false if the content type does not seem to
	 * contain a primary and secondary content type part.
	 */
	public static function setContentType ($content_type) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Get content type
	 * @link http://php.net/manual/en/function.httpresponse-getcontenttype.php
	 * @return string the currently set content type as string.
	 */
	public static function getContentType () {}

	/**
	 * (PECL pecl_http &gt;= 0.13.0)<br/>
	 * Guess content type
	 * @link http://php.net/manual/en/function.httpresponse-guesscontenttype.php
	 * @param string $magic_file <p>
	 * specifies the magic.mime database to use
	 * </p>
	 * @param int $magic_mode [optional] <p>
	 * flags for libmagic
	 * </p>
	 * @return string the guessed content type on success or false on failure.
	 */
	public static function guessContentType ($magic_file, $magic_mode = null) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Set cache
	 * @link http://php.net/manual/en/function.httpresponse-setcache.php
	 * @param bool $cache <p>
	 * whether caching should be attempted
	 * </p>
	 * @return bool true on success or false on failure.
	 */
	public static function setCache ($cache) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Get cache
	 * @link http://php.net/manual/en/function.httpresponse-getcache.php
	 * @return bool true if caching should be attempted, else false.
	 */
	public static function getCache () {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Set cache control
	 * @link http://php.net/manual/en/function.httpresponse-setcachecontrol.php
	 * @param string $control <p>
	 * the primary cache control setting
	 * </p>
	 * @param int $max_age [optional] <p>
	 * the max-age in seconds, suggesting how long the cache entry is valid on the client side
	 * </p>
	 * @param bool $must_revalidate [optional] <p>
	 * whether the cached entity should be revalidated by the client for every request
	 * </p>
	 * @return bool true on success, or false if control does not match one of public, private or no-cache.
	 */
	public static function setCacheControl ($control, $max_age = null, $must_revalidate = null) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Get cache control
	 * @link http://php.net/manual/en/function.httpresponse-getcachecontrol.php
	 * @return string the current cache control setting as a string like sent in a header.
	 */
	public static function getCacheControl () {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Set gzip
	 * @link http://php.net/manual/en/function.httpresponse-setgzip.php
	 * @param bool $gzip <p>
	 * whether GZip compression should be enabled
	 * </p>
	 * @return bool true on success or false on failure.
	 */
	public static function setGzip ($gzip) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Get gzip
	 * @link http://php.net/manual/en/function.httpresponse-getgzip.php
	 * @return bool true if GZip compression is enabled, else false.
	 */
	public static function getGzip () {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Set throttle delay
	 * @link http://php.net/manual/en/function.httpresponse-setthrottledelay.php
	 * @param float $seconds <p>
	 * seconds to sleep after each chunk sent
	 * </p>
	 * @return bool true on success or false on failure.
	 */
	public static function setThrottleDelay ($seconds) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Get throttle delay
	 * @link http://php.net/manual/en/function.httpresponse-getthrottledelay.php
	 * @return double a double representing the throttle delay in seconds.
	 */
	public static function getThrottleDelay () {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Set buffer size
	 * @link http://php.net/manual/en/function.httpresponse-setbuffersize.php
	 * @param int $bytes <p>
	 * the chunk size in bytes
	 * </p>
	 * @return bool true on success or false on failure.
	 */
	public static function setBufferSize ($bytes) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Get buffer size
	 * @link http://php.net/manual/en/function.httpresponse-getbuffersize.php
	 * @return int an int representing the current buffer size in bytes.
	 */
	public static function getBufferSize () {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Set data
	 * @link http://php.net/manual/en/function.httpresponse-setdata.php
	 * @param mixed $data <p>
	 * data to send
	 * </p>
	 * @return bool true on success or false on failure.
	 */
	public static function setData ($data) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Get data
	 * @link http://php.net/manual/en/function.httpresponse-getdata.php
	 * @return string a string containing the previously set data to send.
	 */
	public static function getData () {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Set file
	 * @link http://php.net/manual/en/function.httpresponse-setfile.php
	 * @param string $file <p>
	 * the path to the file to send
	 * </p>
	 * @return bool true on success or false on failure.
	 */
	public static function setFile ($file) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Get file
	 * @link http://php.net/manual/en/function.httpresponse-getfile.php
	 * @return string the previously set path to the file to send as string.
	 */
	public static function getFile () {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Set stream
	 * @link http://php.net/manual/en/function.httpresponse-setstream.php
	 * @param resource $stream <p>
	 * already opened stream from which the data to send will be read
	 * </p>
	 * @return bool true on success or false on failure.
	 */
	public static function setStream ($stream) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Get Stream
	 * @link http://php.net/manual/en/function.httpresponse-getstream.php
	 * @return resource the previously set resource.
	 */
	public static function getStream () {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Send response
	 * @link http://php.net/manual/en/function.httpresponse-send.php
	 * @param bool $clean_ob [optional] <p>
	 * whether to destroy all previously started output handlers and their buffers
	 * </p>
	 * @return bool true on success or false on failure.
	 */
	public static function send ($clean_ob = null) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Capture script output
	 * @link http://php.net/manual/en/function.httpresponse-capture.php
	 * @return void 
	 */
	public static function capture () {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Redirect
	 * @link http://php.net/manual/en/function.httpresponse-redirect.php
	 * @param string $url [optional] 
	 * @param array $params [optional] 
	 * @param bool $session [optional] 
	 * @param int $status [optional] 
	 * @return void 
	 */
	public static function redirect ($url = null,  array $params = null , $session = null, $status = null) {}

	/**
	 * (PECL pecl_http &gt;= 0.12.0)<br/>
	 * Send HTTP response status
	 * @link http://php.net/manual/en/function.httpresponse-status.php
	 * @param int $status 
	 * @return bool 
	 */
	public static function status ($status) {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Get request headers
	 * @link http://php.net/manual/en/function.httpresponse-getrequestheaders.php
	 * @return array 
	 */
	public static function getRequestHeaders () {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Get request body
	 * @link http://php.net/manual/en/function.httpresponse-getrequestbody.php
	 * @return string 
	 */
	public static function getRequestBody () {}

	/**
	 * (PECL pecl_http &gt;= 0.10.0)<br/>
	 * Get request body stream
	 * @link http://php.net/manual/en/function.httpresponse-getrequestbodystream.php
	 * @return resource 
	 */
	public static function getRequestBodyStream () {}

}

class HttpUtil  {

	/**
	 * @param $timestamp [optional]
	 */
/**
*<div id="function.date" class="refentry">  <div class="refnamediv">   <h1 class="refname">date</h1>   <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">date</span> &mdash; <span class="dc-title">Format a local time/date</span></p>   </div>     <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.date-description">   <h3 class="title">Description</h3>   <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><strong>date</strong></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$format</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$timestamp</span><span class="initializer"> = time()</span></span>   ] ) : <span class="type" style="color:#EAB766">string</span></div>    <p class="para rdfs-comment">    Returns a string formatted according to the given format string using the    given integer <span class="parameter" style="color:#2EACF9">timestamp</span> or the current time    if no timestamp is given.  In other words, <span class="parameter" style="color:#2EACF9">timestamp</span>    is optional and defaults to the value of <span class="function">{@link time()}</span>.   </p>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.date-parameters">   <h3 class="title">Parameters</h3>   <span>    <dl>            <dt> <span class="parameter" style="color:#2EACF9">format</span></dt>       <dd>        <p class="para">        The format of the outputted date <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.string.php" class="type string" style="color:#EAB766">string</a></span>. See the formatting        options below. There are also several        <a href="https://www.php.net/manual/en/class.datetimeinterface.php#datetime.constants.types" class="link">predefined date constants</a>        that may be used instead, so for example <strong><span>DATE_RSS</span></strong>        contains the format string <em>&#039;D, d M Y H:i:s&#039;</em>.       </p>       <p class="para">        <table class="doctable table">         <caption><strong>The following characters are recognized in the         <span class="parameter" style="color:#2EACF9">format</span> parameter string</strong></caption>                   <thead>           <tr>            <th><span class="parameter" style="color:#2EACF9">format</span> character</th>            <th>Description</th>            <th>Example returned values</th>           </tr>           </thead>           <tbody class="tbody">           <tr>            <td style="text-align: center;"><em class="emphasis">Day</em></td>            <td>---</td>            <td>---</td>           </tr>            <tr>            <td><em>d</em></td>            <td>Day of the month, 2 digits with leading zeros</td>            <td><em>01</em> to <em>31</em></td>           </tr>            <tr>            <td><em>D</em></td>            <td>A textual representation of a day, three letters</td>            <td><em>Mon</em> through <em>Sun</em></td>           </tr>            <tr>            <td><em>j</em></td>            <td>Day of the month without leading zeros</td>            <td><em>1</em> to <em>31</em></td>           </tr>            <tr>            <td><em>l</em> (lowercase &#039;L&#039;)</td>            <td>A full textual representation of the day of the week</td>            <td><em>Sunday</em> through <em>Saturday</em></td>           </tr>            <tr>            <td><em>N</em></td>            <td>ISO-8601 numeric representation of the day of the week (added in            PHP 5.1.0)</td>            <td><em>1</em> (for Monday) through <em>7</em> (for Sunday)</td>           </tr>            <tr>            <td><em>S</em></td>            <td>English ordinal suffix for the day of the month, 2 characters</td>            <td>             <em>st</em>, <em>nd</em>, <em>rd</em> or             <em>th</em>.  Works well with <em>j</em>            </td>           </tr>            <tr>            <td><em>w</em></td>            <td>Numeric representation of the day of the week</td>            <td><em>0</em> (for Sunday) through <em>6</em> (for Saturday)</td>           </tr>            <tr>            <td><em>z</em></td>            <td>The day of the year (starting from 0)</td>            <td><em>0</em> through <em>365</em></td>           </tr>            <tr>            <td style="text-align: center;"><em class="emphasis">Week</em></td>            <td>---</td>            <td>---</td>           </tr>            <tr>            <td><em>W</em></td>            <td>ISO-8601 week number of year, weeks starting on Monday</td>            <td>Example: <em>42</em> (the 42nd week in the year)</td>           </tr>            <tr>            <td style="text-align: center;"><em class="emphasis">Month</em></td>            <td>---</td>            <td>---</td>           </tr>            <tr>            <td><em>F</em></td>            <td>A full textual representation of a month, such as January or March</td>            <td><em>January</em> through <em>December</em></td>           </tr>            <tr>            <td><em>m</em></td>            <td>Numeric representation of a month, with leading zeros</td>            <td><em>01</em> through <em>12</em></td>           </tr>            <tr>            <td><em>M</em></td>            <td>A short textual representation of a month, three letters</td>            <td><em>Jan</em> through <em>Dec</em></td>           </tr>            <tr>            <td><em>n</em></td>            <td>Numeric representation of a month, without leading zeros</td>            <td><em>1</em> through <em>12</em></td>           </tr>            <tr>            <td><em>t</em></td>            <td>Number of days in the given month</td>            <td><em>28</em> through <em>31</em></td>           </tr>            <tr>            <td style="text-align: center;"><em class="emphasis">Year</em></td>            <td>---</td>            <td>---</td>           </tr>            <tr>            <td><em>L</em></td>            <td>Whether it&#039;s a leap year</td>            <td><em>1</em> if it is a leap year, <em>0</em> otherwise.</td>           </tr>            <tr>            <td><em>o</em></td>            <td>ISO-8601 week-numbering year. This has the same value as             <em>Y</em>, except that if the ISO week number             (<em>W</em>) belongs to the previous or next year, that year             is used instead. (added in PHP 5.1.0)</td>            <td>Examples: <em>1999</em> or <em>2003</em></td>           </tr>            <tr>            <td><em>Y</em></td>            <td>A full numeric representation of a year, 4 digits</td>            <td>Examples: <em>1999</em> or <em>2003</em></td>           </tr>            <tr>            <td><em>y</em></td>            <td>A two digit representation of a year</td>            <td>Examples: <em>99</em> or <em>03</em></td>           </tr>            <tr>            <td style="text-align: center;"><em class="emphasis">Time</em></td>            <td>---</td>            <td>---</td>           </tr>            <tr>            <td><em>a</em></td>            <td>Lowercase Ante meridiem and Post meridiem</td>            <td><em>am</em> or <em>pm</em></td>           </tr>            <tr>            <td><em>A</em></td>            <td>Uppercase Ante meridiem and Post meridiem</td>            <td><em>AM</em> or <em>PM</em></td>           </tr>            <tr>            <td><em>B</em></td>            <td>Swatch Internet time</td>            <td><em>000</em> through <em>999</em></td>           </tr>            <tr>            <td><em>g</em></td>            <td>12-hour format of an hour without leading zeros</td>            <td><em>1</em> through <em>12</em></td>           </tr>            <tr>            <td><em>G</em></td>            <td>24-hour format of an hour without leading zeros</td>            <td><em>0</em> through <em>23</em></td>           </tr>            <tr>            <td><em>h</em></td>            <td>12-hour format of an hour with leading zeros</td>            <td><em>01</em> through <em>12</em></td>           </tr>            <tr>            <td><em>H</em></td>            <td>24-hour format of an hour with leading zeros</td>            <td><em>00</em> through <em>23</em></td>           </tr>            <tr>            <td><em>i</em></td>            <td>Minutes with leading zeros</td>            <td><em>00</em> to <em>59</em></td>           </tr>            <tr>            <td><em>s</em></td>            <td>Seconds with leading zeros</td>            <td><em>00</em> through <em>59</em></td>           </tr>            <tr>            <td><em>u</em></td>            <td>             Microseconds (added in PHP 5.2.2). Note that             <span class="function"><strong style="color:#CC7832">date()</strong></span> will always generate             <em>000000</em> since it takes an <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.integer.php" class="type integer" style="color:#EAB766">integer</a></span>             parameter, whereas <span class="methodname" style="color:#CC7832">{@link DateTime::format()}</span> does             support microseconds if <a href="https://www.php.net/manual/en/class.datetime.php" class="classname">DateTime</a> was             created with microseconds.            </td>            <td>Example: <em>654321</em></td>           </tr>            <tr>            <td><em>v</em></td>            <td>             Milliseconds (added in PHP 7.0.0). Same note applies as for             <em>u</em>.            </td>            <td>Example: <em>654</em></td>           </tr>            <tr>            <td style="text-align: center;"><em class="emphasis">Timezone</em></td>            <td>---</td>            <td>---</td>           </tr>            <tr>            <td><em>e</em></td>            <td>Timezone identifier (added in PHP 5.1.0)</td>            <td>Examples: <em>UTC</em>, <em>GMT</em>, <em>Atlantic/Azores</em></td>           </tr>            <tr>            <td><em>I</em> (capital i)</td>            <td>Whether or not the date is in daylight saving time</td>            <td><em>1</em> if Daylight Saving Time, <em>0</em> otherwise.</td>           </tr>            <tr>            <td><em>O</em></td>            <td>Difference to Greenwich time (GMT) without colon between hours and minutes</td>            <td>Example: <em>+0200</em></td>           </tr>            <tr>            <td><em>P</em></td>            <td>Difference to Greenwich time (GMT) with colon between hours and minutes (added in PHP 5.1.3)</td>            <td>Example: <em>+02:00</em></td>           </tr>            <tr>            <td><em>T</em></td>            <td>Timezone abbreviation</td>            <td>Examples: <em>EST</em>, <em>MDT</em> ...</td>           </tr>            <tr>            <td><em>Z</em></td>            <td>Timezone offset in seconds. The offset for timezones west of UTC is always            negative, and for those east of UTC is always positive.</td>            <td><em>-43200</em> through <em>50400</em></td>           </tr>            <tr>            <td style="text-align: center;"><em class="emphasis">Full Date/Time</em></td>            <td>---</td>            <td>---</td>           </tr>            <tr>            <td><em>c</em></td>            <td>ISO 8601 date (added in PHP 5)</td>            <td>2004-02-12T15:19:21+00:00</td>           </tr>            <tr>            <td><em>r</em></td>            <td><a href="http://www.faqs.org/rfcs/rfc2822" class="link external">&raquo;&nbsp;RFC 2822</a> formatted date</td>            <td>Example: <em>Thu, 21 Dec 2000 16:01:07 +0200</em></td>           </tr>            <tr>            <td><em>U</em></td>            <td>Seconds since the Unix Epoch (January 1 1970 00:00:00 GMT)</td>            <td>See also <span class="function">{@link time()}</span></td>           </tr>           </tbody>                 </table>        </p>       <p class="para">        Unrecognized characters in the format string will be printed        as-is.  The <em>Z</em> format will always return        <em>0</em> when using <span class="function">{@link gmdate()}</span>.       </p>              <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>:         <p class="para">         Since this function only accepts <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.integer.php" class="type integer" style="color:#EAB766">integer</a></span> timestamps the         <em>u</em> format character is only useful when using the         <span class="function">{@link date_format()}</span> function with user based timestamps         created with <span class="function">{@link date_create()}</span>.        </p>       </p></blockquote>      </dd>                 <dt> <span class="parameter" style="color:#2EACF9">timestamp</span></dt> <dd> <p class="para"> The optional <span class="parameter" style="color:#2EACF9">timestamp</span> parameter is an <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.integer.php" class="type integer" style="color:#EAB766">integer</a></span> Unix timestamp that defaults to the current local time if a <span class="parameter" style="color:#2EACF9">timestamp</span> is not given. In other words, it defaults to the value of <span class="function">{@link time()}</span>. </p></dd>         </dl>    </span>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.date-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    Returns a formatted date string. If a non-numeric value is used for     <span class="parameter" style="color:#2EACF9">timestamp</span>, <strong><span>FALSE</span></strong> is returned and an     <strong><span>E_WARNING</span></strong> level error is emitted.   </p>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 errors" id="refsect1-function.date-errors">   <h3 class="title">Errors/Exceptions</h3>        <p class="para"> Every call to a date/time function will generate a <strong><span>E_NOTICE</span></strong> if the time zone is not valid, and/or a <strong><span>E_STRICT</span></strong> or <strong><span>E_WARNING</span></strong> message if using the system settings or the <var class="varname"><var class="varname">TZ</var></var> environment variable. See also <span class="function">{@link date_default_timezone_set()}</span></p>    </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 changelog" id="refsect1-function.date-changelog">   <h3 class="title">Changelog</h3>   <span>    <table class="doctable informaltable">           <thead>       <tr>        <th>Version</th>        <th>Description</th>       </tr>       </thead>       <tbody class="tbody">       <tr>        <td>5.1.1</td>        <td>         There are useful <a href="https://www.php.net/manual/en/datetime.constants.php" class="link">constants</a>          of standard date/time formats that can be used to specify the          <span class="parameter" style="color:#2EACF9">format</span> parameter.        </td>       </tr>        <tr>        <td>5.1.0</td>        <td>         The valid range of a timestamp is typically from Fri, 13 Dec         1901 20:45:54 GMT to Tue, 19 Jan 2038 03:14:07 GMT. (These are         the dates that correspond to the minimum and maximum values for         a 32-bit signed integer). However, before PHP 5.1.0 this range was limited         from 01-01-1970 to 19-01-2038 on some systems (e.g. Windows).        </td>       </tr>               <tr><td>5.1.0</td><td><p class="para"> Now issues the <strong><span>E_STRICT</span></strong> and <strong><span>E_NOTICE</span></strong> time zone errors.</p></td></tr>       </tbody>         </table>    </span>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.date-examples">   <h3 class="title">Examples</h3>   <span>    <div class="example" id="example-2824">     <p><strong>Example #1 <span class="function"><strong style="color:#CC7832">date()</strong></span> examples</strong></p>     <div class="example-contents"> <div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"> <span style="color: #9876AA">&lt;?php<br /></span><span style="color: #FF8000">//&nbsp;set&nbsp;the&nbsp;default&nbsp;timezone&nbsp;to&nbsp;use.&nbsp;Available&nbsp;since&nbsp;PHP&nbsp;5.1<br /></span><span style="color: #9876AA">date_default_timezone_set</span><span style="color: #007700">(</span><span style="color: #DD0000">'UTC'</span><span style="color: #007700">);<br /><br /><br /></span><span style="color: #FF8000">//&nbsp;Prints&nbsp;something&nbsp;like:&nbsp;Monday<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #9876AA">date</span><span style="color: #007700">(</span><span style="color: #DD0000">"l"</span><span style="color: #007700">);<br /><br /></span><span style="color: #FF8000">//&nbsp;Prints&nbsp;something&nbsp;like:&nbsp;Monday&nbsp;8th&nbsp;of&nbsp;August&nbsp;2005&nbsp;03:12:46&nbsp;PM<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #9876AA">date</span><span style="color: #007700">(</span><span style="color: #DD0000">'l&nbsp;jS&nbsp;\of&nbsp;F&nbsp;Y&nbsp;h:i:s&nbsp;A'</span><span style="color: #007700">);<br /><br /></span><span style="color: #FF8000">//&nbsp;Prints:&nbsp;July&nbsp;1,&nbsp;2000&nbsp;is&nbsp;on&nbsp;a&nbsp;Saturday<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">"July&nbsp;1,&nbsp;2000&nbsp;is&nbsp;on&nbsp;a&nbsp;"&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #9876AA">date</span><span style="color: #007700">(</span><span style="color: #DD0000">"l"</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">mktime</span><span style="color: #007700">(</span><span style="color: #9876AA">0</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">0</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">0</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">7</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">2000</span><span style="color: #007700">));<br /><br /></span><span style="color: #FF8000">//&nbsp;use&nbsp;the&nbsp;constants&nbsp;in&nbsp;the&nbsp;format&nbsp;parameter&nbsp;<br />//&nbsp;prints&nbsp;something&nbsp;like:&nbsp;Wed,&nbsp;25&nbsp;Sep&nbsp;2013&nbsp;15:28:57&nbsp;-0700<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #9876AA">date</span><span style="color: #007700">(</span><span style="color: #9876AA">DATE_RFC2822</span><span style="color: #007700">);<br /><br /></span><span style="color: #FF8000">//&nbsp;prints&nbsp;something&nbsp;like:&nbsp;2000-07-01T00:00:00+00:00<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #9876AA">date</span><span style="color: #007700">(</span><span style="color: #9876AA">DATE_ATOM</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">mktime</span><span style="color: #007700">(</span><span style="color: #9876AA">0</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">0</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">0</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">7</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">2000</span><span style="color: #007700">));<br /></span><span style="color: #9876AA">?&gt;</span> </span> </span></div>     </div>     </div>   </span>   <p class="para">    You can prevent a recognized character in the format string from being    expanded by escaping it with a preceding backslash. If the character with    a backslash is already a special sequence, you may need to also escape    the backslash.    <div class="example" id="example-2825">     <p><strong>Example #2 Escaping characters in <span class="function"><strong style="color:#CC7832">date()</strong></span></strong></p>     <div class="example-contents"> <div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"> <span style="color: #9876AA">&lt;?php<br /></span><span style="color: #FF8000">//&nbsp;prints&nbsp;something&nbsp;like:&nbsp;Wednesday&nbsp;the&nbsp;15th<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #9876AA">date</span><span style="color: #007700">(</span><span style="color: #DD0000">'l&nbsp;\t\h\e&nbsp;jS'</span><span style="color: #007700">);<br /></span><span style="color: #9876AA">?&gt;</span> </span> </span></div>     </div>     </div>   </p>   <p class="para">    It is possible to use <span class="function"><strong style="color:#CC7832">date()</strong></span> and    <span class="function">{@link mktime()}</span> together to find dates in the future    or the past.    <div class="example" id="example-2826">     <p><strong>Example #3 <span class="function"><strong style="color:#CC7832">date()</strong></span> and <span class="function">{@link mktime()}</span> example</strong></p>     <div class="example-contents"> <div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"> <span style="color: #9876AA">&lt;?php<br />$tomorrow&nbsp;&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">mktime</span><span style="color: #007700">(</span><span style="color: #9876AA">0</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">0</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">0</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">date</span><span style="color: #007700">(</span><span style="color: #DD0000">"m"</span><span style="color: #007700">)&nbsp;&nbsp;,&nbsp;</span><span style="color: #9876AA">date</span><span style="color: #007700">(</span><span style="color: #DD0000">"d"</span><span style="color: #007700">)+</span><span style="color: #9876AA">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">date</span><span style="color: #007700">(</span><span style="color: #DD0000">"Y"</span><span style="color: #007700">));<br /></span><span style="color: #9876AA">$lastmonth&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">mktime</span><span style="color: #007700">(</span><span style="color: #9876AA">0</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">0</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">0</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">date</span><span style="color: #007700">(</span><span style="color: #DD0000">"m"</span><span style="color: #007700">)-</span><span style="color: #9876AA">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">date</span><span style="color: #007700">(</span><span style="color: #DD0000">"d"</span><span style="color: #007700">),&nbsp;&nbsp;&nbsp;</span><span style="color: #9876AA">date</span><span style="color: #007700">(</span><span style="color: #DD0000">"Y"</span><span style="color: #007700">));<br /></span><span style="color: #9876AA">$nextyear&nbsp;&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">mktime</span><span style="color: #007700">(</span><span style="color: #9876AA">0</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">0</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">0</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">date</span><span style="color: #007700">(</span><span style="color: #DD0000">"m"</span><span style="color: #007700">),&nbsp;&nbsp;&nbsp;</span><span style="color: #9876AA">date</span><span style="color: #007700">(</span><span style="color: #DD0000">"d"</span><span style="color: #007700">),&nbsp;&nbsp;&nbsp;</span><span style="color: #9876AA">date</span><span style="color: #007700">(</span><span style="color: #DD0000">"Y"</span><span style="color: #007700">)+</span><span style="color: #9876AA">1</span><span style="color: #007700">);<br /></span><span style="color: #9876AA">?&gt;</span> </span> </span></div>     </div>     </div>    <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>:      <p class="para">      This can be more reliable than simply adding or subtracting the number      of seconds in a day or month to a timestamp because of daylight saving      time.     </p>    </p></blockquote>   </p>   <p class="para">    Some examples of <span class="function"><strong style="color:#CC7832">date()</strong></span> formatting. Note that    you should escape any other characters, as any which currently    have a special meaning will produce undesirable results, and    other characters may be assigned meaning in future PHP versions.    When escaping, be sure to use single quotes to prevent characters    like \n from becoming newlines.    <div class="example" id="example-2827">     <p><strong>Example #4 <span class="function"><strong style="color:#CC7832">date()</strong></span> Formatting</strong></p>     <div class="example-contents"> <div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"> <span style="color: #9876AA">&lt;?php<br /></span><span style="color: #FF8000">//&nbsp;Assuming&nbsp;today&nbsp;is&nbsp;March&nbsp;10th,&nbsp;2001,&nbsp;5:16:18&nbsp;pm,&nbsp;and&nbsp;that&nbsp;we&nbsp;are&nbsp;in&nbsp;the<br />//&nbsp;Mountain&nbsp;Standard&nbsp;Time&nbsp;(MST)&nbsp;Time&nbsp;Zone<br /><br /></span><span style="color: #9876AA">$today&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">date</span><span style="color: #007700">(</span><span style="color: #DD0000">"F&nbsp;j,&nbsp;Y,&nbsp;g:i&nbsp;a"</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;March&nbsp;10,&nbsp;2001,&nbsp;5:16&nbsp;pm<br /></span><span style="color: #9876AA">$today&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">date</span><span style="color: #007700">(</span><span style="color: #DD0000">"m.d.y"</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;03.10.01<br /></span><span style="color: #9876AA">$today&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">date</span><span style="color: #007700">(</span><span style="color: #DD0000">"j,&nbsp;n,&nbsp;Y"</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;10,&nbsp;3,&nbsp;2001<br /></span><span style="color: #9876AA">$today&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">date</span><span style="color: #007700">(</span><span style="color: #DD0000">"Ymd"</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;20010310<br /></span><span style="color: #9876AA">$today&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">date</span><span style="color: #007700">(</span><span style="color: #DD0000">'h-i-s,&nbsp;j-m-y,&nbsp;it&nbsp;is&nbsp;w&nbsp;Day'</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;05-16-18,&nbsp;10-03-01,&nbsp;1631&nbsp;1618&nbsp;6&nbsp;Satpm01<br /></span><span style="color: #9876AA">$today&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">date</span><span style="color: #007700">(</span><span style="color: #DD0000">'\i\t&nbsp;\i\s&nbsp;\t\h\e&nbsp;jS&nbsp;\d\a\y.'</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;it&nbsp;is&nbsp;the&nbsp;10th&nbsp;day.<br /></span><span style="color: #9876AA">$today&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">date</span><span style="color: #007700">(</span><span style="color: #DD0000">"D&nbsp;M&nbsp;j&nbsp;G:i:s&nbsp;T&nbsp;Y"</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;Sat&nbsp;Mar&nbsp;10&nbsp;17:16:18&nbsp;MST&nbsp;2001<br /></span><span style="color: #9876AA">$today&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">date</span><span style="color: #007700">(</span><span style="color: #DD0000">'H:m:s&nbsp;\m&nbsp;\i\s\&nbsp;\m\o\n\t\h'</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;17:03:18&nbsp;m&nbsp;is&nbsp;month<br /></span><span style="color: #9876AA">$today&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">date</span><span style="color: #007700">(</span><span style="color: #DD0000">"H:i:s"</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;17:16:18<br /></span><span style="color: #9876AA">$today&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">date</span><span style="color: #007700">(</span><span style="color: #DD0000">"Y-m-d&nbsp;H:i:s"</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;2001-03-10&nbsp;17:16:18&nbsp;(the&nbsp;MySQL&nbsp;DATETIME&nbsp;format)<br /></span><span style="color: #9876AA">?&gt;</span> </span> </span></div>     </div>     </div>   </p>   <p class="para">    To format dates in other languages, you should use the    <span class="function">{@link setlocale()}</span> and <span class="function">{@link strftime()}</span>    functions instead of <span class="function"><strong style="color:#CC7832">date()</strong></span>.   </p>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 notes" id="refsect1-function.date-notes">   <h3 class="title">Notes</h3>   <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>:     <p class="para">     To generate a timestamp from a string representation of the date, you     may be able to use <span class="function">{@link strtotime()}</span>. Additionally, some     databases have functions to convert their date formats into timestamps     (such as MySQL&#039;s <a href="http://dev.mysql.com/doc/mysql/en/date-and-time-functions.html" class="link external">&raquo;&nbsp;UNIX_TIMESTAMP</a>     function).    </p>   </p></blockquote>   <div class="tip"><strong class="tip">Tip</strong>    <p class="para">     Timestamp of the start of the request is available in     <var class="varname"><var class="varname"><a href="https://www.php.net/manual/en/reserved.variables.server.php" class="classname">$_SERVER['REQUEST_TIME']</a></var></var> since PHP 5.1.    </p>   </div>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.date-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><span class="function">{@link gmdate()} - Format a GMT/UTC date/time</span></li>     <li class="member"><span class="function">{@link idate()} - Format a local time/date as integer</span></li>     <li class="member"><span class="function">{@link getdate()} - Get date/time information</span></li>     <li class="member"><span class="function">{@link getlastmod()} - Gets time of last page modification</span></li>     <li class="member"><span class="function">{@link mktime()} - Get Unix timestamp for a date</span></li>     <li class="member"><span class="function">{@link strftime()} - Format a local time/date according to locale settings</span></li>     <li class="member"><span class="function">{@link time()} - Return current Unix timestamp</span></li>     <li class="member"><span class="function">{@link strtotime()} - Parse about any English textual datetime description into a Unix timestamp</span></li>     <li class="member"><a href="https://www.php.net/manual/en/class.datetimeinterface.php#datetime.constants.types" class="link">Predefined DateTime Constants</a></li>    </ul>   </span>  </div>  </div>
*/
	public static function date ($timestamp) {}

	/**
	 * @param $url
	 * @param $parts [optional]
	 * @param $flags [optional]
	 * @param $composed [optional]
	 */
	public static function buildUrl ($url, $parts, $flags, &$composed) {}

	/**
	 * @param $query
	 * @param $prefix [optional]
	 * @param $arg_sep [optional]
	 */
	public static function buildStr ($query, $prefix, $arg_sep) {}

	/**
	 * @param $supported
	 * @param $result [optional]
	 */
	public static function negotiateLanguage ($supported, &$result) {}

	/**
	 * @param $supported
	 * @param $result [optional]
	 */
	public static function negotiateCharset ($supported, &$result) {}

	/**
	 * @param $supported
	 * @param $result [optional]
	 */
	public static function negotiateContentType ($supported, &$result) {}

	/**
	 * @param $last_modified
	 * @param $for_range [optional]
	 */
	public static function matchModified ($last_modified, $for_range) {}

	/**
	 * @param $plain_etag
	 * @param $for_range [optional]
	 */
	public static function matchEtag ($plain_etag, $for_range) {}

	/**
	 * @param $header_name
	 * @param $header_value
	 * @param $case_sensitive [optional]
	 */
	public static function matchRequestHeader ($header_name, $header_value, $case_sensitive) {}

	/**
	 * @param $message_string
	 */
	public static function parseMessage ($message_string) {}

	/**
	 * @param $headers_string
	 */
	public static function parseHeaders ($headers_string) {}

	/**
	 * @param $cookie_string
	 */
	public static function parseCookie ($cookie_string) {}

	/**
	 * @param $cookie_array
	 */
	public static function buildCookie ($cookie_array) {}

	/**
	 * @param $param_string
	 * @param $flags [optional]
	 */
	public static function parseParams ($param_string, $flags) {}

	/**
	 * @param $encoded_string
	 */
	public static function chunkedDecode ($encoded_string) {}

	/**
	 * @param $plain
	 * @param $flags [optional]
	 */
	public static function deflate ($plain, $flags) {}

	/**
	 * @param $encoded
	 */
	public static function inflate ($encoded) {}

	/**
	 * @param $feature [optional]
	 */
	public static function support ($feature) {}

}

/**
 * (PECL pecl_http &gt;= 0.1.0)<br/>
 * Compose HTTP RFC compliant date
 * @link http://php.net/manual/en/function.http-date.php
 * @param int $timestamp [optional] <p>
 * Unix timestamp; current time if omitted
 * </p>
 * @return string the HTTP date as string.
 */
function http_date ($timestamp = null) {}

/**
 * (PECL pecl_http &gt;= 0.21.0)<br/>
 * Build an URL
 * @link http://php.net/manual/en/function.http-build-url.php
 * @param mixed $url [optional] <p>
 * (part(s) of) an URL in form of a string or associative array like parse_url returns
 * </p>
 * @param mixed $parts [optional] <p>
 * same as the first argument
 * </p>
 * @param int $flags [optional] <p>
 * a bitmask of binary or'ed HTTP_URL constants;
 * HTTP_URL_REPLACE is the default
 * </p>
 * @param array $new_url [optional] <p>
 * if set, it will be filled with the parts of the composed url like parse_url would return
 * </p>
 * @return string the new URL as string on success or false on failure.
 */
function http_build_url ($url = null, $parts = null, $flags = null,  array &$new_url = null ) {}

/**
 * (PECL pecl_http &gt;= 0.23.0)<br/>
 * Build query string
 * @link http://php.net/manual/en/function.http-build-str.php
 * @param array $query <p>
 * associative array of query string parameters
 * </p>
 * @param string $prefix [optional] <p>
 * top level prefix
 * </p>
 * @param string $arg_separator [optional] <p>
 * argument separator to use (by default the INI setting arg_separator.output will be used, or &quot;&amp;&quot; if neither is set
 * </p>
 * @return string the built query as string on success or false on failure.
 */
function http_build_str (array $query, $prefix = null, $arg_separator = null) {}

/**
 * (PECL pecl_http &gt;= 0.1.0)<br/>
 * Negotiate clients preferred language
 * @link http://php.net/manual/en/function.http-negotiate-language.php
 * @param array $supported <p>
 * array containing the supported languages as values
 * </p>
 * @param array $result [optional] <p>
 * will be filled with an array containing the negotiation results
 * </p>
 * @return string the negotiated language or the default language (i.e. first array entry) if none match.
 */
function http_negotiate_language (array $supported,  array &$result = null ) {}

/**
 * (PECL pecl_http &gt;= 0.1.0)<br/>
 * Negotiate clients preferred character set
 * @link http://php.net/manual/en/function.http-negotiate-charset.php
 * @param array $supported <p>
 * array containing the supported charsets as values
 * </p>
 * @param array $result [optional] <p>
 * will be filled with an array containing the negotiation results
 * </p>
 * @return string the negotiated charset or the default charset (i.e. first array entry) if none match.
 */
function http_negotiate_charset (array $supported,  array &$result = null ) {}

/**
 * (PECL pecl_http &gt;= 0.19.0)<br/>
 * Negotiate clients preferred content type
 * @link http://php.net/manual/en/function.http-negotiate-content-type.php
 * @param array $supported <p>
 * array containing the supported content types as values
 * </p>
 * @param array $result [optional] <p>
 * will be filled with an array containing the negotiation results
 * </p>
 * @return string the negotiated content type or the default content type (i.e. first array entry) if none match.
 */
function http_negotiate_content_type (array $supported,  array &$result = null ) {}

/**
 * (PECL pecl_http &gt;= 0.1.0)<br/>
 * Issue HTTP redirect
 * @link http://php.net/manual/en/function.http-redirect.php
 * @param string $url [optional] <p>
 * the URL to redirect to
 * </p>
 * @param array $params [optional] <p>
 * associative array of query parameters
 * </p>
 * @param bool $session [optional] <p>
 * whether to append session information
 * </p>
 * @param int $status [optional] <p>
 * custom response status code
 * </p>
 * @return void &returns.http.false.orexits; with the specified redirection status code.
 * &see.http.configuration.force_exit;
 */
function http_redirect ($url = null,  array $params = null , $session = null, $status = null) {}

/**
 * (PECL pecl_http &gt;= 0.10.0)<br/>
 * HTTP throttling
 * @link http://php.net/manual/en/function.http-throttle.php
 * @param float $sec [optional] <p>
 * seconds to sleep after each chunk sent
 * </p>
 * @param int $bytes [optional] <p>
 * the chunk size in bytes
 * </p>
 * @return void 
 */
function http_throttle ($sec = null, $bytes = null) {}

/**
 * (PECL pecl_http &gt;= 0.1.0)<br/>
 * Send HTTP response status
 * @link http://php.net/manual/en/function.http-send-status.php
 * @param int $status <p>
 * HTTP status code (100-599)
 * </p>
 * @return bool true on success or false on failure.
 */
function http_send_status ($status) {}

/**
 * (PECL pecl_http &gt;= 0.1.0)<br/>
 * Send Last-Modified
 * @link http://php.net/manual/en/function.http-send-last-modified.php
 * @param int $timestamp [optional] <p>
 * a Unix timestamp, converted to a valid HTTP date;
 * if omitted, the current time will be sent
 * </p>
 * @return bool true on success or false on failure.
 */
function http_send_last_modified ($timestamp = null) {}

/**
 * (PECL pecl_http &gt;= 0.10.0)<br/>
 * Send Content-Type
 * @link http://php.net/manual/en/function.http-send-content-type.php
 * @param string $content_type [optional] <p>
 * the desired content type (primary/secondary)
 * </p>
 * @return bool true on success or false on failure.
 */
function http_send_content_type ($content_type = null) {}

/**
 * (PECL pecl_http &gt;= 0.10.0)<br/>
 * Send Content-Disposition
 * @link http://php.net/manual/en/function.http-send-content-disposition.php
 * @param string $filename <p>
 * the file name the &quot;Save as...&quot; dialog should display
 * </p>
 * @param bool $inline [optional] <p>
 * if set to true and the user agent knows how to handle the content type,
 * it will probably not cause the popup window to be shown
 * </p>
 * @return bool true on success or false on failure.
 */
function http_send_content_disposition ($filename, $inline = null) {}

/**
 * (PECL pecl_http &gt;= 0.1.0)<br/>
 * Match last modification
 * @link http://php.net/manual/en/function.http-match-modified.php
 * @param int $timestamp [optional] <p>
 * Unix timestamp; current time, if omitted
 * </p>
 * @param bool $for_range [optional] <p>
 * if set to true, the header usually used to validate HTTP ranges will be checked
 * </p>
 * @return bool true if timestamp represents an earlier date than the header, else false.
 */
function http_match_modified ($timestamp = null, $for_range = null) {}

/**
 * (PECL pecl_http &gt;= 0.1.0)<br/>
 * Match ETag
 * @link http://php.net/manual/en/function.http-match-etag.php
 * @param string $etag <p>
 * the ETag to match
 * </p>
 * @param bool $for_range [optional] <p>
 * if set to true, the header usually used to validate HTTP ranges will be checked
 * </p>
 * @return bool true if ETag matches or the header contained the asterisk (&quot;*&quot;), else false.
 */
function http_match_etag ($etag, $for_range = null) {}

/**
 * (PECL pecl_http &gt;= 0.1.0)<br/>
 * Caching by last modification
 * @link http://php.net/manual/en/function.http-cache-last-modified.php
 * @param int $timestamp_or_expires [optional] <p>
 * Unix timestamp
 * </p>
 * @return bool &returns.http.false.orexits; with 304 Not Modified if the entity is cached.
 * &see.http.configuration.force_exit;
 */
function http_cache_last_modified ($timestamp_or_expires = null) {}

/**
 * (PECL pecl_http &gt;= 0.1.0)<br/>
 * Caching by ETag
 * @link http://php.net/manual/en/function.http-cache-etag.php
 * @param string $etag [optional] <p>
 * custom ETag
 * </p>
 * @return bool &returns.http.false.orexits; with 304 Not Modified if the entity is cached.
 * &see.http.configuration.force_exit;
 */
function http_cache_etag ($etag = null) {}

/**
 * (PECL pecl_http &gt;= 0.1.0)<br/>
 * Send arbitrary data
 * @link http://php.net/manual/en/function.http-send-data.php
 * @param string $data <p>
 * data to send
 * </p>
 * @return bool true on success or false on failure.
 */
function http_send_data ($data) {}

/**
 * (PECL pecl_http &gt;= 0.1.0)<br/>
 * Send file
 * @link http://php.net/manual/en/function.http-send-file.php
 * @param string $file <p>
 * the file to send
 * </p>
 * @return bool true on success or false on failure.
 */
function http_send_file ($file) {}

/**
 * (PECL pecl_http &gt;= 0.1.0)<br/>
 * Send stream
 * @link http://php.net/manual/en/function.http-send-stream.php
 * @param resource $stream <p>
 * stream to read from (must be seekable)
 * </p>
 * @return bool true on success or false on failure.
 */
function http_send_stream ($stream) {}

/**
 * (PECL pecl_http &gt;= 0.1.0)<br/>
 * Decode chunked-encoded data
 * @link http://php.net/manual/en/function.http-chunked-decode.php
 * @param string $encoded <p>
 * chunked encoded string
 * </p>
 * @return string the decoded string on success or false on failure.
 */
function http_chunked_decode ($encoded) {}

/**
 * (PECL pecl_http &gt;= 0.12.0)<br/>
 * Parse HTTP messages
 * @link http://php.net/manual/en/function.http-parse-message.php
 * @param string $message <p>
 * string containing a single HTTP message or several consecutive HTTP messages
 * </p>
 * @return object a hierarchical object structure of the parsed messages.
 */
function http_parse_message ($message) {}

/**
 * (PECL pecl_http &gt;= 0.10.0)<br/>
 * Parse HTTP headers
 * @link http://php.net/manual/en/function.http-parse-headers.php
 * @param string $header <p>
 * string containing HTTP headers
 * </p>
 * @return array an array on success or false on failure.
 */
function http_parse_headers ($header) {}

/**
 * (PECL pecl_http &gt;= 0.20.0)<br/>
 * Parse HTTP cookie
 * @link http://php.net/manual/en/function.http-parse-cookie.php
 * @param string $cookie <p>
 * string containing the value of a Set-Cookie response header
 * </p>
 * @param int $flags [optional] <p>
 * parse flags (HTTP_COOKIE_PARSE_RAW)
 * </p>
 * @param array $allowed_extras [optional] <p>
 * array containing recognized extra keys;
 * by default all unknown keys will be treated as cookie names
 * </p>
 * @return stdClass|object a stdClass object on success or false on failure.
 */
function http_parse_cookie ($cookie, $flags = null,  array $allowed_extras = null ) {}

/**
 * (PECL pecl_http &gt;= 1.2.0)<br/>
 * Build cookie string
 * @link http://php.net/manual/en/function.http-build-cookie.php
 * @param array $cookie <p>
 * a cookie list like returned from http_parse_cookie
 * </p>
 * @return string the cookie(s) as string.
 */
function http_build_cookie (array $cookie) {}

/**
 * (PECL pecl_http &gt;= 1.0.0)<br/>
 * Parse parameter list
 * @link http://php.net/manual/en/function.http-parse-params.php
 * @param string $param <p>
 * Parameters
 * </p>
 * @param int $flags [optional] <p>
 * Parse flags
 * </p>
 * @return stdClass|object parameter list as stdClass object.
 */
function http_parse_params ($param, $flags = null) {}

/**
 * (PECL pecl_http &gt;= 0.10.0)<br/>
 * Get request headers as array
 * @link http://php.net/manual/en/function.http-get-request-headers.php
 * @return array an associative array of incoming request headers.
 */
function http_get_request_headers () {}

/**
 * (PECL pecl_http &gt;= 0.10.0)<br/>
 * Get request body as string
 * @link http://php.net/manual/en/function.http-get-request-body.php
 * @return string the raw request body as string on success or NULL on failure.
 */
function http_get_request_body () {}

/**
 * (PECL pecl_http &gt;= 0.22.0)<br/>
 * Get request body as stream
 * @link http://php.net/manual/en/function.http-get-request-body-stream.php
 * @return resource the raw request body as stream on success or NULL on failure.
 */
function http_get_request_body_stream () {}

/**
 * (PECL pecl_http &gt;= 0.10.0)<br/>
 * Match any header
 * @link http://php.net/manual/en/function.http-match-request-header.php
 * @param string $header <p>
 * the header name (case-insensitive)
 * </p>
 * @param string $value <p>
 * the header value that should be compared
 * </p>
 * @param bool $match_case [optional] <p>
 * whether the value should be compared case sensitively
 * </p>
 * @return bool true if header value matches, else false.
 */
function http_match_request_header ($header, $value, $match_case = null) {}

/**
 * (PECL pecl_http &gt;= 1.5.0)<br/>
 * Stat persistent handles
 * @link http://php.net/manual/en/function.http-persistent-handles-count.php
 * @return stdClass|object persistent handles statistics as stdClass object on success or false on failure.
 */
function http_persistent_handles_count () {}

/**
 * (PECL pecl_http &gt;= 1.5.0)<br/>
 * Clean up persistent handles
 * @link http://php.net/manual/en/function.http-persistent-handles-clean.php
 * @param string $ident [optional] 
 * @return string 
 */
function http_persistent_handles_clean ($ident = null) {}

/**
 * (PECL pecl_http &gt;= 1.5.0)<br/>
 * Get/set ident of persistent handles
 * @link http://php.net/manual/en/function.http-persistent-handles-ident.php
 * @param string $ident <p>
 * the identification string
 * </p>
 * @return string the prior ident as string on success or false on failure.
 */
function http_persistent_handles_ident ($ident) {}

/**
 * (PECL pecl_http &gt;= 0.1.0)<br/>
 * Perform GET request
 * @link http://php.net/manual/en/function.http-get.php
 * @param string $url <p>
 * URL
 * </p>
 * @param array $options [optional] <p>
 * &link.http.request.options;
 * </p>
 * @param array $info [optional] <p>
 * Will be filled with request/response information
 * </p>
 * @return string &returns.http.response;
 */
function http_get ($url, array $options = null ,  array &$info = null ) {}

/**
 * (PECL pecl_http &gt;= 0.1.0)<br/>
 * Perform HEAD request
 * @link http://php.net/manual/en/function.http-head.php
 * @param string $url [optional] <p>
 * URL
 * </p>
 * @param array $options [optional] <p>
 * &link.http.request.options;
 * </p>
 * @param array $info [optional] <p>
 * &link.http.request.info;
 * </p>
 * @return string &returns.http.response;
 */
function http_head ($url = null, array $options = null ,  array &$info = null ) {}

/**
 * (PECL pecl_http &gt;= 0.1.0)<br/>
 * Perform POST request with pre-encoded data
 * @link http://php.net/manual/en/function.http-post-data.php
 * @param string $url <p>
 * URL
 * </p>
 * @param string $data [optional] <p>
 * String containing the pre-encoded post data
 * </p>
 * @param array $options [optional] <p>
 * &link.http.request.options;
 * </p>
 * @param array $info [optional] <p>
 * &link.http.request.info;
 * </p>
 * @return string &returns.http.response;
 */
function http_post_data ($url, $data = null, array $options = null ,  array &$info = null ) {}

/**
 * (PECL pecl_http &gt;= 0.10.0)<br/>
 * Perform POST request with data to be encoded
 * @link http://php.net/manual/en/function.http-post-fields.php
 * @param string $url <p>
 * URL
 * </p>
 * @param array $data [optional] <p>
 * Associative array of POST values
 * </p>
 * @param array $files [optional] <p>
 * Array of files to post
 * </p>
 * @param array $options [optional] <p>
 * &link.http.request.options;
 * </p>
 * @param array $info [optional] <p>
 * &link.http.request.info;
 * </p>
 * @return string &returns.http.response;
 */
function http_post_fields ($url,  array $data = null ,  array $files = null , array $options = null ,  array &$info = null ) {}

/**
 * (PECL pecl_http &gt;= 0.25.0)<br/>
 * Perform PUT request with data
 * @link http://php.net/manual/en/function.http-put-data.php
 * @param string $url <p>
 * URL
 * </p>
 * @param string $data [optional] <p>
 * PUT request body
 * </p>
 * @param array $options [optional] <p>
 * &link.http.request.options;
 * </p>
 * @param array $info [optional] <p>
 * &link.http.request.info;
 * </p>
 * @return string &returns.http.response;
 */
function http_put_data ($url, $data = null, array $options = null ,  array &$info = null ) {}

/**
 * (PECL pecl_http &gt;= 0.10.0)<br/>
 * Perform PUT request with file
 * @link http://php.net/manual/en/function.http-put-file.php
 * @param string $url <p>
 * URL
 * </p>
 * @param string $file [optional] <p>
 * The file to put
 * </p>
 * @param array $options [optional] <p>
 * &link.http.request.options;
 * </p>
 * @param array $info [optional] <p>
 * &link.http.request.info;
 * </p>
 * @return string &returns.http.response;
 */
function http_put_file ($url, $file = null, array $options = null ,  array &$info = null ) {}

/**
 * (PECL pecl_http &gt;= 0.10.0)<br/>
 * Perform PUT request with stream
 * @link http://php.net/manual/en/function.http-put-stream.php
 * @param string $url <p>
 * URL
 * </p>
 * @param resource $stream [optional] <p>
 * The stream to read the PUT request body from
 * </p>
 * @param array $options [optional] <p>
 * &link.http.request.options;
 * </p>
 * @param array $info [optional] <p>
 * &link.http.request.info;
 * </p>
 * @return string &returns.http.response;
 */
function http_put_stream ($url, $stream = null, array $options = null ,  array &$info = null ) {}

/**
 * (PECL pecl_http &gt;= 1.0.0)<br/>
 * Perform custom request
 * @link http://php.net/manual/en/function.http-request.php
 * @param int $method <p>
 * Request method
 * </p>
 * @param string $url [optional] <p>
 * URL
 * </p>
 * @param string $body [optional] <p>
 * Request body
 * </p>
 * @param array $options [optional] <p>
 * &link.http.request.options;
 * </p>
 * @param array $info [optional] <p>
 * &link.http.request.info;
 * </p>
 * @return string &returns.http.response;
 */
function http_request ($method, $url = null, $body = null, array $options = null ,  array &$info = null ) {}

/**
 * (PECL pecl_http &gt;= 1.0.0)<br/>
 * Encode request body
 * @link http://php.net/manual/en/function.http-request-body-encode.php
 * @param array $fields <p>
 * POST fields
 * </p>
 * @param array $files <p>
 * POST files
 * </p>
 * @return string encoded string on success or false on failure.
 */
function http_request_body_encode (array $fields, array $files) {}

/**
 * (PECL pecl_http &gt;= 0.10.0)<br/>
 * Register request method
 * @link http://php.net/manual/en/function.http-request-method-register.php
 * @param string $method <p>
 * the request method name to register
 * </p>
 * @return int the ID of the request method on success or false on failure.
 */
function http_request_method_register ($method) {}

/**
 * (PECL pecl_http &gt;= 0.10.0)<br/>
 * Unregister request method
 * @link http://php.net/manual/en/function.http-request-method-unregister.php
 * @param mixed $method <p>
 * The request method name or ID
 * </p>
 * @return bool true on success or false on failure.
 */
function http_request_method_unregister ($method) {}

/**
 * (PECL pecl_http &gt;= 0.10.0)<br/>
 * Check whether request method exists
 * @link http://php.net/manual/en/function.http-request-method-exists.php
 * @param mixed $method <p>
 * request method name or ID
 * </p>
 * @return int true if the request method is known, else false.
 */
function http_request_method_exists ($method) {}

/**
 * (PECL pecl_http &gt;= 0.10.0)<br/>
 * Get request method name
 * @link http://php.net/manual/en/function.http-request-method-name.php
 * @param int $method <p>
 * request method ID
 * </p>
 * @return string the request method name as string on success or false on failure.
 */
function http_request_method_name ($method) {}

/**
 * (PECL pecl_http &gt;= 0.10.0)<br/>
 * ETag output handler
 * @link http://php.net/manual/en/function.ob-etaghandler.php
 * @param string $data 
 * @param int $mode 
 * @return string 
 */
function ob_etaghandler ($data, $mode) {}

/**
 * (PECL pecl_http &gt;= 0.15.0)<br/>
 * Deflate data
 * @link http://php.net/manual/en/function.http-deflate.php
 * @param string $data <p>
 * String containing the data that should be encoded
 * </p>
 * @param int $flags [optional] <p>
 * deflate options
 * </p>
 * @return string the encoded string on success, or NULL on failure.
 */
function http_deflate ($data, $flags = null) {}

/**
 * (PECL pecl_http &gt;= 0.15.0)<br/>
 * Inflate data
 * @link http://php.net/manual/en/function.http-inflate.php
 * @param string $data <p>
 * string containing the compressed data
 * </p>
 * @return string the decoded string on success, or NULL on failure.
 */
function http_inflate ($data) {}

/**
 * (PECL pecl_http &gt;= 0.21.0)<br/>
 * Deflate output handler
 * @link http://php.net/manual/en/function.ob-deflatehandler.php
 * @param string $data 
 * @param int $mode 
 * @return string 
 */
function ob_deflatehandler ($data, $mode) {}

/**
 * (PECL pecl_http &gt;= 0.21.0)<br/>
 * Inflate output handler
 * @link http://php.net/manual/en/function.ob-inflatehandler.php
 * @param string $data 
 * @param int $mode 
 * @return string 
 */
function ob_inflatehandler ($data, $mode) {}

/**
 * (PECL pecl_http &gt;= 0.15.0)<br/>
 * Check built-in HTTP support
 * @link http://php.net/manual/en/function.http-support.php
 * @param int $feature [optional] <p>
 * feature to probe for
 * </p>
 * @return int integer, whether requested feature is supported,
 * or a bitmask with all supported features if feature was omitted.
 */
function http_support ($feature = null) {}


/**
 * don't urldecode values
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_COOKIE_PARSE_RAW', 1);

/**
 * whether &quot;secure&quot; was found in the cookie's parameters list
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_COOKIE_SECURE', 16);

/**
 * whether &quot;httpOnly&quot; was found in the cookie's parameter list
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_COOKIE_HTTPONLY', 32);
define ('HTTP_DEFLATE_LEVEL_DEF', 0);
define ('HTTP_DEFLATE_LEVEL_MIN', 1);
define ('HTTP_DEFLATE_LEVEL_MAX', 9);
define ('HTTP_DEFLATE_TYPE_ZLIB', 0);
define ('HTTP_DEFLATE_TYPE_GZIP', 16);
define ('HTTP_DEFLATE_TYPE_RAW', 32);
define ('HTTP_DEFLATE_STRATEGY_DEF', 0);
define ('HTTP_DEFLATE_STRATEGY_FILT', 256);
define ('HTTP_DEFLATE_STRATEGY_HUFF', 512);
define ('HTTP_DEFLATE_STRATEGY_RLE', 768);
define ('HTTP_DEFLATE_STRATEGY_FIXED', 1024);

/**
 * don't flush
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_ENCODING_STREAM_FLUSH_NONE', 0);

/**
 * synchronized flush only
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_ENCODING_STREAM_FLUSH_SYNC', 1048576);

/**
 * full data flush
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_ENCODING_STREAM_FLUSH_FULL', 2097152);

/**
 * use &quot;basic&quot; authentication
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_AUTH_BASIC', 1);

/**
 * use &quot;digest&quot; authentication
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_AUTH_DIGEST', 2);

/**
 * use &quot;NTLM&quot; authentication
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_AUTH_NTLM', 8);

/**
 * use &quot;GSS-NEGOTIATE&quot; authentication
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_AUTH_GSSNEG', 4);

/**
 * try any authentication scheme
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_AUTH_ANY', -1);
define ('HTTP_VERSION_NONE', 0);

/**
 * HTTP version 1.0
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_VERSION_1_0', 1);

/**
 * HTTP version 1.1
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_VERSION_1_1', 2);

/**
 * no specific HTTP protocol version
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_VERSION_ANY', 0);

/**
 * use TLSv1 only
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_SSL_VERSION_TLSv1', 1);

/**
 * use SSLv2 only
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_SSL_VERSION_SSLv2', 2);

/**
 * use SSLv3 only
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_SSL_VERSION_SSLv3', 3);

/**
 * no specific SSL protocol version
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_SSL_VERSION_ANY', 0);

/**
 * use IPv4 only for name lookups
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_IPRESOLVE_V4', 1);

/**
 * use IPv6 only for name lookups
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_IPRESOLVE_V6', 2);

/**
 * use any IP mechanism only for name lookups
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_IPRESOLVE_ANY', 0);

/**
 * the proxy is a SOCKS4 type proxy
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_PROXY_SOCKS4', 4);

/**
 * the proxy is a SOCKS5 type proxy
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_PROXY_SOCKS5', 5);

/**
 * standard HTTP proxy
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_PROXY_HTTP', 0);
define ('HTTP_METH_GET', 1);
define ('HTTP_METH_HEAD', 2);
define ('HTTP_METH_POST', 3);
define ('HTTP_METH_PUT', 4);
define ('HTTP_METH_DELETE', 5);
define ('HTTP_METH_OPTIONS', 6);
define ('HTTP_METH_TRACE', 7);
define ('HTTP_METH_CONNECT', 8);
define ('HTTP_METH_PROPFIND', 9);
define ('HTTP_METH_PROPPATCH', 10);
define ('HTTP_METH_MKCOL', 11);
define ('HTTP_METH_COPY', 12);
define ('HTTP_METH_MOVE', 13);
define ('HTTP_METH_LOCK', 14);
define ('HTTP_METH_UNLOCK', 15);
define ('HTTP_METH_VERSION_CONTROL', 16);
define ('HTTP_METH_REPORT', 17);
define ('HTTP_METH_CHECKOUT', 18);
define ('HTTP_METH_CHECKIN', 19);
define ('HTTP_METH_UNCHECKOUT', 20);
define ('HTTP_METH_MKWORKSPACE', 21);
define ('HTTP_METH_UPDATE', 22);
define ('HTTP_METH_LABEL', 23);
define ('HTTP_METH_MERGE', 24);
define ('HTTP_METH_BASELINE_CONTROL', 25);
define ('HTTP_METH_MKACTIVITY', 26);
define ('HTTP_METH_ACL', 27);

/**
 * guess applicable redirect method
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_REDIRECT', 0);

/**
 * permanent redirect (301 Moved permanently)
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_REDIRECT_PERM', 301);

/**
 * standard redirect (302 Found)
 * RFC 1945 and RFC 2068 specify that the client is not allowed
 * to change the method on the redirected request. However, most
 * existing user agent implementations treat 302 as if it were a 303
 * response, performing a GET on the Location field-value regardless
 * of the original request method. The status codes 303 and 307 have
 * been added for servers that wish to make unambiguously clear which
 * kind of reaction is expected of the client.
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_REDIRECT_FOUND', 302);

/**
 * redirect applicable to POST requests (303 See other)
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_REDIRECT_POST', 303);

/**
 * proxy redirect (305 Use proxy)
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_REDIRECT_PROXY', 305);

/**
 * temporary redirect (307 Temporary Redirect)
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_REDIRECT_TEMP', 307);

/**
 * querying for this constant will always return true
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_SUPPORT', 1);

/**
 * whether support to issue HTTP requests is given, ie. libcurl support was compiled in
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_SUPPORT_REQUESTS', 2);

/**
 * whether support to guess the Content-Type of HTTP messages is given, ie. libmagic support was compiled in
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_SUPPORT_MAGICMIME', 4);

/**
 * whether support for zlib encodings is given, ie. libz support was compiled in
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_SUPPORT_ENCODINGS', 8);

/**
 * whether support to issue HTTP requests over SSL is given, ie. linked libcurl was built with SSL support
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_SUPPORT_SSLREQUESTS', 32);
define ('HTTP_SUPPORT_EVENTS', 128);

/**
 * allow commands additionally to semicolons as separator
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_PARAMS_ALLOW_COMMA', 1);

/**
 * continue parsing after an error occurred
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_PARAMS_ALLOW_FAILURE', 2);

/**
 * raise PHP warnings on parse errors
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_PARAMS_RAISE_ERROR', 4);

/**
 * all three values above, bitwise or'ed
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_PARAMS_DEFAULT', 7);

/**
 * replace every part of the first URL when there's one of the second URL
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_URL_REPLACE', 0);

/**
 * join relative paths
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_URL_JOIN_PATH', 1);

/**
 * join query strings
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_URL_JOIN_QUERY', 2);

/**
 * strip any user authentication information
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_URL_STRIP_USER', 4);

/**
 * strip any password authentication information
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_URL_STRIP_PASS', 8);

/**
 * strip any authentication information
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_URL_STRIP_AUTH', 12);

/**
 * strip explicit port numbers
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_URL_STRIP_PORT', 32);

/**
 * strip complete path
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_URL_STRIP_PATH', 64);

/**
 * strip query string
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_URL_STRIP_QUERY', 128);

/**
 * strip any fragments (#identifier)
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_URL_STRIP_FRAGMENT', 256);

/**
 * strip anything but scheme and host
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_URL_STRIP_ALL', 492);
define ('HTTP_URL_FROM_ENV', 4096);

/**
 * runtime error
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_E_RUNTIME', 1);

/**
 * an invalid parameter was passed
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_E_INVALID_PARAM', 2);

/**
 * header() or similar operation failed
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_E_HEADER', 3);

/**
 * HTTP header parse error
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_E_MALFORMED_HEADERS', 4);

/**
 * unknown/invalid request method
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_E_REQUEST_METHOD', 5);

/**
 * with operation incompatible message type
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_E_MESSAGE_TYPE', 6);

/**
 * encoding/decoding error
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_E_ENCODING', 7);

/**
 * request failure
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_E_REQUEST', 8);

/**
 * request pool failure
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_E_REQUEST_POOL', 9);

/**
 * socket exception
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_E_SOCKET', 10);

/**
 * response failure
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_E_RESPONSE', 11);

/**
 * invalid URL
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_E_URL', 12);

/**
 * querystring operation failure
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_E_QUERYSTRING', 13);

/**
 * the message is of no specific type
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_MSG_NONE', 0);

/**
 * request style message
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_MSG_REQUEST', 1);

/**
 * response style message
 * @link http://php.net/manual/en/http.constants.php
 */
define ('HTTP_MSG_RESPONSE', 2);
define ('HTTP_QUERYSTRING_TYPE_BOOL', 3);
define ('HTTP_QUERYSTRING_TYPE_INT', 1);
define ('HTTP_QUERYSTRING_TYPE_FLOAT', 2);
define ('HTTP_QUERYSTRING_TYPE_STRING', 6);
define ('HTTP_QUERYSTRING_TYPE_ARRAY', 4);
define ('HTTP_QUERYSTRING_TYPE_OBJECT', 5);
