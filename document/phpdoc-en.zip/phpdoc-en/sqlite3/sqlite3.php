<?php

// Start of sqlite3 v.0.7-dev

/**
*<div id="class.sqlite3" class="reference">  <h1 class="title">The SQLite3 class</h1>     <div class="partintro"><p class="verinfo">(PHP 5 &gt;= 5.3.0, PHP 7)</p>     <div class="section" id="sqlite3.intro">    <h2 class="title">Introduction</h2>    <p class="para">     A class that interfaces SQLite 3 databases.    </p>   </div>     <div class="section" id="sqlite3.synopsis">    <h2 class="title">Class synopsis</h2>      <div class="classsynopsis">     <div class="ooclass"></div>       <div class="classsynopsisinfo">      <span class="ooclass">       <strong class="classname">SQLite3</strong>      </span>      {</div>           <div class="classsynopsisinfo classsynopsisinfo_comment">// Methods </div>     <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/sqlite3.busytimeout.php" class="methodname" style="color:#CC7832">busyTimeout</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$msecs</span></span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/sqlite3.changes.php" class="methodname" style="color:#CC7832">changes</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">int</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/sqlite3.close.php" class="methodname" style="color:#CC7832">close</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/sqlite3.construct.php" class="methodname" style="color:#CC7832">__construct</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$filename</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$flags</span><span class="initializer"> = SQLITE3_OPEN_READWRITE | SQLITE3_OPEN_CREATE</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$encryption_key</span><span class="initializer"> = &quot;&quot;</span></span>   ]] )</div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/sqlite3.createaggregate.php" class="methodname" style="color:#CC7832">createAggregate</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    , <span class="methodparam"><span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span> <span class="parameter" style="color:#2EACF9">$step_callback</span></span>    , <span class="methodparam"><span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span> <span class="parameter" style="color:#2EACF9">$final_callback</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$argument_count</span><span class="initializer"> = -1</span></span>   ] ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/sqlite3.createcollation.php" class="methodname" style="color:#CC7832">createCollation</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    , <span class="methodparam"><span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.callable.php" class="type callable" style="color:#EAB766">callable</a></span> <span class="parameter" style="color:#2EACF9">$callback</span></span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832">{@link createFunction}</span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$name</span></span>    , <span class="methodparam"><span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span> <span class="parameter" style="color:#2EACF9">$callback</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$argument_count</span><span class="initializer"> = -1</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$flags</span><span class="initializer"> = 0</span></span>   ]] ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/sqlite3.enableexceptions.php" class="methodname" style="color:#CC7832">enableExceptions</a></span>     ([ <span class="methodparam"><span class="type" style="color:#EAB766">bool</span> <span class="parameter" style="color:#2EACF9">$enableExceptions</span><span class="initializer"> = <strong><span>FALSE</span></strong></span></span>   ] ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="modifier">static</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/sqlite3.escapestring.php" class="methodname" style="color:#CC7832">escapeString</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$value</span></span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/sqlite3.exec.php" class="methodname" style="color:#CC7832">exec</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$query</span></span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/sqlite3.lasterrorcode.php" class="methodname" style="color:#CC7832">lastErrorCode</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">int</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/sqlite3.lasterrormsg.php" class="methodname" style="color:#CC7832">lastErrorMsg</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/sqlite3.lastinsertrowid.php" class="methodname" style="color:#CC7832">lastInsertRowID</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">int</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/sqlite3.loadextension.php" class="methodname" style="color:#CC7832">loadExtension</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$shared_library</span></span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/sqlite3.open.php" class="methodname" style="color:#CC7832">open</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$filename</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$flags</span><span class="initializer"> = SQLITE3_OPEN_READWRITE | SQLITE3_OPEN_CREATE</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$encryption_key</span><span class="initializer"> = &quot;&quot;</span></span>   ]] ) : <span class="type" style="color:#EAB766"><span class="type void" style="color:#EAB766">void</span></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/sqlite3.openblob.php" class="methodname" style="color:#CC7832">openBlob</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$table</span></span>    , <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$column</span></span>    , <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$rowid</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$dbname</span><span class="initializer"> = &quot;main&quot;</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$flags</span><span class="initializer"> = SQLITE3_OPEN_READONLY</span></span>   ]] ) : <span class="type" style="color:#EAB766">resource</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/sqlite3.prepare.php" class="methodname" style="color:#CC7832">prepare</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$query</span></span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/class.sqlite3stmt.php" class="type SQLite3Stmt" style="color:#EAB766">SQLite3Stmt</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/sqlite3.query.php" class="methodname" style="color:#CC7832">query</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$query</span></span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/class.sqlite3result.php" class="type SQLite3Result" style="color:#EAB766">SQLite3Result</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/sqlite3.querysingle.php" class="methodname" style="color:#CC7832">querySingle</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$query</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">bool</span> <span class="parameter" style="color:#2EACF9">$entire_row</span><span class="initializer"> = <strong><span>FALSE</span></strong></span></span>   ] ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="modifier">static</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/sqlite3.version.php" class="methodname" style="color:#CC7832">version</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">array</span></div>     }</div>     </div>   </div>                                                                                                                                                <h2>Table of Contents</h2><ul class="chunklist chunklist_reference"><li>{@link SQLite3::busyTimeout} — Sets the busy connection handler</li><li>{@link SQLite3::changes} — Returns the number of database rows that were changed (or inserted or    deleted) by the most recent SQL statement</li><li>{@link SQLite3::close} — Closes the database connection</li><li>{@link SQLite3::__construct} — Instantiates an SQLite3 object and opens an SQLite 3 database</li><li>{@link SQLite3::createAggregate} — Registers a PHP function for use as an SQL aggregate function</li><li>{@link SQLite3::createCollation} — Registers a PHP function for use as an SQL collating function</li><li>{@link SQLite3::createFunction} — Registers a PHP function for use as an SQL scalar function</li><li>{@link SQLite3::enableExceptions} — Enable throwing exceptions</li><li>{@link SQLite3::escapeString} — Returns a string that has been properly escaped</li><li>{@link SQLite3::exec} — Executes a result-less query against a given database</li><li>{@link SQLite3::lastErrorCode} — Returns the numeric result code of the most recent failed SQLite request</li><li>{@link SQLite3::lastErrorMsg} — Returns English text describing the most recent failed SQLite request</li><li>{@link SQLite3::lastInsertRowID} — Returns the row ID of the most recent INSERT into the database</li><li>{@link SQLite3::loadExtension} — Attempts to load an SQLite extension library</li><li>{@link SQLite3::open} — Opens an SQLite database</li><li>{@link SQLite3::openBlob} — Opens a stream resource to read a BLOB</li><li>{@link SQLite3::prepare} — Prepares an SQL statement for execution</li><li>{@link SQLite3::query} — Executes an SQL query</li><li>{@link SQLite3::querySingle} — Executes a query and returns a single result</li><li>{@link SQLite3::version} — Returns the SQLite3 library version as a string constant and as a number</li></ul> </div>
*/
class SQLite3  {

	/**
	 * Opens an SQLite database
	 * @link http://php.net/manual/en/sqlite3.open.php
	 * @param string $filename <p>
	 * Path to the SQLite database, or :memory: to use in-memory database.
	 * </p>
	 * @param int $flags [optional] <p>
	 * Optional flags used to determine how to open the SQLite database. By
	 * default, open uses SQLITE3_OPEN_READWRITE | SQLITE3_OPEN_CREATE.
	 * <p>
	 * SQLITE3_OPEN_READONLY: Open the database for
	 * reading only.
	 * </p>
	 * @param string $encryption_key [optional] <p>
	 * An optional encryption key used when encrypting and decrypting an
	 * SQLite database.
	 * </p>
	 * @return void No value is returned.
	 * @since 5.3.0
	 */
	public function open ($filename, $flags = SQLITE3_OPEN_READWRITE | SQLITE3_OPEN_CREATE, $encryption_key = null) {}

	/**
	 * Closes the database connection
	 * @link http://php.net/manual/en/sqlite3.close.php
	 * @return bool <b>TRUE</b> on success, <b>FALSE</b> on failure.
	 * @since 5.3.0
	 */
	public function close () {}

	/**
	 * Executes a result-less query against a given database
	 * @link http://php.net/manual/en/sqlite3.exec.php
	 * @param string $query <p>
	 * The SQL query to execute (typically an INSERT, UPDATE, or DELETE
	 * query).
	 * </p>
	 * @return bool <b>TRUE</b> if the query succeeded, <b>FALSE</b> on failure.
	 * @since 5.3.0
	 */
/**
*<div id="function.exec" class="refentry">  <div class="refnamediv">   <h1 class="refname">exec</h1>   <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">exec</span> &mdash; <span class="dc-title">Execute an external program</span></p>   </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.exec-description">   <h3 class="title">Description</h3>   <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><strong>exec</strong></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$command</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">array</span> <span class="parameter" style="color:#2EACF9">&$output</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">&$return_var</span></span>   ]] ) : <span class="type" style="color:#EAB766">string</span></div>    <p class="para rdfs-comment">    <span class="function"><strong style="color:#CC7832">exec()</strong></span> executes the given    <span class="parameter" style="color:#2EACF9">command</span>.   </p>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.exec-parameters">   <h3 class="title">Parameters</h3>   <span>    <dl>            <dt> <span class="parameter" style="color:#2EACF9">command</span></dt>       <dd>        <p class="para">        The command that will be executed.       </p>      </dd>                 <dt> <span class="parameter" style="color:#2EACF9">output</span></dt>       <dd>        <p class="para">        If the <span class="parameter" style="color:#2EACF9">output</span> argument is present, then the        specified array will be filled with every line of output from the        command.  Trailing whitespace, such as <em>\n</em>, is not        included in this array.  Note that if the array already contains some        elements, <span class="function"><strong style="color:#CC7832">exec()</strong></span> will append to the end of the array.        If you do not want the function to append elements, call        <span class="function">{@link unset()}</span> on the array before passing it to        <span class="function"><strong style="color:#CC7832">exec()</strong></span>.       </p>      </dd>                 <dt> <span class="parameter" style="color:#2EACF9">return_var</span></dt>       <dd>        <p class="para">        If the <span class="parameter" style="color:#2EACF9">return_var</span> argument is present        along with the <span class="parameter" style="color:#2EACF9">output</span> argument, then the        return status of the executed command will be written to this        variable.       </p>      </dd>          </dl>    </span>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.exec-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    The last line from the result of the command.  If you need to execute a     command and have all the data from the command passed directly back without     any interference, use the <span class="function">{@link passthru()}</span> function.   </p>   <p class="para">    To get the output of the executed command, be sure to set and use the    <span class="parameter" style="color:#2EACF9">output</span> parameter.   </p>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.exec-examples">   <h3 class="title">Examples</h3>   <span>    <div class="example" id="example-4513">     <p><strong>Example #1 An <span class="function"><strong style="color:#CC7832">exec()</strong></span> example</strong></p>     <div class="example-contents"> <div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"> <span style="color: #9876AA">&lt;?php<br /></span><span style="color: #FF8000">//&nbsp;outputs&nbsp;the&nbsp;username&nbsp;that&nbsp;owns&nbsp;the&nbsp;running&nbsp;php/httpd&nbsp;process<br />//&nbsp;(on&nbsp;a&nbsp;system&nbsp;with&nbsp;the&nbsp;"whoami"&nbsp;executable&nbsp;in&nbsp;the&nbsp;path)<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #9876AA">exec</span><span style="color: #007700">(</span><span style="color: #DD0000">'whoami'</span><span style="color: #007700">);<br /></span><span style="color: #9876AA">?&gt;</span> </span> </span></div>     </div>     </div>   </span>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 notes" id="refsect1-function.exec-notes">   <h3 class="title">Notes</h3>   <div class="warning"><strong class="warning">Warning</strong><p class="para">When allowing user-supplied data to be passed to this function, use <span class="function">{@link escapeshellarg()}</span> or <span class="function">{@link escapeshellcmd()}</span> to ensure that users cannot trick the system into executing arbitrary commands.</p></div>   <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>: <p class="para">If a program is started with this function, in order for it to continue running in the background, the output of the program must be redirected to a file or another output stream. Failing to do so will cause PHP to hang until the execution of the program ends.</p></p></blockquote>   <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>: <p class="para">On Windows <span class="function"><strong style="color:#CC7832">exec()</strong></span> will first start cmd.exe to launch the command. If you want to start an external program without starting cmd.exe use <span class="function">{@link proc_open()}</span> with the <span class="parameter" style="color:#2EACF9">bypass_shell</span> option set.</p></p></blockquote>   <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>: <span class="simpara">When <a href="https://www.php.net/manual/en/features.safe-mode.php" class="link">safe mode</a> is enabled, you can only execute files within the <a href="https://www.php.net/manual/en/ini.sect.safe-mode.php#ini.safe-mode-exec-dir" class="link">safe_mode_exec_dir</a>. For practical reasons, it is currently not allowed to have <em>..</em> components in the path to the executable.</span></p></blockquote>   <div class="warning"><strong class="warning">Warning</strong><p class="simpara">With <a href="https://www.php.net/manual/en/features.safe-mode.php" class="link">safe mode</a> enabled, the command string is escaped with <span class="function">{@link escapeshellcmd()}</span>. Thus, <em>echo y | echo x</em> becomes <em>echo y \| echo x</em>.</p></div>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.exec-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><span class="function">{@link system()} - Execute an external program and display the output</span></li>     <li class="member"><span class="function">{@link passthru()} - Execute an external program and display raw output</span></li>     <li class="member"><span class="function">{@link escapeshellcmd()} - Escape shell metacharacters</span></li>     <li class="member"><span class="function">{@link pcntl_exec()} - Executes specified program in current process space</span></li>     <li class="member"><a href="https://www.php.net/manual/en/language.operators.execution.php" class="link">backtick operator</a></li>    </ul>   </span>  </div>  </div>
*/
	public function exec ($query) {}

	/**
	 * Returns the SQLite3 library version as a string constant and as a number
	 * @link http://php.net/manual/en/sqlite3.version.php
	 * @return array an associative array with the keys "versionString" and
	 * "versionNumber".
	 * @since 5.3.0
	 */
	public static function version () {}

	/**
	 * Returns the row ID of the most recent INSERT into the database
	 * @link http://php.net/manual/en/sqlite3.lastinsertrowid.php
	 * @return int the row ID of the most recent INSERT into the database
	 * @since 5.3.0
	 */
	public function lastInsertRowID () {}

	/**
	 * Returns the numeric result code of the most recent failed SQLite request
	 * @link http://php.net/manual/en/sqlite3.lasterrorcode.php
	 * @return int an integer value representing the numeric result code of the most
	 * recent failed SQLite request.
	 * @since 5.3.0
	 */
	public function lastErrorCode () {}

	/**
	 * Returns English text describing the most recent failed SQLite request
	 * @link http://php.net/manual/en/sqlite3.lasterrormsg.php
	 * @return string an English string describing the most recent failed SQLite request.
	 * @since 5.3.0
	 */
	public function lastErrorMsg () {}

	/**
	 * Sets the busy connection handler
	 * @link http://php.net/manual/en/sqlite3.busytimeout.php
	 * @param int $msecs <p>
	 * The milliseconds to sleep. Setting this value to a value less than
	 * or equal to zero, will turn off an already set timeout handler.
	 * </p>
	 * @return bool <b>TRUE</b> on success, <b>FALSE</b> on failure.
	 * @since 5.3.3
	 */
	public function busyTimeout ($msecs) {}

	/**
	 * Attempts to load an SQLite extension library
	 * @link http://php.net/manual/en/sqlite3.loadextension.php
	 * @param string $shared_library <p>
	 * The name of the library to load. The library must be located in the
	 * directory specified in the configure option sqlite3.extension_dir.
	 * </p>
	 * @return bool <b>TRUE</b> if the extension is successfully loaded, <b>FALSE</b> on failure.
	 * @since 5.3.0
	 */
	public function loadExtension ($shared_library) {}

	/**
	 * Returns the number of database rows that were changed (or inserted or
	 * deleted) by the most recent SQL statement
	 * @since 5.3.0
	 * @link http://php.net/manual/en/sqlite3.changes.php
	 * @return int an integer value corresponding to the number of
	 * database rows changed (or inserted or deleted) by the most recent SQL
	 * statement.
	 */
	public function changes () {}

	/**
	 * Returns a string that has been properly escaped
	 * @link http://php.net/manual/en/sqlite3.escapestring.php
	 * @param string $value <p>
	 * The string to be escaped.
	 * </p>
	 * @return string a properly escaped string that may be used safely in an SQL
	 * statement.
	 * @since 5.3.0
	 */
	public static function escapeString ($value) {}

	/**
	 * Prepares an SQL statement for execution
	 * @link http://php.net/manual/en/sqlite3.prepare.php
	 * @param string $query <p>
	 * The SQL query to prepare.
	 * </p>
	 * @return SQLite3Stmt an <b>SQLite3Stmt</b> object on success or <b>FALSE</b> on failure.
	 * @since 5.3.0
	 */
	public function prepare ($query) {}

	/**
	 * Executes an SQL query
	 * @link http://php.net/manual/en/sqlite3.query.php
	 * @param string $query <p>
	 * The SQL query to execute.
	 * </p>
	 * @return SQLite3Result an <b>SQLite3Result</b> object if the query returns results. Otherwise,
	 * returns <b>TRUE</b> if the query succeeded, <b>FALSE</b> on failure.
	 * @since 5.3.0
	 */
	public function query ($query) {}

	/**
	 * Executes a query and returns a single result
	 * @link http://php.net/manual/en/sqlite3.querysingle.php
	 * @param string $query <p>
	 * The SQL query to execute.
	 * </p>
	 * @param bool $entire_row [optional] <p>
	 * By default, <b>querySingle</b> returns the value of the
	 * first column returned by the query. If
	 * <i>entire_row</i> is <b>TRUE</b>, then it returns an array
	 * of the entire first row.
	 * </p>
	 * @return mixed the value of the first column of results or an array of the entire
	 * first row (if <i>entire_row</i> is <b>TRUE</b>).
	 * </p>
	 * <p>
	 * If the query is valid but no results are returned, then <b>NULL</b> will be
	 * returned if <i>entire_row</i> is <b>FALSE</b>, otherwise an
	 * empty array is returned.
	 * </p>
	 * <p>
	 * Invalid or failing queries will return <b>FALSE</b>.
	 * @since 5.3.0
	 */
	public function querySingle ($query, $entire_row = false) {}

	/**
	 * Registers a PHP function for use as an SQL scalar function
	 * @link http://php.net/manual/en/sqlite3.createfunction.php
	 * @param string $name <p>
	 * Name of the SQL function to be created or redefined.
	 * </p>
	 * @param mixed $callback <p>
	 * The name of a PHP function or user-defined function to apply as a
	 * callback, defining the behavior of the SQL function.
	 * </p>
	 * @param int $argument_count [optional] <p>
	 * The number of arguments that the SQL function takes. If
	 * this parameter is negative, then the SQL function may take
	 * any number of arguments.
	 * </p>
	 * @param int $flags [optional]
	 * <p>A bitwise conjunction of flags.
	 * Currently, only <b>SQLITE3_DETERMINISTIC</b> is supported, which specifies that the function always returns
	 * the same result given the same inputs within a single SQL statement.</p>
	 * @return bool <b>TRUE</b> upon successful creation of the function, <b>FALSE</b> on failure.
	 * @since 5.3.0
	 */
	public function createFunction ($name, $callback, $argument_count = -1, int $flags = 0) {}

	/**
	 * Registers a PHP function for use as an SQL aggregate function
	 * @link http://php.net/manual/en/sqlite3.createaggregate.php
	 * @param string $name <p>
	 * Name of the SQL aggregate to be created or redefined.
	 * </p>
	 * @param mixed $step_callback <p>
	 * The name of a PHP function or user-defined function to apply as a
	 * callback for every item in the aggregate.
	 * </p>
	 * @param mixed $final_callback <p>
	 * The name of a PHP function or user-defined function to apply as a
	 * callback at the end of the aggregate data.
	 * </p>
	 * @param int $argument_count [optional] <p>
	 * The number of arguments that the SQL aggregate takes. If
	 * this parameter is negative, then the SQL aggregate may take
	 * any number of arguments.
	 * </p>
	 * @return bool <b>TRUE</b> upon successful creation of the aggregate, <b>FALSE</b> on
	 * failure.
	 * @since 5.3.0
	 */
	public function createAggregate ($name, $step_callback, $final_callback, $argument_count = -1) {}

	/**
	 * Registers a PHP function for use as an SQL collating function
	 * @link http://php.net/manual/en/sqlite3.createcollation.php
	 * @param string $name <p>
	 * Name of the SQL collating function to be created or redefined
	 * </p>
	 * @param callable $callback <p>
	 * The name of a PHP function or user-defined function to apply as a
	 * callback, defining the behavior of the collation. It should accept two
	 * strings and return as <b>strcmp</b> does, i.e. it should
	 * return -1, 1, or 0 if the first string sorts before, sorts after, or is
	 * equal to the second.
	 * </p>
	 * @return bool <b>TRUE</b> on success or <b>FALSE</b> on failure.
	 * @since 5.3.11
	 */
	public function createCollation ($name, callable $callback) {}

	/**
	 * Opens a stream resource to read a BLOB
	 * @link http://php.net/manual/en/sqlite3.openblob.php
	 * @param $table <p>The table name.</p>
	 * @param $column <p>The column name.</p>
	 * @param $rowid <p>The row ID.</p>
	 * @param $dbname [optional] <p>The symbolic name of the DB</p>
	 * @param int $flags [optional]
	 * <p>Either <b>SQLITE3_OPEN_READONLY</b> or <b>SQLITE3_OPEN_READWRITE</b> to open the stream for reading only, or for reading and writing, respectively.</p?
	 * @return resource|bool Returns a stream resource, or FALSE on failure.
	 */
	public function openBlob ($table, $column, $rowid, $dbname, int $flags = SQLITE3_OPEN_READONLY) {}

	/**
	 * @param $enableExceptions
	 */
	public function enableExceptions ($enableExceptions) {}

	/**
	 * Instantiates an SQLite3 object and opens an SQLite 3 database
	 * @link http://php.net/manual/en/sqlite3.construct.php
	 * @param string $filename <p>
	 * Path to the SQLite database, or :memory: to use in-memory database.
	 * </p>
	 * @param int $flags [optional] <p>
	 * Optional flags used to determine how to open the SQLite database. By
	 * default, open uses SQLITE3_OPEN_READWRITE | SQLITE3_OPEN_CREATE.
	 * <p>
	 * SQLITE3_OPEN_READONLY: Open the database for
	 * reading only.
	 * </p>
	 * @param string $encryption_key [optional] <p>
	 * An optional encryption key used when encrypting and decrypting an
	 * SQLite database.
	 * </p>
	 * @since 5.3.0
	 */
	public function __construct ($filename, $flags = null, $encryption_key = null) {}

}

/**
*<div id="class.sqlite3stmt" class="reference">  <h1 class="title">The SQLite3Stmt class</h1>     <div class="partintro"><p class="verinfo">(PHP 5 &gt;= 5.3.0, PHP 7)</p>     <div class="section" id="sqlite3stmt.intro">    <h2 class="title">Introduction</h2>    <p class="para">     A class that handles prepared statements for the SQLite 3 extension.    </p>   </div>     <div class="section" id="sqlite3stmt.synopsis">    <h2 class="title">Class synopsis</h2>      <div class="classsynopsis">     <div class="ooclass"></div>       <div class="classsynopsisinfo">      <span class="ooclass">       <strong class="classname">SQLite3Stmt</strong>      </span>      {</div>           <div class="classsynopsisinfo classsynopsisinfo_comment">// Methods </div>     <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/sqlite3stmt.bindparam.php" class="methodname" style="color:#CC7832">bindParam</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span> <span class="parameter" style="color:#2EACF9">$sql_param</span></span>    , <span class="methodparam"><span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span> <span class="parameter" style="color:#2EACF9">&$param</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$type</span></span>   ] ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/sqlite3stmt.bindvalue.php" class="methodname" style="color:#CC7832">bindValue</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span> <span class="parameter" style="color:#2EACF9">$sql_param</span></span>    , <span class="methodparam"><span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span> <span class="parameter" style="color:#2EACF9">$value</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$type</span></span>   ] ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/sqlite3stmt.clear.php" class="methodname" style="color:#CC7832">clear</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/sqlite3stmt.close.php" class="methodname" style="color:#CC7832">close</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/sqlite3stmt.execute.php" class="methodname" style="color:#CC7832">execute</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/class.sqlite3result.php" class="type SQLite3Result" style="color:#EAB766">SQLite3Result</a></span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/sqlite3stmt.getsql.php" class="methodname" style="color:#CC7832">getSQL</a></span>     ([ <span class="methodparam"><span class="type" style="color:#EAB766">bool</span> <span class="parameter" style="color:#2EACF9">$expanded</span><span class="initializer"> = <strong><span>FALSE</span></strong></span></span>   ] ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/sqlite3stmt.paramcount.php" class="methodname" style="color:#CC7832">paramCount</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">int</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/sqlite3stmt.readonly.php" class="methodname" style="color:#CC7832">readOnly</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/sqlite3stmt.reset.php" class="methodname" style="color:#CC7832">reset</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div>     }</div>     </div>   </div>                                                                    <h2>Table of Contents</h2><ul class="chunklist chunklist_reference"><li>{@link SQLite3Stmt::bindParam} — Binds a parameter to a statement variable</li><li>{@link SQLite3Stmt::bindValue} — Binds the value of a parameter to a statement variable</li><li>{@link SQLite3Stmt::clear} — Clears all current bound parameters</li><li>{@link SQLite3Stmt::close} — Closes the prepared statement</li><li>{@link SQLite3Stmt::execute} — Executes a prepared statement and returns a result set object</li><li>{@link SQLite3Stmt::getSQL} — Get the SQL of the statement</li><li>{@link SQLite3Stmt::paramCount} — Returns the number of parameters within the prepared statement</li><li>{@link SQLite3Stmt::readOnly} — Returns whether a statement is definitely read only</li><li>{@link SQLite3Stmt::reset} — Resets the prepared statement</li></ul> </div>
*/
class SQLite3Stmt  {

	/**
	 * Returns the number of parameters within the prepared statement
	 * @link http://php.net/manual/en/sqlite3stmt.paramcount.php
	 * @return int the number of parameters within the prepared statement.
	 * @since 5.3.0
	 */
	public function paramCount () {}

	/**
	 * Closes the prepared statement
	 * @link http://php.net/manual/en/sqlite3stmt.close.php
	 * @return bool <b>TRUE</b>
	 * @since 5.3.0
	 */
	public function close () {}

	/**
	 * Resets the prepared statement
	 * @link http://php.net/manual/en/sqlite3stmt.reset.php
	 * @return bool <b>TRUE</b> if the statement is successfully reset, <b>FALSE</b> on failure.
	 * @since 5.3.0
	 */
/**
*<div id="function.reset" class="refentry">  <div class="refnamediv">   <h1 class="refname">reset</h1>   <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">reset</span> &mdash; <span class="dc-title">Set the internal pointer of an array to its first element</span></p>   </div>  <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.reset-description">   <h3 class="title">Description</h3>   <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><strong>reset</strong></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">array</span> <span class="parameter" style="color:#2EACF9">&$array</span></span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span></div>    <p class="para rdfs-comment">    <span class="function"><strong style="color:#CC7832">reset()</strong></span> rewinds <span class="parameter" style="color:#2EACF9">array</span>&#039;s internal    pointer to the first element and returns the value of the first array    element.   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.reset-parameters">   <h3 class="title">Parameters</h3>   <span>    <dl>            <dt> <span class="parameter" style="color:#2EACF9">array</span></dt>       <dd>        <p class="para">        The input array.       </p>      </dd>          </dl>    </span>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.reset-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    Returns the value of the first array element, or <strong><span>FALSE</span></strong> if the array is    empty.   </p>   <div class="warning"><strong class="warning">Warning</strong><p class="simpara">This function may return Boolean <strong><span>FALSE</span></strong>, but may also return a non-Boolean value which evaluates to <strong><span>FALSE</span></strong>. Please read the section on <a href="https://www.php.net/manual/en/language.types.boolean.php" class="link">Booleans</a> for more information. Use <a href="https://www.php.net/manual/en/language.operators.comparison.php" class="link">the === operator</a> for testing the return value of this function.</p></div>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.reset-examples">   <h3 class="title">Examples</h3>   <span>    <div class="example" id="example-6301">     <p><strong>Example #1 <span class="function"><strong style="color:#CC7832">reset()</strong></span> example</strong></p>     <div class="example-contents"> <div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"> <span style="color: #9876AA">&lt;?php<br /><br />$array&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #DD0000">'step&nbsp;one'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'step&nbsp;two'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'step&nbsp;three'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'step&nbsp;four'</span><span style="color: #007700">);<br /><br /></span><span style="color: #FF8000">//&nbsp;by&nbsp;default,&nbsp;the&nbsp;pointer&nbsp;is&nbsp;on&nbsp;the&nbsp;first&nbsp;element<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">)&nbsp;.&nbsp;</span><span style="color: #DD0000">"&lt;br&nbsp;/&gt;\n"</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;"step&nbsp;one"<br /><br />//&nbsp;skip&nbsp;two&nbsp;steps<br /></span><span style="color: #9876AA">next</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">);<br /></span><span style="color: #9876AA">next</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">);<br />echo&nbsp;</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">)&nbsp;.&nbsp;</span><span style="color: #DD0000">"&lt;br&nbsp;/&gt;\n"</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;"step&nbsp;three"<br /><br />//&nbsp;reset&nbsp;pointer,&nbsp;start&nbsp;again&nbsp;on&nbsp;step&nbsp;one<br /></span><span style="color: #9876AA">reset</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">);<br />echo&nbsp;</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">)&nbsp;.&nbsp;</span><span style="color: #DD0000">"&lt;br&nbsp;/&gt;\n"</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;"step&nbsp;one"<br /><br /></span><span style="color: #9876AA">?&gt;</span> </span> </span></div>     </div>     </div>   </span>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 notes" id="refsect1-function.reset-notes">   <h3 class="title">Notes</h3>   <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>:     <span class="simpara">     The return value for an empty array is indistinguishable from      the return value in case of an array which has a <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.boolean.php" class="type boolean" style="color:#EAB766">boolean</a></span> <strong><span>FALSE</span></strong>      first element. To properly check the value of the first element of an array     which may contain <strong><span>FALSE</span></strong> elements, first check the <span class="function">{@link count()}</span>     of the array, or check that <span class="function">{@link key()}</span> is not     <strong><span>NULL</span></strong>, after calling <span class="function"><strong style="color:#CC7832">reset()</strong></span>.    </span>   </p></blockquote>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.reset-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><span class="function">{@link current()} - Return the current element in an array</span></li>     <li class="member"><span class="function">{@link each()} - Return the current key and value pair from an array and advance the array cursor</span></li>     <li class="member"><span class="function">{@link end()} - Set the internal pointer of an array to its last element</span></li>     <li class="member"><span class="function">{@link next()} - Advance the internal pointer of an array</span></li>     <li class="member"><span class="function">{@link prev()} - Rewind the internal array pointer</span></li>     <li class="member"><span class="function">{@link array_key_first()} - Gets the first key of an array</span></li>    </ul>   </span>  </div>  </div>
*/
	public function reset () {}

	/**
	 * Clears all current bound parameters
	 * @link http://php.net/manual/en/sqlite3stmt.clear.php
	 * @return bool <b>TRUE</b> on successful clearing of bound parameters, <b>FALSE</b> on
	 * failure.
	 * @since 5.3.0
	 */
	public function clear () {}

	/**
	 * Executes a prepared statement and returns a result set object
	 * @link http://php.net/manual/en/sqlite3stmt.execute.php
	 * @return SQLite3Result an <b>SQLite3Result</b> object on successful execution of the prepared
	 * statement, <b>FALSE</b> on failure.
	 * @since 5.3.0
	 */
	public function execute () {}

	/**
	 * Binds a parameter to a statement variable
	 * @link http://php.net/manual/en/sqlite3stmt.bindparam.php
	 * @param string $sql_param <p>
	 * An string identifying the statement variable to which the
	 * parameter should be bound.
	 * </p>
	 * @param mixed $param <p>
	 * The parameter to bind to a statement variable.
	 * </p>
	 * @param int $type [optional] <p>
	 * The data type of the parameter to bind.
	 * <p>
	 * SQLITE3_INTEGER: The value is a signed integer,
	 * stored in 1, 2, 3, 4, 6, or 8 bytes depending on the magnitude of
	 * the value.
	 * </p>
	 * @return bool <b>TRUE</b> if the parameter is bound to the statement variable, <b>FALSE</b>
	 * on failure.
	 * @since 5.3.0
	 */
	public function bindParam ($sql_param, &$param, $type = null) {}

	/**
	 * Binds the value of a parameter to a statement variable
	 * @link http://php.net/manual/en/sqlite3stmt.bindvalue.php
	 * @param string $sql_param <p>
	 * An string identifying the statement variable to which the
	 * value should be bound.
	 * </p>
	 * @param mixed $value <p>
	 * The value to bind to a statement variable.
	 * </p>
	 * @param int $type [optional] <p>
	 * The data type of the value to bind.
	 * <p>
	 * SQLITE3_INTEGER: The value is a signed integer,
	 * stored in 1, 2, 3, 4, 6, or 8 bytes depending on the magnitude of
	 * the value.
	 * </p>
	 * @return bool <b>TRUE</b> if the value is bound to the statement variable, <b>FALSE</b>
	 * on failure.
	 * @since 5.3.0
	 */
	public function bindValue ($sql_param, $value, $type = null) {}

	public function readOnly () {}

	/**
	 * @param $sqlite3
	 */
	private function __construct ($sqlite3) {}

}

/**
*<div id="class.sqlite3result" class="reference">  <h1 class="title">The SQLite3Result class</h1>     <div class="partintro"><p class="verinfo">(PHP 5 &gt;= 5.3.0, PHP 7)</p>     <div class="section" id="sqlite3result.intro">    <h2 class="title">Introduction</h2>    <p class="para">     A class that handles result sets for the SQLite 3 extension.    </p>   </div>     <div class="section" id="sqlite3result.synopsis">    <h2 class="title">Class synopsis</h2>      <div class="classsynopsis">     <div class="ooclass"></div>       <div class="classsynopsisinfo">      <span class="ooclass">       <strong class="classname">SQLite3Result</strong>      </span>      {</div>           <div class="classsynopsisinfo classsynopsisinfo_comment">// Methods </div>     <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/sqlite3result.columnname.php" class="methodname" style="color:#CC7832">columnName</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$column_number</span></span>    ) : <span class="type" style="color:#EAB766">string</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/sqlite3result.columntype.php" class="methodname" style="color:#CC7832">columnType</a></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$column_number</span></span>    ) : <span class="type" style="color:#EAB766">int</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/sqlite3result.fetcharray.php" class="methodname" style="color:#CC7832">fetchArray</a></span>     ([ <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$mode</span><span class="initializer"> = SQLITE3_BOTH</span></span>   ] ) : <span class="type" style="color:#EAB766">array</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/sqlite3result.finalize.php" class="methodname" style="color:#CC7832">finalize</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/sqlite3result.numcolumns.php" class="methodname" style="color:#CC7832">numColumns</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">int</span></div> <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="modifier">public</span> <span class="methodname" style="color:#CC7832"><a href="https://www.php.net/manual/en/sqlite3result.reset.php" class="methodname" style="color:#CC7832">reset</a></span>     ( <span class="methodparam">void</span>    ) : <span class="type" style="color:#EAB766">bool</span></div>     }</div>     </div>   </div>                                               <h2>Table of Contents</h2><ul class="chunklist chunklist_reference"><li>{@link SQLite3Result::columnName} — Returns the name of the nth column</li><li>{@link SQLite3Result::columnType} — Returns the type of the nth column</li><li>{@link SQLite3Result::fetchArray} — Fetches a result row as an associative or numerically indexed array or both</li><li>{@link SQLite3Result::finalize} — Closes the result set</li><li>{@link SQLite3Result::numColumns} — Returns the number of columns in the result set</li><li>{@link SQLite3Result::reset} — Resets the result set back to the first row</li></ul> </div>
*/
class SQLite3Result  {

	/**
	 * Returns the number of columns in the result set
	 * @link http://php.net/manual/en/sqlite3result.numcolumns.php
	 * @return int the number of columns in the result set.
	 * @since 5.3.0
	 */
	public function numColumns () {}

	/**
	 * Returns the name of the nth column
	 * @link http://php.net/manual/en/sqlite3result.columnname.php
	 * @param int $column_number <p>
	 * The numeric zero-based index of the column.
	 * </p>
	 * @return string the string name of the column identified by
	 * <i>column_number</i>.
	 * @since 5.3.0
	 */
	public function columnName ($column_number) {}

	/**
	 * Returns the type of the nth column
	 * @link http://php.net/manual/en/sqlite3result.columntype.php
	 * @param int $column_number <p>
	 * The numeric zero-based index of the column.
	 * </p>
	 * @return int the data type index of the column identified by
	 * <i>column_number</i> (one of
	 * <b>SQLITE3_INTEGER</b>, <b>SQLITE3_FLOAT</b>,
	 * <b>SQLITE3_TEXT</b>, <b>SQLITE3_BLOB</b>, or
	 * <b>SQLITE3_NULL</b>).
	 * @since 5.3.0
	 */
	public function columnType ($column_number) {}

	/**
	 * Fetches a result row as an associative or numerically indexed array or both
	 * @link http://php.net/manual/en/sqlite3result.fetcharray.php
	 * @param int $mode [optional] <p>
	 * Controls how the next row will be returned to the caller. This value
	 * must be one of either SQLITE3_ASSOC,
	 * SQLITE3_NUM, or SQLITE3_BOTH.
	 * <p>
	 * SQLITE3_ASSOC: returns an array indexed by column
	 * name as returned in the corresponding result set
	 * </p>
	 * @return array a result row as an associatively or numerically indexed array or
	 * both. Alternately will return <b>FALSE</b> if there are no more rows.
	 * @since 5.3.0
	 */
	public function fetchArray ($mode = SQLITE3_BOTH) {}

	/**
	 * Resets the result set back to the first row
	 * @link http://php.net/manual/en/sqlite3result.reset.php
	 * @return bool <b>TRUE</b> if the result set is successfully reset
	 * back to the first row, <b>FALSE</b> on failure.
	 * @since 5.3.0
	 */
/**
*<div id="function.reset" class="refentry">  <div class="refnamediv">   <h1 class="refname">reset</h1>   <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">reset</span> &mdash; <span class="dc-title">Set the internal pointer of an array to its first element</span></p>   </div>  <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.reset-description">   <h3 class="title">Description</h3>   <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><strong>reset</strong></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">array</span> <span class="parameter" style="color:#2EACF9">&$array</span></span>    ) : <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.pseudo-types.php#language.types.mixed" class="type mixed" style="color:#EAB766">mixed</a></span></div>    <p class="para rdfs-comment">    <span class="function"><strong style="color:#CC7832">reset()</strong></span> rewinds <span class="parameter" style="color:#2EACF9">array</span>&#039;s internal    pointer to the first element and returns the value of the first array    element.   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.reset-parameters">   <h3 class="title">Parameters</h3>   <span>    <dl>            <dt> <span class="parameter" style="color:#2EACF9">array</span></dt>       <dd>        <p class="para">        The input array.       </p>      </dd>          </dl>    </span>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.reset-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    Returns the value of the first array element, or <strong><span>FALSE</span></strong> if the array is    empty.   </p>   <div class="warning"><strong class="warning">Warning</strong><p class="simpara">This function may return Boolean <strong><span>FALSE</span></strong>, but may also return a non-Boolean value which evaluates to <strong><span>FALSE</span></strong>. Please read the section on <a href="https://www.php.net/manual/en/language.types.boolean.php" class="link">Booleans</a> for more information. Use <a href="https://www.php.net/manual/en/language.operators.comparison.php" class="link">the === operator</a> for testing the return value of this function.</p></div>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.reset-examples">   <h3 class="title">Examples</h3>   <span>    <div class="example" id="example-6301">     <p><strong>Example #1 <span class="function"><strong style="color:#CC7832">reset()</strong></span> example</strong></p>     <div class="example-contents"> <div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"> <span style="color: #9876AA">&lt;?php<br /><br />$array&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #DD0000">'step&nbsp;one'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'step&nbsp;two'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'step&nbsp;three'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'step&nbsp;four'</span><span style="color: #007700">);<br /><br /></span><span style="color: #FF8000">//&nbsp;by&nbsp;default,&nbsp;the&nbsp;pointer&nbsp;is&nbsp;on&nbsp;the&nbsp;first&nbsp;element<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">)&nbsp;.&nbsp;</span><span style="color: #DD0000">"&lt;br&nbsp;/&gt;\n"</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;"step&nbsp;one"<br /><br />//&nbsp;skip&nbsp;two&nbsp;steps<br /></span><span style="color: #9876AA">next</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">);<br /></span><span style="color: #9876AA">next</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">);<br />echo&nbsp;</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">)&nbsp;.&nbsp;</span><span style="color: #DD0000">"&lt;br&nbsp;/&gt;\n"</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;"step&nbsp;three"<br /><br />//&nbsp;reset&nbsp;pointer,&nbsp;start&nbsp;again&nbsp;on&nbsp;step&nbsp;one<br /></span><span style="color: #9876AA">reset</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">);<br />echo&nbsp;</span><span style="color: #9876AA">current</span><span style="color: #007700">(</span><span style="color: #9876AA">$array</span><span style="color: #007700">)&nbsp;.&nbsp;</span><span style="color: #DD0000">"&lt;br&nbsp;/&gt;\n"</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;"step&nbsp;one"<br /><br /></span><span style="color: #9876AA">?&gt;</span> </span> </span></div>     </div>     </div>   </span>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 notes" id="refsect1-function.reset-notes">   <h3 class="title">Notes</h3>   <blockquote class="note" style="border:1px gray solid"><p><strong class="note" style="border:1px gray solid">Note</strong>:     <span class="simpara">     The return value for an empty array is indistinguishable from      the return value in case of an array which has a <span class="type" style="color:#EAB766"><a href="https://www.php.net/manual/en/language.types.boolean.php" class="type boolean" style="color:#EAB766">boolean</a></span> <strong><span>FALSE</span></strong>      first element. To properly check the value of the first element of an array     which may contain <strong><span>FALSE</span></strong> elements, first check the <span class="function">{@link count()}</span>     of the array, or check that <span class="function">{@link key()}</span> is not     <strong><span>NULL</span></strong>, after calling <span class="function"><strong style="color:#CC7832">reset()</strong></span>.    </span>   </p></blockquote>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.reset-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><span class="function">{@link current()} - Return the current element in an array</span></li>     <li class="member"><span class="function">{@link each()} - Return the current key and value pair from an array and advance the array cursor</span></li>     <li class="member"><span class="function">{@link end()} - Set the internal pointer of an array to its last element</span></li>     <li class="member"><span class="function">{@link next()} - Advance the internal pointer of an array</span></li>     <li class="member"><span class="function">{@link prev()} - Rewind the internal array pointer</span></li>     <li class="member"><span class="function">{@link array_key_first()} - Gets the first key of an array</span></li>    </ul>   </span>  </div>  </div>
*/
	public function reset () {}

	/**
	 * Closes the result set
	 * @link http://php.net/manual/en/sqlite3result.finalize.php
	 * @return bool <b>TRUE</b>.
	 * @since 5.3.0
	 */
	public function finalize () {}

	private function __construct () {}

}

/**
*       Specifies that the <span class="methodname">{@link Sqlite3Result::fetchArray()}</span>       method shall return an array indexed by column name as returned in the       corresponding result set.      
*/
define ('SQLITE3_ASSOC', 1);

/**
*       Specifies that the <span class="methodname">{@link Sqlite3Result::fetchArray()}</span>       method shall return an array indexed by column number as returned in the       corresponding result set, starting at column 0.      
*/
define ('SQLITE3_NUM', 2);

/**
*       Specifies that the <span class="methodname">{@link Sqlite3Result::fetchArray()}</span>       method shall return an array indexed by both column name and number as       returned in the corresponding result set, starting at column 0.      
*/
define ('SQLITE3_BOTH', 3);

/**
*       Represents the SQLite3 INTEGER storage class.      
*/
define ('SQLITE3_INTEGER', 1);

/**
*       Represents the SQLite3 REAL (FLOAT) storage class.      
*/
define ('SQLITE3_FLOAT', 2);

/**
*       Represents the SQLite3 TEXT storage class.      
*/
define ('SQLITE3_TEXT', 3);

/**
*       Represents the SQLite3 BLOB storage class.      
*/
define ('SQLITE3_BLOB', 4);

/**
*       Represents the SQLite3 NULL storage class.      
*/
define ('SQLITE3_NULL', 5);

/**
*       Specifies that the SQLite3 database be opened for reading only.      
*/
define ('SQLITE3_OPEN_READONLY', 1);

/**
*       Specifies that the SQLite3 database be opened for reading and writing.      
*/
define ('SQLITE3_OPEN_READWRITE', 2);

/**
*       Specifies that the SQLite3 database be created if it does not already       exist.      
*/
define ('SQLITE3_OPEN_CREATE', 4);

// End of sqlite3 v.0.7-dev
?>
