<?php

// Start of tokenizer v.0.1

/**
*<div id="function.token-get-all" class="refentry">  <div class="refnamediv">   <h1 class="refname">token_get_all</h1>   <p class="verinfo">(PHP 4 &gt;= 4.2.0, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">token_get_all</span> &mdash; <span class="dc-title">Split given source into PHP tokens</span></p>   </div>  <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.token-get-all-description">   <h3 class="title">Description</h3>   <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><strong>token_get_all</strong></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">string</span> <span class="parameter" style="color:#2EACF9">$source</span></span>    [, <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$flags</span><span class="initializer"> = 0</span></span>   ] ) : <span class="type" style="color:#EAB766">array</span></div>    <p class="para rdfs-comment">    <span class="function"><strong style="color:#CC7832">token_get_all()</strong></span> parses the given <span class="parameter" style="color:#2EACF9">source</span>     string into PHP language tokens using the Zend engine&#039;s lexical scanner.   </p>   <p class="para">    For a list of parser tokens, see <a href="https://www.php.net/manual/en/tokens.php" class="xref">List of Parser Tokens</a>, or use     <span class="function">{@link token_name()}</span> to translate a token value into its string    representation.   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.token-get-all-parameters">   <h3 class="title">Parameters</h3>   <span>    <dl>            <dt> <span class="parameter" style="color:#2EACF9">source</span></dt>       <dd>        <p class="para">        The PHP source to parse.       </p>      </dd>                 <dt> <span class="parameter" style="color:#2EACF9">flags</span></dt>       <dd>        <p class="para">        Valid flags:        <ul class="itemizedlist">         <li class="listitem">          <span class="simpara">           <strong><span>TOKEN_PARSE</span></strong> - Recognises the ability to use           reserved words in specific contexts.          </span>         </li>        </ul>       </p>      </dd>          </dl>    </span>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.token-get-all-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    An array of token identifiers. Each individual token identifier is either    a single character (i.e.: <em>;</em>, <em>.</em>,     <em>&gt;</em>, <em>!</em>, etc...),    or a three element array containing the token index in element 0, the string    content of the original token in element 1 and the line number in element 2.   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 changelog" id="refsect1-function.token-get-all-changelog">   <h3 class="title">Changelog</h3>   <span>    <table class="doctable informaltable">           <thead>       <tr>        <th>Version</th>        <th>Description</th>       </tr>       </thead>       <tbody class="tbody">       <tr>        <td>7.0.0</td>        <td>         Added the optional <span class="parameter" style="color:#2EACF9">flags</span> parameter along with         the <strong><span>TOKEN_PARSE</span></strong> flag.        </td>       </tr>        <tr>        <td>5.2.2</td>        <td>         Line numbers are returned in element 2        </td>       </tr>       </tbody>         </table>    </span>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.token-get-all-examples">   <h3 class="title">Examples</h3>   <span>    <div class="example" id="example-5049">     <p><strong>Example #1 <span class="function"><strong style="color:#CC7832">token_get_all()</strong></span> example</strong></p>     <div class="example-contents"> <div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"> <span style="color: #9876AA">&lt;?php<br />$tokens&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">token_get_all</span><span style="color: #007700">(</span><span style="color: #DD0000">'&lt;?php&nbsp;echo;&nbsp;?&gt;'</span><span style="color: #007700">);<br /><br />foreach&nbsp;(</span><span style="color: #9876AA">$tokens&nbsp;</span><span style="color: #007700">as&nbsp;</span><span style="color: #9876AA">$token</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(</span><span style="color: #9876AA">is_array</span><span style="color: #007700">(</span><span style="color: #9876AA">$token</span><span style="color: #007700">))&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"Line&nbsp;</span><span style="color: #007700">{</span><span style="color: #9876AA">$token</span><span style="color: #007700">[</span><span style="color: #9876AA">2</span><span style="color: #007700">]}</span><span style="color: #DD0000">:&nbsp;"</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">token_name</span><span style="color: #007700">(</span><span style="color: #9876AA">$token</span><span style="color: #007700">[</span><span style="color: #9876AA">0</span><span style="color: #007700">]),&nbsp;</span><span style="color: #DD0000">"&nbsp;('</span><span style="color: #007700">{</span><span style="color: #9876AA">$token</span><span style="color: #007700">[</span><span style="color: #9876AA">1</span><span style="color: #007700">]}</span><span style="color: #DD0000">')"</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">PHP_EOL</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /></span><span style="color: #9876AA">?&gt;</span> </span> </span></div>     </div>      <div class="example-contents"><p>The above example will output something similar to:</p></div>     <div class="example-contents screen" style="background:black;padding-left:5px;"> <div class="cdata"><span> Line 1: T_OPEN_TAG (&#039;&lt;?php &#039;) Line 1: T_ECHO (&#039;echo&#039;) Line 1: T_WHITESPACE (&#039; &#039;) Line 1: T_CLOSE_TAG (&#039;?&gt;&#039;) </span></div>     </div>    </div>   </span>   <p class="para">    <div class="example" id="example-5050">     <p><strong>Example #2 <span class="function"><strong style="color:#CC7832">token_get_all()</strong></span> incorrect usage example</strong></p>     <div class="example-contents"> <div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"> <span style="color: #9876AA">&lt;?php<br />$tokens&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">token_get_all</span><span style="color: #007700">(</span><span style="color: #DD0000">'//&nbsp;comment&nbsp;'</span><span style="color: #007700">);<br /><br />foreach&nbsp;(</span><span style="color: #9876AA">$tokens&nbsp;</span><span style="color: #007700">as&nbsp;</span><span style="color: #9876AA">$token</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(</span><span style="color: #9876AA">is_array</span><span style="color: #007700">(</span><span style="color: #9876AA">$token</span><span style="color: #007700">))&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"Line&nbsp;</span><span style="color: #007700">{</span><span style="color: #9876AA">$token</span><span style="color: #007700">[</span><span style="color: #9876AA">2</span><span style="color: #007700">]}</span><span style="color: #DD0000">:&nbsp;"</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">token_name</span><span style="color: #007700">(</span><span style="color: #9876AA">$token</span><span style="color: #007700">[</span><span style="color: #9876AA">0</span><span style="color: #007700">]),&nbsp;</span><span style="color: #DD0000">"&nbsp;('</span><span style="color: #007700">{</span><span style="color: #9876AA">$token</span><span style="color: #007700">[</span><span style="color: #9876AA">1</span><span style="color: #007700">]}</span><span style="color: #DD0000">')"</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">PHP_EOL</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /></span><span style="color: #9876AA">?&gt;</span> </span> </span></div>     </div>      <div class="example-contents"><p>The above example will output something similar to:</p></div>     <div class="example-contents screen" style="background:black;padding-left:5px;"> <div class="cdata"><span> Line 1: T_INLINE_HTML (&#039;// comment &#039;) </span></div>     </div>    </div>    Note in the previous example that the string is parsed as    <strong><span>T_INLINE_HTML</span></strong> rather than the expected    <strong><span>T_COMMENT</span></strong>. This is because no open tag was used in the    code provided. This would be equivalent to putting a comment outside of the    PHP tags in a normal file.   </p>   <p class="para">    <div class="example" id="example-5051">     <p><strong>Example #3       <span class="function"><strong style="color:#CC7832">token_get_all()</strong></span> on a class using a reserved word example     </strong></p>     <div class="example-contents"> <div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"> <span style="color: #9876AA">&lt;?php<br /><br />$source&nbsp;</span><span style="color: #007700">=&nbsp;&lt;&lt;&lt;'code'<br /></span><span style="color: #DD0000">&lt;?php<br /><br />class&nbsp;A<br />{<br />&nbsp;&nbsp;&nbsp;&nbsp;const&nbsp;PUBLIC&nbsp;=&nbsp;1;<br />}<br /></span><span style="color: #007700">code;<br /><br /></span><span style="color: #9876AA">$tokens&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #9876AA">token_get_all</span><span style="color: #007700">(</span><span style="color: #9876AA">$source</span><span style="color: #007700">,&nbsp;</span><span style="color: #9876AA">TOKEN_PARSE</span><span style="color: #007700">);<br /><br />foreach&nbsp;(</span><span style="color: #9876AA">$tokens&nbsp;</span><span style="color: #007700">as&nbsp;</span><span style="color: #9876AA">$token</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(</span><span style="color: #9876AA">is_array</span><span style="color: #007700">(</span><span style="color: #9876AA">$token</span><span style="color: #007700">))&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #9876AA">token_name</span><span style="color: #007700">(</span><span style="color: #9876AA">$token</span><span style="color: #007700">[</span><span style="color: #9876AA">0</span><span style="color: #007700">])&nbsp;,&nbsp;</span><span style="color: #9876AA">PHP_EOL</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /></span><span style="color: #9876AA">?&gt;</span> </span> </span></div>     </div>      <div class="example-contents"><p>The above example will output something similar to:</p></div>     <div class="example-contents screen" style="background:black;padding-left:5px;"> <div class="cdata"><span> T_OPEN_TAG T_WHITESPACE T_CLASS T_WHITESPACE T_STRING T_CONST T_WHITESPACE T_STRING T_LNUMBER </span></div>     </div>    </div>    Without the <strong><span>TOKEN_PARSE</span></strong> flag, the penultimate    token (<strong><span>T_STRING</span></strong>) would have been    <strong><span>T_PUBLIC</span></strong>.   </p>  </div>    <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.token-get-all-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><span class="function">{@link token_name()} - Get the symbolic name of a given PHP token</span></li>    </ul>   </span>  </div>  </div>
 * @return array An array of token identifiers. Each individual token identifier is either*/
function token_get_all ($source, $flags = 0) {}

/**
*<div id="function.token-name" class="refentry">  <div class="refnamediv">   <h1 class="refname">token_name</h1>   <p class="verinfo">(PHP 4 &gt;= 4.2.0, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">token_name</span> &mdash; <span class="dc-title">Get the symbolic name of a given PHP token</span></p>   </div>  <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 description" id="refsect1-function.token-name-description">   <h3 class="title">Description</h3>   <div class="methodsynopsis dc-description" style="border:1px gray;padding-left:5px;background:#232525">    <span class="methodname" style="color:#CC7832"><strong>token_name</strong></span>     ( <span class="methodparam"><span class="type" style="color:#EAB766">int</span> <span class="parameter" style="color:#2EACF9">$token</span></span>    ) : <span class="type" style="color:#EAB766">string</span></div>    <p class="para rdfs-comment">    <span class="function"><strong style="color:#CC7832">token_name()</strong></span> gets the symbolic name for a PHP     <span class="parameter" style="color:#2EACF9">token</span> value.    </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 parameters" id="refsect1-function.token-name-parameters">   <h3 class="title">Parameters</h3>   <span>    <dl>            <dt> <span class="parameter" style="color:#2EACF9">token</span></dt>       <dd>        <p class="para">        The token value.       </p>      </dd>          </dl>    </span>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 returnvalues" id="refsect1-function.token-name-returnvalues">   <h3 class="title">Return Values</h3>   <p class="para">    The symbolic name of the given <span class="parameter" style="color:#2EACF9">token</span>.   </p>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 examples" id="refsect1-function.token-name-examples">   <h3 class="title">Examples</h3>   <span>    <div class="example" id="example-5052">     <p><strong>Example #1 <span class="function"><strong style="color:#CC7832">token_name()</strong></span> example</strong></p>     <div class="example-contents"> <div class="phpcode" style="border-color:gray;background:#232525"><span><span style="color: #000000"> <span style="color: #9876AA">&lt;?php<br /></span><span style="color: #FF8000">//&nbsp;260&nbsp;is&nbsp;the&nbsp;token&nbsp;value&nbsp;for&nbsp;the&nbsp;T_EVAL&nbsp;token<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #9876AA">token_name</span><span style="color: #007700">(</span><span style="color: #9876AA">260</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;-&gt;&nbsp;"T_EVAL"<br /><br />//&nbsp;a&nbsp;token&nbsp;constant&nbsp;maps&nbsp;to&nbsp;its&nbsp;own&nbsp;name<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #9876AA">token_name</span><span style="color: #007700">(</span><span style="color: #9876AA">T_FUNCTION</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;-&gt;&nbsp;"T_FUNCTION"<br /></span><span style="color: #9876AA">?&gt;</span> </span> </span></div>     </div>     </div>   </span>  </div>   <br></br><div style="BORDER-TOP: gray 1px dashed; OVERFLOW: hidden; HEIGHT: 1px"></div><div class="refsect1 seealso" id="refsect1-function.token-name-seealso">   <h3 class="title">See Also</h3>   <span>    <ul class="simplelist">     <li class="member"><a href="https://www.php.net/manual/en/tokens.php" class="link">List of Parser Tokens</a></li>    </ul>   </span>  </div>  </div>
 * @return string The symbolic name of the given <i>token</i>.*/
function token_name ($token) {}

define('TOKEN_PARSE', 1);
define('T_REQUIRE_ONCE', 262);
define('T_REQUIRE', 261);
define('T_EVAL', 260);
define('T_INCLUDE_ONCE', 259);
define('T_INCLUDE', 258);
define('T_LOGICAL_OR', 263);
define('T_LOGICAL_XOR', 264);
define('T_LOGICAL_AND', 265);
define('T_PRINT', 266);
define('T_YIELD', 267);
define('T_DOUBLE_ARROW', 268);
define('T_YIELD_FROM', 269);
define('T_POW_EQUAL', 281);
define('T_SR_EQUAL', 280);
define('T_SL_EQUAL', 279);
define('T_XOR_EQUAL', 278);
define('T_OR_EQUAL', 277);
define('T_AND_EQUAL', 276);
define('T_MOD_EQUAL', 275);
define('T_CONCAT_EQUAL', 274);
define('T_DIV_EQUAL', 273);
define('T_MUL_EQUAL', 272);
define('T_MINUS_EQUAL', 271);
define('T_PLUS_EQUAL', 270);
define('T_COALESCE', 282);
define('T_BOOLEAN_OR', 283);
define('T_BOOLEAN_AND', 284);
define('T_SPACESHIP', 289);
define('T_IS_NOT_IDENTICAL', 288);
define('T_IS_IDENTICAL', 287);
define('T_IS_NOT_EQUAL', 286);
define('T_IS_EQUAL', 285);
define('T_IS_GREATER_OR_EQUAL', 291);
define('T_IS_SMALLER_OR_EQUAL', 290);
define('T_SR', 293);
define('T_SL', 292);
define('T_INSTANCEOF', 294);
define('T_UNSET_CAST', 303);
define('T_BOOL_CAST', 302);
define('T_OBJECT_CAST', 301);
define('T_ARRAY_CAST', 300);
define('T_STRING_CAST', 299);
define('T_DOUBLE_CAST', 298);
define('T_INT_CAST', 297);
define('T_DEC', 296);
define('T_INC', 295);
define('T_POW', 304);
define('T_CLONE', 306);
define('T_NEW', 305);
define('T_ELSEIF', 308);
define('T_ELSE', 309);
define('T_ENDIF', 310);
define('T_PUBLIC', 316);
define('T_PROTECTED', 315);
define('T_PRIVATE', 314);
define('T_FINAL', 313);
define('T_ABSTRACT', 312);
define('T_STATIC', 311);
define('T_LNUMBER', 317);
define('T_DNUMBER', 318);
define('T_STRING', 319);
define('T_VARIABLE', 320);
define('T_INLINE_HTML', 321);
define('T_ENCAPSED_AND_WHITESPACE', 322);
define('T_CONSTANT_ENCAPSED_STRING', 323);
define('T_STRING_VARNAME', 324);
define('T_NUM_STRING', 325);
define('T_EXIT', 326);
define('T_IF', 327);
define('T_ECHO', 328);
define('T_DO', 329);
define('T_WHILE', 330);
define('T_ENDWHILE', 331);
define('T_FOR', 332);
define('T_ENDFOR', 333);
define('T_FOREACH', 334);
define('T_ENDFOREACH', 335);
define('T_DECLARE', 336);
define('T_ENDDECLARE', 337);
define('T_AS', 338);
define('T_SWITCH', 339);
define('T_ENDSWITCH', 340);
define('T_CASE', 341);
define('T_DEFAULT', 342);
define('T_BREAK', 343);
define('T_CONTINUE', 344);
define('T_GOTO', 345);
define('T_FUNCTION', 346);
define('T_CONST', 347);
define('T_RETURN', 348);
define('T_TRY', 349);
define('T_CATCH', 350);
define('T_FINALLY', 351);
define('T_THROW', 352);
define('T_USE', 353);
define('T_INSTEADOF', 354);
define('T_GLOBAL', 355);
define('T_VAR', 356);
define('T_UNSET', 357);
define('T_ISSET', 358);
define('T_EMPTY', 359);
define('T_HALT_COMPILER', 360);
define('T_CLASS', 361);
define('T_TRAIT', 362);
define('T_INTERFACE', 363);
define('T_EXTENDS', 364);
define('T_IMPLEMENTS', 365);
define('T_OBJECT_OPERATOR', 366);
define('T_LIST', 367);
define('T_ARRAY', 368);
define('T_CALLABLE', 369);
define('T_LINE', 370);
define('T_FILE', 371);
define('T_DIR', 372);
define('T_CLASS_C', 373);
define('T_TRAIT_C', 374);
define('T_METHOD_C', 375);
define('T_FUNC_C', 376);
define('T_COMMENT', 377);
define('T_DOC_COMMENT', 378);
define('T_OPEN_TAG', 379);
define('T_OPEN_TAG_WITH_ECHO', 380);
define('T_CLOSE_TAG', 381);
define('T_WHITESPACE', 382);
define('T_START_HEREDOC', 383);
define('T_END_HEREDOC', 384);
define('T_DOLLAR_OPEN_CURLY_BRACES', 385);
define('T_CURLY_OPEN', 386);
define('T_PAAMAYIM_NEKUDOTAYIM', 387);
define('T_NAMESPACE', 388);
define('T_NS_C', 389);
define('T_NS_SEPARATOR', 390);
define('T_ELLIPSIS', 391);
define('T_DOUBLE_COLON', 387);

// End of tokenizer v.0.1
