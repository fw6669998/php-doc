<?php


namespace Parle;


use Exception;
use Throwable;

class LexerException extends Exception implements Throwable
{

}